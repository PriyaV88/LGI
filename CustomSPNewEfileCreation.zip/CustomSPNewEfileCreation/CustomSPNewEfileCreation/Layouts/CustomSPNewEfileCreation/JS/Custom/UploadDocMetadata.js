﻿/// <reference path="../library/jquery-1.12.4.intellisense.js" />
/// <reference path="../library/jquery-1.12.4.js" />
/*
(function ($) {
    $(document).ready(function () {
        var dialog = $("#dialog-form").dialog({
            autoOpen: false,
            height: 400,
            width: 350,
            modal: true,
            buttons: {
                Upload: function () {
                    alert("Uploaded successfully")
                },
                Cancel: function () {
                    dialog.dialog("close");
                }
            }
        });

        $("#BtnUploadDocs").on("click", function (event) {
            event.preventDefault();
            dialog.dialog("open");
        });
    });
})(jQuery);

*/
var dialog = $("#dialog-form").dialog({
    autoOpen: false,
    height: 200,
    width: 350,
    modal: true,
    buttons: {
        Upload: function () {
            var docGroup = $("select[id$='ddlDocGroup']").val();
            var doctype = $("select[id$='ddlDoctype']").val();

            //$("input[id$='txtDoctitleV2']").val(docTitle);
            $("input[id$='ddlDocGroupV2']").val(docGroup);
            $("input[id$='ddlDoctypeV2']").val(doctype);
            $("[id$='BtnUploadDocsV2']").click();
        },
        Cancel: function () {
            dialog.dialog("close");
        }
    }
});
$(document).ready(function () {
    console.log($("#BtnUploadDocs").length);
    $("#BtnUploadDocs").on("click", function (event) {
        event.preventDefault();
        dialog.dialog("open");
    });
    //$("#BtnUploadFiles").on("click", function (event) {
    //  //  $("[id$='BtnUploadDocsV2']").click();
    //    //var docTitle = $("input[id$='txtDoctitle']").val();
    //    var docGroup = $("select[id$='ddlDocGroup']").val();
    //    var doctype = $("select[id$='ddlDoctype']").val();

    //    $("input[id$='txtDoctitleV2']").val(docTitle);
    //    $("input[id$='ddlDocGroupV2']").val(docGroup);
    //    $("input[id$='ddlDoctypeV2']").val(doctype);
    //    $("[id$='BtnUploadDocsV2']").click();
    //});

});
