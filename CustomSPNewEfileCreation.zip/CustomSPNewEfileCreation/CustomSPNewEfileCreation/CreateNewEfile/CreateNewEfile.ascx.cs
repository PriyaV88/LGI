﻿using System;
using System.Windows.Forms;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using DWHDAL;
using System.Data;
using System.IO;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Collections;
using System.Linq;
using Microsoft.SharePoint.Linq;
namespace CustomSPNewEfileCreation.CreateNewEfile
{
    [ToolboxItemAttribute(false)]
    public partial class CreateNewEfile : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]

        string currentEfileUrl = string.Empty;
        EFileMapper eFilePath = new EFileMapper();
        EFileMapper allefiles = new EFileMapper();

        DWHDAL.DWHDAL newDAL = new DWHDAL.DWHDAL();
        // string caseid;
        string CaseId = string.Empty;
        public CreateNewEfile()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            DcnPanel.Visible = true;
            DCNDataPanel.Visible = false;
            // Label32.Visible = false;
            DocUploadPanel.Visible = true;
            LabelEfilecreationPanel.Visible = false;
            if (!Page.IsPostBack)
            {
                using (SPSite site = new SPSite(SPContext.Current.Web.Url))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList list = web.Lists["eFileConfigList"];
                        SPQuery myquery = new SPQuery();
                        myquery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>DocumentGroups</Value></Eq></Where>";
                        SPListItemCollection myitem = list.GetItems(myquery);
                        string[] itemname = myitem[0]["Value"].ToString().Split(',');
                        SPQuery newquery = new SPQuery();
                        newquery.Query = "<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>DocumentTypes</Value></Eq></Where>";
                        SPListItemCollection newitem = list.GetItems(newquery);
                        string[] newitemname = newitem[0]["Value"].ToString().Split(',');

                        foreach (var item in itemname)
                        {
                            ddlDocGroup.Items.Add(item);
                            // DropDownList1.DataSource = item;
                        }
                        ddlDocGroup.DataBind();
                        foreach (var nitem in newitemname)
                        {
                            ddlDoctype.Items.Add(nitem);
                            // DropDownList1.DataSource = item;
                        }
                        ddlDoctype.DataBind();
                    }
                }
            }
        }

        protected void SearchBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // PolTxtBox
                //ViewState[caseid] = CaseTxt.Text;
                //ViewState["caseid"] = CaseId;
                CaseId = CaseTxt.Text;
                if (CaseId != string.Empty)
                {

                    // eFilePath = newDAL.GetDcnMetaData(CaseId);
                    eFilePath = newDAL.GetDcnMetaDatafromOracleDb(CaseId);

                    if (eFilePath == null)
                    {
                        DCNDataPanel.Visible = true;
                        Label54.Text = "DCN not found...";
                        DCNDataPanel.Visible = true;
                        CaseId = string.Empty;
                    }
                    else
                    {
                        ViewState["eFilePath"] = eFilePath;
                        EfilePanel.Visible = true;
                        DocUploadPanel.Visible = false;
                        DCNDataPanel.Visible = false;
                        DcnPanel.Visible = false;
                        CreateEfilePanel.Visible = true;
                        Label33.Text = eFilePath.LOB.ToString();
                        Label34.Text = eFilePath.Product.ToString();
                        Label35.Text = eFilePath.Country.ToString();
                        Label36.Text = eFilePath.InsuredName.ToString();
                        Label37.Text = eFilePath.PolicyYear.ToString();
                        Label38.Text = eFilePath.PolicyInceptionDate.ToString();
                        Label39.Text = eFilePath.PolicyExpiryDate.ToString();
                        Label40.Text = eFilePath.Company.ToString();
                        Label41.Text = eFilePath.BranchName.ToString();
                        Label42.Text = eFilePath.BranchCode.ToString();
                        Label43.Text = eFilePath.SourceSystemName.ToString();
                        Label44.Text = eFilePath.CaseId.ToString();
                        Label45.Text = eFilePath.MasterStatus.ToString();
                        Label46.Text = eFilePath.Function.ToString();
                        Label47.Text = eFilePath.IsConfidential.ToString();
                        Label48.Text = eFilePath.eFileCategory.ToString();
                        Label49.Text = eFilePath.InsuredCode.ToString();
                        Label50.Text = eFilePath.IntermediaryName.ToString();
                        Label51.Text = eFilePath.IntermediaryCode.ToString();
                        Label52.Text = eFilePath.SMName.ToString();
                        Label53.Text = eFilePath.SMCode.ToString();

                    }
                }
                else
                {
                    this.Page.Response.Redirect(this.Page.Request.RawUrl);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnCreateEfile_Click(object sender, EventArgs e)
        {
            DcnPanel.Visible = false;
            if (ViewState["eFilePath"] != null)
            {
                eFilePath = (EFileMapper)ViewState["eFilePath"];
            }

            // method to create new efile
            string message = SharePointEFileUploader.CreateNewEFile(eFilePath);
            EfilePanel.Visible = true;
            CreateEfilePanel.Visible = false;
            LabelEfilecreationPanel.Visible = true;

            if (message == EfileSuccessMessage.Text)
            {
                EfileSuccessMessage.Visible = true;
            }
            else
            {
                EfileErrorMessage.Visible = true;
            }
            DocUploadPanel.Visible = true;
            DCNDataPanel.Visible = false;



        }

        protected void BtnSearchAnotherDcn_Click(object sender, EventArgs e)
        {
            this.Page.Response.Redirect(this.Page.Request.RawUrl);
        }

        protected void BtnUploadDocs_Click(object sender, EventArgs e)
        {
            DcnPanel.Visible = false;
            EfilePanel.Visible = true;
            LabelEfilecreationPanel.Visible = true;
            DocUploadPanel.Visible = true;
            DCNDataPanel.Visible = false;

        }

        protected void Button2_Click(object sender, EventArgs e)
        {

            if (FileUpload1.HasFiles)
            {
                EFileMapper eFiles = new EFileMapper();
                try
                {
                    if (ViewState["eFilePath"] != null)
                    {
                        eFilePath = (EFileMapper)ViewState["eFilePath"];
                    }

                    // method to get sharepoint efile url
                    eFiles = newDAL.GetDCNSharepointFileURL(eFilePath.CaseId, eFilePath);
                    var postedFiles = FileUpload1.PostedFiles;
                    foreach (var file in postedFiles)
                    {
                        SPSecurity.RunWithElevatedPrivileges(delegate()
                       {
                           string efileUrl = eFiles.efile_Url;
                           string filename = file.FileName.Split('.').ToList().FirstOrDefault();

                           string siteColUrl = eFiles.site_collection_url;
                           SPSite site = new SPSite(eFiles.site_collection_url);
                           SPWeb web = site.OpenWeb();
                           site.AllowUnsafeUpdates = true;
                           web.AllowUnsafeUpdates = true;
                           SPFolder ds = web.GetFolder(eFiles.efile_Url);
                           Boolean replaceExistingFiles = true;
                           SPFile spfile = ds.Files.Add(file.FileName, file.InputStream, replaceExistingFiles);
                           var item = spfile.ListItemAllFields;
                           item["EFDocumentTitle"] = filename;
                           item["EFeFileDocumentGroup"] = ddlDocGroupV2.Text;
                           item["EFeFileDocumentType"] = ddlDoctypeV2.Text;
                           item.Update();
                           ds.Update();
                           site.AllowUnsafeUpdates = false;
                           web.AllowUnsafeUpdates = false;
                           UploadMessage.Text = "Files Uploaded successfully...";
                       });
                    }

                }
                catch (Exception ex)
                {

                }
            }
        }



    }
}
