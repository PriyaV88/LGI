﻿using DWHDAL;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Configuration;


namespace CustomSPNewEfileCreation
{
    public static class SharePointEFileUploader
    {
       

        public static string CreateNewEFile(EFileMapper currentEfile)
        {

            HttpWebRequest req = null;
            HttpWebResponse res = null;
            string message = string.Empty;
            string EfileSuccessMessage = string.Empty;
            string EfileErrorMessage = string.Empty;

            try
            {
                //string url = t
                string url = ConfigurationManager.AppSettings["ServiceUrl"];
              //  SchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "url=" + url);
                req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/xml; charset=utf-8";
                req.Timeout = 300000;
                req.PreAuthenticate = true;
                req.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["ServiceUser"], ConfigurationManager.AppSettings["ServicePwd"], "lvgi");

                DateTime PolicyInceptionDate;
                DateTime PolicyExpiryDate;

                PolicyInceptionDate = Convert.ToDateTime(currentEfile.PolicyInceptionDate);
               // SchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "PolicyInceptionDate= " + PolicyInceptionDate);
                PolicyExpiryDate = Convert.ToDateTime(currentEfile.PolicyExpiryDate);
              //  SchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "PolicyExpiryDate= " + PolicyExpiryDate);
                string[] formats = { "MM/dd/yyyy" };
                if ((currentEfile.LOB == "Marine") || (currentEfile.LOB == "Marine Cargo"))
                {
                    currentEfile.LOB = "Marine_Cargo";
                }
                //if (currentEfile.LOB == "Miscellaneous")
                //{
                //    currentEfile.LOB = "Misc";
                //}
                if ((currentEfile.LOB == "Miscellaneous - Package") || (currentEfile.LOB == "Miscellaneous"))
                {
                    currentEfile.LOB = "Misc";
                }
                if (currentEfile.LOB == "Engineering")
                {
                    currentEfile.LOB = "ENGG";
                }
                if (currentEfile.LOB == "Personal Accident")
                {
                    currentEfile.LOB = "Personal_Accident";
                }
                if (currentEfile.Company.Trim() == string.Empty)
                {
                    currentEfile.Company = "LVGI";
                }
                if (currentEfile.Function.Trim() == string.Empty)
                {
                    currentEfile.Function = "uploadDocumentECM";
                }
                if (currentEfile.eFileCategory.Trim() == string.Empty)
                {
                    currentEfile.eFileCategory = "Policy";
                }
                if (currentEfile.RiskLocation.Trim() == string.Empty)
                {
                    currentEfile.RiskLocation = "India";
                }
                if (currentEfile.MasterStatus.Trim() == string.Empty)
                {
                    currentEfile.MasterStatus = "Intimated";
                }
                if (currentEfile.IntermediaryName.Length >= 35)
                {
                    currentEfile.IntermediaryName = currentEfile.IntermediaryName.Remove(34);
                }

                if (currentEfile.RiskLocation.Length >= 26)
                {
                    currentEfile.RiskLocation = currentEfile.RiskLocation.Remove(25);
                }


                string sXml = @"<RequestData >
                  <EntityInformation Type='Underwriting'>
                  <MetadataProperties>
		          <MetadataProperty Name='LOB' Value='" + currentEfile.LOB + "' />" +
                  "<MetadataProperty Name='Product' Value='" + currentEfile.Product.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='PolicyNumber' Value='" + currentEfile.PolicyNumber + "' />" +
                  "<MetadataProperty Name='Country' Value='" + currentEfile.Country + "' />" +
                  "<MetadataProperty Name='InsuredName' Value='" + currentEfile.InsuredName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='PolicyYear' Value='" + currentEfile.PolicyYear + "' />" +
                  "<MetadataProperty Name='UWStage' Value='" + currentEfile.UWStage + "' />" +
                    // "<MetadataProperty Name='PolicyInceptionDate' Value='01/29/2013' /> " +
                    //" <MetadataProperty Name='PolicyExpiryDate' Value= '08/31/2016' />" +
                  "<MetadataProperty Name='PolicyInceptionDate' Value='" + PolicyInceptionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) + "' /> " +// MM/dd/yyyy 11/29/2015
                  "<MetadataProperty Name='PolicyExpiryDate' Value='" + PolicyExpiryDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) + "' />" +
                  "<MetadataProperty Name='Company' Value='" + currentEfile.Company + "' />" +
                  "<MetadataProperty Name='BranchName' Value='" + currentEfile.BranchName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='BranchCode' Value='" + currentEfile.BranchCode + "' />" +
                  "<MetadataProperty Name='QuoteNumber' Value='" + currentEfile.QuoteNumber.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null) + "' />" +
                  "<MetadataProperty Name='BatchNumber' Value='" + currentEfile.BatchNumber.Replace("&", "and") + "' />" +
                  "<MetadataProperty Name='Zone' Value='" + currentEfile.Zone + "' />" +
                  "<MetadataProperty Name='SourceSystemName' Value='" + currentEfile.SourceSystemName + "' />" +
                  "<MetadataProperty Name='CaseId' Value='" + currentEfile.CaseId + "' />" +
                  "<MetadataProperty Name='PreviousPolicyNumber' Value='" + currentEfile.PreviousPolicyNumber + "' />" +
                  "<MetadataProperty Name='Underwriter' Value='" + currentEfile.Underwriter + "' />" +
                  "<MetadataProperty Name='UnderwritingAssistant' Value='" + currentEfile.UnderwritingAssistant + "' />" +
                  "<MetadataProperty Name='MasterStatus' Value='" + currentEfile.MasterStatus + "' />" +
                  "<MetadataProperty Name='Function' Value='" + currentEfile.Function.Replace("&", "and") + "' />" +
                  "<MetadataProperty Name='RiskLocation' Value='" + currentEfile.RiskLocation.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='IsConfidential' Value='" + currentEfile.IsConfidential + "' />" +
                  "<MetadataProperty Name='eFileCategory' Value='" + currentEfile.eFileCategory + "' />" +
                  "<MetadataProperty Name='InsuredCode' Value='" + currentEfile.InsuredCode + "' />" +
                  "<MetadataProperty Name='IntermediaryName' Value='" + currentEfile.IntermediaryName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='IntermediaryCode' Value='" + currentEfile.IntermediaryCode + "' />" +
                  "<MetadataProperty Name='SMName' Value='" + currentEfile.SMName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='SMCode' Value='" + currentEfile.SMCode + "' />" +
                  "</MetadataProperties >" +
                  "</EntityInformation>" +
                  "</RequestData>";

                req.ContentLength = sXml.Length;
               // SchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Efile request data: " + sXml);
                var sw = new StreamWriter(req.GetRequestStream());
                sw.Write(sXml);
                sw.Close();

                res = (HttpWebResponse)req.GetResponse();
                Stream responseStream = res.GetResponseStream();
                var streamReader = new StreamReader(responseStream);

                //Read the response into an xml document
                var soapResonseXmlDocument = new XmlDocument();
                soapResonseXmlDocument.LoadXml(streamReader.ReadToEnd());

                //return only the xml representing the response details (inner request)
                string successString = soapResonseXmlDocument.InnerXml;

                string successState = soapResonseXmlDocument.GetElementsByTagName("Status").Item(0).InnerXml;

                if (successState.Equals("FAILED"))
                    return message =  EfileErrorMessage = "Error occurred in efile creation...";
                else
                    return message = EfileSuccessMessage = "Efile got created successfully...";
                //label32 = successString.ToString();
                
               // Console.WriteLine("efile created successfully");
                
               // Console.ReadLine();
               // message = successString;

              //  SchedulerMovePolicyDataLogError.LogFileWrite("Log : Info : Successstring" + successString);
            }
            catch (Exception ex)
            {
               // SchedulerMovePolicyDataLogError.LogFileWrite("Error while creating efile:" + ex.Message);
                message = EfileErrorMessage = "Error occurred in efile creation...";; 
            }

            return message;
            //string error = "Error in creating new efile";
            //SchedulerEfileCountLogError.LogFailureErrorToDB(currentEfile.policy_no, currentEfile.PolicyFTPPath, configurationHandler, error);
        }
    }
}
