﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DWHDAL
{
    [Serializable]
   public class EFileMapper
    {
        public string DatabaseColumn
        {
            get;
            set;
        }

        public string LOB
        {
            get;
            set;
        }
        public string Product
        {
            get;
            set;
        }
        public string PolicyNumber
        {
            get;
            set;
        }
        public string ShareDrivePath
        {
            get;
            set;
        }
        public string Country
        {
            get;
            set;
        }

        public string InsuredName
        {
            get;
            set;
        }

        public string PolicyYear
        {
            get;
            set;
        }

        public string PolicyInceptionDate
        {
            get;
            set;
        }

        public string PolicyExpiryDate
        {
            get;
            set;
        }

        public string UWStage
        {
            get;
            set;
        }

        public string Company
        {
            get;
            set;
        }

        public string BranchName
        {
            get;
            set;
        }


        public string BranchCode
        {
            get;
            set;
        }

        public string QuoteNumber
        {
            get;
            set;
        }

        public string BatchNumber
        {
            get;
            set;
        }

        public string Zone
        {
            get;
            set;
        }

        public string SourceSystemName
        {
            get;
            set;
        }
        public string CaseId
        {
            get;
            set;
        }
        public string PreviousPolicyNumber
        {
            get;
            set;
        }
        public string Underwriter
        {
            get;
            set;
        }
        public string UnderwritingAssistant
        {
            get;
            set;
        }
        public string MasterStatus
        {
            get;
            set;
        }
        public string Function
        {
            get;
            set;
        }
        public string RiskLocation
        {
            get;
            set;
        }
        public string IsConfidential
        {
            get;
            set;
        }
        public string eFileCategory
        {
            get;
            set;
        }

        public string InsuredCode
        {
            get;
            set;
        }

        public string IntermediaryName
        {
            get;
            set;
        }

        public string IntermediaryCode
        {
            get;
            set;
        }
        public string SMName
        {
            get;
            set;
        }

        public string SMCode
        {
            get;
            set;
        }

        public string site_collection_url
        {
            get;
            set;
        }
        public string doc_lib_name
        {
            get;
            set;
        }
        public string efile_name
        {
            get;
            set;
        }
        public string PolicyNo
        {
            get;
            set;
        }
        public string policy_no
        {
            get;
            set;
        }
        public string case_id
        {
            get;
            set;
        }
        public string EndtNo
        {
            get;
            set;
        }

        public string efile_Url
        {
            get;
            set;
        }

        public string PolicyFTPPath
        {
            get;
            set;
        }
        public string JobStartDate
        {
            get;
            set;
        }
        public string JobEndDate
        {
            get;
            set;
        }
        private string policyfilename;
        private string policyfilepath;

        public string PolicyFileName
        {
            get
            {
                return policyfilename;
            }
            set
            {
                policyfilename = value;
            }
        }

        public string PolicyFilePath
        {
            get
            {
                return policyfilepath;
            }
            set
            {
                policyfilepath = value;
            }
        }

        //for oracle database
        public string DCNNo
        {
            get;
            set;
        }
    }
}
