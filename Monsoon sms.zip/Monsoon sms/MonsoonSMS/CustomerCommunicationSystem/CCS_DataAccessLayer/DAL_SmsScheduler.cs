﻿using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using CCS_EntityLayer;

namespace CCS_DataAccessLayer
{
    public class DAL_SmsScheduler
    {
        string strconnstring = System.Configuration.ConfigurationManager.AppSettings["ConnectionString"].ToString();
        public DataSet GetPolicyDetails()
        {
            Database objDB = new SqlDatabase(strconnstring);
            using (DbCommand objCMD = objDB.GetStoredProcCommand("usp_GetPolicyDetails"))
            {
                //objDB.AddInParameter(objCMD, "@ProposalNo",
                //                   DbType.String, objEntity.ProposalNo);
                try
                {             
                    DataSet ds = objDB.ExecuteDataSet(objCMD);
                    return ds; 
                }
                catch (Exception ex)
                {
                    EventLog objLog = new EventLog();
                    //objLog.LogError(ex);
                    throw ex;
                }
            }
        }

        public DataSet GetDateDetailsforWelcomeSMS()
        {
            Database objDB = new SqlDatabase(strconnstring);
            using (DbCommand objCMD = objDB.GetStoredProcCommand("usp_GetDateDetailsforWelcomeSMS"))
            {         
                try
                {
                    DataSet dsWelcomeSMS = objDB.ExecuteDataSet(objCMD);
                    return dsWelcomeSMS;
                }
                catch (Exception ex)
                {
                    EventLog objLog = new EventLog();
                    throw ex;
                }
            }
        }

        public int SaveSMSstatusDetails(EL_Scheduler objEntity)
        {
            int i = 0;
            Database objDB = new SqlDatabase(strconnstring);
            using (DbCommand objCMD = objDB.GetStoredProcCommand("usp_SaveSMSstatusDetails"))
            {
                objDB.AddInParameter(objCMD, "@ClientId",
                                     DbType.String, objEntity.ClientId);
                objDB.AddInParameter(objCMD, "@ClientName",
                                    DbType.String, objEntity.ClientName); 
                objDB.AddInParameter(objCMD, "@Status",
                                     DbType.String, objEntity.Status);
                objDB.AddInParameter(objCMD, "@PhoneNumber",
                                        DbType.String, objEntity.PhoneNumbers);
                objDB.AddInParameter(objCMD, "@Days",
                                        DbType.String, objEntity.daysStatus);

                objDB.AddInParameter(objCMD, "@PolicyNum",
                                      DbType.String, objEntity.PolicyNo);

                objDB.AddInParameter(objCMD, "@ClientType",
                                     DbType.String, objEntity.ClientType); 
                objDB.AddOutParameter(objCMD, "@strErrorMessage", DbType.String, 50);
                try
                {
                    i = objDB.ExecuteNonQuery(objCMD);
                    objEntity.ErrorMessage = objDB.GetParameterValue(objCMD, "@strErrorMessage").ToString();
                    return i;
                }
                catch (Exception ex)
                {
                    EventLog objLog = new EventLog();
                    throw ex;
                }
            }
        }
    }
}
