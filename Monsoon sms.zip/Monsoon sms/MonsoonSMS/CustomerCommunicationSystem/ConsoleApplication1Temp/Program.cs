﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using CCS_CommonFunctionsLayer;
using System.Data.OleDb;
using System.IO;
using System.Configuration;
using System.Net;
using System.Text.RegularExpressions;

namespace ConsoleApplication1Temp
{
    class Program
    {
        static OleDbConnection conn;
        static void Main(string[] args)
        {
            LoadExcelData();
        }
       
        static void LoadExcelData()
        {
            CFL_ErrorHandling objerror = new CFL_ErrorHandling();
            try
            {
                DAL_EmailScheduler objEmailDAlScheduler = new DAL_EmailScheduler();
                String msg = "";
                CCS_CommonFunctionsLayer.CFL_SendSMS objSms = new CCS_CommonFunctionsLayer.CFL_SendSMS();
                System.IO.StreamWriter sw = new System.IO.StreamWriter(System.Configuration.ConfigurationManager.AppSettings["LogPath"] + "msgstatus" + DateTime.Today.Day.ToString("00") + "_" + DateTime.Today.Month.ToString("00") + "_" + DateTime.Today.Year.ToString() + ".log");
           
                StringBuilder strRemarks = new StringBuilder();
                string MobileNo = null;
                DataSet ds = new DataSet();
               
                ds = objEmailDAlScheduler.ConvertCSVtoDataTable();
                int j = 0;

                for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {
                    
                    try
                    {
                    MobileNo = ds.Tables[0].Rows[i]["MobileNumber"].ToString(); //ConfigurationManager.AppSettings["MobileNumber"];// ConfigurationManager.AppSettings["MobileNumber"];

                            if (ConfigurationManager.AppSettings["LogTrackingEnabled"] == "true")
                            {
                                objerror.WriteLog("MobileNoOG:" + MobileNo + " MobileNo: " + MobileNo ,"SchedulerLog_", 2);//Added SMS by shekhar 26102016
                            }

                            if (MobileNo != null)
                            {

                                msg = String.Format("Greetings from Liberty Videocon! Avoid driving in water-logged area where water height is above the center of the tyre. In case the vehicle is submerged in water do not try to crank or push start the engine. Even 1 attempt can cause major damage inside engine. For any guidance/ assistance please contact us @ 18002665844/ care@libertyinsurance.in");
                                string response = objSms.SendSMS(MobileNo, msg);
                                if (response.IndexOf('x') == -1)
                                    sw.WriteLine("Success:" + MobileNo + " Response " + response);
                                else
                                    sw.WriteLine("Failed:" + MobileNo);
                                sw.Flush();
                            }
                    }
                    catch (Exception ex)
                    {
                        //sw.WriteLine("Failed:" + mobileno);
                        objerror.WriteLog("For loop expetion Failed" + " --- " + MobileNo, "SchedulerLog_", 2);
                    }
                   // Thread.Sleep(1000);
                    objerror.WriteLog("Processed: " + j.ToString() + " --- " + MobileNo + " -- " + msg, "SchedulerLog_", 2);
                    j++;

                }

                objerror.WriteLog("Processed: " + j.ToString() + " out of " + (ds.Tables[0].Rows.Count).ToString(), "SchedulerLog_", 2);
                sw.Close();
            }
            catch (Exception ex)
            {
                 objerror.WriteLog("Main Exception getBitURl1 exception "+ex.ToString(), "SchedulerLog_", 2);
              
             
            }
            finally
            {
            }
        }

    }
}
