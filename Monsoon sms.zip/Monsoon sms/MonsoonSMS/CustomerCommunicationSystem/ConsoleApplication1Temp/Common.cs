﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Linq;
using System.IO;
using System.Configuration;
using System.Net;
//using System.DirectoryServices;
using System.Collections;
using System.Globalization;

namespace ConsoleApplication1Temp
{
    public class Common
    {
        int _logType;
        string _logPath;
        string orgId = null;
        int _ConfigFileSize;

        string Constring = string.Empty;
        // Common objCommon = new Common();

        public Common()
        {

            _logPath = System.Configuration.ConfigurationManager.AppSettings["LogPath"].ToString()+@"\";
            _logType = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["LogType"].ToString());
            _ConfigFileSize = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["FileSize"].ToString());
        }
        public string GetMessage(string nodeVal, string filePath)
        {
            try
            {
                string messageVal;
                if (nodeVal != null)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    XmlNode xmlNode;
                    XmlNodeList xmlNodeList;

                    xmlDoc.Load(filePath);
                    xmlNodeList = xmlDoc.SelectNodes(nodeVal);
                    xmlNode = xmlNodeList.Item(0);

                    messageVal = xmlNode.ChildNodes.Item(0).InnerText.ToString();
                    return messageVal;
                }
                else
                    return "";
            }
            catch (System.Exception ex)
            {
                return "";
            }
        }

        public bool WriteLog(string src)
        {

            string folderName = null;
            string fileName;
            StringBuilder objStringBuilder = new StringBuilder();
            StreamWriter objStreamWriter;
            folderName = DateTime.Now.ToString("dd_MM_yyyy");
            fileName = "GenericMailer_Monsoon_" + DateTime.Now.ToString("dd_MM_yyyy");
            try
            {

                bool exists = Directory.Exists(_logPath + @"\" + folderName + @"\");
                if (!exists)
                {
                    Directory.CreateDirectory(_logPath + @"\" + folderName + @"\");
                }
                objStreamWriter = File.AppendText(_logPath + @"\" + folderName + @"\" + fileName + ".Log");
                FileInfo fileSize = new FileInfo(_logPath + @"\" + folderName + @"\" + fileName + ".Log");

                int maxSize = Convert.ToInt32(fileSize.Length / 1024);
                maxSize = maxSize / 1024;
                if (maxSize < _ConfigFileSize)
                {

                    objStringBuilder.Append("<" + System.DateTime.Now + ">");
                    objStringBuilder.Append(" ");
                    objStringBuilder.Append(src);
                    objStreamWriter.WriteLine(objStringBuilder.ToString());
                    objStreamWriter.Close();
                }
                else
                {
                    objStringBuilder.Append("<" + System.DateTime.Now + ">");
                    objStringBuilder.Append(" ");
                    objStringBuilder.Append(src);
                    objStreamWriter.WriteLine(objStringBuilder.ToString());
                    objStreamWriter.Close();
                    System.IO.File.Move(_logPath + @"\" + folderName + @"\" + fileName + ".Log", _logPath + @"\" + folderName + @"\" + fileName + DateTime.Now.ToString("-HH-mm-ss") + ".Log");
                }
                return true;
            }
            catch
            {
                return false;
            }
        }



        public static string ToString(object value)
        {
            if (value == null || value == DBNull.Value)
                return "";
            else
                return Convert.ToString(value);
        }
        public string MakeQueryParam(object value)
        {
            return ToString(value).Replace("'", "''");
        }
    }
}
