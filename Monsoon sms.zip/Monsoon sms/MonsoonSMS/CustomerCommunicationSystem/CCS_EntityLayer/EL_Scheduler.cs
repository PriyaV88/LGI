﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CCS_EntityLayer
{
    public class EL_Scheduler
    {
        private DateTime dtPolicyGeneratedDate;
        private string dtPolicyExpiryDate;
        private string StrStatus = "";
        private string strClientId ="";
        private string strClientName = "";
        private string strPhoneNumbers = "";
        private string strErrorMessage = "";
        private string strPolicyType = "";
        private string strdays = "";
        private string strPolicyNo = "";
        private string StrClientType = "";


        public string ClientType
        {
            get
            {
                return StrClientType;
            }
            set
            {
                StrClientType = value;
            }
        }

        public string PolicyNo
        {
            get
            {
                return strPolicyNo;
            }
            set
            {
                strPolicyNo = value;
            }
        }

        public string daysStatus
        {
            get
            {
                return strdays;
            }
            set
            {
                strdays = value;
            }
        }

        public DateTime PolicyGeneratedDate
        {
            get
            {
                return dtPolicyGeneratedDate;
            }
            set
            {
                dtPolicyGeneratedDate = value;
            }
        }

        public string PolicyType
        {
            get
            {
                return strPolicyType;
            }
            set
            {
                strPolicyType = value;
            }
        }

        public string PolicyExpiryDate
        {
            get
            {
                return dtPolicyExpiryDate;
            }
            set
            {
                dtPolicyExpiryDate = value;
            }
        }


        public string Status
        {
            get
            {
                return StrStatus;
            }
            set
            {
                StrStatus = value;
            }
        }

        public string ClientId
        {
            get
            {
                return strClientId;
            }
            set
            {
                strClientId = value;
            }
        }

        public string ClientName
        {
            get
            {
                return strClientName;
            }
            set
            {
                strClientName = value;
            }
        }

        public string PhoneNumbers
        {
            get
            {
                return strPhoneNumbers;
            }
            set
            {
                strPhoneNumbers = value;
            }
        }

        public string ErrorMessage
        {
            get
            {
                return strErrorMessage;
            }
            set
            {
                strErrorMessage = value;
            }
        }
    }
}
