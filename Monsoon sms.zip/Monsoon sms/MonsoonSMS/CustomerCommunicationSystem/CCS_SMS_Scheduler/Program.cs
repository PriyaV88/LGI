﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CCS_BusinessLogicLayer;

namespace CCS_SMS_Scheduler
{
    class Program
    {
        static void Main(string[] args)
        {        
            BLL_SendSMS objSMS = new BLL_SendSMS();
            //string strErr=objSMS.RenewalReminderSMSSend();
            //objSMS.WelcomeSMSSend();
            //if ((strErr.Trim().ToUpper() == "") || (strErr.ToUpper().IndexOf("SENDSMS") != -1))
            //{
            //    Console.WriteLine("SMS send successfully");
            //    Console.ReadLine();
            //}          
            //else
            //{
            //    Console.WriteLine(strErr.Trim());
            //    Console.ReadLine();
            //}
            
        }
    }
}
