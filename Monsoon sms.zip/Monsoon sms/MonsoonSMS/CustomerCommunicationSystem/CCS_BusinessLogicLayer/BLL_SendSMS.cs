﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Net;
using CCS_CommonFunctionsLayer;
using CCS_DataAccessLayer;
using System.Data;
using System.Configuration;
using CCS_EntityLayer;
using System.Threading;

namespace CCS_BusinessLogicLayer
{  
    public class BLL_SendSMS
    {
        CFL_ErrorHandling objerror = new CFL_ErrorHandling();
        DAL_SmsScheduler objDAlScheduler = new DAL_SmsScheduler();
        CFL_CheckUnicodeCharacters objchk = new CFL_CheckUnicodeCharacters();
        CFL_SendSMS objSms = new CFL_SendSMS();
        EL_Scheduler objEntity;      
        string strRenewalSMS = "Dear @Customer,\r\nThis is to remind you that your @PolicyType Policy (@PolicyNo) with Liberty Videocon General Insurance is due for renewal on @Renewaldate. Kindly contact your nearest branch for renewal or call our toll free number 1800-266-5844. Please ignore if already renewed.\r\nTeam-LVGI";      
        string strWelcomeSMS = System.Configuration.ConfigurationManager.AppSettings["WelcomeSMSmsg"].ToString();
              
        public string RenewalReminderSMSSend()
        {
            DataSet ds;       
            try
            {
                string str = "";
                ds = new DataSet(); 
                ds = objDAlScheduler.GetPolicyDetails();

                if (ds.Tables.Count > 1)
                {
                    /******************************  T-30    ***************************/
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int j = 0; j < ds.Tables[1].Rows.Count; j++)
                        {
                            objEntity = new EL_Scheduler();
                            try
                            {
                                objEntity.ClientId = ds.Tables[1].Rows[j]["ClientID"].ToString().Trim();
                                objEntity.ClientName = ds.Tables[1].Rows[j]["ClientName"].ToString().Trim().Trim();
                                objEntity.PolicyExpiryDate = ds.Tables[1].Rows[j]["PolicyEndDate"].ToString().Trim();
                                objEntity.PolicyNo = ds.Tables[1].Rows[j]["PolicyNumber"].ToString().Trim();
                                if (ds.Tables[1].Rows[j]["PolicyType"].ToString().Trim().ToUpper().Contains("POLICY") == true)
                                {
                                    objEntity.PolicyType = ds.Tables[1].Rows[j]["PolicyType"].ToString().Replace("Policy", "").Trim();
                                }
                                objEntity.PhoneNumbers = ds.Tables[1].Rows[j]["MobNo-Home"].ToString().Trim();
                                objEntity.daysStatus = "30days";
                                objEntity.ClientType = ds.Tables[1].Rows[j]["ClientType"].ToString().Trim().ToUpper();
                                if (objEntity.ClientType == "INDIVIDUAL")
                                {
                                    objEntity.Status = objSms.SendSMS(objEntity.PhoneNumbers,strRenewalSMS.Replace("@Renewaldate", objEntity.PolicyExpiryDate).Replace("@PolicyType", objEntity.PolicyType).Replace("@PolicyNo", objEntity.PolicyNo).Replace("@Customer", objEntity.ClientName));
                                }
                                else
                                {
                                    objEntity.Status = objSms.SendSMS(objEntity.PhoneNumbers,strRenewalSMS.Replace("@Renewaldate", objEntity.PolicyExpiryDate).Replace("@PolicyType", objEntity.PolicyType).Replace("@PolicyNo", objEntity.PolicyNo).Replace("@Customer", "Customer"));
                                }
                               
                                if (objEntity.Status.IndexOf('x') == -1)
                                {
                                    str = str + "SendSMS";
                                }
                                else
                                {
                                    str = str + "ERROR :" + objEntity.Status;
                                }
                                int resultinsert = objDAlScheduler.SaveSMSstatusDetails(objEntity);
                                if (objEntity.ErrorMessage.Trim() == "")
                                {
                                    objerror.WriteLog(objEntity.ErrorMessage + "(Client ID=" + objEntity.ClientId + ")", "SchedulerLog_", 2);
                                }
                                if (resultinsert <= 0)
                                {
                                    objerror.WriteLog("Error Occurred (Client ID=" + objEntity.ClientId + ")", "SchedulerLog_", 2);
                                }
                                objerror.WriteLog("Inserted Status of SMS : " + objEntity.Status + " for  Client ID = " + objEntity.ClientId, "SchedulerLog_", 2);
                            }
                            catch (Exception ex)
                            {
                                objerror.WriteLog("Error : ( for loop - T-30)" + ex.Message, "SchedulerLog_", 2);
                            }
                            finally
                            {
                                objEntity = null;
                               
                            }
                        }
                    }
                    else
                    {
                        if ((str.ToUpper().IndexOf("SENDSMS") == -1) && (str.ToUpper().IndexOf("ERROR") == -1))
                        {
                            str = "No records found";
                        }
                    }
                    System.Threading.Thread.Sleep(5000);
                }
                else
                {
                    if ((str.ToUpper().IndexOf("SENDSMS") == -1) && (str.ToUpper().IndexOf("ERROR") == -1))
                    {
                        str = "No records found";
                    }
                }

                if ((str.ToUpper().IndexOf("ERROR") != -1) && (str.ToUpper().IndexOf("SENDSMS") == -1))
                {
                    return str.Replace("No records found", " ").Replace("<br>", " ");
                }
                System.Threading.Thread.Sleep(5000);
                return str;
            }
            catch (ThreadAbortException thex)
            {
                objerror.WriteLog(thex.Message, "SchedulerLog_", 1);
                return "Error";              
            }
            catch (Exception ex)
            {
                objerror.WriteLog(ex.Message, "SchedulerLog_", 1);
                return "Error";
            }
            finally
            {
                objerror = null;
                objDAlScheduler = null;
                objchk=null;
                objSms = null;
                ds = null;
            }
        }

    }
}
