﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Net;

namespace CCS_CommonFunctionsLayer
{
    public class CFL_SendSMS
    {
        public string msg;
        public string phonenos;
        CFL_CheckUnicodeCharacters objchk;
        CFL_ErrorHandling objerror;
        string IsCheck = System.Configuration.ConfigurationManager.AppSettings["IsCheck"].ToString();   
        string PhoneNumberSMS = System.Configuration.ConfigurationManager.AppSettings["PhoneNumberSMS"].ToString();        
        public string SendSMS(string phoneNo, string SMSMessage)
        {
            string responseString = "";
            string Recipients = "";
            string MessageData = "";
            try
            {
                objerror = new CFL_ErrorHandling();             
                string UserId = HttpUtility.UrlEncode("RenewalApp"); //username for successful login
                string Pswd = HttpUtility.UrlEncode("p(8Sv!0Q"); //user's password              
                string senderId = HttpUtility.UrlEncode("LVGICL");
                if (IsCheck.ToUpper() == "TRUE")
                {
                    Recipients = PhoneNumberSMS; //who  will get the message
                }
                else
                {
                     Recipients = HttpUtility.UrlEncode(phoneNo); //who  will get the message
                }
                MessageData = HttpUtility.UrlEncode(SMSMessage); //body of message      
                //uncomment
                
                string createdURL = "";
                int lenchk = getDoubleCharacterSpace(SMSMessage);                     
                bool hasUnicode =false;
                objchk = new CFL_CheckUnicodeCharacters();
                hasUnicode = objchk.ContainsUnicodeCharacter(MessageData);
                if (hasUnicode == true)
                {
                    if (MessageData.Length >= 70)
                    {
                        createdURL = "http://www.unicel.in/SendSMS/sendmsg.php?" +
                        "&uname=" + UserId +
                        "&pass=" + Pswd +
                        "&send=" + senderId +
                        "&dest=" + Recipients +
                        "&msg=" + MessageData +
                        "&udhi=1&dcs=8";
                    }
                    else
                    {
                        objerror.WriteLog("UnicodeCharactesCheckMsg:  Message text length should be a maximum of 70 characters, Message text=" + MessageData + "dest = " + Recipients, "SchedulerLog_", 2);
                    }
                }
                else
                {
                    if (lenchk <= 160)
                    {
                        createdURL = "http://www.unicel.in/SendSMS/sendmsg.php?" +
                       "&uname=" + UserId +
                       "&pass=" + Pswd +
                       "&send=" + senderId +
                       "&dest=" + Recipients +
                       "&msg=" + MessageData;
                    }
                    if (lenchk > 160)
                    {
                        createdURL = "http://www.unicel.in/SendSMS/sendmsg.php?" +
                        "&uname=" + UserId +
                        "&pass=" + Pswd +
                        "&send=" + senderId +
                        "&dest=" + Recipients +
                        "&msg=" + MessageData +
                        "&concat=1";
                    }
                }
                //The Systen is not sending any binary message like ringtone,logos, pictures
                HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(createdURL);
                HttpWebResponse myResp = (HttpWebResponse)myReq.GetResponse();
                System.IO.StreamReader respStreamReader = new System.IO.StreamReader(myResp.GetResponseStream());
                String ver = myResp.ProtocolVersion.ToString();
                string  desc=myResp.StatusDescription;
                //StreamReader reader = new StreamReader(response.GetResponseStream());
                responseString = respStreamReader.ReadToEnd();
                objerror.WriteLog(responseString, "SchedulerLog_", 2);
                respStreamReader.Close();
                myResp.Close();
                //uncomment
                
                return responseString;         
            }
            catch (Exception ex)
            {
                responseString = "ERROR";
                objerror.WriteLog(ex.Message + "ERROR_SendSMS Function", "SchedulerLog_", 1);
                return responseString;
            }
            finally
            {
                objchk = null;
                objerror = null;
                Recipients = "";
                MessageData = "";
            }
        }
  
        public int getDoubleCharacterSpace(string msg)
        {
            string str = "{,},[,~,],|,^,<FF>,€,\\";
            string[] arrStr = str.Split(',');
            int lenofmsg = msg.Length;
            if (msg.Length >= 160)
            {
                for (int i = 0; i < arrStr.Length; i++)
                {
                    if (msg.IndexOf(arrStr[i].ToString()) != -1)
                    {
                        lenofmsg = lenofmsg + 1;
                    }
                }
            }
            return lenofmsg;
        }
    }
}
