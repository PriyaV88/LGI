﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading;

namespace CCS_CommonFunctionsLayer
{
    public class CFL_ErrorHandling
    {
        string _logPath = string.Empty;
        string Constring = string.Empty;
        static string XMLPath = string.Empty;
        static int _ConfigFileSize = 2;

        public bool WriteLog(string src, string userName, int logTypeFlg)
        {
            /* 1 for Only Write Exceptions block
               0 for Only Event or method block
             */
            _ConfigFileSize = Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["FileSize"].ToString());
            _logPath = System.Configuration.ConfigurationManager.AppSettings["LogPath"].ToString();
            string fileName;
            StringBuilder objStringBuilder = new StringBuilder();
            StreamWriter objStreamWriter;
            fileName = userName;
            try
            {
                if (src.Contains("Thread was being aborted.") == false &&
                    src.Contains("Object reference not set to an instance of an object.") == false)
                {
                    bool exists = Directory.Exists(_logPath);
                    if (!exists)
                    {
                        Directory.CreateDirectory(_logPath);
                    }
                    objStreamWriter = File.AppendText(_logPath + fileName + DateTime.Today.Day.ToString("00") + "_" + DateTime.Today.Month.ToString("00") + "_" + DateTime.Today.Year.ToString() + ".Log");

                    FileInfo fileSize = new FileInfo(_logPath + fileName + DateTime.Today.Day.ToString("00") + "_" + DateTime.Today.Month.ToString("00") + "_" + DateTime.Today.Year.ToString() + ".Log");

                    int maxSize = Convert.ToInt32(fileSize.Length / 1024);
                    maxSize = maxSize / 1024;
                    if (maxSize < _ConfigFileSize)
                    {
                        objStringBuilder.Append("<" + System.DateTime.Now + ">");
                        objStringBuilder.Append(" ");
                        objStringBuilder.Append("" + logTypeFlg + ":");
                        objStringBuilder.Append(src);
                        objStreamWriter.WriteLine(objStringBuilder.ToString());
                        objStreamWriter.Close();
                    }
                    else
                    {
                        objStringBuilder.Append("<" + System.DateTime.Now + ">");
                        objStringBuilder.Append(" ");
                        objStringBuilder.Append("" + logTypeFlg + ":");
                        objStringBuilder.Append(src);
                        objStreamWriter.WriteLine(objStringBuilder.ToString());
                        objStreamWriter.Close();
                        System.IO.File.Move(_logPath + fileName + DateTime.Today.Day.ToString("00") + "_" + DateTime.Today.Month.ToString("00") + "_" + DateTime.Today.Year.ToString() + ".Log", _logPath + fileName + DateTime.Today.Day.ToString("00") + "_" + DateTime.Today.Month.ToString("00") + "_" + DateTime.Today.Year.ToString() + DateTime.Now.ToString("-HH-mm-ss") + ".Log");
                    }
                }
                return true;
            }
            catch (ThreadAbortException ex)
            {
                return true;
            }
            catch
            {
                return false;
            }
        }

        public void DeleteLogFiles()
        {           // deleted files older than 2 months 
            string[] files = Directory.GetFiles(_logPath);
            foreach (string file in files)
            {
                FileInfo fi = new FileInfo(file);
                if (fi.Exists == true)
                {
                    if (fi.LastAccessTime < DateTime.Now.AddMonths(-2))
                    {
                        fi.Delete();
                    }
                }
            }
        }        
    }
}
