﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.IO;
using System.Web.Configuration;
using Oracle.DataAccess.Client;



namespace DWHDAL
{
    public class DWHDAL
    {
        //AppConfigHandler configurationHandler { get; set; }
        //string viewconn = ConfigurationManager.ConnectionStrings["ViewConnectionString"].ConnectionString;
        //string spefileconn = ConfigurationManager.ConnectionStrings["SPefileConenctionString"].ConnectionString;
        public string ViewConnectionString { get; set; }
        public string SPefileConenctionString { get; set; }
        public string efileConnectionString { get; set; }
        public string ViewHBConnectionString { get; set; }
        //public string oradb = "Data Source=(DESCRIPTION =" + "(ADDRESS = (PROTOCOL = TCP)(HOST = 10.134.10.44)(PORT = 1521))" + "(CONNECT_DATA =" + "(SERVER = DEDICATED)" + "(SERVICE_NAME = PREPROD)));" + "User Id= dw_rep;Password=dw_rep;";
        public string oradb = "Data Source=(DESCRIPTION =" + "(ADDRESS = (PROTOCOL = TCP)(HOST = 10.134.11.145)(PORT = 1521))" + "(CONNECT_DATA =" + "(SERVER = DEDICATED)" + "(SERVICE_NAME = prodods)));" + "User Id= dw_rep;Password=dw_rep;";
        public DWHDAL()
        {
            //ViewConnectionString = "Data Source=10.134.11.109,1643; Initial Catalog=LVGI_Staging; User id=EFILE; Password=Efile$123!";
            //SPefileConenctionString = "Data Source=IN-CLD-UDMS2\\SQL2012; Initial Catalog=LVGI_ECM_DB;Integrated Security=True";
            GetConnectionString();
        }

        public void GetConnectionString()
        {
            try
            {
                ViewConnectionString = ConfigurationManager.ConnectionStrings["ViewConnectionString"].ConnectionString;
                SPefileConenctionString = ConfigurationManager.ConnectionStrings["SPefileConenctionString"].ConnectionString;
                efileConnectionString = ConfigurationManager.ConnectionStrings["efileConnectionString"].ConnectionString;
                ViewHBConnectionString = ConfigurationManager.ConnectionStrings["ViewHBConnectionString"].ConnectionString;
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        public EFileMapper GetDCNMetaData(string caseid)
        {

            EFileMapper eFiles = new EFileMapper();

            using (SqlConnection connection = new SqlConnection(ViewConnectionString))
            {
                DataTable table = new DataTable("PolicyMetadata");

                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["ViewName"] + " with (NOLOCK) where CaseID = '" + caseid + "'";
                //string command = "SELECT * FROM VW_E_File where PolicyNumber = '201250020115101282300000'";

                var cmd = new SqlCommand(command, connection);
                cmd.CommandTimeout = 2000;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                connection.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);


                //read data from DataTable 
                //using lamdaexpression

                eFiles = (from DataRow row in table.Rows

                          select new EFileMapper
                          {
                              // EndtNo = row["EndorsementNumber"].ToString(),
                              LOB = row["LOB"].ToString(),
                              Product = row["Product"].ToString(),
                              PolicyNo = row["PolicyNumber"].ToString(),
                              Country = row["Country"].ToString(),
                              InsuredName = row["InsuredName"].ToString(),
                              PolicyYear = row["PolicyYear"].ToString(),
                              PolicyInceptionDate = row["PolicyInceptionDate"].ToString(),
                              PolicyExpiryDate = row["PolicyExpiryDate"].ToString(),
                              UWStage = row["UWStage"].ToString(),
                              Company = row["Company"].ToString(),
                              BranchName = row["BranchName"].ToString(),
                              BranchCode = row["BranchCode"].ToString(),
                              QuoteNumber = row["QuoteNumber"].ToString(),
                              BatchNumber = row["BatchNumber"].ToString(),
                              Zone = row["Zone"].ToString(),
                              SourceSystemName = row["SourceSystemName"].ToString(),
                              CaseId = row["CaseId"].ToString(),
                              PreviousPolicyNumber = row["PreviousPolicyNumber"].ToString(),
                              Underwriter = row["Underwriter"].ToString(),
                              UnderwritingAssistant = row["UnderwritingAssistant"].ToString(),
                              MasterStatus = row["MasterStatus"].ToString(),
                              Function = row["Function"].ToString(),
                              RiskLocation = row["RiskLocation"].ToString(),
                              IsConfidential = row["IsConfidential"].ToString(),
                              eFileCategory = row["eFileCategory"].ToString(),
                              InsuredCode = row["InsuredCode"].ToString(),
                              IntermediaryName = row["IntermediaryName"].ToString(),
                              IntermediaryCode = row["IntermediaryCode"].ToString(),
                              SMName = row["SMName"].ToString(),
                              SMCode = row["SMCode"].ToString(),
                              EndtNo = row["EndorsementNumber"].ToString(),
                              // ProductCode = row["ProductCode"].ToString(),
                              //  ProductCode = "Null"
                          }).FirstOrDefault();

                eFiles.ProductCode = string.Empty;
                //eFiles.ProductCode = "1412";
            }
            return eFiles;
        }

        public EFileMapper GetDCNMetaDatafromHBView(string caseid)
        {

            EFileMapper eFiles = new EFileMapper();

            using (SqlConnection connection = new SqlConnection(ViewHBConnectionString))
            {
                DataTable table = new DataTable("PolicyMetadata");

                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["HBViewName"] + " with (NOLOCK) where [DCN No] = '" + caseid + "'";
                //string command = "SELECT * FROM VW_E_File where PolicyNumber = '201250020115101282300000'";

                var cmd = new SqlCommand(command, connection);
                cmd.CommandTimeout = 2000;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                connection.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);


                //read data from DataTable 
                //using lamdaexpression

                eFiles = (from DataRow row in table.Rows

                          select new EFileMapper
                          {
                              // EndtNo = row["EndorsementNumber"].ToString(),
                              LOB = row["LOB Name"].ToString(),
                              Product = row["Product Name"].ToString(),
                              PolicyNo = string.Empty,
                              Country = "India",
                              InsuredName = row["Customer Name"].ToString(),
                              PolicyYear = Convert.ToDateTime(row["Policy Start Date"].ToString()).Year.ToString(),
                              PolicyInceptionDate = row["Policy Start Date"].ToString(),
                              PolicyExpiryDate = row["Policy End Date"].ToString(),
                              UWStage = string.Empty,
                              Company = "LVI",
                              BranchName = row["Office Name"].ToString(),
                              BranchCode = row["Office Code"].ToString(),
                              QuoteNumber = string.Empty,
                              BatchNumber = string.Empty,
                              Zone = string.Empty,
                              SourceSystemName = "HB",
                              CaseId = row["DCN No"].ToString(),
                              PreviousPolicyNumber = string.Empty,
                              Underwriter = string.Empty,
                              UnderwritingAssistant = string.Empty,
                              MasterStatus = "Booked",
                              Function = "UW",
                              RiskLocation = string.Empty,
                              IsConfidential = "No",
                              eFileCategory = "Case",
                              InsuredCode = row["Customer ID"].ToString(),
                              IntermediaryName = row["IMD_Name"].ToString(),
                              IntermediaryCode = row["IMD_Code"].ToString(),
                              SMName = row["SM Name"].ToString(),
                              SMCode = row["SM Code"].ToString(),
                              // EndtNo = row["EndorsementNumber"].ToString(),
                             // ProductCode = row["Product Code"].ToString(),
                              //  ProductCode = "Null"
                          }).FirstOrDefault();

                 eFiles.ProductCode = string.Empty;
               // eFiles.ProductCode = "1211";
            }
            return eFiles;
        }

        public EFileMapper GetDcnMetaDatafromGCView(string caseid)
        {

            EFileMapper eFiles = new EFileMapper();
            try
            {
                OracleConnection connection = new OracleConnection(oradb);
                connection.Open();
                string columnName = "\"DCN No\"";
                OracleDataAdapter adap = new OracleDataAdapter(string.Format("select * from dw_inward_details_gc WHERE {0} = '{1}'", columnName, caseid), connection);
                DataTable table = new DataTable();
                adap.Fill(table);


                List<DataColumn> allColumns = new List<DataColumn>();
                foreach (DataColumn col in table.Columns)
                {
                    allColumns.Add(col);
                }


                eFiles = (from DataRow row in table.Rows
                          select new EFileMapper
                          {
                              LOB = row[getColumn(allColumns, "lob name")].ToString(),
                              Product = row[getColumn(allColumns, "product name")].ToString(),
                              PolicyNo = string.Empty,
                              Country = "India",
                              InsuredName = row[getColumn(allColumns, "customer name")].ToString(),
                              PolicyYear = Convert.ToDateTime(row[getColumn(allColumns, "policy start date")].ToString()).Year.ToString(),
                              PolicyInceptionDate = row[getColumn(allColumns, "policy start date")].ToString(),
                              PolicyExpiryDate = row[getColumn(allColumns, "policy end date")].ToString(),
                              UWStage = string.Empty,
                              Company = "LVI",
                              BranchName = row[getColumn(allColumns, "office name")].ToString(),
                              BranchCode = row[getColumn(allColumns, "office code")].ToString(),
                              QuoteNumber = string.Empty,
                              BatchNumber = string.Empty,
                              Zone = string.Empty,
                              SourceSystemName = "GC",
                              CaseId = row[getColumn(allColumns, "dcn no")].ToString(),
                              PreviousPolicyNumber = string.Empty,
                              Underwriter = string.Empty,
                              UnderwritingAssistant = string.Empty,
                              MasterStatus = "Booked",
                              Function = "UW",
                              RiskLocation = string.Empty,
                              IsConfidential = "No",
                              eFileCategory = "Case",
                              InsuredCode = row[getColumn(allColumns, "customer id")].ToString(),
                              IntermediaryName = row[getColumn(allColumns, "imd_name")].ToString(),
                              IntermediaryCode = row[getColumn(allColumns, "imd_code")].ToString(),
                              SMName = row[getColumn(allColumns, "sm name")].ToString(),
                              SMCode = row[getColumn(allColumns, "sm code")].ToString(),
                             // ProductCode = row[getColumn(allColumns, "product code")].ToString(),
                              //ProductCode = "1211",
                               ProductCode = string.Empty,

                          }).FirstOrDefault();
            }
            catch (OracleException ex)
            {
                Console.WriteLine("Record is not inserted into the database table.");
                Console.WriteLine("Exception Message: " + ex.Message);
                Console.WriteLine("Exception Source: " + ex.Source);
            }

            return eFiles;

        }

        private static DataColumn getColumn(List<DataColumn> allColumns, string columnName)
        {
            return allColumns.Where(col => col.ColumnName.Trim().ToLower() == columnName).FirstOrDefault();
        }
        public EFileMapper GetPolicySharepointFileURL(string caseid, EFileMapper metaDataEfile)
        {
            EFileMapper eFilePath = new EFileMapper();
            using (SqlConnection conn = new SqlConnection(SPefileConenctionString))
            {
                DataTable table = new DataTable("SpEfileLocation");

                //string command = "SELECT * FROM uw_document_set where PolicyNumber = '" + PolicyNumber + "'";
                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["TableName"] + " with (NOLOCK)  where case_id = '" + caseid + "'";
                //string command = "SELECT * FROM uw_document_set where policy_no =  'POL656565656'";

                var cmd = new SqlCommand(command, conn);
                // cmd.CommandTimeout = 200;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                conn.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);
                eFilePath = (from DataRow row in table.Rows

                             select new EFileMapper
                             {
                                 policy_no = row["policy_no"].ToString(),
                                 site_collection_url = row["site_collection_url"].ToString(),
                                 doc_lib_name = row["doc_lib_name"].ToString(),
                                 efile_name = row["efile_name"].ToString(),
                                 efile_Url = row["site_collection_url"].ToString() + row["doc_lib_name"].ToString() + "/" + row["efile_name"].ToString(),
                                 s3folderUrl = row["s3folderUrl"].ToString(),
                                 documentset_no = row["documentset_no"].ToString(),
                             }).FirstOrDefault();

            }

            if (eFilePath != null)
            {

                metaDataEfile.policy_no = eFilePath.policy_no;
                metaDataEfile.site_collection_url = eFilePath.site_collection_url;
                metaDataEfile.doc_lib_name = eFilePath.doc_lib_name;
                metaDataEfile.efile_name = eFilePath.efile_name;
                metaDataEfile.efile_Url = eFilePath.efile_Url;
                metaDataEfile.s3folderUrl = eFilePath.s3folderUrl;
                metaDataEfile.documentset_no = eFilePath.documentset_no;
            }
            else
            {

            }


            return metaDataEfile;
        }

        public EFileMapper GetProductCodeDetails(string ProductCode, string DocCategory, EFileMapper efilemetadata)
        {

            EFileMapper ProductDetails = new EFileMapper();

            using (SqlConnection connection = new SqlConnection(efileConnectionString))
            {
                DataTable table = new DataTable("ProductCodeMetadata");

                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["ProductTableName"] + " with (NOLOCK) where ProductCode = '" + ProductCode + "'" + "and DocumentCategory ='" + DocCategory + "'";
                //string command = "SELECT * FROM VW_E_File where PolicyNumber = '201250020115101282300000'";

                var cmd = new SqlCommand(command, connection);
                // cmd.CommandTimeout = 2000;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                connection.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);

                //read data from DataTable 
                //using lamdaexpression
                //foreach (DataRow dr in table.Rows)
                ProductDetails = (from DataRow row in table.Rows

                                  select new EFileMapper
                                  {
                                      // EndtNo = row["EndorsementNumber"].ToString(),
                                      lob = row["LOB"].ToString(),
                                      ProductName = row["ProductName"].ToString(),
                                      sourcesytemname = row["SourceSystemName"].ToString(),
                                      DocType = row["DocumentType"].ToString(),
                                      StartPage = row["StartPage"].ToString(),
                                      EndPage = row["EndPage"].ToString()
                                  }).FirstOrDefault();

            }

            if (ProductDetails != null)
            {

                efilemetadata.ProductName = ProductDetails.ProductName;
                efilemetadata.lob = ProductDetails.lob;
                efilemetadata.sourcesytemname = ProductDetails.sourcesytemname;
                efilemetadata.DocType = ProductDetails.DocType;
                efilemetadata.StartPage = ProductDetails.StartPage;
                efilemetadata.EndPage = ProductDetails.EndPage;

            }
            else
            {

            }

            return efilemetadata;
        }

        public DataTable GetProductCodeMetaData(string ProductCode, string DocCategory,string Lob, EFileMapper efilemetadata)
        {

            EFileMapper ProductDetails = new EFileMapper();

            using (SqlConnection connection = new SqlConnection(efileConnectionString))
            {
                DataTable table = new DataTable("ProdCodeMetadata");

                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["ProductTableName"] + " with (NOLOCK) where (ProductCode = '" + ProductCode + "'" + "and DocumentCategory ='" + DocCategory + "'" + "and LOB ='" + Lob +"') or (ProductCode = ''" + "and DocumentCategory  ='" + DocCategory + "'" + "and LOB  ='" + Lob + "')";
                //string command = "SELECT * FROM VW_E_File where PolicyNumber = '201250020115101282300000'";

                var cmd = new SqlCommand(command, connection);
                // cmd.CommandTimeout = 2000;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                connection.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);

                //read data from DataTable 
                //using lamdaexpression
                // foreach (DataRow dr in table.Rows)


                return table;
            }
        }

        public int InsertAWSDocumentMDtoDb(EFileMapper efiles,AWSEfileMapper docmetadata, string s3fileurl, string filename)
        {


            // return value
            int documentFileNo = 0;

            StringBuilder sql = new StringBuilder();
            sql.Append("INSERT INTO dbo.AWSfilemetadata (");

            //if (docmetadata.DatabaseColumn.Length > 0)
            //    sql.AppendFormat("{0},", docmetadata.DatabaseColumn);

            // add the location fields
            sql.Append("documentset_no,PolicyNumber,CaseId,DocumentGroup,DocumentType,DocumentTitle,FileName,SourceSystemName,EndorsementNumber,s3fileUrl,CreatedByID,ModifiedByID,EmailTo,EmailFrom,EmailCC,EmailDate,Subject,ClaimNumber)");

            sql.Append(" VALUES (");

            //if (docmetadata.DatabaseColumn.Length > 0)
            //        sql.AppendFormat("@{0},", docmetadata.DatabaseColumn);


            // add the location parameter names and the sharepoint id parameter name
            sql.Append("@documentset_no,@PolicyNumber,@CaseId,@DocumentGroup,@DocumentType,@DocumentTitle,@FileName,@SourceSystemName,@EndorsementNumber,@s3fileUrl,@CreatedByID,@ModifiedByID,@EmailTo,@EmailFrom,@EmailCC,@EmailDate,@Subject,@ClaimNumber) ");
            sql.Append("SELECT SCOPE_IDENTITY() AS NewID ");
            //sql.Append("END");

            using (SqlConnection connection = new SqlConnection(SPefileConenctionString))
            {
                using (SqlCommand command = new SqlCommand(sql.ToString(), connection))
                {
                    // add in the values of the parameters.

                    // add the location parameters and the sharepoint id parameter
                    if (!string.IsNullOrEmpty(efiles.PolicyNumber))
                    {
                        command.Parameters.Add(new SqlParameter("PolicyNumber", efiles.PolicyNumber));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("PolicyNumber", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(efiles.CaseId))
                    {
                        command.Parameters.Add(new SqlParameter("CaseId", efiles.CaseId));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("CaseId", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.CreatedByID))
                    {
                        command.Parameters.Add(new SqlParameter("CreatedByID", docmetadata.CreatedByID));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("CreatedByID", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.ModifiedByID))
                    {
                        command.Parameters.Add(new SqlParameter("ModifiedByID", docmetadata.ModifiedByID));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("ModifiedByID", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.EmailTo))
                    {
                        command.Parameters.Add(new SqlParameter("EmailTo", docmetadata.EmailTo));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("EmailTo", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.EmailFrom))
                    {
                        command.Parameters.Add(new SqlParameter("EmailFrom", docmetadata.EmailFrom));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("EmailFrom", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.EmailCC))
                    {
                        command.Parameters.Add(new SqlParameter("EmailCC", docmetadata.EmailCC));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("EmailCC", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.EmailDate))
                    {
                        command.Parameters.Add(new SqlParameter("EmailDate", docmetadata.EmailDate));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("EmailDate", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.Subject))
                    {
                        command.Parameters.Add(new SqlParameter("Subject", docmetadata.Subject));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("Subject", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.ClaimNumber))
                    {
                        command.Parameters.Add(new SqlParameter("ClaimNumber", docmetadata.ClaimNumber));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("ClaimNumber", string.Empty));
                    }
                    if (!string.IsNullOrEmpty(docmetadata.DocumentType))
                    {
                        command.Parameters.Add(new SqlParameter("DocumentType", efiles.DocType));
                    }
                    else
                    {
                        command.Parameters.Add(new SqlParameter("DocumentType", "Policy Documentation"));
                    }
                    command.Parameters.Add(new SqlParameter("documentset_no", efiles.documentset_no));
                    command.Parameters.Add(new SqlParameter("DocumentGroup", "Policy"));
                  //  command.Parameters.Add(new SqlParameter("DocumentType", docmetadata.DocumentType));
                    command.Parameters.Add(new SqlParameter("DocumentTitle", string.Empty));
                    command.Parameters.Add(new SqlParameter("FileName", filename));
                    command.Parameters.Add(new SqlParameter("SourceSystemName", efiles.SourceSystemName));
                    command.Parameters.Add(new SqlParameter("EndorsementNumber", "000"));
                    command.Parameters.Add(new SqlParameter("s3fileUrl", s3fileurl));
                    // command.Parameters.Add(new SqlParameter("CaseId", docmetadata.CaseId));
                    // command.Parameters.Add(new SqlParameter("CreatedByID", docmetadata.CreatedByID));
                    //command.Parameters.Add(new SqlParameter("ModifiedByID", docmetadata.ModifiedByID));
                    //command.Parameters.Add(new SqlParameter("EmailTo", docmetadata.EmailTo));
                    // command.Parameters.Add(new SqlParameter("EmailFrom", docmetadata.EmailFrom));
                    //command.Parameters.Add(new SqlParameter("EmailCC", docmetadata.EmailCC));
                    // command.Parameters.Add(new SqlParameter("EmailDate", docmetadata.EmailDate));
                    // command.Parameters.Add(new SqlParameter("Subject", docmetadata.Subject));
                    //command.Parameters.Add(new SqlParameter("ClaimNumber", docmetadata.ClaimNumber));

                    connection.Open();
                    object ID = command.ExecuteScalar();
                    if (ID != null && ID != DBNull.Value)
                        documentFileNo = Convert.ToInt32(ID);
                    connection.Close();
                }
            }
            return documentFileNo;
        }
    }
}