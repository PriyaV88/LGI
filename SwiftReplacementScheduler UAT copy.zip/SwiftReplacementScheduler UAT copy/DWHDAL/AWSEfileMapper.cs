﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;


namespace DWHDAL
{
   public class AWSEfileMapper
    {
        public string DatabaseColumn
        {
            get;
            set;
        }

        public string LOB
        {
            get;
            set;
        }
        public string Product
        {
            get;
            set;
        }
        public string PolicyNumber
        {
            get;
            set;
        }

        public string Country
        {
            get;
            set;
        }

        public string InsuredName
        {
            get;
            set;
        }

        public string PolicyYear
        {
            get;
            set;
        }

        public string PolicyInceptionDate
        {
            get;
            set;
        }

        public string PolicyExpiryDate
        {
            get;
            set;
        }

        public string UWStage
        {
            get;
            set;
        }

        public string Company
        {
            get;
            set;
        }

        public string BranchName
        {
            get;
            set;
        }


        public string BranchCode
        {
            get;
            set;
        }

        public string QuoteNumber
        {
            get;
            set;
        }

        public string BatchNumber
        {
            get;
            set;
        }

        public string Zone
        {
            get;
            set;
        }

        public string SourceSystemName
        {
            get;
            set;
        }
        public string CaseId
        {
            get;
            set;
        }
        public string PreviousPolicyNumber
        {
            get;
            set;
        }
        public string Underwriter
        {
            get;
            set;
        }
        public string UnderwritingAssistant
        {
            get;
            set;
        }
        public string MasterStatus
        {
            get;
            set;
        }
        public string Function
        {
            get;
            set;
        }
        public string RiskLocation
        {
            get;
            set;
        }
        public string IsConfidential
        {
            get;
            set;
        }
        public string eFileCategory
        {
            get;
            set;
        }

        public string InsuredCode
        {
            get;
            set;
        }

        public string IntermediaryName
        {
            get;
            set;
        }

        public string IntermediaryCode
        {
            get;
            set;
        }
        public string SMName
        {
            get;
            set;
        }

        public string SMCode
        {
            get;
            set;
        }

        public string site_collection_url
        {
            get;
            set;
        }
        public string doc_lib_name
        {
            get;
            set;
        }
        public string efile_name
        {
            get;
            set;
        }
        public string policy_no
        {
            get;
            set;
        }

        public string s3folderUrl
        {
            get;
            set;
        }
        public string s3fileUrl
        {
            get;
            set;
        }
        public string documentset_no
        {
            get;
            set;
        }

        public string case_id
        {
            get;
            set;
        }
        public string DocumentGroup
        {
            get;
            set;
        }
        public string DocumentType
        {
            get;
            set;
        }
        public string DocumentStatus
        {
            get;
            set;
        }
        public string DocumentTitle
        {
            get;
            set;
        }
        public string FileName
        {
            get;
            set;
        }
        public string EndorsementNumber
        {
            get;
            set;
        }
        public string fileUrl
        {
            get;
            set;
        }
        public string s3folderName
        {
            get;
            set;
        }

        public string CreatedByID
        {
            get;
            set;
        }
        public string ModifiedByID
        {
            get;
            set;
        }
        public string EmailTo
        {
            get;
            set;
        }
        public string EmailFrom
        {
            get;
            set;
        }
        public string EmailCC
        {
            get;
            set;
        }
        public string EmailDate
        {
            get;
            set;
        }
        public string Subject
        {
            get;
            set;
        }
        public string ClaimNumber
        {
            get;
            set;
        }
    }
}
