﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DWHDAL
{
    public class ProductMapper
    {
        //for Product code master table details
   
        public string ProductName
        {
            get;
            set;
        }
        public string sourcesytemname
        {
            get;
            set;
        }
        public string lob
        {
            get;
            set;
        }
        public string DocType
        {
            get;
            set;
        }
        public string StartPage
        {
            get;
            set;
        }
        public string EndPage
        {
            get;
            set;
        }

    }
}
