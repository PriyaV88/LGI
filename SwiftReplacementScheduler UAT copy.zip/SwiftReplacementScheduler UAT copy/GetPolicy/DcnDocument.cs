﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulerForAppData
{
    public class DcnDocument
    {
        private string dcnfilename;
        private string dcnfilepath;

        public string PolicyFileName
        {
            get
            {
                return dcnfilename;
            }
            set
            {
                dcnfilename = value;
            }
        }

        public string PolicyFilePath
        {
            get
            {
                return dcnfilepath;
            }
            set
            {
                dcnfilepath = value;
            }
        }
    }
}
