﻿using DWHDAL;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Web;
using System.Drawing;
using System.IO;
using System.Web.UI.HtmlControls;
using Amazon.S3;
using Amazon.S3.Model;
using System.Configuration;

namespace SchedulerForAppData
{
    public static class SharePointEFileUploader
    {
        /// <summary>
        /// Upload file into Document Set
        /// </summary>
        /// <param name="list">List Title</param>
        /// <param name="docSetName">DocumentSet Name</param>
        /// <param name="fileName">File name to upload</param>
        public static IAmazonS3 client;
        public static readonly Amazon.RegionEndpoint bucketRegion = Amazon.RegionEndpoint.USEast2;
        public static string folderUrl = string.Empty;

        public static void UploadFileIntoDocumentSet(AppConfigHandler configurationHandler, EFileMapper metaDataEfile, string sharedocfilepath, string docfileName,string doctypename)
        {
            try
            {
                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                DcnDocument objClaimDoc = new DcnDocument();
                using (var ctx = new ClientContext(metaDataEfile.site_collection_url))
                {
                    var list = ctx.Web.Lists.GetByTitle(metaDataEfile.doc_lib_name);
                    ctx.Load(list.RootFolder);
                    ctx.ExecuteQuery();
                    //get stream using FTP Connector
                    using (var fs = new FileStream(sharedocfilepath, FileMode.Open, FileAccess.Read))
                    {
                        ctx.ExecuteQuery();
                        var fileUrl = string.Empty;
                        docfileName = docfileName.Replace("&", "and");
                        fileUrl = String.Format("{0}/{1}/{2}", list.RootFolder.ServerRelativeUrl, metaDataEfile.efile_name, docfileName);
                        ctx.ExecuteQuery();
                        Microsoft.SharePoint.Client.File.SaveBinaryDirect(ctx, fileUrl, fs, true);
                        Microsoft.SharePoint.Client.File file = ctx.Web.GetFileByServerRelativeUrl(fileUrl);
                        file.ListItemAllFields["EFeFileDocumentGroup"] = "Policy Documentation";
                        file.ListItemAllFields["EFDocumentStatus"] = "Final";
                        file.ListItemAllFields["EFDocumentTitle"] = docfileName.Split('.')[0];
                        file.ListItemAllFields["EFeFileDocumentType"] = doctypename;
                        file.ListItemAllFields["EndorsementNumber"] = "000";
                       // file.ListItemAllFields["ClaimNumber"] = metaDataEfile.ClaimIntNo;
                        file.ListItemAllFields.Update();
                        file.CheckIn("", CheckinType.MajorCheckIn);
                        ctx.Load(file);
                        try
                        {
                            ctx.ExecuteQuery();
                            SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Uploading done successfully...");
                        }
                        catch (Exception ex)
                        {
                            SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error while uploading files:" + ex.Message);
                        }
                    }
                }
            }
            catch
            {
               // ClaimsdataNALog.LogFileWrite(Environment.NewLine + "Log : Info : Uploading failed for ClaimNumber#.. " + metaDataEfile.ClaimIntNo + "  with shareddocfilepath# - " + sharedocfilepath);
            }
        }

        // check Document set exixts on sharepoint or not 
        public static void UploadFileToAWSBucketFolder(AppConfigHandler configurationHandler, EFileMapper metaDataEfile, string sharedocfilepath, string docfileName, string doctypename)
        {
            
            try
            {
                FileInfo fi = new FileInfo(sharedocfilepath);
                string bucketname = metaDataEfile.LOB.ToLower() + ConfigurationManager.AppSettings["s3LobExtension"];
                using (client = new AmazonS3Client(bucketRegion))
                {
                    try
                    {
                        
                        PutObjectRequest request = new PutObjectRequest();
                        //  string bucketname = toWhichBucketName.ToLower() + WebConfigurationManager.AppSettings["s3LobExtension"];
                        request.BucketName = bucketname;
                        // request.ContentBody = contents;
                        //var fs = new FileStream(localFilePath, FileMode.Open, FileAccess.Read);
                        //string path = "Priya123" + "/" + s3filename;

                        String folderKey = metaDataEfile.efile_name + "/" + docfileName;
                        request.Key = folderKey;
                        FileStream fs = new FileStream(sharedocfilepath, FileMode.Open);
                        
                            request.InputStream = fs;
                        
                        // folderRequest.InputStream = new MemoryStream(new byte[0]);
                        PutObjectResponse folderResponse = client.PutObject(request);
                    }
                    catch (AmazonS3Exception e)
                    {
                        Console.WriteLine("file upload has failed.");
                        Console.WriteLine("Amazon error code: {0}",
                            string.IsNullOrEmpty(e.ErrorCode) ? "None" : e.ErrorCode);
                        Console.WriteLine("Exception message: {0}", e.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error while uploading files:" + ex.Message);
            }
        }

        public static void CreateNewEFile(AppConfigHandler configurationHandler, EFileMapper currentEfile,string dcn)
        {

            HttpWebRequest req = null;
            HttpWebResponse res = null;

            try
            {
                //string url = t
                string url = configurationHandler.serviceurl;
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "url=" + url);
                req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/xml; charset=utf-8";
                req.Timeout = 300000;
                req.PreAuthenticate = true;
                req.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd, "lvgi");
                
                DateTime PolicyInceptionDate;
                DateTime PolicyExpiryDate;
                
                PolicyInceptionDate = Convert.ToDateTime(currentEfile.PolicyInceptionDate);
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "PolicyInceptionDate= " + PolicyInceptionDate);
                PolicyExpiryDate = Convert.ToDateTime(currentEfile.PolicyExpiryDate);
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "PolicyExpiryDate= " + PolicyExpiryDate);
                string[] formats = { "MM/dd/yyyy" };
                if ((currentEfile.LOB == "Marine") || (currentEfile.LOB == "Marine Cargo"))
                {
                    currentEfile.LOB = "Marine_Cargo";
                }
                if ((currentEfile.LOB == "Miscellaneous - Package") || (currentEfile.LOB == "Miscellaneous"))
                {
                    currentEfile.LOB = "Misc";
                }
                if (currentEfile.LOB == "Engineering")
                {
                    currentEfile.LOB = "ENGG";
                }
                if (currentEfile.LOB == "Personal Accident")
                {
                    currentEfile.LOB = "Personal_Accident";
                }
                if (currentEfile.Company.Trim() == string.Empty)
                {
                    currentEfile.Company = "LVGI";
                }
                if (currentEfile.Function.Trim() == string.Empty)
                {
                    currentEfile.Function = "uploadDocumentECM";
                }
                if (currentEfile.eFileCategory.Trim() == string.Empty)
                {
                    currentEfile.eFileCategory = "Policy";
                }
                if (currentEfile.RiskLocation.Trim() == string.Empty)
                {
                    currentEfile.RiskLocation = "India";
                }
                if (currentEfile.MasterStatus.Trim() == string.Empty)
                {
                    currentEfile.MasterStatus = "Intimated";
                }
                if (currentEfile.IntermediaryName.Length >= 35)
                {
                    currentEfile.IntermediaryName = currentEfile.IntermediaryName.Remove(34);
                }

                if (currentEfile.RiskLocation.Length >= 26)
                {
                    currentEfile.RiskLocation = currentEfile.RiskLocation.Remove(25);
                }
                if (currentEfile.PolicyYear == string.Empty)
                {
                    currentEfile.PolicyYear = PolicyInceptionDate.ToString("yyyy",CultureInfo.InvariantCulture);
                }
               

                string sXml = @"<RequestData >
                  <EntityInformation Type='Underwriting'>
                  <MetadataProperties>
		          <MetadataProperty Name='LOB' Value='" + currentEfile.LOB + "' />" +
                  "<MetadataProperty Name='Product' Value='" + currentEfile.Product.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='PolicyNumber' Value='" + currentEfile.PolicyNo + "' />" +
                  "<MetadataProperty Name='Country' Value='" + currentEfile.Country + "' />" +
                  "<MetadataProperty Name='InsuredName' Value='" + currentEfile.InsuredName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='PolicyYear' Value='" + currentEfile.PolicyYear + "' />" +
                  "<MetadataProperty Name='UWStage' Value='" + currentEfile.UWStage + "' />" +
                 // "<MetadataProperty Name='PolicyInceptionDate' Value='01/29/2013' /> " +
                 //" <MetadataProperty Name='PolicyExpiryDate' Value= '08/31/2016' />" +
                  "<MetadataProperty Name='PolicyInceptionDate' Value='" + PolicyInceptionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) + "' /> " +// MM/dd/yyyy 11/29/2015
                  "<MetadataProperty Name='PolicyExpiryDate' Value='" + PolicyExpiryDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) + "' />" +
                  "<MetadataProperty Name='Company' Value='" + currentEfile.Company + "' />" +
                  "<MetadataProperty Name='BranchName' Value='" + currentEfile.BranchName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='BranchCode' Value='" + currentEfile.BranchCode + "' />" +
                  "<MetadataProperty Name='QuoteNumber' Value='" + currentEfile.QuoteNumber.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null) + "' />" +
                  "<MetadataProperty Name='BatchNumber' Value='" + currentEfile.BatchNumber.Replace("&", "and") + "' />" +
                  "<MetadataProperty Name='Zone' Value='" + currentEfile.Zone + "' />" +
                  "<MetadataProperty Name='SourceSystemName' Value='" + currentEfile.SourceSystemName + "' />" +
                  "<MetadataProperty Name='CaseId' Value='" + currentEfile.CaseId + "' />" +
                  "<MetadataProperty Name='PreviousPolicyNumber' Value='" + currentEfile.PreviousPolicyNumber + "' />" +
                  "<MetadataProperty Name='Underwriter' Value='" + currentEfile.Underwriter + "' />" +
                  "<MetadataProperty Name='UnderwritingAssistant' Value='" + currentEfile.UnderwritingAssistant + "' />" +
                  "<MetadataProperty Name='MasterStatus' Value='" + currentEfile.MasterStatus + "' />" +
                  "<MetadataProperty Name='Function' Value='" + currentEfile.Function.Replace("&", "and") + "' />" +
                  "<MetadataProperty Name='RiskLocation' Value='" + currentEfile.RiskLocation.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='IsConfidential' Value='" + currentEfile.IsConfidential + "' />" +
                  "<MetadataProperty Name='eFileCategory' Value='" + currentEfile.eFileCategory + "' />" +
                  "<MetadataProperty Name='InsuredCode' Value='" + currentEfile.InsuredCode + "' />" +
                  "<MetadataProperty Name='IntermediaryName' Value='" + currentEfile.IntermediaryName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='IntermediaryCode' Value='" + currentEfile.IntermediaryCode + "' />" +
                  "<MetadataProperty Name='SMName' Value='" + currentEfile.SMName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='SMCode' Value='" + currentEfile.SMCode + "' />" +
                  "</MetadataProperties >" +
                  "</EntityInformation>" +
                  "</RequestData>";
               
                req.ContentLength = sXml.Length;
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Efile request data: " + sXml);
                var sw = new StreamWriter(req.GetRequestStream());
                sw.Write(sXml);
                sw.Close();

                res = (HttpWebResponse)req.GetResponse();
                Stream responseStream = res.GetResponseStream();
                var streamReader = new StreamReader(responseStream);

                //Read the response into an xml document
                var soapResonseXmlDocument = new XmlDocument();
                soapResonseXmlDocument.LoadXml(streamReader.ReadToEnd());

                //return only the xml representing the response details (inner request)
                string successString = soapResonseXmlDocument.InnerXml;
                SwiftReplacementDcnDataLogError.LogFileWrite("Log : Info : Successstring" + successString);
            }
            catch (Exception ex)
            {
                SwiftReplacementDcnDataLogError.LogFileWrite("Error while creating efile for dcn:" + dcn + ex.Message);
                
            }

            string error = "Error in creating new efile";
            SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, currentEfile.PolicyFTPPath, configurationHandler, error);
        }


        //public string GetFilePath()
        //{
        //    return HttpContext.Current.Server.MapPath("/UploadedFiles");
        //}
        public  static String[] SplitFile(AppConfigHandler configurationHandler,String file_name, string imageId,string destlocn)
        {
            string Splitimagepath = destlocn + "\\Split_Files";
          //  Splitimagepath = HttpContext.Current.Server.MapPath(Splitimagepath);
            if (!Directory.Exists(Splitimagepath))
            {
                Directory.CreateDirectory(Splitimagepath);
            }
            System.Drawing.Image imageFile;
            imageFile = System.Drawing.Image.FromFile(file_name);
            System.Drawing.Imaging.FrameDimension frameDimensions = new System.Drawing.Imaging.FrameDimension(imageFile.FrameDimensionsList[0]);
            int NumberOfFrames = imageFile.GetFrameCount(frameDimensions);
            string[] paths = new string[NumberOfFrames];
            for (int intFrame = 0; intFrame < NumberOfFrames; ++intFrame)
            {
                imageFile.SelectActiveFrame(frameDimensions, intFrame);
                Bitmap bmp = new Bitmap(imageFile);
                paths[intFrame] = Splitimagepath + @"\" + imageId + "_" + intFrame.ToString() + ".tif";
                bmp.Save(paths[intFrame], System.Drawing.Imaging.ImageFormat.Tiff);
                bmp.Dispose();
            }
            imageFile.Dispose();
            return paths;
        }

        public static void TiffPageExtract(AppConfigHandler configurationHandler,string fileName, string destination, string StartPage, string endPage, string[] inputPath)
        {
            //if (!Directory.Exists(HttpContext.Current.Server.MapPath("Temp")))
            //    Directory.CreateDirectory(HttpContext.Current.Server.MapPath("Temp"));
            string temppath = configurationHandler.sharedrivepath + configurationHandler.appfoldername + "\\Temp";
            //  Splitimagepath = HttpContext.Current.Server.MapPath(Splitimagepath);
            if (!Directory.Exists(temppath))
            {
                Directory.CreateDirectory(temppath);
            }
            TiffUtil.TiffUtil tiffUtilObj = new TiffUtil.TiffUtil(temppath);
            string outfile = destination;
            int counter = 0;
            int startPage = Int32.Parse(StartPage);
            int EndPage = Int32.Parse(endPage);
            if(inputPath.Length >= EndPage)
            {
                string[] FileNamerray = new string[EndPage - startPage + 1];

                for (int j = startPage; j <= EndPage; j++)
                {
                    FileNamerray[counter++] = inputPath[j - 1];
                }
                tiffUtilObj.mergeTiffPages(FileNamerray, destination);
            }
            else
            {
                string[] FileNamerray = new string[inputPath.Length - startPage + 1];

                for (int j = startPage; j <= inputPath.Length; j++)
                {
                    FileNamerray[counter++] = inputPath[j - 1];
                }
                tiffUtilObj.mergeTiffPages(FileNamerray, destination);
            }
        }

       

        #region 
        //Delete files if they are already exists
        public static void FileDelete(string[] filePath)
        {
            try
            {
                for (int counter = 0; counter < filePath.Length; counter++)
                {
                   System.IO.File.Delete(filePath[counter]);
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //logger.Info("ReScanImageUpload : Problem in FileDelete event : " + ex.ToString() + "\n");
            }
        }
        #endregion
    }
}
