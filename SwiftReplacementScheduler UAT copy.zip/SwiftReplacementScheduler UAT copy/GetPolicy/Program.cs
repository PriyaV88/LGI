﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using DWHDAL;
using System.Globalization;
using System.Data;
using System.Configuration;

namespace SchedulerForAppData
{
    public class Program
    {
        public static void Main(string[] args)
         {
            AppConfigHandler configurationHandler = new AppConfigHandler();

            try
            {

                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                DWHDAL.DWHDAL newDAL = new DWHDAL.DWHDAL();
                List<DcnDocument> DCNNumbers = new List<DcnDocument>();
                string SchedulerStartdatetime = DateTime.Now.ToString();
              string[] DCNProcessed = newConnector.GetDCNNumbers(newConnector.configurationHandler);
                SwiftReplacementDcnDataLogError.LogFileWrite(DateTime.Now + "Total files count = " + DCNProcessed.Length.ToString());
                
                int PCounter = 0;
                int RCounter = 0;
                    //1. Metadata
              if (DCNProcessed != null && DCNProcessed.Length > 0)
                        {
                            foreach (var item in DCNProcessed)
                            {
                                
                               
                                try
                                {
                                    PCounter++;
                                    //Console.WriteLine(PCounter);
                                    string currentEfileUrl = string.Empty;
                                    EFileMapper eFilePath = new EFileMapper();
                                    EFileMapper eFiles = new EFileMapper();
                                    
                                    //1. Metadata
                                   
                                     string dcn = item.ToString();
                                   // string dcn = "20180708400401900004";
                                  //  string dcn = "2016052840050110041";
                                     char[] array = dcn.ToCharArray();
                                     char sixth = dcn[dcn.Length - 6];
                                     if (sixth.ToString() == "9")
                                     {
                                         // eFilePath = newDAL.GetDCNMetaDatafromHBView(dcn); //HB view
                                         eFilePath = newDAL.GetDCNMetaDatafromHBView(dcn);
                                     }
                                     else
                                     {
                                         eFilePath = newDAL.GetDcnMetaDatafromGCView(dcn); //GC view
                                     }

                                           // eFilePath = newDAL.GetDCNMetaData(dcn);
                                   // eFiles.PolicyFilePath = item.PolicyFilePath;
                                   
                                   if (eFilePath == null)
                                 {
                                     SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "DCN:- " + dcn);
                                   string error = "Policy Metadata not found";
                                    SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Policy Metadata not found" + dcn);
                                    SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                 }

                                    else
                                    {
                                         //2.SharePoint EFIle Path
                                        eFiles = newDAL.GetPolicySharepointFileURL(dcn, eFilePath);
                                        
                                        if (eFiles != null)
                                        {
                                           //if (string.IsNullOrEmpty(eFiles.ProductCode))
                                            
                                            //eFiles.ShareDrivePath = item.PolicyFilePath;
                                            if (string.IsNullOrEmpty(eFiles.site_collection_url))
                                            {
                                                try
                                                {
                                                    SharePointEFileUploader.CreateNewEFile(newConnector.configurationHandler, eFiles,dcn);
                                                }
                                                catch
                                                {
                                                    SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                                   string error = "Error in creating new efile";
                                                   SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                                   SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Error in creating new efile of DCN#" + dcn);
                                                }
                                            }
                                        
                                            //4.newly created EFIle Path from step 3
                                            eFiles = newDAL.GetPolicySharepointFileURL(dcn, eFiles);


                                            //5.if exist or new Upload Docs in doc set url from step 2
                                            try
                                            {
                                                // get the policy number 
                                                // get the dcouemtn by policy number 
                                                //upload the file to efile 
                                                UploadProcess(configurationHandler, eFiles,dcn);
                                                RCounter++;
                                            }
                                            catch (Exception ex)
                                            {
                                                //throw ex;
                                                SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                                //string error = "Error in uploading document";
                                                //SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);

                                            }

                                           // SwiftReplacementSolutionEfileCount.LogPolicyToDB(eFiles, configurationHandler,dcn); //PDF pushed --> path including filename
                                            SwiftReplacementDcnDataLogError.LogFileWrite("Log : Info : Logging Done.. EFile Details to DWH  #" + PCounter + " Policy Document #" + eFiles.PolicyFileName);//how many folders processe
                                        
                                        }

                                        else
                                        {
                                            SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                            SwiftReplacementDcnDataLogError.LogFileWrite("Log : Info : Policy metadata not found From DWH #" + PCounter);
                                            string error = "Metadata not found from DWH";
                                            SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                        }


                                    }

                                   
                             }
                                catch (Exception ex)
                                {
                                    SwiftReplacementDcnDataLogError.LogFileWrite("Log : Error : Processing Policy Documents  " + item + Environment.NewLine
                                                  + ex.InnerException.Message + Environment.NewLine + ex.StackTrace);//how many folders processe
                                    continue;
                                    //throw ex;
                                }
                            }
                            SwiftReplacementSolutionEfileCount.LogFileWrite(DateTime.Now + "No. of files uploaded = " + RCounter);
                           string DocCount = DCNProcessed.Length.ToString();
                           string TotalDocsUploaded = RCounter.ToString();
                           string FailedDocsCount = TotalDocsUploaded.Replace(DocCount, "");
                            string SchedulerEnddatetime = DateTime.Now.ToString();
                            SwiftReplacementSolutionEfileCount.ProcessedDataLogToDB(DocCount, FailedDocsCount,TotalDocsUploaded, configurationHandler, SchedulerStartdatetime, SchedulerEnddatetime);
                        }
                  
            }
            catch (Exception ex)
            {
                SwiftReplacementDcnDataLogError.LogFileWrite("Log : Error : Processing Whole Policy Document" + Environment.NewLine
                   + ex.InnerException.Message + Environment.NewLine + ex.StackTrace);
               // throw ex;
            }
        }
  

     private static void UploadProcess(AppConfigHandler configurationHandler, EFileMapper eFiles, string dcn)
        {
            UploadDocuments(configurationHandler, eFiles,dcn);

        }
     private static void UploadDocuments(AppConfigHandler configurationHandler, EFileMapper eFiles, string dcn)
        {
            int documentFileNo = 0;
            try
            {
                var fileUrl = string.Empty;
                bool uploadSuccess = false;
                List<string> allDocfiles = new List<string>();
                List<string> allOutputfiles = new List<string>();
                List<string> doctypeFolders = new List<string>();
                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                DWHDAL.DWHDAL newDAL = new DWHDAL.DWHDAL();
                allDocfiles = newConnector.GetallfilesofCurrentFolder(dcn);

                if (string.IsNullOrEmpty(eFiles.ProductCode))
                // if (eFiles.ProductCode == "null")
                {

                    if (allDocfiles != null)
                    {
                        foreach (var docitem in allDocfiles)
                        {

                            string docfilepath = docitem + "\\";
                            string policyfileName = System.IO.Path.GetDirectoryName(docfilepath).Split('\\').LastOrDefault();
                            docfilepath = docfilepath.TrimEnd('\\');

                            //string[] val = policyfileName.Split('.');
                            //fileUrl = docitem + "." + val[val.Length - 1];
                            fileUrl = System.IO.Path.GetDirectoryName(docfilepath);
                            string DocFolderName = System.IO.Path.GetDirectoryName(fileUrl + "\\").Split('\\').LastOrDefault();
                            string sourceLocation = fileUrl;
                            string DestLocation = fileUrl + "\\" + "Output";
                            MoveFileToOutputDirectory(sourceLocation, DestLocation, dcn, policyfileName);

                            allOutputfiles = newConnector.GetallfilesofOutputFolder(DestLocation);

                            foreach (var outdocitem in allOutputfiles)
                            {
                                uploadSuccess = false;
                                string sharedocfilepath = outdocitem + "\\";
                                string DocfileName = System.IO.Path.GetDirectoryName(sharedocfilepath).Split('\\').LastOrDefault();
                                sharedocfilepath = sharedocfilepath.TrimEnd('\\');

                                try
                                {
                                    if (!string.IsNullOrEmpty(eFiles.site_collection_url))
                                    {
                                        SharePointEFileUploader.UploadFileIntoDocumentSet(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                        uploadSuccess = true;
                                    }
                                    else
                                    {
                                        SharePointEFileUploader.UploadFileToAWSBucketFolder(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                        uploadSuccess = true;
                                        eFiles.s3fileUrl = eFiles.s3folderUrl + DocfileName;
                                        uploadSuccess = true;
                                        AWSEfileMapper docmetadata = new AWSEfileMapper();
                                        documentFileNo = newDAL.InsertAWSDocumentMDtoDb(eFiles, docmetadata, eFiles.s3fileUrl, DocfileName);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //throw ex;
                                    if (!uploadSuccess)
                                    {
                                        if (Directory.Exists(DestLocation))
                                        {
                                            System.IO.DirectoryInfo extractdirectory = new DirectoryInfo(DestLocation + "\\");

                                            foreach (FileInfo file in extractdirectory.GetFiles())
                                            {

                                                if (DocfileName.Contains(file.Name))
                                                {
                                                    file.Delete();
                                                }
                                            }
                                        }
                                    }
                                    SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                    string error = "Error in uploading document";
                                    SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                }
                                eFiles.ShareDrivePath = sharedocfilepath;
                                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading done for Policy# - " + dcn + " with shareddocfilepath# - " + sharedocfilepath);
                                SwiftReplacementSolutionEfileCount.LogPolicyToDB(eFiles, configurationHandler, dcn);
                                //AllDocsuploadSuccess = true;
                                if (uploadSuccess)
                                {
                                    string sourcePath = configurationHandler.sharedrivepath + configurationHandler.appfoldername;
                                    string DestPath = configurationHandler.sharedrivepath + @"\\Archive\\" + configurationHandler.appfoldername;
                                    if (!System.IO.Directory.Exists(DestPath))
                                    {
                                        System.IO.Directory.CreateDirectory(DestPath);
                                    }
                                    foreach (string dirPath in Directory.GetDirectories(sourcePath, "*", SearchOption.AllDirectories))
                                        Directory.CreateDirectory(dirPath.Replace(sourcePath, DestPath));

                                    ////Copy all the files & Replaces any files with the same name
                                    // foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
                                    //    File.Copy(newPath, newPath.Replace(sourcePath, DestPath), true);

                                    if (!System.IO.Directory.Exists(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output"))
                                    {
                                        System.IO.Directory.CreateDirectory(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output");
                                    }
                                    string destFile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output" + "//", DocfileName);
                                    System.IO.File.Copy(sharedocfilepath, destFile, true);
                                   string sourcefile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName  + "//", policyfileName);
                                   System.IO.File.Copy(docfilepath, sourcefile, true);
                                   File.Delete(sharedocfilepath);
                                   File.Delete(docfilepath);
                                   string[] TXTFiles = Directory.GetFiles(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                   if (TXTFiles.Length == 0)
                                   {
                                       Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName + "\\" + "Output");
                                       Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                       Directory.Delete(sourcePath + "\\" + dcn);
                                   }
                                }
                                //PDF pushed --> path including filename
                            }

                        }

                    }   
                }
                else
                {
                    //get doc type by product code from shared folder
                    string[] alldoctypeFolders = newConnector.GetalldoctypeFolders(newConnector.configurationHandler, dcn);

                    foreach (var docCategoryitem in alldoctypeFolders)
                    {

                        string DocFolderName = System.IO.Path.GetDirectoryName(docCategoryitem + "\\").Split('\\').LastOrDefault();
                        //get input details start and end page from db by doc type and product code
                        string productcode = eFiles.ProductCode;
                        string lob = eFiles.LOB;
                        string sourcePath = configurationHandler.sharedrivepath + configurationHandler.appfoldername;
                        EFileMapper DocTypedetails = new EFileMapper();
                        DataTable ProductCodetable = new DataTable();
                        ProductCodetable = newDAL.GetProductCodeMetaData(productcode, docCategoryitem, lob, eFiles);

                        if (ProductCodetable.Rows.Count == 0)
                        {
                            allDocfiles = newConnector.GetallfilesofCurrentFolder(dcn);
                            if (allDocfiles != null)
                            {
                                foreach (var docitem in allDocfiles)
                                {

                                    string docfilepath = docitem + "\\";
                                    string policyfileName = System.IO.Path.GetDirectoryName(docfilepath).Split('\\').LastOrDefault();
                                    docfilepath = docfilepath.TrimEnd('\\');
                                    // eFiles.DocFilePath = docfilepath;
                                    //string[] val = policyfileName.Split('.');
                                    //fileUrl = docitem + "." + val[val.Length - 1];
                                    fileUrl = System.IO.Path.GetDirectoryName(docfilepath);
                                    string DocsFolderName = System.IO.Path.GetDirectoryName(fileUrl + "\\").Split('\\').LastOrDefault();
                                    string sourceLocation = fileUrl;
                                    string DestLocation = fileUrl + "\\" + "Output";
                                    MoveFileToOutputDirectory(sourceLocation, DestLocation, dcn, policyfileName);

                                    allOutputfiles = newConnector.GetallfilesofOutputFolder(DestLocation);

                                    foreach (var outdocitem in allOutputfiles)
                                    {
                                        uploadSuccess = false;
                                        string sharedocfilepath = outdocitem + "\\";
                                        string DocfileName = System.IO.Path.GetDirectoryName(sharedocfilepath).Split('\\').LastOrDefault();
                                        sharedocfilepath = sharedocfilepath.TrimEnd('\\');

                                        try
                                        {
                                            if (!string.IsNullOrEmpty(eFiles.site_collection_url))
                                            {
                                                SharePointEFileUploader.UploadFileIntoDocumentSet(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                                uploadSuccess = true;
                                            }
                                            else
                                            {
                                                SharePointEFileUploader.UploadFileToAWSBucketFolder(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                                uploadSuccess = true;
                                                eFiles.s3fileUrl = ConfigurationManager.AppSettings["AWSConsoleUrl"] + eFiles.s3folderUrl + "/" + DocfileName;
                                                uploadSuccess = true;
                                                AWSEfileMapper docmetadata = new AWSEfileMapper();
                                                documentFileNo = newDAL.InsertAWSDocumentMDtoDb(eFiles, docmetadata, eFiles.s3fileUrl, DocfileName);
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            //throw ex;
                                            if (!uploadSuccess)
                                            {
                                                if (Directory.Exists(DestLocation))
                                                {
                                                    System.IO.DirectoryInfo extractdirectory = new DirectoryInfo(DestLocation + "\\");

                                                    foreach (FileInfo file in extractdirectory.GetFiles())
                                                    {

                                                        if (DocfileName.Contains(file.Name))
                                                        {
                                                            file.Delete();
                                                        }
                                                    }
                                                }
                                            }
                                            SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                            string error = "Error in uploading document";
                                            SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                        }
                                        eFiles.ShareDrivePath = sharedocfilepath;
                                        SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading done for Policy# - " + dcn + " with shareddocfilepath# - " + sharedocfilepath);
                                        SwiftReplacementSolutionEfileCount.LogPolicyToDB(eFiles, configurationHandler, dcn);
                                        //AllDocsuploadSuccess = true;
                                        if (uploadSuccess)
                                        {
                                            //  string sourcePath = configurationHandler.sharedrivepath + configurationHandler.appfoldername;
                                            string DestPath = configurationHandler.sharedrivepath + @"\\Archive\\" + configurationHandler.appfoldername;
                                            if (!System.IO.Directory.Exists(DestPath))
                                            {
                                                System.IO.Directory.CreateDirectory(DestPath);
                                            }
                                            foreach (string dirPath in Directory.GetDirectories(sourcePath, "*", SearchOption.AllDirectories))
                                                Directory.CreateDirectory(dirPath.Replace(sourcePath, DestPath));

                                            ////Copy all the files & Replaces any files with the same name
                                            // foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
                                            //    File.Copy(newPath, newPath.Replace(sourcePath, DestPath), true);

                                            if (!System.IO.Directory.Exists(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output"))
                                            {
                                                System.IO.Directory.CreateDirectory(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output");
                                            }
                                            string destFile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output" + "//", DocfileName);
                                            System.IO.File.Copy(sharedocfilepath, destFile, true);
                                            string sourcefile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "//", policyfileName);
                                            System.IO.File.Copy(docfilepath, sourcefile, true);
                                            File.Delete(sharedocfilepath);
                                            File.Delete(docfilepath);
                                            string[] TXTFiles = Directory.GetFiles(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                            if (TXTFiles.Length == 0)
                                            {
                                                Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName + "\\" + "Output");
                                                Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                                Directory.Delete(sourcePath + "\\" + dcn);
                                            }
                                        }
                                        //PDF pushed --> path including filename
                                    }
//-----
                                }

                            }
                        }
                        else
                        {
                            foreach (DataRow row in ProductCodetable.Rows)
                            {
                                eFiles.ProductName = row["ProductName"].ToString();
                                eFiles.lob = row["LOB"].ToString();
                                eFiles.sourcesytemname = row["SourceSystemName"].ToString();
                                eFiles.DocType = row["DocumentType"].ToString();
                                eFiles.StartPage = row["StartPage"].ToString();
                                eFiles.EndPage = row["EndPage"].ToString();
                                

                                //  DocTypedetails = newDAL.GetProductCodeDetails(productcode, docCategoryitem, eFiles);
                                // if Doctypedetails null or empty 
                                //Since indexing for RFQ not present as of now. remove later
                                if (eFiles.DocType != "RFQ")
                                {

                                allDocfiles = newConnector.GetallfilesofdoctypeFolder(dcn, docCategoryitem);
                                if (allDocfiles != null)
                                {
                                    foreach (var docitem in allDocfiles)
                                    {

                                        string docfilepath = docitem + "\\";
                                        string policyfileName = System.IO.Path.GetDirectoryName(docfilepath).Split('\\').LastOrDefault();
                                        string FinalFilename = policyfileName.Split(new char[] { '.' })[0];
                                        string FileExtension = policyfileName.Split(new char[] { '.' })[1];
                                        //string FileExtension = Path.GetExtension(policyfileName);
                                        docfilepath = docfilepath.TrimEnd('\\');
                                        eFiles.DocFilePath = docfilepath;
                                        fileUrl = System.IO.Path.GetDirectoryName(docfilepath);
                                        string DocsFolderName = System.IO.Path.GetDirectoryName(fileUrl + "\\").Split('\\').LastOrDefault();
                                        //string sourceLocation = fileUrl;
                                        string sourceLocation = fileUrl;
                                        string DestLocation = fileUrl + "\\Output";
                                        //  string destFilepath = fileUrl + "\\Output" + "\\" + dcn + "_" + FinalFilename + "_" + eFiles.DocType + ".tif";
                                        if (FileExtension != "tif")
                                        {
                                       MoveFileToOutputDirectory(sourceLocation, DestLocation, dcn, policyfileName);

                                    allOutputfiles = newConnector.GetallfilesofOutputFolder(DestLocation);

                                    foreach (var outdocitem in allOutputfiles)
                                    {
                                        uploadSuccess = false;
                                        string sharedocfilepath = outdocitem + "\\";
                                        string DocfileName = System.IO.Path.GetDirectoryName(sharedocfilepath).Split('\\').LastOrDefault();
                                        sharedocfilepath = sharedocfilepath.TrimEnd('\\');

                                        try
                                        {
                                          if (!string.IsNullOrEmpty(eFiles.site_collection_url))
                                             {
                                              SharePointEFileUploader.UploadFileIntoDocumentSet(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                               uploadSuccess = true;
                                             }
                                            else
                                             {
                                                SharePointEFileUploader.UploadFileToAWSBucketFolder(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                                uploadSuccess = true;
                                                eFiles.s3fileUrl = ConfigurationManager.AppSettings["AWSConsoleUrl"] + eFiles.s3folderUrl + "/" + DocfileName;
                                               uploadSuccess = true;
                                                AWSEfileMapper docmetadata = new AWSEfileMapper();
                                               documentFileNo = newDAL.InsertAWSDocumentMDtoDb(eFiles, docmetadata, eFiles.s3fileUrl,DocfileName);
                                             }
                                         }
                                        catch (Exception ex)
                                        {
                                            //throw ex;
                                            if (!uploadSuccess)
                                            {
                                                if (Directory.Exists(DestLocation))
                                                {
                                                    System.IO.DirectoryInfo extractdirectory = new DirectoryInfo(DestLocation + "\\");

                                                    foreach (FileInfo file in extractdirectory.GetFiles())
                                                    {

                                                        if (DocfileName.Contains(file.Name))
                                                        {
                                                            file.Delete();
                                                        }
                                                    }
                                                }
                                            }
                                            SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                            string error = "Error in uploading document";
                                            SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                        }
                                        eFiles.ShareDrivePath = sharedocfilepath;
                                        SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading done for Policy# - " + dcn + " with shareddocfilepath# - " + sharedocfilepath);
                                        SwiftReplacementSolutionEfileCount.LogPolicyToDB(eFiles, configurationHandler, dcn);
                                        //AllDocsuploadSuccess = true;
                                        if (uploadSuccess)
                                        {
                                            //  string sourcePath = configurationHandler.sharedrivepath + configurationHandler.appfoldername;
                                            string DestPath = configurationHandler.sharedrivepath + @"\\Archive\\" + configurationHandler.appfoldername;
                                            if (!System.IO.Directory.Exists(DestPath))
                                            {
                                                System.IO.Directory.CreateDirectory(DestPath);
                                            }
                                            foreach (string dirPath in Directory.GetDirectories(sourcePath, "*", SearchOption.AllDirectories))
                                                Directory.CreateDirectory(dirPath.Replace(sourcePath, DestPath));

                                            ////Copy all the files & Replaces any files with the same name
                                            // foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
                                            //    File.Copy(newPath, newPath.Replace(sourcePath, DestPath), true);

                                            if (!System.IO.Directory.Exists(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output"))
                                            {
                                                System.IO.Directory.CreateDirectory(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output");
                                            }
                                            string destFile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output" + "//", DocfileName);
                                            System.IO.File.Copy(sharedocfilepath, destFile, true);
                                            string sourcefile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "//", policyfileName);
                                            System.IO.File.Copy(docfilepath, sourcefile, true);
                                            File.Delete(sharedocfilepath);
                                            File.Delete(docfilepath);
                                            string[] TXTFiles = Directory.GetFiles(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                            if (TXTFiles.Length == 0)
                                            {
                                                Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName + "\\" + "Output");
                                                Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                                Directory.Delete(sourcePath + "\\" + dcn);
                                            }
                                        }
                                        //PDF pushed --> path including filename
                                    }
                                        }

                                        else
                                        {
                                        string destFilepath = fileUrl + "\\Output" + "\\" + FinalFilename + "_" + eFiles.DocType + ".tif";
                                        // SharePointEFileUploader.showimage(policyfileName, docfilepath)

                                        //iterate input details with TiffPageExtract --> add reference tifUtils
                                        String[] filePath = SharePointEFileUploader.SplitFile(newConnector.configurationHandler, docfilepath, policyfileName, DestLocation);

                                        SharePointEFileUploader.TiffPageExtract(newConnector.configurationHandler, docfilepath, destFilepath, eFiles.StartPage, eFiles.EndPage, filePath);

                                        SharePointEFileUploader.FileDelete(filePath);
                                        Directory.Delete(DestLocation + "\\Split_Files");
                                        Directory.Delete(configurationHandler.sharedrivepath + configurationHandler.appfoldername + "\\Temp");
                                        allOutputfiles = newConnector.GetallfilesofOutputFolder(DestLocation);

                                        foreach (var outdocitem in allOutputfiles)
                                        {
                                            uploadSuccess = false;
                                            string sharedocfilepath = outdocitem + "\\";
                                            string DocfileName = System.IO.Path.GetDirectoryName(sharedocfilepath).Split('\\').LastOrDefault();
                                            sharedocfilepath = sharedocfilepath.TrimEnd('\\');

                                            try
                                            {
                                                        if (!string.IsNullOrEmpty(eFiles.site_collection_url))
                                                        {
                                                            SharePointEFileUploader.UploadFileIntoDocumentSet(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                                            uploadSuccess = true;
                                                        }
                                                        else
                                                        {
                                                            SharePointEFileUploader.UploadFileToAWSBucketFolder(configurationHandler, eFiles, sharedocfilepath, DocfileName, DocFolderName);
                                                            eFiles.s3fileUrl = ConfigurationManager.AppSettings["AWSConsoleUrl"] + eFiles.s3folderUrl + "/" + DocfileName;
                                                            uploadSuccess = true;
                                                            AWSEfileMapper docmetadata = new AWSEfileMapper();
                                                            documentFileNo = newDAL.InsertAWSDocumentMDtoDb(eFiles, docmetadata, eFiles.s3fileUrl, DocfileName);
                                                        }
                                                    }
                                            catch (Exception ex)
                                            {
                                                //throw ex;
                                                if (!uploadSuccess)
                                                {
                                                    if (Directory.Exists(DestLocation))
                                                    {
                                                        System.IO.DirectoryInfo extractdirectory = new DirectoryInfo(DestLocation + "\\");

                                                        foreach (FileInfo file in extractdirectory.GetFiles())
                                                        {

                                                            if (DocfileName.Contains(file.Name))
                                                            {
                                                                file.Delete();
                                                            }
                                                        }
                                                    }
                                                }
                                                SwiftReplacementDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                                string error = "Error in uploading document";
                                                SwiftReplacementSolutionEfileCount.LogFailureErrorToDB(dcn, eFiles.ShareDrivePath, configurationHandler, error);
                                            }
                                            eFiles.ShareDrivePath = sharedocfilepath;
                                            SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading done for Policy# - " + dcn + " with shareddocfilepath# - " + sharedocfilepath);
                                            SwiftReplacementSolutionEfileCount.LogPolicyToDB(eFiles, configurationHandler, dcn);
                                            if (uploadSuccess)
                                            {
                                                //string sourcePath = configurationHandler.sharedrivepath + configurationHandler.appfoldername;
                                                string DestPath = configurationHandler.sharedrivepath + @"\\Archive\\" + configurationHandler.appfoldername;
                                                if (!System.IO.Directory.Exists(DestPath))
                                                {
                                                    System.IO.Directory.CreateDirectory(DestPath);
                                                }
                                                foreach (string dirPath in Directory.GetDirectories(sourcePath, "*", SearchOption.AllDirectories))
                                                    Directory.CreateDirectory(dirPath.Replace(sourcePath, DestPath));

                                                ////Copy all the files & Replaces any files with the same name
                                                // foreach (string newPath in Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories))
                                                //    File.Copy(newPath, newPath.Replace(sourcePath, DestPath), true);

                                                if (!System.IO.Directory.Exists(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output"))
                                                {
                                                    System.IO.Directory.CreateDirectory(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output");
                                                }
                                                string destFile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "\\Output" + "//", DocfileName);
                                                System.IO.File.Copy(sharedocfilepath, destFile, true);
                                                string sourcefile = System.IO.Path.Combine(DestPath + "\\" + dcn + "\\" + DocFolderName + "//", policyfileName);
                                                System.IO.File.Copy(docfilepath, sourcefile, true);
                                                File.Delete(sharedocfilepath);
                                                //  File.Delete(docfilepath);

                                            }

                                            //PDF pushed --> path including filename
                                        }
                                    }
                                    }

                                }

                            }
                            }
                            File.Delete(eFiles.DocFilePath);
                            string[] TextFiles = Directory.GetFiles(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                            if (TextFiles.Length == 0)
                            {
                                Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName + "\\" + "Output");
                                Directory.Delete(sourcePath + "\\" + dcn + "\\" + DocFolderName);
                                Directory.Delete(sourcePath + "\\" + dcn);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SwiftReplacementDcnDataLogError.LogFileWrite("Log : Error : Uploading document " + Environment.NewLine
                           + ex.InnerException.Message + Environment.NewLine + ex.StackTrace);
                //throw ex;
            }
        }
     public static void MoveFileToOutputDirectory(string sourcePath, string targetPath, string Pln, string FileName)
     {
         //To copy a folder's contents to a new location:
         //Create a new target folder, if necessary.
         if (!System.IO.Directory.Exists(targetPath))
         {
             System.IO.Directory.CreateDirectory(targetPath);
         }

         string fileName = string.Empty;
         string destFile = string.Empty;
         //if (System.IO.Directory.Exists(sourcePath))
         //{
            string[] files = System.IO.Directory.GetFiles(sourcePath + "\\");

             // Copy the files and overwrite destination files if they already exist.

             foreach (string s in files)
             {
                 //Use static Path methods to extract only the file name from the path.
                 fileName = System.IO.Path.GetFileName(s);
                 if (FileName == fileName)
                 {
                     destFile = System.IO.Path.Combine(targetPath + "//" , fileName);
                     System.IO.File.Copy(s,destFile,true);
                 }
             }
         }
        
     }

    }

               







