﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web;
using context = System.Web.HttpContext;
using DWHDAL;

namespace SchedulerForAppData
{
    public static class SwiftReplacementSolutionEfileCount
    {
        public static void LogFileWrite(string message)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                string logFilePath = "E:\\SwiftReplacementSolutionEfileCount\\";

                logFilePath = logFilePath + "SwiftReplacementSchedulerEfile_Log" + "-" + DateTime.Today.ToString("ddMMyyyy") + "." + "txt";

                if (logFilePath.Equals("")) return;
                #region Create the Log file directory if it does not exists
                DirectoryInfo logDirInfo = null;
                FileInfo logFileInfo = new FileInfo(logFilePath);
                logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);
                if (!logDirInfo.Exists) logDirInfo.Create();
                #endregion Create the Log file directory if it does not exists

                if (!logFileInfo.Exists)
                {
                    fileStream = logFileInfo.Create();
                }
                else
                {
                    fileStream = new FileStream(logFilePath, FileMode.Append);
                }
                streamWriter = new StreamWriter(fileStream);

                streamWriter.WriteLine(message);
            }
            finally
            {
                if (streamWriter != null) streamWriter.Close();
                if (fileStream != null) fileStream.Close();
            }

        }
        public static void LogPolicyToDB(EFileMapper currentDocument, AppConfigHandler configHandler, string dcn)
        {
            using (SqlConnection connection = new SqlConnection(configHandler.spefileconn))
            {
                connection.Open();
                SqlCommand com = new SqlCommand("sp_InsertSwiftReplacementSchedulerDocument", connection);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@DCN", dcn);
                com.Parameters.AddWithValue("@DocSharedrivePath", currentDocument.ShareDrivePath);
                com.Parameters.AddWithValue("@DocEFilePath", currentDocument.efile_Url);
                com.ExecuteNonQuery();
            }


        }

        public static void LogFailureErrorToDB(string dcn, string PolicyFilePath, AppConfigHandler configHandler, string error)
        {

            using (SqlConnection connection = new SqlConnection(configHandler.spefileconn))
            {
                connection.Open();
                SqlCommand com = new SqlCommand("sp_SwiftReplacementdocsNotUploaded", connection);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@DCN", dcn);
                com.Parameters.AddWithValue("@DocFilePath", PolicyFilePath);
                com.Parameters.AddWithValue("@ReasonForFailure", error);
                com.ExecuteNonQuery();
            }


        }

        public static void ProcessedDataLogToDB(string TotalDocs, string FailedDocs, string ProcessedDocs, AppConfigHandler configHandler, string startdatetime, string enddatetime)
        {
            using (SqlConnection connection = new SqlConnection(configHandler.spefileconn))
            {
                connection.Open();
                SqlCommand com = new SqlCommand("sp_InsertSwiftReplacementSchedulerDataLogs", connection);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@SchedulerStartDateTime", startdatetime);
                com.Parameters.AddWithValue("@SchedulerEndDateTime", enddatetime);
                com.Parameters.AddWithValue("@TotalDocs", TotalDocs);
                com.Parameters.AddWithValue("@ProcessedDocs", ProcessedDocs);
                com.Parameters.AddWithValue("@FailedDocs", FailedDocs);
                com.ExecuteNonQuery();
            }


        }
    }
}
