﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using System.Configuration;
using System.Xml;
using System.Reflection;

namespace SchedulerForAppData
{
    public class AppConfigHandler
    {  
            // read values from app.config file
      public string viewconn { get; set; }
      public string spefileconn { get; set; }
      public string efileconn { get; set; }
      public string sharedrivepath { get; set; }
      public string viewname { get; set; }
      public string tablename { get; set; }
      public string producttablename { get; set; }
      public string logtable { get; set; }
      public string serviceuser { get; set; }
      public string servicepwd { get; set; }
      public string serviceurl { get; set; }
      public string allowfolderfromDB { get; set; }
      public string appfoldername { get; set; }
        public AppConfigHandler()
      {
        try 
	        {
                 viewconn = ConfigurationManager.ConnectionStrings["ViewConnectionString"].ConnectionString;
                 spefileconn = ConfigurationManager.ConnectionStrings["SPefileConenctionString"].ConnectionString;
                 efileconn = ConfigurationManager.ConnectionStrings["efileConnectionString"].ConnectionString;
                 sharedrivepath = ConfigurationManager.AppSettings["SharedDrivePath"];
                 viewname = ConfigurationManager.AppSettings["ViewName"];
                 tablename = ConfigurationManager.AppSettings["TableName"];
                 serviceuser = ConfigurationManager.AppSettings["ServiceUser"];
                 servicepwd = ConfigurationManager.AppSettings["ServicePwd"];
                 serviceurl = ConfigurationManager.AppSettings["ServiceUrl"];
                 logtable = ConfigurationManager.AppSettings["LogTableName"];
                 allowfolderfromDB = ConfigurationManager.AppSettings["AllowFolderfromDB"];
                 appfoldername = ConfigurationManager.AppSettings["AppFolderName"];
                 producttablename = tablename = ConfigurationManager.AppSettings["ProductTableName"];
	        }
	   catch (Exception ex)
	        {
		
		        throw ex;
	        }
     

      }


      public void UpdateValuesAppConfig(string Key, string value)
      {
          try
          {
              Configuration config = ConfigurationManager.OpenExeConfiguration(Assembly.GetEntryAssembly().Location); 

            //  System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

              config.AppSettings.Settings[Key].Value =value;
              config.AppSettings.SectionInformation.ForceSave = true;
              config.Save(ConfigurationSaveMode.Modified);
              ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name);
              }
          catch (Exception ex)
          {

              throw ex;
          }


      }

    }

    
}
