﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using System.Net;
using System.Configuration;
using System.Globalization;
using DWHDAL;


namespace SchedulerForAppData
{

    public class ShareFolderConnector
    {
        DWHDAL.DWHDAL newDAL = new DWHDAL.DWHDAL();
        public AppConfigHandler configurationHandler = new AppConfigHandler();
        public List<DcnDocument> todaysPolicyNumbers = new List<DcnDocument>();



        public ShareFolderConnector(AppConfigHandler configHandler)
        {
            AppConfigHandler configurationHandler = configHandler;

            //SharedDrivePath = "ftp://10.134.10.52/PDF_File_Generated/GENERATED/";

        }

        /// <summary>
        /// NetworkCredential just to set the User and password of ftp path.
        /// </summary>
        //public NetworkCredential CreateNetworkCredentials()
        //{
        //    return new NetworkCredential(configurationHandler.ftpuserid, configurationHandler.ftppwd);
        //}


        //Helps to download file from FTP and save it to local folder.



        public string[] GetDCNNumbers(AppConfigHandler configurationHandler)
        {
            //LogHelper.LogFileWrite("Log : Info : Inside method GetClaimNumbers... ");

            List<string> DCNProcessed = new List<string>(); 
            try
            {

                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
        

                string newFolderpath = configurationHandler.sharedrivepath + configurationHandler.appfoldername;
                    string[] DCNFolders = System.IO.Directory.GetDirectories(newFolderpath);

                    foreach (var newItem in DCNFolders)
                    {
                        string newfilepath = newItem + "\\";
                        string DCNFolderName = Path.GetDirectoryName(newfilepath).Split('\\').LastOrDefault();
                        DCNProcessed.Add(DCNFolderName);
                    }
                
               return DCNProcessed.ToArray();
                
            }
            catch (Exception ex)
            {
                // throw;
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetDCNNumbers:" + ex.Message);
                return null;
                
            }

        }


        
        public List<string> GetallfilesofCurrentFolder(string DCN)
        {
            try
            {
                List<string> alldocfiles = new List<string>();
                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                string newpath = configurationHandler.sharedrivepath + configurationHandler.appfoldername + "\\";

                string[] allDocTypeFolders = System.IO.Directory.GetDirectories(newpath + DCN);


                // string[] allfiles = System.IO.Directory.GetFiles(newpath + PolicyNumber);
                foreach (var item in allDocTypeFolders)
                {

                    string filepath = item + "\\";
                    //string newdocfilepath = newitem + "\\";

                    string[] allfiles = System.IO.Directory.GetFiles(filepath);

                    foreach (var fileName in allfiles)
                    {
                        // checks if the file is hidden or not
                        //if hidden then excludes those files.
                        FileAttributes attributes = File.GetAttributes(fileName);
                        if ((attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //If the filename has an extension, then it actually is 
                            //a file and should be added to 'fnl'.            

                            if (fileName.IndexOf(".") > 0)
                            {
                                DcnDocument objPolicyDoc = new DcnDocument();
                                objPolicyDoc.PolicyFilePath = fileName + "\\";

                                //list.Add("file_name");
                                alldocfiles.Add(objPolicyDoc.PolicyFilePath);

                            }
                        }
                        
                    }
                  
                }
                return alldocfiles;
            }
            // }

            catch (Exception ex)
            {
                // throw;
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetallfilesofCurrentFolder:" + ex.Message);
                return null;
                //throw new Exception(" no files for " + configurationHandler.sharedrivepath + "\n");
            }
            return null;
        }

        public List<string> GetallfilesofdoctypeFolder(string DCN, string docCategory)
        {
            try
            {
                List<string> alldocfiles = new List<string>();
                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                string filepath = configurationHandler.sharedrivepath + configurationHandler.appfoldername + "\\" + DCN + "\\" + docCategory + "\\";

               // string[] allDocTypeFolders = System.IO.Directory.GetDirectories(newpath + DCN + "\\" + doctype);


                // string[] allfiles = System.IO.Directory.GetFiles(newpath + PolicyNumber);


                  //  string filepath = item + "\\";
                    //string newdocfilepath = newitem + "\\";

                    string[] allfiles = System.IO.Directory.GetFiles(filepath);

                    foreach (var fileName in allfiles)
                    {
                        // checks if the file is hidden or not
                        //if hidden then excludes those files.
                        FileAttributes attributes = File.GetAttributes(fileName);
                        if ((attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //If the filename has an extension, then it actually is 
                            //a file and should be added to 'fnl'.            

                            if (fileName.IndexOf(".") > 0)
                            {
                                DcnDocument objPolicyDoc = new DcnDocument();
                                objPolicyDoc.PolicyFilePath = fileName + "\\";

                                //list.Add("file_name");
                                alldocfiles.Add(objPolicyDoc.PolicyFilePath);

                            }
                        }

                    }

                return alldocfiles;
            }
            // }

            catch (Exception ex)
            {
                // throw;
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetallfilesofCurrentFolder:" + ex.Message);
                return null;
                //throw new Exception(" no files for " + configurationHandler.sharedrivepath + "\n");
            }
            return null;
        }

        public List<string> GetallfilesofOutputFolder(string path)
        {
            try
            {
                List<string> alloutputfiles = new List<string>();
                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                //string newpath = configurationHandler.sharedrivepath + configurationHandler.appfoldername + "\\";

                //string[] allDocTypeFolders = System.IO.Directory.GetDirectories(newpath + PolicyNumber);


                // string[] allfiles = System.IO.Directory.GetFiles(newpath + PolicyNumber);
               // foreach (var item in allDocTypeFolders)
               // {

                  //  string filepath = item + "\\" + "Output" + "\\";
                    //string newdocfilepath = newitem + "\\";

                string[] allfiles = System.IO.Directory.GetFiles(path);

                    foreach (var fileName in allfiles)
                   {
                        // checks if the file is hidden or not
                        //if hidden then excludes those files.
                        FileAttributes attributes = File.GetAttributes(fileName);
                        if ((attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //If the filename has an extension, then it actually is 
                            //a file and should be added to 'fnl'.            

                            if (fileName.IndexOf(".") > 0)
                            {
                                DcnDocument objPolicyDoc = new DcnDocument();
                                objPolicyDoc.PolicyFilePath = fileName + "\\";

                                //list.Add("file_name");
                                alloutputfiles.Add(objPolicyDoc.PolicyFilePath);

                            }
                        }
                        return alloutputfiles;
                    }


               // }
            }
            // }

            catch (Exception ex)
            {
                // throw;
                SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetallfilesofCurrentFolder:" + ex.Message);
                return null;
                //throw new Exception(" no files for " + configurationHandler.sharedrivepath + "\n");
            }
            return null;
        }

        public string[] GetalldoctypeFolders(AppConfigHandler configurationHandler, string dcn)
        {
            List<string> allDocTypeFolders = new List<string>();
            try
             {
                 WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                 request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                 request.Proxy = null;
                 request.PreAuthenticate = true;


                 string newFolderpath = configurationHandler.sharedrivepath + configurationHandler.appfoldername + "\\" + dcn;
                 string[] DocTypeFolders = System.IO.Directory.GetDirectories(newFolderpath);

                 foreach (var newItem in DocTypeFolders)
                 {
                     string newfilepath = newItem + "\\";
                     string DocTypeFolderName = Path.GetDirectoryName(newfilepath).Split('\\').LastOrDefault();
                     allDocTypeFolders.Add(DocTypeFolderName);
                 }

                 // LogHelper.LogFileWrite("Log : Info :  " + currentFolder);
                 //  SchedulerEfileCountLogError.LogFileWrite("Total files count = " + PolicyToBeProcessed.ToArray());
                 return allDocTypeFolders.ToArray();
             }
            catch (Exception ex)
              {
                  // throw;
                  SwiftReplacementDcnDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetalldoctypeFolders:" + ex.Message);
                  return null;
              }
                   
           
        }
    }

}
