﻿/*Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
using Microsoft.Office.RecordsManagement.InformationPolicy;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Taxonomy.ContentTypeSync;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace GS.SP.ECM.EF.ContentType
{
    public class ContentTypeCreator
    {
        private XmlDocument xmlDoc;
        private SPSite site;
        private SPWeb web;

        public ContentTypeCreator(XmlDocument document, SPSite spSite, SPWeb spWeb)
        {
            this.xmlDoc = document;
            this.site = spSite;
            this.web = spWeb;
        }

        /// <summary>
        /// Reads the xml file and adds the site columns and shared columns to a list
        /// </summary>
        public void ReadXmlAndCreateContentType()
        {
            List<string> columnNames = new List<string>();
            List<string> lstSharedColumns = new List<string>();

            XmlNodeList ContentTypes = xmlDoc.GetElementsByTagName("ContentTypes");
            XmlNodeList ContentType = xmlDoc.GetElementsByTagName("ContentType");

            foreach (XmlNode xmlnod in ContentType)
            {
                columnNames.Clear();
                lstSharedColumns.Clear();

                var ctGroup = xmlnod.Attributes["Group"].Value;
                var ctName = xmlnod.Attributes["Name"].Value;
                var parentGroup = xmlnod.Attributes["ParentType"].Value;
                bool updateIfExists;
                Boolean.TryParse(xmlnod.Attributes["UpdateIfExists"].Value, out updateIfExists);
                XmlNode fileldf = xmlnod.SelectSingleNode("Fields");
                if (fileldf.HasChildNodes)
                {
                    for (int i = 0; i < fileldf.ChildNodes.Count; i++)
                    {
                        var fieldname = fileldf.ChildNodes[i].Attributes["Name"].Value;
                        if (!columnNames.Contains(fieldname))
                        {
                            columnNames.Add(fieldname);
                        }
                    }

                    string policyXml = string.Empty;
                    if (xmlnod.SelectSingleNode("policy") != null)
                    {
                        policyXml = xmlnod.SelectSingleNode("policy").InnerXml;
                    }

                    XmlNodeList siteColumns = xmlDoc.GetElementsByTagName("SiteColumns");
                    string allowedContentTypeName = string.Empty;

                    foreach (XmlNode sitecol in siteColumns)
                    {
                        XmlNode node = sitecol.SelectSingleNode("Columns");
                        if (node.HasChildNodes)
                        {
                            allowedContentTypeName = node.Attributes["AllowedCT"].Value;
                            for (int i = 0; i < node.ChildNodes.Count; i++)
                            {
                                var columns = node.ChildNodes[i].Attributes["Name"].Value;
                                if (!lstSharedColumns.Contains(columns))
                                {
                                    lstSharedColumns.Add(columns);
                                }
                            }
                        }
                    }

                    this.CreateContentType(site, web, parentGroup, ctName, ctGroup, columnNames, updateIfExists, policyXml, lstSharedColumns, allowedContentTypeName);
                }
            }
        }

        /// <summary>
        /// Creates a content type or updats a aready existing content type
        /// </summary>
        private void CreateContentType(SPSite site, SPWeb web, string parentContentType, string contentTypeName, string groupName, List<string> columnNames, bool updateIfExists, string policyXml, List<string> lstSharedColumns, string allowedContentTypeName)
        {

            // Create an empty content type and add it to content type collection
            SPContentType existingContentType = web.ContentTypes[contentTypeName];
            if (existingContentType == null)
            {
                SPContentType contentType = new SPContentType(web.AvailableContentTypes[parentContentType], web.ContentTypes, contentTypeName);
                contentType.Group = groupName;
                web.ContentTypes.Add(contentType);

                //add columns from the list to the content type
                foreach (string internalName in columnNames)
                {
                    try
                    {
                        SPField field = web.Fields.GetFieldByInternalName(internalName);
                        SPFieldLink fieldLink = new SPFieldLink(field);
                        contentType.FieldLinks.Add(fieldLink);
                    }
                    catch (ArgumentException)
                    {
                        throw;
                    }
                }

                contentType.Update();
                web.Update();

                this.AddSharedColumnsToContentType(lstSharedColumns, contentType);

                this.SetAllowedContentTypeToDocumentSet(web, allowedContentTypeName, contentType);

                this.CreateOrUpdateRetentionPolicy(policyXml, contentType, true);

                if (ContentTypePublisher.IsContentTypeSharingEnabled(site))
                {
                    ContentTypePublisher ctPublisher = new ContentTypePublisher(site);
                    ctPublisher.Publish(contentType);
                }
            }
            else
            {
                if (updateIfExists)
                {
                    if (existingContentType.ReadOnly)
                    {
                        existingContentType.ReadOnly = false;
                        existingContentType.Update();
                    }

                    // Content type already exists
                    bool isUpdated = false;
                    foreach (string internalName in columnNames)
                    {
                        if (!existingContentType.Fields.ContainsField(internalName))
                        {
                            try
                            {
                                SPField field = web.Fields.GetFieldByInternalName(internalName);
                                SPFieldLink fieldLink = new SPFieldLink(field);
                                isUpdated = true;
                                existingContentType.FieldLinks.Add(fieldLink);
                            }
                            catch (ArgumentException)
                            {
                                throw;
                            }
                        }
                    }

                    if (isUpdated)
                    {
                        existingContentType.Update();
                        web.Update();
                    }

                    this.AddSharedColumnsToContentType(lstSharedColumns, existingContentType);

                    this.SetAllowedContentTypeToDocumentSet(web, allowedContentTypeName, existingContentType);

                    this.CreateOrUpdateRetentionPolicy(policyXml, existingContentType, false);

                    //publishing a content type
                    if (ContentTypePublisher.IsContentTypeSharingEnabled(site))
                    {
                        ContentTypePublisher ctPublisher = new ContentTypePublisher(site);
                        if (ctPublisher.IsPublished(existingContentType))
                            ctPublisher.Publish(existingContentType);
                        else
                            ctPublisher.Publish(existingContentType);
                    }
                }
            }
        }

        /// <summary>
        /// Creates or updates a retention policy 
        /// </summary>
        private void CreateOrUpdateRetentionPolicy(string policyXml, SPContentType contentType, bool isNew)
        {
            if (!string.IsNullOrWhiteSpace(policyXml))
            {
                // Retention Policy
                if (isNew)
                {
                    Policy.CreatePolicy(contentType, null);
                }

                Policy policy = Policy.GetPolicy(contentType);
                if (!isNew)
                {
                    policy.Items.Delete("Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration");
                }

                policy.Items.Add("Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration", policyXml);
                policy.Update();
            }
        }

        /// <summary>
        /// Sets the allowed content type to the document set
        /// </summary>
        private void SetAllowedContentTypeToDocumentSet(SPWeb web, string allowedContentTypeName, SPContentType contentType)
        {
            if (!string.IsNullOrWhiteSpace(allowedContentTypeName))
            {
                // Allowed Content Type
                SPContentType allowedCT = web.ContentTypes[allowedContentTypeName];
                if (allowedCT != null)
                {
                    string ctFormat = "<act:AllowedContentTypes xmlns:act=\"http://schemas.microsoft.com/office/documentsets/allowedcontenttypes\" LastModified=\"1/1/2014 08:00:00 AM\"><AllowedContentType id=\"{0}\" /></act:AllowedContentTypes>";
                    XmlDocument allowedCTXML = new XmlDocument();
                    XmlNamespaceManager ns1 = new XmlNamespaceManager(allowedCTXML.NameTable);
                    ns1.AddNamespace("NamespaceURI", "http://schemas.microsoft.com/office/documentsets/allowedcontenttypes");
                    allowedCTXML.LoadXml(string.Format(ctFormat, allowedCT.Id.ToString()));
                    contentType.XmlDocuments.Delete("http://schemas.microsoft.com/office/documentsets/allowedcontenttypes");
                    contentType.XmlDocuments.Add(allowedCTXML);
                    contentType.Update();
                }
            }
        }

        /// <summary>
        /// Adds the shared column to the content type
        /// </summary>
        private void AddSharedColumnsToContentType(List<string> lstSharedColumns, SPContentType contentType)
        {
            // Shared Columns
            if (lstSharedColumns != null && lstSharedColumns.Count > 0)
            {
                StringBuilder sbShared = new StringBuilder();
                string sharedColPrefix = "<sf:SharedFields xmlns:sf=\"http://schemas.microsoft.com/office/documentsets/sharedfields\" LastModified=\"1/1/2014 3:31:50 PM\">{0}</sf:SharedFields>";
                string format = "<SharedField id=\"{0}\" />";

                foreach (string internalName in lstSharedColumns)
                {
                    string id = contentType.Fields.GetFieldByInternalName(internalName).Id.ToString();
                    sbShared.Append(string.Format(format, id));
                }

                string finalSharedXml = string.Format(sharedColPrefix, sbShared.ToString());

                XmlDocument oXMLDocument = new XmlDocument();
                XmlNamespaceManager nsm = new XmlNamespaceManager(oXMLDocument.NameTable);
                nsm.AddNamespace("NamespaceURI", "http://schemas.microsoft.com/office/documentsets/sharedfields");
                oXMLDocument.LoadXml(finalSharedXml);
                contentType.XmlDocuments.Delete("http://schemas.microsoft.com/office/documentsets/sharedfields");
                contentType.XmlDocuments.Add(oXMLDocument);
                contentType.Update();
            }
        }      
    }
}
