/*Copyright � 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
using Microsoft.SharePoint;
using System;
using System.Runtime.InteropServices;
using System.Xml;

namespace GS.SP.ECM.EF.ContentType
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("ee1786d2-be52-43d3-9c48-1fe4093d9807")]
    public class GSSPECMEFEventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            try
            {
                SPSite site = properties.Feature.Parent as SPSite;
                SPWeb web = site.RootWeb;
                SPFile xmlFile = web.GetFile("Shared Documents/ContentTypes.xml");
                if (xmlFile.Exists)
                {
                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.Load(xmlFile.OpenBinaryStream());
                    ContentTypeCreator ctCreator = new ContentTypeCreator(xmlDoc, site, web);
                    ctCreator.ReadXmlAndCreateContentType();
                }
                else
                {
                    throw new System.IO.FileNotFoundException("File Not Found", "ContentTypes.xml");
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
                
        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
