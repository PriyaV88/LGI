﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace GS.SP.ECM.EF.WCFMail
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IDocumentActionsImpl" in both code and config file together.
    [ServiceContract]
    public interface IDocumentActionsImpl
    {
        [OperationContract]
        [WebInvoke(UriTemplate = "ExecuteController",
            Method = "GET",
            BodyStyle = WebMessageBodyStyle.Wrapped,
            ResponseFormat = WebMessageFormat.Json,
            RequestFormat = WebMessageFormat.Json)]
        string CopyDocuments(string srcUrl, string destUrl, string srcLibrary, string destLibrary, string destDocSet, string srcDocSet, string fileName, string action);
        [OperationContract]
        [WebInvoke(UriTemplate = "ExecuteController",
            Method = "POST",
            BodyStyle = WebMessageBodyStyle.Wrapped,
            ResponseFormat = WebMessageFormat.Json,
            RequestFormat = WebMessageFormat.Json)]

        bool SaveAsDocumentsToEFile(string dropZoneUrl, string docName, string policyNumber);
    }
}
