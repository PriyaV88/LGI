﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Microsoft.SharePoint.Client.Search;
using Microsoft.SharePoint.Client.Search.Query;
using System.Globalization;
using System.Collections;
using Microsoft.SharePoint.Client.Taxonomy;

namespace GS.SP.ECM.EF.WCFMail
{
    // NOTE: In order to launch WCF Test Client for testing this service, please select DocumentActionsImpl.svc or DocumentActionsImpl.svc.cs at the Solution Explorer and start debugging.
    public class DocumentActionsImpl : IDocumentActionsImpl
    {
        // Default network credentials or site collection admin credentials to be updated
        NetworkCredential defaultCredentials = new NetworkCredential("n0249120", "Saranya2", "LM");
        public static string managedMetadataSServiceAppln = "Managed Metadata Service";
        public string CopyDocuments(string srcUrl, string destUrl, string srcLibrary, string destLibrary, string destDocSet, string srcDocSet, string fileName, string action)
        {
            string status = "failure";
            // set up the source site client context - credentials to authenticate yet to be addded
            ClientContext srcContext = new ClientContext(srcUrl);
            srcContext.ExecutingWebRequest += new EventHandler<WebRequestEventArgs>(ExecutingWebRequest);
            srcContext.AuthenticationMode = ClientAuthenticationMode.Default;

            // set up the destination context - credentials to authenticate yet to be addded
            ClientContext destContext = new ClientContext(destUrl);
            destContext.ExecutingWebRequest += new EventHandler<WebRequestEventArgs>(ExecutingWebRequest);
            destContext.AuthenticationMode = ClientAuthenticationMode.Default;

            Web srcWeb = srcContext.Web;

            List srcList = srcWeb.Lists.GetByTitle(srcLibrary);
            // get the file from source document set (folder)
            var query = srcContext.LoadQuery(srcList.RootFolder.Folders.Where(fd => fd.Name == srcDocSet));
            srcContext.ExecuteQuery();


            Folder dsFolder = query.FirstOrDefault();
            // get the file from the folder/document set
            if (dsFolder != null)
            {
                var dsFiles = dsFolder.Files;
                //srcContext.Load(dsFiles, fls => fls.Include(fl => fileName));
                //srcContext.ExecuteQuery();

                // get the destination web context 
                Web destWeb = destContext.Web;
                destContext.Load(destWeb);
                destContext.ExecuteQuery();

                foreach (Microsoft.SharePoint.Client.File file in dsFiles)
                {
                    if (file.Name == fileName)
                    {
                        if (action.ToLower() == "copy")
                        {
                            // build new location url
                            string nLocation = destWeb.ServerRelativeUrl.TrimEnd('/') + "/" + destLibrary.Replace(" ", "") + "/" + file.Name;

                            // read the file, copy the content to new file at new location
                            FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(srcContext, file.ServerRelativeUrl);
                            Microsoft.SharePoint.Client.File.SaveBinaryDirect(destContext, nLocation, fileInfo.Stream, true);
                        }
                        if (action.ToLower() == "cut" || action.ToLower() == "move")
                        {
                            // to be done
                        }
                    }
                }
            }
            return status;
        }

        private void ExecutingWebRequest(object sender, WebRequestEventArgs e)
        {
            e.WebRequestExecutor.WebRequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
        }

        /// <summary>
        /// Save documents to eFile document sets from dropzone doc library
        /// </summary>
        /// <param name="dropZoneUrl">Drop Zone document library site URL</param>
        /// <param name="docName">Document name to be saved from drop zone to eFile site</param>
        /// <param name="policyNumber">eFile Document Set Policy Number (to be unique)</param>
        /// <returns>Status True if successful and False if unsuccessful as bool</returns>
        public bool SaveAsDocumentsToEFile(string dropZoneUrl, string docName, string policyNumber)
        {
            bool saveAsStatus = false;
            string[] docViewFields = { "EFPolicyNumber", "EFSubmissionNumber", "EFDocumentGroup", "EFDocumentType" };
            string dropZoneDocLibrary = "SaveAs";

            // get the drop zone source web
            ClientContext dropZoneContext = new ClientContext(dropZoneUrl);
            dropZoneContext.Credentials = defaultCredentials;

            dropZoneContext.ExecutingWebRequest += new EventHandler<WebRequestEventArgs>(ExecutingWebRequest);
            dropZoneContext.AuthenticationMode = ClientAuthenticationMode.Default;

            // get the drop zone web and get the document to be moved to eFile sites
            Web dropZoneWeb = dropZoneContext.Web;

            List drpList = dropZoneWeb.Lists.GetByTitle(dropZoneDocLibrary);
            CamlQuery query = new CamlQuery();
            //query.ViewXml = "<ViewFields><FieldRef Name='WorkAddress' /></ViewFields><Where><Eq><FieldRef Name='LinkFilename' /><Value Type='Computed'>" + docName + "</Value></Eq></Where>";

            //query.ViewXml = "<View><Query><Where><Eq><FieldRef Name='LinkFilename' /><Value Type='Computed'>" + docName + "</Value></Eq></Where></Query><ViewFields></ViewFields><QueryOptions /></View>";
            query.ViewXml = "<View><Query><Where><Eq><FieldRef Name='LinkFilename' /><Value Type='Computed'>" + docName + "</Value></Eq></Where></Query><ViewFields>";
            foreach (string viewField in docViewFields)
            {
                query.ViewXml += "<FieldRef Name='" + viewField + "' />";
            }
            query.ViewXml += "</ViewFields><QueryOptions /></View>";
            ListItemCollection col = drpList.GetItems(query);
            //Microsoft.SharePoint.Client.ListItemCollection col = drpList.GetItems(query);
            dropZoneContext.Load(col);
            dropZoneContext.ExecuteQuery();


            try
            {
                foreach (var doc in col)
                {

                    if ((doc.FileSystemObjectType == FileSystemObjectType.File))// condition to check for draft version to be added
                    {
                        var file = doc.File;
                        ListItem item = doc;
                        Dictionary<string, string> filePropDict = GetItemMetadata(item);

                        dropZoneContext.Load(file);
                        dropZoneContext.ExecuteQuery();


                        FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(dropZoneContext, file.ServerRelativeUrl);

                        saveAsStatus = FindDocSetAndUpload(fileInfo, filePropDict, policyNumber, dropZoneUrl, docName);
                        // delete source file from destination if save as is successful
                        if (saveAsStatus)
                        {
                            doc.DeleteObject();
                            dropZoneContext.ExecuteQuery();
                        }

                    }
                }
            }

            catch (ClientRequestException ex)
            {
                // exception when the destination context is not available

            }
            catch
            {

            }

            return saveAsStatus;
        }

        /// <summary>
        /// Find document set and upload the file
        /// </summary>
        /// <param name="file">Source File Stream</param>
        /// <param name="destPolicyNo">Destination Policy Number (document set)</param>
        /// <param name="dropZoneUrl">Source site URL</param>
        /// <returns></returns>
        public bool FindDocSetAndUpload(FileInformation file, Dictionary<string, string> fileMetadata, string destPolicyNo, string dropZoneUrl, string documentName)
        {
            bool uploadStatus = false;
            string eFileContentTypeName = "eFileDS";
            Hashtable metadataKeys = new Hashtable();
            metadataKeys.Add("EFDocumentTitle", "Text");
            metadataKeys.Add("EFDocumentGroup", "MMD");
            metadataKeys.Add("EFDocumentType", "MMD");
            metadataKeys.Add("EFDocumentStatus", "Text");
            string statusMessage = string.Empty;
            using (ClientContext clientContext = new ClientContext(dropZoneUrl))
            {
                clientContext.AuthenticationMode = ClientAuthenticationMode.Default;
                clientContext.Credentials = defaultCredentials;
                Web web = clientContext.Web;
                clientContext.Load(web);
                KeywordQuery keywordQuery = new KeywordQuery(clientContext);
                keywordQuery.SelectProperties.Add("Title");
                keywordQuery.SelectProperties.Add("Path");
                keywordQuery.SelectProperties.Add("SPSiteURL");
                keywordQuery.SelectProperties.Add("SitePath");

                keywordQuery.QueryText = string.Format(CultureInfo.InvariantCulture, "SPContentType:\"{0}\" AND EFPolicyNumberOWSTEXT:\"{1}\" OR EFSubmissionNumberOWSTEXT:\"{2}\"", eFileContentTypeName, destPolicyNo);

                try
                {
                    SearchExecutor searchExecutor = new SearchExecutor(clientContext);

                    ClientResult<ResultTableCollection> results = searchExecutor.ExecuteQuery(keywordQuery);

                    clientContext.ExecuteQuery();

                    // condition to be added for submission and policy number
                    foreach (var resultRow in results.Value[0].ResultRows)
                    {

                        // get the destination site context
                        ClientContext destContext = new ClientContext(resultRow["SPSiteURL"].ToString());
                        destContext.AuthenticationMode = ClientAuthenticationMode.Default;
                        destContext.Credentials = defaultCredentials;

                        Uri uri = new Uri(resultRow["Path"].ToString());

                        string docLocationRelativePath = uri.AbsolutePath;
                        docLocationRelativePath += "/" + documentName;
                        Microsoft.SharePoint.Client.File.SaveBinaryDirect(destContext, docLocationRelativePath, file.Stream, true);

                        // update the file metadata - start
                        Web destWeb = destContext.Web;
                        destContext.Load(destWeb);

                        // get the uploaded file with relative url
                        Microsoft.SharePoint.Client.File uploadedFile = destWeb.GetFileByServerRelativeUrl(docLocationRelativePath);
                        destContext.Load(uploadedFile);
                        destContext.ExecuteQuery();
                        
                        ListItem listItem = uploadedFile.ListItemAllFields;
                        // Loop metadata keys and update MMD fields
                        foreach (DictionaryEntry metadataKey in metadataKeys)
                        {
                            if (metadataKey.Value.Equals("MMD"))
                            {
                                string metadataValue = fileMetadata.FirstOrDefault(x => x.Key == Convert.ToString(metadataKey.Key)).Value;
                                SetManagedMetaDataField(destContext, listItem, Convert.ToString(metadataKey.Key), metadataValue);
                            }
                        }

                        // Loop metadata keys and update
                        foreach (DictionaryEntry metadataKey in metadataKeys)
                        {
                            if (!metadataKey.Value.Equals("MMD"))
                            {
                                string metadataValue = fileMetadata.FirstOrDefault(x => x.Key == Convert.ToString(metadataKey.Key)).Value;
                                uploadedFile.ListItemAllFields[Convert.ToString(metadataKey.Key)] = metadataValue;
                            }
                        }
                        uploadedFile.ListItemAllFields.Update();
                        destContext.ExecuteQuery();
                        // update the file metadata - end

                        uploadStatus = true;
                    }
                }
                catch (UnauthorizedAccessException unEx)
                {
                    statusMessage = "Access to destination site is unauthorized. Exception: " + unEx.Message;
                }

            }

            return uploadStatus;
        }

        private Dictionary<string, string> GetItemMetadata(ListItem item)
        {
            Dictionary<string, string> itemProperties = new Dictionary<string, string>();
            foreach (var props in item.FieldValues)
            {
                string propertyValue = (props.Value != null) ? props.Value.ToString() : "";
                Console.WriteLine(props.Key + ":" + props.Value);
                if (!string.IsNullOrEmpty(propertyValue))
                {
                    if (props.Value.ToString().Contains("TaxonomyFieldValue"))
                    {
                        TaxonomyFieldValue value = (TaxonomyFieldValue)props.Value;
                        itemProperties.Add(props.Key.ToString(), value.Label);
                    }
                    else
                    {
                        itemProperties.Add(props.Key.ToString(), props.Value.ToString());
                    }

                }

            }
            return itemProperties;
        }

        public static void SetManagedMetaDataField(ClientContext clientContext, ListItem listItem, string fieldName, string term)
        {

            List list = listItem.ParentList;
            FieldCollection fields = list.Fields;
            Field field = fields.GetByInternalNameOrTitle(fieldName);

            clientContext.Load(fields);
            clientContext.Load(field);
            clientContext.ExecuteQuery();

            TaxonomyField txField = clientContext.CastTo<TaxonomyField>(field);
            string termId = GetTermIdForTerm(term, txField.TermSetId, clientContext);

            TaxonomyFieldValueCollection termValues = null;
            TaxonomyFieldValue termValue = null;

            string termValueString = string.Empty;

            if (txField.AllowMultipleValues)
            {

                termValues = listItem[fieldName] as TaxonomyFieldValueCollection;
                foreach (TaxonomyFieldValue tv in termValues)
                {
                    termValueString += tv.WssId + ";#" + tv.Label + "|" + tv.TermGuid + ";#";
                }

                termValueString += "-1;#" + term + "|" + termId;
                termValues = new TaxonomyFieldValueCollection(clientContext, termValueString, txField);
                txField.SetFieldValueByValueCollection(listItem, termValues);

            }
            else
            {
                termValue = new TaxonomyFieldValue();
                termValue.Label = term;
                termValue.TermGuid = termId;
                termValue.WssId = -1;
                txField.SetFieldValueByValue(listItem, termValue);
            }

            listItem.Update();
            clientContext.ExecuteQuery();
            clientContext.Load(listItem);

        }

        public static string GetTermIdForTerm(string term, Guid termSetId, ClientContext clientContext)
        {
            string termId = string.Empty;

            TaxonomySession tSession = TaxonomySession.GetTaxonomySession(clientContext);

            // Old method
            //TermStore ts = tSession.GetDefaultSiteCollectionTermStore();

            TermStore ts = tSession.TermStores.GetByName(managedMetadataSServiceAppln);

            TermSet tset = ts.GetTermSet(termSetId);

            LabelMatchInformation lmi = new LabelMatchInformation(clientContext);

            lmi.Lcid = 1033;
            lmi.TrimUnavailable = true;
            lmi.TermLabel = term;

            TermCollection termMatches = tset.GetTerms(lmi);
            clientContext.Load(tSession);
            clientContext.Load(ts);
            clientContext.Load(tset);
            clientContext.Load(termMatches);

            clientContext.ExecuteQuery();

            if (termMatches != null && termMatches.Count() > 0)
                termId = termMatches.First().Id.ToString();

            return termId;

        }


    }
}
