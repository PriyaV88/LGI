/*Copyright � 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
/*!
 * Base files : Jquery Library
 * Content : UI generic methods & UI effects
 * Date: 2014-04-28
 * Project : LM ECM
*/
// to find whether page has scroll or not
function hasScrollAvailable(obj) {
    // comparing with object
    return obj.get(0).scrollHeight > obj.height();
}
// Based on the page name it adds classes, this function enhances the reusability of styles and add page specific on top of that
function addPageClass() {
    var filename = window.location.href.substr(window.location.href.lastIndexOf("/") + 1);
    filename = filename.replace('.aspx', '');
    filename = filename.replace(window.location.search, '');
    filename = filename.replace(window.location.hash, '');
    // have to do twice # replacement since some of the page has # appended dynamically which is actually not hash in return
    filename = filename.replace("#", '');
    if (filename === "") { filename = 'myhome'; } // providing class for root directory
    $('body').addClass(String(filename).toLowerCase());
}
// Toggle Show/Hide  function 
function toggleShow(elm) {
    $(elm).closest('.ms-webpart-chrome-title').next().find('.ms-srch-result').slideToggle();
    if ($(elm).text() === 'Show') {
        $(elm).text('Hide');
        if ($(document).width() > 480) { $(elm).next('.clearFilter').show(); }
    } else {
        $(elm).text('Show');
        if ($(document).width() > 480) { $(elm).next('.clearFilter').hide(); }
    }
}
// Clear Filter function is triggered on click of "Clear Filter" button 
function clearFilter() {
    // Store current page path and splitting them using .aspx
    var pageurl = window.location.href, rplurl = pageurl.split('aspx');
    // Assignment of the array value 
    window.location.href = rplurl[0] + 'aspx';
}
// Clear Filter  function for home page-spotlight
function clearFilterSpot() {
    var pageurl = window.location.href, webPart = $('#QueryGroupNameSpot').val(), rplurl = pageurl.split('#');
    if (rplurl[1].indexOf(webPart) >= 0) {
        if (rplurl[2] === undefined) { window.location.href = rplurl[0]; } else { window.location.href = rplurl[0] + '#' + rplurl[2]; }
    }
    if (rplurl[2].indexOf(webPart) >= 0) { window.location.href = rplurl[0] + '#' + rplurl[1]; }
}
// Clear Filter  function for home page-recent
function clearFilterRecent() {
    var pageurl = window.location.href, webPart = $('#QueryGroupNameRecent').val(), rplurl = pageurl.split('#');
    if (rplurl[1].indexOf(webPart) >= 0) {
        if (rplurl[2] === undefined) {
            window.location.href = rplurl[0];
        } else {
            window.location.href = rplurl[0] + '#' + rplurl[2];
        }
    }
    if (rplurl[2].indexOf(webPart) >= 0) {
        window.location.href = rplurl[0] + '#' + rplurl[1];
    }
}
// Clear Filter  function 
function clearFilterInsured() {
    var pageurl = window.location.href, rplurl = pageurl.split('#');
    window.location.href = rplurl[0];
}

/* Generic function which controlls refiner positioning in following cases
	1. On page load
	2. On Cell width change
	3. if arrow image added
*/
var internalLoop;
function rePositionRefiner() {
    setTimeout(function () {
        // Looping through all tables which need refiner repositioning
        internalLoop = setInterval(function () {
            $('table.gs-ecm-resultsgrid').each(function (indexT) {
                // Making sure that arrows are available
                $(this).find('th').children('.gs-ecm-dropdown').closest('th').each(function () {
                    // making sure that current th element is stored in a diffrent valiable to avoid conflict.
                    var _self = $(this), cObj = _self.attr('class');
                    cObj = cObj.split(' ');
                    // Picking up respective refiner element and placing them just above arrow mark
                    $('.ms-ref-ctrl.gs-ecm-columnheaders')
                    .eq(indexT)
                    .find('.ms-reff-refiner.' + cObj[cObj.length - 1]).css({
                        'left': ($(document).width() <= 480) ? (_self.offset().left) + (_self.width()) - ($('table.gs-ecm-resultsgrid').eq(indexT).offset().left) : (_self.offset().left) + (_self.width()) - ($('table.gs-ecm-resultsgrid').eq(indexT).offset().left), // different left calculation for mobile and desktop views
                        position: 'absolute',
                        'z-index': 100,
                        'display': 'inline-block'
                    });
                    // Avoid permonance impact 
                    if (cObj !== undefined) {
                        untouchedPerformance();
                    };
                });
            });
            // Assign max-width to refiner header
            $('.gs-ecm-columnheaders').css('max-width', $(document).width());
        }, 1000);
        function untouchedPerformance() {
            setTimeout(function () {
                clearInterval(internalLoop);
            }, 10000);
        }
        // Binding refiner positioning with pagination links
        $('ul#Paging li a').on('click', function () {
            clearInterval(internalLoop);
            rePositionRefiner();
        });
        // Avoid refiner flyout going off the screen 
        $(".ms-ref-refinername").each(function () {
            $(this).bind('click', function () {
                var elm = $(this).next(), // grab current element
				w = elm.width(), // assigning width of the current element
				rElm = $(this).offset(), // a common element which tell offset of the current element
				isElementVisible = (rElm.left - w >= 0), // conditional expression to check whether current element left value remain +ve or -ve
				str = $('.ms-reff-refiner.gs-ecm-th-year')
				.find('.gs-ecm-columnheaders-filters #Value .ms-ref-name').text(), // grab text of the each applicable on search pages
				res = str.split('.0'); // storing value in array element

                if (!isElementVisible) {
                    elm.addClass('edge'); // if partial/not visible 
                } else {
                    elm.removeClass('edge'); // if visible
                }
                // refresh data one refiners are applied
                setTimeout(function () {
                    if ($(elm).is(':visible')) {
                        $(elm)
						.on('click', '.gs-ecm-columnheaders-actions-apply, .gs-ecm-columnheaders-actions-clear', function () {
						    //  window.location.href = location.href;
						    clearInterval(internalLoop);
						    rePositionRefiner();
						});
                    }
                    // Binding refiner positioning with pagination links
                    $('ul#Paging li a').on('click', function () {
                        clearInterval(internalLoop);
                        rePositionRefiner();
                    });

                }, 1000);

                // Removes decimal values from year field 
                if ($('.ms-reff-refiner.gs-ecm-th-year')
				.find('.gs-ecm-columnheaders-filters #Value .ms-ref-name').text().indexOf('.0') !== -1) {
                    $('.ms-reff-refiner.gs-ecm-th-year')
					.find('.gs-ecm-columnheaders-filters #Value .ms-ref-name')
					.text(res[0]);
                }
            });
        });

        // Binding ellipsis for lengthy chars under Product cell which has class name assigned as "multiItems". 
        // Applicable to all pages where product is avaible as columns
        $('.gs-ecm-resultsgrid .multiItems').on('mouseenter', function () {
            // grab text value
            var proTxt = $(this).text();
            // if length exceed 10 chars
            if (proTxt.length > 10) {
                $(this).css('cursor', 'pointer'); // turning mouse pointer to hand
                $('.gs-ecm-inpage-flyout').remove(); // removes already available flyout to avoid adding multiple flyout items
                $(this)
				.closest('td')
				.css('position', 'relative')
				.append('<div class="gs-ecm-inpage-flyout"><span class="js-callout-beakLeftRight js-callout-beakLeft js-callout-beak"></span>' + proTxt + '</div>'); // append of the flyout to respective element
                // positioning flyuout relative to its cell
                $('.gs-ecm-inpage-flyout').css({
                    minWidth: '180px',
                    maxWidth: '300px',
                    whiteSpace: 'normal',
                    padding: '10px',
                    top: '0',
                    left: '65px'
                }).show(); // show element
            }
        });
        // bind mouseleave to multiple product cells
        $('.gs-ecm-resultsgrid .multiItems').closest('td').on('mouseleave', function () {
            $('.gs-ecm-inpage-flyout').remove();
        });
    }, 2000);
}

function prompForOldIE() {
    var isAtLeastIE11 = !!(navigator.userAgent.match(/Trident/) && !navigator.userAgent.match(/MSIE/) && navigator.appVersion.match(/Gecko/)), btnCls = $('<div class="btnCLose"></div>');
    if (navigator.appName === 'Microsoft Internet Explorer') {
        if (!isAtLeastIE11) {
            // Detect browser if not IE11
            var ieMessage = getFromConfigList('IE11Warning');
            divIE11 = $('<div id="ie11alert">' + ieMessage + '</div>');
            $('body').prepend(divIE11);
            $(divIE11).append(btnCls);
            $(btnCls).on('click', function () {
                $(this).hide();
                $(divIE11).slideUp(100);
                var vphight = GetViewportHeight();
                $('#s4-workspace').height(vphight - 35);
            });
        }
    }
}
// Jquery DOMReady
$(function () {
    // fix for IOS nth-child flaw
    isOSAIOS8();
    // Overwriting margin and background for tab elements
    $('.gs-ecm-entity-tabs').closest('.ms-webpart-chrome-vertical').css({ 'background': 'transparent', 'padding': '0!important' });
    $('.gs-ecm-entity-tabs').closest('.ms-rtestate-field').css('margin-bottom', '0px');
    // Add page specific classes
    addPageClass();
    // check if the browser if older than IE11
    //prompForOldIE()
    // Dynamic handling of refinement panel (Apply || Cancel)
    $(window).on('resize', function () {
        clearInterval(internalLoop);
        rePositionRefiner();
    });
    rePositionRefiner();

    // Reusable methods, registering new custom methods
    jQuery.fn.extend({
        //Add tabs outside parent element
        addTabs: function () {
            try {
                var hpara = '<ul class="gs-ecm-entity-tabs dyntab">',
				i = 1,
				len = arguments.length;
                for (i = 1; i < len; i += 1) {
                    hpara += '<li><input type="button" value="'
							 + arguments[i] + '" class="gs-ecm-dyntab'
							 + i + ' hideTable" ></li>';
                }
                hpara += '</ul>';
                // Once hpara ready feed before parent tags
                $(arguments[0]).before(hpara);
                // Apply selection to first tab
                $(arguments[0]).prev().find('>li:eq(0)')
				.addClass("selected") // aplied to li element
				.children('input:eq(0)')
				.addClass("selected"); // aplied to anchor element
            } catch (ignore) { }
        },
        addSearchMobileTabs: function () {
            if ($(document).width() <= 480) {
                $('body').addTabs($(arguments[0]).parent(), arguments[1], arguments[2]);
                //$('#gs-ecm-contentcontainer h1').append('<a href="javascript:searchMobileFilter();" class="mobile-filter">Filter</a>');
            }
        },
        removeAttribute: function () {
            return this.each(function () { this.removeAttr('colspan'); }); // remove colspan attributes for assigned elements
        },
        revealtNote: function () {
            $('.note-flyout:visible').css({ 'display': 'none' });
            $(this).next('.note-flyout').slideDown(); // animate sticky note
        },
        closeBox: function () {
            $(this).parent().slideToggle();
        },
        hideRibbon: function () {
            $(this).find('iframe').each(function () {
                $(this).contents().find('#s4-ribbonrow').hide(); // hide ribbons from iframe 
            });
        },
        isDesignMode: function () {
            var inDesignMode = document.forms[MSOWebPartPageFormName].MSOLayout_InDesignMode.value;
            if (inDesignMode == "1") {/*$(this).addClass('designModeView');*/ }
            //gs-ecm-resultsgrid     
        }
    });

    // check whether open page is in design or browse mode 
    $('body').isDesignMode();
    //commented by priya - to show calendar box
    // Hide popupIns on clicking outside area
    /*$(document).bind('mouseup', function (e) {
        var container = $('.ms-ref-unselSec,#ui-datepicker-div');
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.each(function () {
                if (!/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet PC/i.test(navigator.userAgent)) {
                    $(this).hide();
                }
            });
        }
    });
    $(document).bind('mousedown', function (e) {
        var container = $('.ms-ref-unselSec,#ui-datepicker-div');
        if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
        {
            container.each(function () {
                if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet PC/i.test(navigator.userAgent)) {
                    $(this).hide();
                }
            });
        }
    });*/
    if ($(document).width() <= 1024) $('input').attr("autocomplete", "off");

    // Modal window reveal method	
    setTimeout(function () {
        $('#DocsTable .DataTables_sort_wrapper .gs-ecm-dropdown-link').css('opacity', 1);
        // bind click event to refiner object
        $(document).on('click', '.ms-ref-refinername', function (e) {
            if ($(document).width() <= 480) {
                // For mobile elements
                var getHead = $(document).find('.ms-ref-refinername')
                .closest('.ms-reff-refiner').attr('class'), // get class name of refiner object
                // split value with spaces
                thHead = getHead.split(' '),
                // grab the text of the table head
                thHeadTxt = $('.gs-ecm-resultsgrid:first th.' + thHead[1]).find('a:first').text();
                // remove duplicate head\
                $('.mobRefHead').remove();
                // appending heading along with head
                $('.ms-ref-unselSec').prepend('<div class="mobRefHead">' + thHeadTxt + '</div>');
                // adding overlay translucent element
                mobileOverlay();
            }
        });

    }, 3000);

    // Toggle Functionality for dynamically added buttons
    $(document).delegate('.hideTable:not(".selected")', 'click', function () {
        $(this).addClass('selected').parent().addClass('selected');
        $(this).parent().siblings().removeClass('selected').children('.selected').removeClass('selected');
    });

    // remove colspan by pages
    $('.resultspage').find('table th').removeAttribute();

    // Custom select styling which picks up all select elements whose id reads as "stage" 
    $('.policydetails select#stage').each(function () {
        if (!$(this).prop('multiple')) {
            $(this).wrap(function () {
                return "<div class='customSelect'></div>"
            });
        }
    });
    // Adding caret and para which are the actual visual area
    $('div.customSelect').prepend('<span class="caret"></span><p class="selectVal"></p>');
    // Assigning current value of select element to paragraph
    $('.customSelect select').each(function () {
        $(this).parent().children('.selectVal').text($(this).children('option:selected').text());

    });
    // Sync paragraph text with current value
    $('.customSelect select').on('click', function () {
        var currentVal = $(this).children('option:selected').text();
        $(this).parent().children('.selectVal').text(currentVal);
    });
    // Sync paragraph text with current value
    $('.customSelect select').on('change', function () {
        $(this).parent('.customSelect').children('.selectVal').text($(this).children('option:selected').text());
    });

    // Appending tab on Policy Detail page
    $('.policydetails').addTabs('div.gs-ecm-content-toptable', 'Default View', 'Email View');

    // Arranging postioning of the ribbon element including help icon if horizontal scroll added or removed.
    if (hasScrollAvailable($('#s4-workspace'))) {
        $('div.ms-cui-TabRowRight').css('padding-right', '26px');
    }

    $(window).bind('resize load', function () {
        setTimeout(function () {
            // Appending hide button to "Spotlight eFiles"
            if ($('.ms-webpart-titleText').eq(0).find('span').text() === "Spotlight eFiles" && $('.toggleShow, .clearFilter').length === 0) {
                $('<a />', {
                    'class': 'toggleShow',
                    'id': 'spotlightefiles',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:toggleShow("#spotlightefiles")'
                }).text('Hide').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));

                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void',
                    'onclick': 'javascript:clearFilterSpot()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));
            }
            if ($('.ms-webpart-titleText').eq(3).find('span').text() === "Recent eFiles") {
                $('<a />', {
                    'class': 'toggleShow',
                    'id': 'recentefiles',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:toggleShow("#recentefiles")'
                }).text('Hide').appendTo($('.ms-webpart-titleText').eq(3).find('span:first'));

                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilterRecent()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(3).find('span:first'));
            }
            if ($('.ms-webpart-titleText').eq(0).find('span').text() === "All eFiles") {
                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilter()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));
            }
            if ($('.ms-webpart-titleText').eq(0).find('span').text() === "My Policies") {
                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilter()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));
            }
            if ($('.ms-webpart-titleText').eq(0).find('span').text() === "My Quotes") {
                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilter()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));
            }
            if ($('.ms-webpart-titleText').eq(0).find('span').text() === "My Renewals") {
                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilter()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));
            }
            if ($('.ms-webpart-titleText').eq(0).find('span').text() === "eFiles") {
                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilter()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(0).find('span:first'));
            }
            if ($('.insuredpage .ms-webpart-titleText').eq(1).find('span').text() === "eFiles") {
                $('<a />', {
                    'class': 'clearFilter',
                    'href': 'javascript:void(0)',
                    'onclick': 'javascript:clearFilterInsured()'
                }).text('Clear Filter').appendTo($('.ms-webpart-titleText').eq(1).find('span:first'));
            }
        }, 500);
    });

    // Search Result page side_box & content tag css change
    if (location.pathname.indexOf('/ResultsPage.aspx') !== -1 || location.pathname.indexOf('/respage.aspx') !== -1) {
        $('#sideNavBox').css({ display: 'none' });
        $('#gs-ecm-content').css({ 'margin-left': 0 });
        $('.tableCol-75').parent().css('margin-top', 0).addClass('searchResultsPage');
        $('.searchResultsPage .tableCol-75>div>.cell-margin.tableCol-50')
		.filter(':first').addClass('gs-ecm-content-leftcolumn').end()
		.filter(':last').addClass('gs-ecm-content-rightcolumn');
    }
    // Appending tab on Search Page page
    $('.resultspage').addSearchMobileTabs('.gs-ecm-content-rightcolumn', 'eFile', 'Insured Name');
    // Highlighting first tab as selected for all search pages
    $('.resultspage #eFilesButtonListItem, .efiledocuments #eFileDocumentsButtonListItem, .LegacyDocumentsSearch #legacyDocumentsButtonListItem, .TemplatesSearch #templateDocumentsButtonListItem').addClass('selected');


    setTimeout(function () {
        // Adding scroll to left pane refiners avaialble on search pages
        $('.tableCol-75 .gs-ecm-content-leftcolumn .gs-ecm-classification-filter ul ul')
    	.has('li:eq(10)')
    	.addClass('autoScrollVert');
        // Added animation for details page
        $(".policydetails .ms-rtestate-field")
        .slideDown();
        $('.policydetails #DocsTable th')
        .eq("1")
        .find('.gs-ecm-custom-filters.ms-ref-refiner')
        .css({ left: 0, width: "220px" });

        // Click handler for top menu
        $('#suiteBarLeft .ms-core-suiteLinkList#menu>li:parent>a').on('click', function (e) {
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet PC/i.test(navigator.userAgent)) {
                e.preventDefault();
                $(e.target).parent('li').toggleClass('hover');
            }
        });

        // Hide popupIns on clicking outside area
        $(document).bind('mouseup', function (e) {
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet PC/i.test(navigator.userAgent)) {
                var container = $('#suiteBarLeft .ms-core-suiteLinkList#menu>li ul');
                if (!container.is(e.target) // if the target of the click isn't the container...
                    && container.has(e.target).length === 0) // ... nor a descendant of the container
                {
                    $(container).parent('li').removeClass('hover');
                }
            }
        });

        // Hide/Show Details functionality for eFile Details Page 
        $('.toggleSearchGroup').on('click', function (e) {
            e.preventDefault();
            // checks for data avaialability in all five cells if data value is avialable then picks the values and put them into single cell
            if ($(this).parent()
            .parent('.gs-ecm-entitydetails').css('height') !== "70px") {
                // change text value 
                $(this).text("Show Details");
                // hide all cells
                $(this).parent()
                .parent('.gs-ecm-entitydetails')
                .css({ display: "block" })
                .animate({ height: "70px" }, 300).children().hide();
                // checks if first cell is hidden 
                if ($('.gs-ecm-entitydetails')
                .find('.gs-ecm-entitydetails-column1').is(':hidden')) {
                    // picking first two labels and its values
                    $('.gs-ecm-entitydetails')
                    .find('.gs-ecm-entitydetails-column1').css({ display: "block", width: "100%", height: "auto" })
                    .find('>div').slice(0, 2).hide();
                    // once data is grabbed it will form new wrap elements
                    $('.gs-ecm-entitydetails')
                    .find('.gs-ecm-entitydetails-column1 > div:eq(2), .gs-ecm-entitydetails-column1 > div:eq(3)')
                    .wrapAll("<div class='unwrap' style='float:left;margin-right:15px;'></div>");
                    $('.gs-ecm-entitydetails')
                    .find('.gs-ecm-entitydetails-column1 > div:eq(3), .gs-ecm-entitydetails-column1 > div:eq(4)')
                    .wrapAll("<div class='unwrap' style='float:left;margin-right:15px;'></div>");
                    // appending hide button to new cell
                    $(this).appendTo('.gs-ecm-entitydetails-column1')
                     .css({ float: 'right', 'margin': '19px 5px 0' });

                }
            } else {

                // brigning back to original state
                // reaching to parent element first then to its children and revealing them with fadein effect
                $(this).parent()
                .parent('.gs-ecm-entitydetails').css({ display: "table" })
                .animate({ height: "200px" }, 300).children().fadeIn();
                // Removing added css property as part of IF condition to bring it to original state
                $('.gs-ecm-entitydetails')
                .find('.gs-ecm-entitydetails-column1').css({ display: "", width: "", height: "" })
                .find('>div').css({ float: "none" }).slice(0, 2).show();
                // Swapping text
                $(this).text("Hide Details");
                // removing wrapped element which was created as part of IF condition
                $('.unwrap').contents().unwrap();
                // appending button back to last cell
                $(this).appendTo('.gs-ecm-entitydetails-column3:last');
            }
        });
    }, 1000);


    // If list item has UL inside it
    if ($('#gs-ecm-topnav .ms-core-listMenu-horizontalBox > ul.ms-core-listMenu-root > li').children('ul').width() > 0) {
        $('#gs-ecm-topnav .ms-core-listMenu-horizontalBox > ul.ms-core-listMenu-root > li').addClass('notEmpty');
        $('#gs-ecm-topnav .ms-core-listMenu-horizontalBox > ul.ms-core-listMenu-root > li').animate({ 'opacity': 1 }, 100);
    }

    // Fadein effect for body element step taken post Zero char removal dynamic code for better user expetience
    $('body').animate({
        'opacity': 1,
        'filter': 'alpha(opacity=100)'
    }, 200);

    // Adding margin bottom to first table
    if ($('.myhome div[data-name="WebPartZone"]').not('.ms-rtestate-read .ms-rte-wpbox')) {
        $('.myhome div[data-name="WebPartZone"]').addClass('ms-rtestate-read ms-rte-wpbox');
        if ($('.ms-webpart-titleText').eq(0).find('span').text() === "Spotlight eFiles") {
            if ($(document).width() <= 480) {
                $('.ms-webpart-titleText').eq(0).closest('div[data-name="WebPartZone"]').css('margin-bottom', 10);
            }
            else {
                $('.ms-webpart-titleText').eq(0).closest('div[data-name="WebPartZone"]').css('margin-bottom', 20);
            }
        }
    }

    // Alignment of action flyout vertically middle - it calculates the height of the flyout element and adjust height to vertically middle 
    $('.gs-ecm-inpage-flyout').css('margin-top', -((32 * ($('.gs-ecm-inpage-flyout>li').length)) / 2 + 15));

    // Adding arrow to flyout
    if ($('.gs-ecm-inpage-flyout').find('li').length % 2 === 0) {
        var fnode = $(".gs-ecm-inpage-flyout").find("li").length / 2;
        $("ul.gs-ecm-inpage-flyout>li:eq('" + fnode + "')").after('<li style="padding:0;height:0;"><span class="js-callout-beakLeftRight js-callout-beakLeft js-callout-beak" ></span></li>');
    }

    $('.policydetails').find('.gs-ecm-resultsgrid').addClass('defaultView');
    $('.policydetails').on('click', 'input.gs-ecm-dyntab2', function () {
        $('.policydetails').find('.gs-ecm-resultsgrid').removeClass('defaultView').addClass('emailView');
        clearInterval(internalLoop);
        rePositionRefiner();
    });
    // Show Column in Policy Datails Page on button Default view click
    $('.policydetails').on('click', 'input.gs-ecm-dyntab1', function () {
        $('.policydetails').find('.gs-ecm-resultsgrid').removeClass('emailView').addClass('defaultView');
        clearInterval(internalLoop);
        rePositionRefiner();
    });
    // Bind click to dynamic generated table itself to switch from Default to Email view and vice versa
    $('.policydetails').on('click', '.ms-rtestate-field:eq(1)', function () {
        if ($(document).width() > 480) {
            if ($('.policydetails').find('.gs-ecm-resultsgrid').hasClass('defaultView')) {
                $('.policydetails').find('.gs-ecm-resultsgrid').removeClass('emailView').addClass('defaultView');
                clearInterval(internalLoop);
                rePositionRefiner();
            } else {
                $('.policydetails').find('.gs-ecm-resultsgrid').removeClass('defaultView').addClass('emailView');
                clearInterval(internalLoop);
                rePositionRefiner();
            }
        }
    });
    // search page tab switch
    $('.resultspage').on('click', '.gs-ecm-dyntab2', function () {
        if ($(document).width() <= 480) { toggleMobView('.resultspage .gs-ecm-dyntab2'); }
    });
    // search page tab switch
    $('.resultspage').on('click', '.gs-ecm-dyntab1', function () {
        if ($(document).width() <= 480) { toggleMobView('.resultspage .gs-ecm-dyntab1'); }
    });
    $(document).on('mousedown', '.ms-ref-refinername', function () {
        setTimeout(function () { selectStates(); }, 350);
    });
    // Add, reveal & delete note feature
    $(document).on('click', '.notetext>a', function () { $(this).revealtNote(); });
    $(document).on('click', '.note-flyout>.btnClose', function () {
        $(this).closeBox();  // closes note flyout
    });
});
// Swith Mobile Tab View
function toggleMobView(args) {
    if (args === '.resultspage .gs-ecm-dyntab1') {
        $('.gs-ecm-resultsgrid td:nth-child(2)').removeClass('hideView').addClass('showView');
        $('.gs-ecm-resultsgrid td:nth-child(1)').removeClass('showView').addClass('hideView');
        $('.gs-ecm-resultsgrid th:nth-child(2)').removeClass('hideView').addClass('showView');
        $('.gs-ecm-resultsgrid th:nth-child(1)').removeClass('showView').addClass('hideView');
    } else {
        $('.gs-ecm-resultsgrid td:nth-child(1)').removeClass('hideView').addClass('showView');
        $('.gs-ecm-resultsgrid td:nth-child(2)').removeClass('showView').addClass('hideView');
        $('.gs-ecm-resultsgrid th:nth-child(1)').removeClass('hideView').addClass('showView');
        $('.gs-ecm-resultsgrid th:nth-child(2)').removeClass('showView').addClass('hideView');
    }
}
// Fetching value for mobile view
var _eFileDetailsInterval;
_eFileDetailsInterval = setInterval(function () {
    if (document.documentElement.offsetWidth > 481) { clearInterval(_eFileDetailsInterval); }
    if (document.documentElement.offsetWidth <= 480
		&& document.querySelector('#eF-dtls-snum')
		&& String(document.querySelector('#hdnEFileNumber').value).length > 0) {
        document.querySelector('#eF-dtls-snum').innerHTML
            = document.querySelector('#hdnEFileNumber').value;
        clearInterval(_eFileDetailsInterval);
    }
}, 3000);
// Custom mobile ovelay 
function mobileOverlay() {
    $('.mobOverlay').remove();
    $('<div />', {
        'class': 'mobOverlay'
    }).appendTo('body').css({ width: $(document).width(), height: $(document).height() });
    // removing overlay element on click of close | apply | clear buttons
    $('.mobOverlay, .gs-ecm-columnheaders-actions-close, .gs-ecm-columnheaders-actions-apply, .gs-ecm-columnheaders-actions-clear')
    .click(function (e) {
        var container = $('.gs-ecm-columnheaders-actions-close, .mobOverlay');
        $('.mobOverlay').remove();
        //refiner on policy details page
        $('#DocsTable .DataTables_sort_wrapper .gs-ecm-dropdown-link').css('opacity', 1);
        // Tab switch on result page
        if (!container.is(e.target)
			&& container.has(e.target).length === 0) {
            $('.resultspage .gs-ecm-entity-tabs.dyntab')
            .children('li').removeClass('selected')
            .find('>input').removeClass('selected')
            .closest('ul').children('li:first')
            .addClass('selected');
        }
    });
}
/* function to display a single message
    on home page if no efiles are present in spotlight and recent 
    efiles web part
*/
function checkAndDisplaySingleMsg() {
    if (($("#noHomeRecenteFiles").text().length > 0) && ($("#noHomeSpoteFiles").text().length > 0)) {
        var messageCell = $('#singleMsg').closest('.s4-wpcell-plain.ms-webpartzone-cell').attr('id');
        var tabsCell = $('.gs-ecm-entity-tabs').closest('.s4-wpcell-plain.ms-webpartzone-cell').attr('id');
        $("div[id^=MSOZoneCell]").each(function () {
            if ($(this).attr('id') != messageCell && $(this).attr('id') != tabsCell) {
                $(this).hide();
            }
        });
        $('#singleMsg').show();
    }
}

function newFilterList(obj) {
    var filter = $('.gs-ecm-select-filters:visible').val().toLowerCase();
    var excluded = $('.gs-ecm-columnheaders-filters:visible>div').find("label:Contains(" + filter + ")").parent();
    if ($(obj).val().length >= 1 && excluded.length > 0) {
        $('.gs-ecm-columnheaders-filters:visible>span').fadeOut(0);
        $('.gs-ecm-columnheaders-filters:visible>div').not(excluded).slideUp();
    } else if (excluded.length == 0) {
        $('.gs-ecm-columnheaders-filters:visible>div').slideUp();
        $('.gs-ecm-columnheaders-filters:visible>span').fadeIn(0);
    }
}
function refreshFilterList(obj) {
    $('.gs-ecm-columnheaders-filters:visible>div').slideDown();
    $('.gs-ecm-columnheaders-filters:visible>span').fadeOut(0);
}
function selectAll(obj) {
    var obj = obj || $('.gs-ecm-all-filters:visible');
    if (!$('.gs-ecm-sqrfill-filters:visible').is('.solidfill, .intfill')) {
        if ($('.gs-ecm-columnheaders-filters:visible>div:visible').length === $('.gs-ecm-columnheaders-filters:visible>div').length) {
            $(obj).find('.gs-ecm-sqrfill-filters').removeClass('intfill').addClass('solidfill');
        } else {
            $(obj).find('.gs-ecm-sqrfill-filters').removeClass('solidfill').addClass('intfill');
        }
        $('.gs-ecm-columnheaders-filters:visible>div:visible').find('input[type=checkbox]').prop('checked', true);
    }
    else {
        $(obj).find('.gs-ecm-sqrfill-filters').removeClass('solidfill intfill');
        $('.gs-ecm-columnheaders-filters:visible>div:visible').find('input[type=checkbox]').prop('checked', false);
    }
}

function selectStates(obj) {
    var chkelm = $('.gs-ecm-columnheaders-filters:visible>div:visible').find('input[type=checkbox]:checked').length;
    var divelm = $('.gs-ecm-columnheaders-filters:visible>div').length;
    if (chkelm === divelm) {
        $('.gs-ecm-all-filters:visible').find('.gs-ecm-sqrfill-filters').removeClass('intfill').addClass('solidfill');
    } else if (chkelm === 0) {
        $('.gs-ecm-all-filters:visible').find('.gs-ecm-sqrfill-filters').removeClass('solidfill intfill');
    } else {
        $('.gs-ecm-all-filters:visible').find('.gs-ecm-sqrfill-filters').removeClass('solidfill').addClass('intfill');

    }
}

// efile details page refiner
function efileDetailsRefinerMobile(obj) {
    if ($(document).width() <= 480) {
        var getHead = obj.closest('.DataTables_sort_wrapper').find('>a').text(), customWidth = ($(document).width() - 40);
        $('.mobRefHead').remove();
        $('.mobile.policydetails .gs-ecm-custom-filters.ms-ref-refiner').prepend('<div class="mobRefHead">' + getHead + '</div>');
        var refHeight = $('.mobile.policydetails .gs-ecm-custom-filters.ms-ref-refiner').height() / 2;
        $('.mobile.policydetails .gs-ecm-custom-filters.ms-ref-refiner').css({
            width: customWidth + 'px',
            marginTop: -refHeight
        }).animate({ 'opacity': 1 }, 0);
        $('#DocsTable .DataTables_sort_wrapper .gs-ecm-dropdown-link').css('opacity', 0);
        // adding overlay translucent element
        mobileOverlay();
    }
}
// IOS 8 does not support nth-child hence fix for that written below
function isOSAIOS8() {
    if ("600.1.4" == navigator.appVersion || navigator.userAgent.indexOf('OS 8_')) {
        $('body').addClass('IOS');
        return true;
    }
    return false;
}
!function (a) { a.getScriptOnce = function (b, c) { return -1 === a.getScriptOnce.loaded.indexOf(b) ? (a.getScriptOnce.loaded.push(b), void 0 === c ? a.getScript(b) : a.getScript(b, function (a, b, d) { c(a, b, d) })) : !1 }, a.getScriptOnce.loaded = [] }(jQuery);
