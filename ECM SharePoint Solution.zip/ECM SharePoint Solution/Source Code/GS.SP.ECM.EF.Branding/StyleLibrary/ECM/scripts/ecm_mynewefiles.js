﻿/*Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
/**
 * File Description: This file is used to 1. Get all recent eFiles using service call.
                2. Dispaly the results a table format with pagination and sorting.
 * Pages Referencing: MyNewefiles.aspx
*/

//Global Variables
var loginName;
var Type;
var Url;
var Data;
var ContentType;
var DataType;
var ProcessData;
var serviceURL;
var globalCounter = 0;
var userid = _spPageContextInfo.userId; // Current user's SharePoint user Id
ULS.enable = true;
var itemId = 0;
var entityVersion = 0;
var siteVersion = 0;
var versionId = 0;
/**
    * Document Ready function:
        1. Triggers the service URL function call
        2. Triggers the Cuurent Logged-in User function call
        3. Triggers the recent eFiles service call 
        4. Displays the files in a DataTable
*/

$(document).ready(function () {
    try {

        //function call to get the Service URL
        GetServiceURL();

        //function call to get the Current logged-in user
        GetCurrentUser();


        SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
            $.getScript('/_layouts/sp.ui.dialog.js', function () {
            });

            $.getScript("/Style%20Library/ECM/scripts/jquery.dataTables.js", function () {

                $.getScript('/Style%20Library/ECM/scripts/dataTables.getColumnData.js', function () {

                    //Initiating the dataTable
                    var oTable = $("#DocsTable").dataTable(
                     {
                         "iDisplayLength": 4,
                         "bPaginate": true,
                         "bLengthChange": false,
                         "bFilter": true,
                         "bSort": true,
                         "bInfo": true,
                         "bAutoWidth": false,
                         "bJQueryUI": true,
                         "sPaginationType": "full_numbers",
                         "aoColumns": null,
                         "oLanguage": {
                             "sEmptyTable": "Loading Documents...",
                             "sSearch": "   ",
                             "sInfo": "",
                             "sInfoFiltered": "",
                             "sInfoEmpty": "",
                             "oPaginate": {
                                 "sNext": '<span class="ms-promlink-button-image" id="PagingImageLink"><img src="/Style%20Library/ECM/images/rightsmall.png"></span>',
                                 "sPrevious": '<span class="ms-promlink-button-image" id="PagingImageLink"><img src="/Style%20Library/ECM/images/leftsmall.png"></span>'
                             }
                         },

                         "sDom": '<"top"ifl>t<"bottom"pi>',
                         "fnInitComplete": function () {
                             $("#DocsTable_last").show();
                             $("#DocsTable_first").show();
                             var url = document.URL;
                             var tValue = "";
                             if (url.indexOf("#Default=") != -1) {
                                 var jsonString = decodeURIComponent(url.substr(url.indexOf("#Default=") + 9));
                                 //var str = JSON.stringify(jsonString);
                                 var jsonObj = JSON.parse(jsonString);
                                 tValue = jsonObj.r[0].t.toString().replace(/"/g, '');
                                 tValue = tValue.substr(url.indexOf(':'));

                                 //alert("tValue " + tValue);
                                 if (tValue != parseInt(tValue)) {
                                     $("#DocsTable").dataTable().fnFilter(tValue, 10, true, false);
                                 }
                             }

                         },
                         "fnDrawCallback": function (oSettings) {
                             /*Added to resolve defect TFS#104726 -Add Total Number of Pages Returned on all Search Results Pages*/
                             var iPage = Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength);
                             var iTotalPages = Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength);
                             var htmlString = "";

                             if (iTotalPages > 1) {
                                 htmlString = 'You are viewing page ' + (iPage + 1) + ' of ' + iTotalPages + '.';
                                 $('#ViewCurrentPage').html(htmlString);
                             }
                             var pageCount = $("#PageNumbers").children().length;
                             if (pageCount > 1) {
                                 $(".bottom").show();
                                 //document.getElementById("s4-workspace").scrollTop = 0;
                             } else {
                                 $(".bottom").hide();
                             }
                         }
                     }
                    );
                    $(".bottom").hide();
                    oTable.fnFilterOnReturn();

                    //Function call to update the filters and pagination container.
                    ProcessEntity();

                    //Function call to trigger the Service call
                    HideOrShowAuditButtons();


                    //Function call to Update the filter container position.
                    positionFilters();

                    //ExecuteOrDelayUntilScriptLoaded(ShowOrHideAuditButtons, "SP.Core.js");

                });

            });
        });
    }
    catch (error) {
        ULSOnError(error, document.location.href, 0);
    }
});

/**
    * Get the Current logged-in User ID (LM)
    * Assigns Current logged-in User ID (LM) to the variable - loginName(Global Variable)
    * @return NA
*/
function GetCurrentUser() {
    //userid(Global Variable) - Current user's SharePoint user Id
    var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";

    var requestHeaders = { "accept": "application/json;odata=verbose" };

    //Trigger Ajax call
    $.ajax({
        url: requestUri,
        contentType: "application/json;odata=verbose",
        headers: requestHeaders,
        success: onSuccessGetUser,
        error: onErrorGetUser
    });
}

/**
    * Get the Current logged-in User ID (LM) Sucess Method
    * Assigns Current logged-in User ID (LM) to the variable - loginName(Global Variable)
    * @param {object} data [Current Logged in User bject]
    * @return NA
*/
function onSuccessGetUser(data) {
    loginName = data.d.LoginName.split('|')[1];
    if (loginName.indexOf('\\') != -1) {
        //Assigns Current logged-in User ID (LM) to the variable
        loginName = loginName.split('\\')[1];
    }
}

/**
    * Get the Current logged-in User ID (LM) Error Method
    * Logs the into Console
    * @param {string} error [Error message]
    * @return NA
*/
function onErrorGetUser(error) {
    console.log("onErrorGetUser" + error);
    ULSOnError(error, document.location.href, 0);
}

/**
    * Get the Service URL from the SharePoint Config List
    * Assigns Service URL to the variable - serviceURL(Global Variable)
    * @return NA
*/
function GetServiceURL() {
    //SharePoint Config List Name
    var listName = 'efileConfigList';

    //Trigger Ajax call
    $.ajax({
        url: _spPageContextInfo.webAbsoluteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items",
        type: "GET",
        headers: {
            "Accept": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            $.each(data.d.results, function (index, item) {
                if (item.Title == "ECM Service URL") {
                    //Assigns Service URL to the variable
                    serviceURL = item.Value;
                }
            });
        },
        error: function (data) {
            console.log("error in get service url" + JSON.stringify(data));
            ULSOnError(JSON.stringify(data), document.location.href, 0);
        }
    });
}
/**
    * Assign values to Variables
    * Triggers the recent eFiles service call 
    * @return NA
*/
function WCFJSON() {

    Type = "GET";
    Url = serviceURL + "/restService/GetRecentEFiles/" + loginName;
    ContentType = "application/x-www-form-urlencoded; charset=UTF-8";
    DataType = "json";
    //recent eFiles service call 
    CallService();

}

/**
    * Function to call recent eFiles Service.
    * Append the results into DataTable for display.
    * @return NA
*/
function CallService() {

    //Trigger Ajax call
    $.ajax({
        type: Type,
        url: Url,
        data: '',
        dataType: DataType, //Expected data format from server
        acync: false,
        xhrFields: {
            withCredentials: true
        },
        success: function (msg) {
            //Function Call on Succes in Service call
            if (msg.length == 0)
                $(".dataTables_empty").text("No eFiles to be displayed.");
            else
                ServiceSucceeded(msg);

        },
        error: function (msg) {
            //Function Call on failure in Service call
            ServiceFailed(msg);
            ULSOnError(msg, document.location.href, 0);
        }

    });

}

/**
    * Recent eFiles Service call Error Method
    * Logs error status and statusText the into Console
    * @param {object} result [Error message]
    * @return NA
*/
function ServiceFailed(result) {
    console.log('Service call failed: ' + result.status + '' + result.statusText);
    Type = null;
    Data = null;
    ContentType = null;
    DataType = null;
    ProcessData = null;
    ULSOnError(result.statusText, document.location.href, 0);
}

/**
    * Recent eFiles Service call Sucess Method
    * Iterate through all the eFiles and append the results into DataTable for display.
    * @param {object} result [Current Logged in User bject]
    * @return NA
*/
function ServiceSucceeded(result) {
    try {
        if (DataType == "json") {


            for (var k = 0; k < result.length; k++) {

                var itemAvailable = 0;
                //cloumn variables
                var eFileNo = '', InsuredName = '', UnderWriter = '', UnderWriterAsst = '', BrokerCo = '', Inc = '', Exp = '', LOB = '', Product = '', UWStage = '', MasterStatus = '';
                //eFile Icon for display
                var icon = '<img src="/Style%20Library/ECM/images/eFileIcon.png"><span style="display:none"></span>';
                //Variable for Callout structure for display
                var callOut = '<div id="Item_Default"><div data-rowid="' + (globalCounter + 1);
                var callOutImage = '';

                var resultObject = result[k].EntityInformation;
                if (resultObject != null) {
                    var objMetadata = resultObject.MetadataProperties;
                    if (objMetadata != null) {
                        var newSubNo;
                        for (var i = 0; i < objMetadata.length; i++) {
                            //Add Submission Number to the DataTable
                            if (objMetadata[i].Name.indexOf("submission_no") != -1) {
                                if (callOut.indexOf("data-eFileNo") == -1) {
                                    if (objMetadata[i].Value) {

                                        eFileNo = objMetadata[i].Value;
                                        newSubNo = eFileNo;
                                        callOut += '" data-eFileNo="' + eFileNo;
                                        callOutImage = '<img data-title="' + eFileNo + '" class="ms-ellipsis-icon" src="/_layouts/15/images/spcommon.png?rev=23">';

                                        itemAvailable++;

                                    }
                                }

                            }

                            //Add Policy Number to the DataTable
                            if (objMetadata[i].Name.indexOf("policy_no") != -1) {
                                if (objMetadata[i].Value) {
                                    eFileNo = objMetadata[i].Value;
                                    if (callOut.indexOf("data-eFileNo") != -1) {
                                        callOut = callOut.replace(newSubNo, eFileNo);
                                    }
                                    else {
                                        callOut += '" data-eFileNo="' + eFileNo;
                                    }
                                    callOutImage = '<img data-title="' + eFileNo + '" class="ms-ellipsis-icon" src="/_layouts/15/images/spcommon.png?rev=23">';


                                    itemAvailable++;
                                }
                            }

                            //Add Insured Name to the DataTable
                            if (objMetadata[i].Name.indexOf("insured_name") != -1) {
                                if (objMetadata[i].Name.indexOf("insured_name_id") == -1) {
                                    InsuredName = objMetadata[i].Value;
                                    callOut += '" data-insuredName="' + InsuredName;
                                    itemAvailable++;
                                }
                            }

                            //Add UnderWriter Name to the DataTable
                            if (objMetadata[i].Name == "underwriter") {
                                UnderWriter = objMetadata[i].Value;
                                callOut += '" data-uw="' + UnderWriter;
                                itemAvailable++;
                            }

                            //Add UnderWriterAsst. Name to the DataTable
                            if (objMetadata[i].Name == "underwriter_assistant") {
                                UnderWriterAsst = objMetadata[i].Value;
                                callOut += '" data-uwa="' + UnderWriterAsst;
                                itemAvailable++;
                            }

                            //Add broker name to the DataTable
                            if (objMetadata[i].Name.indexOf("broker_name") != -1) {
                                BrokerCo = objMetadata[i].Value;
                                callOut += '" data-broker="' + BrokerCo;
                                itemAvailable++;
                            }

                            //Add policy inception date to the DataTable
                            if (objMetadata[i].Name.indexOf("policy_inception_date") != -1) {
                                var IncDate = objMetadata[i].Value;
                                if (IncDate != '') {
                                    var IncpDate = new Date(IncDate);
                                    Inc = IncpDate;
                                }
                                callOut += '" data-inc="' + Inc;
                                itemAvailable++;
                            }

                            //Add policy expiry date to the DataTable
                            if (objMetadata[i].Name.indexOf("policy_expiry_date") != -1) {
                                var ExpiryDate = objMetadata[i].Value;
                                if (ExpiryDate != '') {
                                    var ExpDate = new Date(ExpiryDate);
                                    Exp = ExpDate;
                                }
                                callOut += '" data-exp="' + Exp;
                                itemAvailable++;
                            }

                            //Add policy LOB to the DataTable
                            if (objMetadata[i].Name.indexOf("gs_line_of_business") != -1) {
                                LOB = objMetadata[i].Value;
                                callOut += '" data-lob ="' + LOB;
                                itemAvailable++;
                            }

                            //Add policy Product to the DataTabl
                            if (objMetadata[i].Name.indexOf("product") != -1) {
                                Product = objMetadata[i].Value;
                                callOut += '" data-product="' + Product;
                                itemAvailable++;
                            }

                            //Add policy UW stage to the DataTabl
                            if (objMetadata[i].Name.indexOf("uw_stage") != -1) {
                                UWStage = objMetadata[i].Value;
                                callOut += '" data-uwstage="' + UWStage;
                                itemAvailable++;
                            }

                            //Add policy master status to the DataTabl
                            if (objMetadata[i].Name.indexOf("master_status") != -1) {
                                MasterStatus = objMetadata[i].Value;
                                callOut += '" data-ms="' + MasterStatus;
                                itemAvailable++;
                            }
                            // get policy values and render policy number
                            if (objMetadata[i].Name.indexOf("eFile_location") != -1) {
                                eFileLocation = encodeURIComponent(objMetadata[i].Value);
                                callOut += '" data-href="' + objMetadata[i].Value;
                                policyLink = "PolicyDetails.aspx?PolicyNumber=" + eFileNo + "&polLoc=" + eFileLocation;
                                eFileNoLink = '<a href="' + policyLink + '" class="documentUrl" >' + eFileNo + '</a>';
                            }
                            if (objMetadata[i].Name.indexOf("sharepoint_id") != -1) {
                                SharePointID = objMetadata[i].Value;
                                callOut += '" data-id="' + SharePointID;
                            }
                        }
                    }

                    if (SharePointID != null || SharePointID != undefined) {
                        policyLink = "PolicyDetails.aspx?PolicyNumber=" + eFileNo + "&polLoc=" + eFileLocation + "&SpID=" + SharePointID;
                        eFileNoLink = '<a href="' + policyLink + '" class="documentUrl" >' + eFileNo + '</a>';
                    }
                    //append the column variables to the callout variable for display.
                    callOut += '" class="callout" id="' + (globalCounter + 1) + '"class="callout" id="' + (globalCounter + 1) + '" name="Item" data-displaytemplate="DefaultItem"><a title="Open Menu" class="ms-lstItmLinkAnchor ms-ellipsis-a">' + callOutImage + '</a></div></div>';

                    if (itemAvailable > 0) {
                        //Update the valriables to the dataTable and add it the table for display
                        $("#DocsTable").dataTable().fnAddData([
                                  icon,
                                  eFileNoLink,
                                  callOut,
                                  InsuredName,
                                  UnderWriter,
                                  UnderWriterAsst,
                                  BrokerCo,
                                  Inc.format("MMM dd, yyyy"),
                                  Exp.format("MMM dd, yyyy"),
                                  LOB,
                                  Product,
                                  UWStage,
                                  MasterStatus
                        ]);
                    }
                }

            }
            //Function call to Create the dropdown on each column of the table for filters.
            createDropdowns();
            createCallouts();
        }

    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
    * Function to update the filters and pagination container.
    * @return NA
*/
function ProcessEntity() {
    try {
        $('.dataTables_filter label').append('<input type="button" class="gs-ecm-searchbutton" id="goFilter"/><br><br>');

        // Adding table heading
        $('.dataTables_filter').attr("style", "display:inline-block");
        $('.dataTables_filter').attr("id", "SearchBox");
        $('.dataTables_filter').attr("class", "gs-ecm-searchbox fg-toolbar");
        $('.gs-ecm-document-tabs').insertAfter('.top');
        $('#DocsTable_paginate').attr("class", "ms-srch-Paging");
        $('#DocsTable_paginate').attr("style", "display:inline-block");
        $('.dataTables_info').attr("class", "ms-srch-resultscount ms-srch-resultFooter gs-ecm-results ms-srch-result dataTables_info");
        $('.dataTables_info').attr("style", "display:inline-block");
        $('#DocsTable_paginate').append('<br><br>');
        /*Added to resolve defect TFS#104726 -Add Total Number of Pages Returned on all Search Results Pages*/
        $('.bottom').append('<div id="ViewCurrentPage"></div>');
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
    * Function to Create the dropdown on each column of the table for filters.
    * @return NA
*/
function createDropdowns() {
    try {
        var filterBox;
        $("thead th").each(function (i) {
            if ($('.filter_column.filter_date_range').length > 0) return;
            //skip 2nd and 4th column
            if (i != 1 && i != 3) {
                var columnName = $(this).text();
                var cellValue = $(this).find(">div.DataTables_sort_wrapper>a").text();
                var filterValues = $("#DocsTable").dataTable().fnGetColumnData(i);
                var classArray = $(this).attr('class').split(" ");
                var className = classArray[1];
                var columnHeader = $(this);

                //create filter HTML
                var filterDiv = "";

                if (String(cellValue).indexOf('Inc.') != -1 || String(cellValue) === 'Exp.') {
                    filterDiv += "<div class='gs-ecm-custom-filters ms-ref-refiner " + className + "' style='text-transform:none;font-weight:normal;border:1px #999 solid;position:absolute;z-index:100;background-color:#FFF;display:block;color:black;font-size:13px;font-family:Arial,sans-serif'>";
                    filterDiv += "<div class='gs-ecm-columnheaders-actions' style='padding:5px 0px 5px 10px'>"
                    filterDiv += "<div id='SubmitValue' style='width:220px'>";
                    filterDiv += "<div class='gs-ecm-columnheaders-actions-close'></div>";
                    filterDiv += "<div id='submit'>";
                    filterDiv += "<a class='gs-ecm-columnheaders-actions-apply dRange' style='padding:5px 15px;margin-right:5px'>Apply</a>";
                    filterDiv += "<a class='gs-ecm-columnheaders-actions-clear' style='padding:5px 15px;margin-right:5px'>Clear</a>";
                    filterDiv += "</div></div></div>";
                    filterDiv += '<div class="gs-ecm-daterange" ><div class="frm-group"><label for="fromDate">From</label><input type="text" class="startDate " name="from" value="" readonly /></div><div class="frm-group"><label for="toDate">To</label><input type="text" class="endDate"  readonly  name="to" value="" /></div></div>';
                } else {
                    //create filter HTML
                    filterDiv += "<div class='gs-ecm-custom-filters ms-ref-refiner " + className + "' style='text-transform:none;font-weight:normal;border:1px #999 solid;position:absolute;z-index:100;background-color:#FFF;display:block;color:black;font-size:13px;font-family:Arial,sans-serif'>";
                    filterDiv += "<div class='gs-ecm-columnheaders-actions' style='padding:5px 0px 5px 10px'>"
                    filterDiv += "<div id='SubmitValue' style='width:220px'>";
                    filterDiv += "<div class='gs-ecm-columnheaders-actions-close'></div>";
                    filterDiv += "<div id='submit'>";
                    filterDiv += "<a class='gs-ecm-columnheaders-actions-apply' style='padding:5px 15px;margin-right:5px'>Apply</a>";
                    filterDiv += "<a class='gs-ecm-columnheaders-actions-clear' style='padding:5px 15px;margin-right:5px'>Clear</a>";
                    filterDiv += "</div></div></div>";
                    filterDiv += '<div class="gs-ecm-all-filters" onclick="selectAll(this)"><span class="gs-ecm-sqr-filters"><span class="gs-ecm-sqrfill-filters"></span></span> <label>Select All</label></div>'
                    filterDiv += "<div class='gs-ecm-columnheaders-filters' style='padding:5px 0px 5px 10px;border-top:1px #999 solid;max-height:180px;overflow-y:auto'>";

                }
                //enumerate through filter values
                var filterValueArray = [];
                for (var j = 0; j < filterValues.length; j++) {
                    var filterValue = filterValues[j];
                    if (i < 13) {
                        if (filterValue.toString().indexOf("<") >= 0) {
                            filterValue = $(filterValue).text();
                        }
                        filterValueArray.push(filterValue);
                    }
                    //split up Additional and Keyword filters
                    if (i > 12) {
                        var taxValues = filterValue.split(';');
                        for (var m = 0; m < taxValues.length - 1; m++) {
                            filterValueArray.push(taxValues[m]);
                        }
                    }
                }
                //sort and add to div
                filterValueArray.sort();
                for (var k = 0; k < filterValueArray.length; k++) {
                    if (String(cellValue).indexOf('Inc.') == -1 && String(cellValue).indexOf('Exp.') == -1)
                        filterDiv += "<div class='gs-ecm-filter-row' id='Value' style='padding:4px 0'><input class='gs-ecm-checkbox' type='checkbox' onclick='selectStates()'><label style='color:#666666' class='ms-ref-name ms-displayInlineBlock ms-ref-ellipsis'>" + filterValueArray[k] + "</label></div>"
                }
                filterDiv += "</div></div>";
                $(this).find('.gs-ecm-custom-filters').remove();
                $(this).prepend(filterDiv);
            }

            //hide filters to start
            $('.gs-ecm-custom-filters').hide();

            //open filters on click
            var filterBox = $(this).children('.gs-ecm-custom-filters');
            var dropdownLink = $(this).children().children('.gs-ecm-dropdown-link');
            $(document).mousedown(function (e) {
                var container = $('.gs-ecm-custom-filters,#ui-datepicker-div');
                if (!container.is(e.target) // if the target of the click isn't the container...
                && container.has(e.target).length === 0) // ... nor a descendant of the container
                {
                    container.each(function () { $(this).hide(); })
                }
            });
            $(document).mouseup(function (e) {
                var container = $(".startDate,.endDate");
                if (container.is(e.target)) // ... nor a descendant of the container
                {
                    $('#ui-datepicker-div').show()
                }
            });
            dropdownLink.click(function (e) {
                e.stopPropagation();
                var container = $('.gs-ecm-custom-filters');
                container.each(function () { $(container).hide(); })
                $(this).parent().prev('.gs-ecm-custom-filters').toggle();
            });

            $("input.startDate,input.endDate").
            datepicker({
                dateFormat: "M dd, yy",
                changeMonth: true,
                changeYear: true
            });
            //get checked values for apply button
            var applybutton = $(this).find('.gs-ecm-columnheaders-actions-apply').not('.dRange');

            var applyDatebutton = $(this).find('.gs-ecm-columnheaders-actions-apply.dRange');
            var filters = $(this).find('.gs-ecm-columnheaders-filters');
            applyDatebutton.click(function (e) {
                e.stopPropagation();
                var startDate = $('.startDate:visible').val();
                var endDate = $('.endDate:visible').val();
                if ($('.startDate:visible').val().length == 0 && $('.endDate:visible').val().length > 0) {
                    startDate = $('.endDate:visible').val();
                } else if ($('.startDate:visible').val().length > 0 && $('.endDate:visible').val().length == 0) {
                    endDate = $('.startDate:visible').val();
                }
                $('.startDate:visible').val(startDate);
                $('.endDate:visible').val(endDate);
                var checkedValues = new Array();
                startDate = new Date(startDate);
                startDate = startDate.format("MM/dd/yyyy");
                endDate = new Date(endDate);
                endDate = endDate.format("MM/dd/yyyy");
                var dateStart = parseDateValue(startDate);
                var dateEnd = parseDateValue(endDate);
                var columnIndex = $(this).parents('.gs-ecm-ref-target').index();
                var data = $("#DocsTable").dataTable().fnGetData();
                for (var j = 0; j < data["length"]; j++) {
                    var adate = new Date(data[j][columnIndex]);
                    adate = adate.format("MM/dd/yyyy");
                    var evalDate = parseDateValue(adate);
                    if (evalDate >= dateStart && evalDate <= dateEnd) {
                        checkedValues.push(data[j][columnIndex]);
                    }
                }
                if (checkedValues.length == 0) {
                    checkedValuesString = "''";
                }
                else
                    checkedValuesString = checkedValues.join("|");
                $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false);

                if ($("#DocsTable").find('.dataTables_empty').length) {
                    $('.dataTables_empty').text("No results were found.");
                    $('.dataTables_empty').show();
                }

                // Function for converting a mm/dd/yyyy date value into a numeric string for comparison (example 08/12/2010 becomes 20100812
                function parseDateValue(rawDate) {
                    var dateArray = rawDate.split("/");
                    var parsedDate = dateArray[2] + dateArray[0] + dateArray[1];
                    return parsedDate;
                }

                //rangeFilter(trElm);
                dropdownLink.prev('a').addClass("filtered");
                $(this).closest('.gs-ecm-custom-filters').toggle();
            });
            //apply checked filters
            applybutton.click(function (e) {
                var checkedValues = new Array();
                filters.children().each(function () {
                    if ($(this).children(".gs-ecm-checkbox").is(":checked")) {
                        var value = $(this).text();
                        checkedValues.push("^" + replaceSpecialCharacters(unescape(value)) + "$");
                    }
                });
                var checkedValuesString = checkedValues.join("|"); //join multiple values with the "|" regex OR operator
                if (checkedValuesString.length > 0) { $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false); }
                else { $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false); }

                //Function call to toggle the sort icon On-Click.
                toggleIcons(null);

                //Function call to Update the filter container position.
                positionFilters();

                //Function callto  Create callout.
                createCallouts();
                filterBox.hide();
                e.stopPropagation();
            });

            //clear values and checkboxes
            var clearbutton = $(this).find('.gs-ecm-columnheaders-actions-clear');
            clearbutton.click(function (e) {
                e.stopPropagation();
                //$(this).children(".gs-ecm-checkbox").removeAttr("checked");
                $(this).closest('th').find(".gs-ecm-checkbox").each(function () { $(this).removeAttr('checked'); });
                $(this).closest('th').find('.gs-ecm-sqrfill-filters').removeClass('solidfill intfill');

                if ($(this).siblings().hasClass('dRange')) {
                    $('.startDate:visible').val("")
                    $('.endDate:visible').val("")
                }

                checkedValuesString = "";
                $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false);
                toggleIcons(null);
                positionFilters();
                createCallouts();
                //emailButtons();
                filterBox.hide();
                e.stopPropagation();
            });

            //close button functionality
            var closebutton = $(this).find('.gs-ecm-columnheaders-actions-close');
            closebutton.click(function (e) {
                //clear checkboxes if not filtered
                if (!columnHeader.find('.gs-ecm-filter-icon').length && !columnHeader.find('.filtered').length) {
                    filters.children().each(function () {
                        $(this).children(".gs-ecm-checkbox").prop("checked", false);
                    });
                    filters.parent().find('.gs-ecm-sqrfill-filters').removeClass('solidfill intfill');
                }
                filterBox.hide();
                e.stopPropagation();
            });

            //stops sorting when you click filters
            $('.gs-ecm-custom-filters').click(function (e) {
                e.stopPropagation();
            });

            //unbind click event for certain column headers
            $('.gs-ecm-disable-sort').unbind("click");

            //toggle icons when sorted
            $(this).click(function () {
                var sortInfo = $(this)[0].getAttribute("aria-sort");

                //Function call to toggle the sort icon On-Click.
                toggleIcons(sortInfo);

                //Function callto  Create callout.
                createCallouts();
            });

            /**
                * Function to Toggle the sort icon On-click.
                * @return NA
            */
            function toggleIcons(sortInfo) {
                //remove icons
                if (sortInfo == null) {
                    dropdownLink.prev('a').removeClass("filtered");
                }
                //see if any filters are checked
                var checkedCount = 0;
                filters.children().each(function () {
                    if ($(this).children(".gs-ecm-checkbox").prop("checked")) {
                        checkedCount++;
                    }
                });

                //determine which icon to display
                if (checkedCount > 0 && sortInfo) {
                    $('.sortIcon').remove();
                    iconClass = "descending";
                    if (sortInfo == "ascending") {
                        iconClass = "ascending";
                    }
                    dropdownLink.prev('a').before("<span class='sortIcon " + iconClass + "'>");
                    if (dropdownLink.prev('a').length == 0) {
                        dropdownLink.prev('img').prev().before("<span class='sortIcon " + iconClass + "'>");
                    }

                } else if (sortInfo) {
                    $('.sortIcon').remove();
                    iconClass = "descending";
                    if (sortInfo == "ascending") {
                        iconClass = "ascending";
                    }
                    dropdownLink.prev('a').before("<span class='sortIcon " + iconClass + "'>");
                }
                else if (checkedCount > 0) {
                    //$('.sortIcon').remove();
                    //iconClass = "gs-ecm-filter";
                    //dropdownLink.prev('a').before("<span class='gs-ecm-filter-icon " + iconClass + "'>");
                    dropdownLink.prev('a').addClass("filtered");
                }
            }
            //re-add lync presence on paging
            $(document).on('click', '.ui-button', function () {
                //Function callto  Create callout.
                createCallouts();
            });

            //add search button functionality
            $('#goFilter').click(function () {
                $("#DocsTable").dataTable().fnFilter($('#textSearchBox').val());
            });

            //sort descending by date
            if (i == 4) {
                $("#DocsTable").dataTable().fnSort([[4, 'desc']]);
                //dropdownLink.before("<span class='gs-ecm-sort-icon gs-ecm-sort-s'>");
            }

            //check for newly added document and move to top of table
            var lastAdded = sessionStorage.wblastadded;
            if (lastAdded != "" && lastAdded != null) {
                var row = $("a:contains(" + lastAdded + ")").parent().parent();
                row.insertAfter($(".gs-ecm-resultsgrid tr:first"));
                sessionStorage.wblastadded = "";
            }
        });
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}
function replaceSpecialCharacters(pattern) {
    var specials = new RegExp("[$+?^()\\[\\]{}\\\\]", "g"); // .*+?|()[]{}\$
    return pattern.replace(specials, "\\$&");
}
/**
    * Function to Update the filter container position.
    * @return NA
*/
function positionFilters() {
    try {
        reposition();
        var resizeTimer;

        //Event to handle resizing
        $(window).resize(function () {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(reposition, 100);
        });
        function reposition() {
            $('.gs-ecm-custom-filters').each(function () {
                var targetIcon = $(this).parent().find('.gs-ecm-dropdown');
                $(this).position({
                    "my": "right top",
                    "at": "right top-10%",
                    "collision": "fit none",
                    "of": targetIcon,
                });
            });
        }
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
    * Function to Clear filter
    * @return NA
*/
function fnResetAllFilters() {
    try {
        var oTable = $('.dataTable').dataTable();
        var oSettings = oTable.fnSettings();
        for (iCol = 0; iCol < oSettings.aoPreSearchCols.length; iCol++) {
            oSettings.aoPreSearchCols[iCol].sSearch = '';
        }
        $('input:checkbox').removeAttr('checked');
        $('.DataTables_sort_wrapper').find('a').removeClass("filtered");
        $('.sortIcon').remove();
        $('.startDate').val("")
        $('.endDate').val("")
        oSettings.oPreviousSearch.sSearch = '';
        oTable.fnDraw();

        createCallouts();
        filterBox.hide();
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

function HideOrShowAuditButtons() {

    siteUrl = document.URL.toLowerCase().split('/pages/')[0];

    $.ajax({
        url: siteUrl + "/_api/web/lists/getbytitle('efileConfigList')/items?$filer= Title eq AuditGrantAccessGroups",
        method: "GET",
        headers: {
            "Accept": "application/json;odata=verbose"
        },
        success: function (data) {
            $.each(data.d.results, function (index, item) {
                if (item.Title == "AuditGrantAccessGroups") {
                    var listItem = item.Value;
                    IsCurrentUserMemberOfGroup(listItem);
                }
            });
        },
        error: function (data) {
            WCFJSON();
            console.log(JSON.stringify(data));
            ULSOnError(JSON.stringify(data), document.location.href, 0);
        }

    });

}

function IsCurrentUserMemberOfGroup(groupName) {

    var groups = groupName.split(';');
    var currentContext = SP.ClientContext.get_current();
    var currentWeb = currentContext.get_web();

    var currentUser = currentContext.get_web().get_currentUser();
    var currentUserGroups = currentUser.get_groups();
    currentContext.load(currentUserGroups);


    var allGroups = currentWeb.get_siteGroups();
    currentContext.load(allGroups);

    var caGroup = allGroups.getByName(groups[0]);
    currentContext.load(caGroup, "Title");

    var usGroup = allGroups.getByName(groups[1]);
    currentContext.load(usGroup, "Title");

    currentContext.executeQueryAsync(function () {

        var userInGroup = false;
        var usGroupUserEnumerator = currentUserGroups.getEnumerator();
        while (usGroupUserEnumerator.moveNext()) {
            var usGroupUser = usGroupUserEnumerator.get_current();
            if (usGroupUser.get_title() == caGroup.get_title() || usGroupUser.get_title() == usGroup.get_title()) {
                userInGroup = true;
                break;
            }
        }
        WCFJSON();
        OnComplete(userInGroup);
    }, function (sender, args) {
        WCFJSON();
        $("#myNewAuditFormButton").hide();
        $("#myViewAuditFormButton").hide();
    });


}

function OnComplete(isPresent) {
    if (isPresent) {
        $("#myNewAuditFormButton").show();
        $("#myViewAuditFormButton").show();
    }
}
//ecm_newefile_callout starts
/**
 * Description: This file is used to attach callout for each eFile in the page.
 * Loads the values inside the callout.
 * Pages Referencing: MyNeweFile.aspx
*/

//call createCallouts once sp.js is loaded

ExecuteOrDelayUntilScriptLoaded(createCallouts, "sp.js");
/**
* Loading the required script for callouts
 * @return NA
*/

function createCallouts() {
    ULS.enable = true;
    SP.SOD.executeFunc('callout.js', 'SP.ClientContext', loadScripts);
    function loadScripts() {
        var scriptbase = _spPageContextInfo.webAbsoluteUrl + '/_layouts/15/';
        $.getScriptOnce(scriptbase + 'callout.js', function () {
        });

        $.getScriptOnce(scriptbase + 'mquery.js', function () {
        });
        $.getScriptOnce(scriptbase + 'core.js', function () {
        });

        $.getScriptOnce(scriptbase + 'sp.ui.dialog.js', function () {
        });
        $.getScriptOnce(scriptbase + 'sp.js', function () {
        });

    }

    //call CreateCallOutPopup once callout.js is loaded
    ExecuteOrDelayUntilScriptLoaded(CreateCallOutPopup, "callout.js");
}

/**
* creating callout body
* @return NA
*/

function CreateCallOutPopup() {
    try {

        setTimeout(function () {

            var count = 0;
            $(".callout").each(function (index) {
                count++;
                //gather info passed from item template
                var eFileNo = $(this).data('efileno');
                var InsuredName = $(this).data('insuredname');
                var uw = $(this).data('uw');
                var uwa = $(this).data('uwa');
                var broker = $(this).data('broker');
                var inc = $(this).data('inc');
                var incDate = new Date(inc);
                inc = incDate.format("MMM d, yyyy");

                var exp = $(this).data('exp');
                var expDate = new Date(exp);
                exp = expDate.format("MMM d, yyyy");

                var lob = $(this).data('lob');
                var product = $(this).data('product');
                var uwstage = $(this).data('uwstage');
                var ms = $(this).data('ms');
                var href = $(this).data('href');
                var listItemID = $(this).data('id');
                var entity = href.split('/');
                var entityValue = entity[3];

                //path is server relative url
                var path = href.substring(href.toLowerCase().indexOf(entityValue), href.length);
                var parts = path.split('/');

                // Set variables for file lookup.
                var targetRootSite = parts[0];
                var targetSite = parts[1];
                var targetLibrary = parts[2];
                var targetFolder = parts[3];

                var content = "<div><br></div>";

                //Build content display div by div
                content = content + "<div>eFile No.: " + eFileNo + "</div>";
                content = content + "<div>Insured Name : " + InsuredName + "</div>";
                content = content + "<div>Underwriter: " + uw + "</div>";
                content = content + "<div>Under. Asst: " + uwa + "</div>";
                content = content + "<div>Broker Company : " + broker + "</div>";
                content = content + "<div>Policy Inception Date: " + inc + "</div>";
                content = content + "<div>Policy Expiry Date: " + exp + "</div>";
                content = content + "<div>Line of Business : " + lob + "</div>";
                content = content + "<div>Product : " + product + "</div>";
                content = content + "<div>UW Stage: " + uwstage + "</div>";
                content = content + "<div>Master Status : " + ms + "</div>";

                //set up calloutmanager variables - location, ID, orientation, etc
                var targetElement = this;
                var calloutOptions = new CalloutOptions();
                calloutOptions.ID = 'callout' + count;
                calloutOptions.launchPoint = targetElement;
                calloutOptions.beakOrientation = 'leftRight';
                calloutOptions.content = content;
                calloutOptions.title = eFileNo;
                calloutOptions.contentWidth = 450;

                calloutOptions.openOptions.event = 'hover';

                var myCustomCallout = CalloutManager.createNewIfNecessary(calloutOptions);
                //set up ellipsis.  Graphic is shown when menu is not expressly given a name
                var menuEntries = new Array();

                //View Properties
                var menuEntry1 = new CalloutActionMenuEntry('eFile Properties', function (action, selectedEntryIndex) {
                    var ready = Liberty.DocumentProperties.ready(eFileNo, listItemID, href, 'View');
                });
                menuEntries.push(menuEntry1);

                //Version History
                var menuEntry2 = new CalloutActionMenuEntry('Version History', function (action, selectedEntryIndex) {
                    entityVersion = targetRootSite;
                    siteVersion = targetSite;
                    var listGuid = getGuid(targetLibrary, listItemID);
                });
                menuEntries.push(menuEntry2);

                var menuActionOptions = new CalloutActionOptions();
                menuActionOptions.menuEntries = menuEntries;
                var menuAction = new CalloutAction(menuActionOptions);
                if (myCustomCallout.getActionMenu().getActions().length < 1) {
                    myCustomCallout.addAction(menuAction);
                }

            });
            var targetElement = document.getElementById('test');
            var calloutOptions = new CalloutOptions();
            calloutOptions.ID = 'callout1';
            calloutOptions.launchPoint = targetElement;
            calloutOptions.beakOrientation = 'leftRight';
            calloutOptions.content = 'This is the content';
            calloutOptions.title = 'This is a custom callout';
            calloutOptions.contentWidth = 450;
            calloutOptions.openOptions.event = 'click';

            var myCustomCallout = CalloutManager.createNewIfNecessary(calloutOptions);
            var customAction = new CalloutActionOptions();
            customAction.text = 'Action 1';
            customAction.onClickCallback = function (event, action) {
            };

            var _newCustomAction = new CalloutAction(customAction);
            myCustomCallout.addAction(_newCustomAction);
        }, 1000);


    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* function to load the list and get the GUID
* @param {string} targetLibrary [name of the list]
* @return NA
*/
function getGuid(targetLibrary, listitemid) {
    var targetSiteUrl = '/' + entityVersion + '/' + siteVersion;
    var tempListId = listitemid;

    var url = _spPageContextInfo.siteAbsoluteUrl + "/" + targetSiteUrl + "/_api/web/lists/getByTitle('" + targetLibrary + "')?$select=Id";

    //Trigger Ajax call
    $.ajax({
        url: url,
        method: "GET",
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (x, y, z) {   //getFile success method
            var results = JSON.parse(z.responseText);
            var listGuid = results.d.Id;

            var url = document.URL;
            var CurrentUrl = (document.URL).split("/");
            var rootUrl = CurrentUrl[2];
            var rootSite = entityVersion + '/' + siteVersion;

            //building te url for version history
            var test = '';
            test = CurrentUrl[0] + "//" + rootUrl + '/' + rootSite + '/_layouts/DocSetVersions.aspx?list=' + listGuid + '&ID=' + tempListId + '&IsDlg=1';
            ExecuteOrDelayUntilScriptLoaded(function () {
                SP.UI.ModalDialog.showModalDialog({ url: test });
                $('.ms-dlgFrame').load(function () {
                    for (var i = 0; i < frames.length; i++) {
                        $(".ms-unselectedtitle", frames[i].document).removeAttr('onmouseover');
                        $(".ms-unselectedtitle td:last-of-type", frames[i].document).hide();
                        $('td.ms-propertysheet', frames[i].document).each(function (index, value) {
                            var colName = $.trim($(this).text());
                            if (colName == 'PolicyYear') {
                                var yearValue = $(this).nextAll().first().text().replace(',', '');
                                $(this).nextAll().first().text(yearValue);
                            }
                        });
                    }
                });
                return false;
            }, "sp.js");
        },
        error: function (c, k, r) {   //getFile Error method
            console.log('------> ERROR:\n' + c.responseText);
            ULSOnError(c.responseText, document.location.href, 0);
        }
    });

}
