﻿/*Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
/**
 * Description: This file is used to attach callout for each eFile in the page.
 * Loads the values inside the callout.
 * Pages Referencing: myHome.aspx, allHome.aspx, InsuredPage.aspx
*/

//Global Variables
var itemId = 0;
var isDocSet = true;
var entityVersion = 0;
var siteVersion = 0;
var versionId = 0;
ULS.enable = true;
//call createCallouts once sp.init.js is loaded
ExecuteOrDelayUntilScriptLoaded(createCallouts, "SP.init.js");

/**
* Loading the required scripot for callouts
 * @return NA
*/
function createCallouts() {

    SP.SOD.executeFunc('callout.js', 'SP.ClientContext', loadScripts);
    function loadScripts() {
        var scriptbase = _spPageContextInfo.webAbsoluteUrl + '/_layouts/15/';
        $.getScriptOnce(scriptbase + 'callout.js', function () {
        });

        $.getScriptOnce(scriptbase + 'mquery.js', function () {
        });
        $.getScriptOnce(scriptbase + 'core.js', function () {
        });
    }

    //call CreateCallOutPopup once callout.js is loaded
    ExecuteOrDelayUntilScriptLoaded(CreateCallOutPopup, "callout.js");
}

/**
* creating callout body
* @return NA
*/
function CreateCallOutPopup() {
    setTimeout(function () {
        var count = 0;
        $(".callout").each(function (index) {
            count++;

            //context object creation
            //gather info passed from item template
            var href = $(this).data('href');
            var title = $(this).data('title');
            var modBy = $(this).data('modby');
            var ccID = $(this).data('ccid');
            var modByName = $(this).data('modname');
            var modDate = $(this).data('modby');
            var product = $(this).data('product');
            var functionalArea = $(this).data('functionalarea');
            var policyInceptionDate = $(this).data('policyinceptiondate');
            var Underwriter = $(this).data('underwriter');
            var master = $(this).data('master');
            var Stage = $(this).data('stage');
            var intermediaryname = $(this).data('intermediaryname');
            var intermediarycode = $(this).data('intermediarycode');

            var polNumber = $(this).data('entityname');
            var contentsource = $(this).data('contentsource');
            if (!$isNull(contentsource)) {
                if (contentsource.toLowerCase().indexOf('efiledocument') > 0) {
                    isDocSet = false;
                }
            }
            itemId = $(this).data('listitemid');
            var listitemid = $(this).data('listitemid');
            var entityName;

            //modify title div to make text visible                         
            title = "<div style='color:#000000;'>" + title + "</div>";
            var content = "<div><br></div>";

            /*
            Jyoti Commented
            var entity = href.split('/');
            var entityValue = entity[3];

            //path is server relative url
            var path = href.substring(href.toLowerCase().indexOf(entityValue), href.length);
            var parts = path.split('/');

            // Set variables for file lookup.
            var targetRootSite = parts[0];
            var targetSite = parts[1];
            var targetLibrary = parts[2];
            var targetFolder = parts[3];

            // Set target folder correctly for CB and APUW libraries.
            if (parts.length > 5) {
                targetFolder += '/' + parts[4];
            }
            */

            //Jyoti : Corrections in url
            var path = href;
            var entity = path.split('/');
            var entityValue = entity[3];

            var fullPath = path;
            //path = path.substring(path.toLowerCase().indexOf(entityValue), path.length);
            var parts = path.split('/');
            var partsLength = parts.length;
            // Set variables for file lookup.
            var targetRootSite = parts[0] + '/' + parts[1] + '/' + parts[2];
            var targetSite = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4];
            var targetLibrary = parts[5];
            var targetFolder = parts[6];



            //Get the source library path
            var libraryPath = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4] + '/' + parts[5];



            //set up display and query variables based on entity type
            var acctURL = "../Pages/PolicyDetails.aspx?PolicyNumber=" + targetFolder;
            var sourceDisplay = "eFile No: ";
            var passType = "Account";
            entityName = targetFolder;

            //Build content display div by div
            //Changed by with Lync presence
            // content = content + "<div>Changed By: <span> <span class='ms-imnSpan'><a href='#' onclick='IMNImageOnClick(event);return false;' class='ms-imnlink ms-spimn-presenceLink' >";
            //content = content + "<span class='ms-spimn-presenceWrapper ms-imnImg ms-spimn-imgSize-10x10'><img name='imnmark' title='' ShowOfflinePawn='1' class='ms-spimn-img ms-spimn-presence-disconnected-10x10x32' src='/_layouts/15/images/spimn.png?rev=23' alt='User Presence' sip=" + modBy + " id=" + ccID + " />";
            //content = content + "</span></a></span><span><a href='#' onclick='IMNImageOnClick(event);return false;' class='ms-imnlink' tabIndex='-1'>";
            //content = content + "<img name='imnmark' title='' ShowOfflinePawn='1' class=' ms-hide' src='/_layouts/15/images/spimn.png?rev=23' alt='User Presence' sip=" + modBy + " id=" + ccID + " />";

            //modified by/date/time
            //content = content + "</a>" + modByName + " on " + modDate + "</span></span></div>";

            //entity link - error message for items not returning a proper URL from search
            if (acctURL !== "") {
                content = content + "<div>" + sourceDisplay + polNumber + "</a></div>";
            } else {
                content = content + "<div>" + sourceDisplay + "</div>";
            }
            content = content + "<div>UW Stage: " + Stage + "</div>";
            content = content + "<div>Line of Business : " + functionalArea + "</div>";
            content = content + "<div>Inception Date : " + policyInceptionDate + "</div>";
            content = content + "<div>Product : " + product + "</div>";
            content = content + "<div>Underwriter : " + Underwriter + "</div>";
            content = content + "<div>Master Status : " + master + "</div>";
            content = content + "<div>IMD Name : " + intermediaryname + "</div>";
            content = content + "<div>IMD Code : " + intermediarycode + "</div>";

            //set up calloutmanager variables - location, ID, orientation, etc
            var targetElement = this;
            var calloutOptions = new CalloutOptions();
            calloutOptions.ID = 'callout' + count;
            calloutOptions.launchPoint = targetElement;
            calloutOptions.beakOrientation = 'leftRight';
            calloutOptions.content = content;
            calloutOptions.title = "";
            calloutOptions.contentWidth = 450;
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet PC/i.test(navigator.userAgent)) {
                calloutOptions.openOptions.event = 'click';
            } else {
                calloutOptions.openOptions.event = 'hover';
            }
            var myCustomCallout = CalloutManager.createNewIfNecessary(calloutOptions);

            //set up ellipsis.  Graphic is shown when menu is not expressly given a name
            var menuEntries = new Array();

            //View Properties
            var menuEntry1 = new CalloutActionMenuEntry('eFile Properties', function (action, selectedEntryIndex) {
                if (isDocSet) {
                    var ready = Liberty.DocumentProperties.ready(passType, listitemid, href, 'View');
                }
                else {
                    entityVersion = targetRootSite;
                    siteVersion = targetSite;
                    getDocSetId(passType, href, targetLibrary, targetFolder);
                }
            });
            menuEntries.push(menuEntry1);

            //Version History
            var menuEntry8 = new CalloutActionMenuEntry('Version History', function (action, selectedEntryIndex) {
                entityVersion = targetRootSite;
                siteVersion = targetSite;

                var listGuid = getGuid(targetLibrary, listitemid);
            });
            menuEntries.push(menuEntry8);

            var menuActionOptions = new CalloutActionOptions();
            menuActionOptions.menuEntries = menuEntries;
            var menuAction = new CalloutAction(menuActionOptions);
            if (myCustomCallout.getActionMenu().getActions().length < 1) {
                myCustomCallout.addAction(menuAction);
            }
        });

        var targetElement = document.getElementById('test');
        var calloutOptions = new CalloutOptions();
        calloutOptions.ID = 'callout1';
        calloutOptions.launchPoint = targetElement;
        calloutOptions.beakOrientation = 'leftRight';
        calloutOptions.content = 'This is the content';
        calloutOptions.title = 'This is a custom callout';
        calloutOptions.contentWidth = 450;
        calloutOptions.openOptions.event = 'click';

        var myCustomCallout = CalloutManager.createNewIfNecessary(calloutOptions);
        var customAction = new CalloutActionOptions();
        customAction.text = 'Action 1';
        customAction.onClickCallback = function (event, action) {
        };

        var _newCustomAction = new CalloutAction(customAction);
        myCustomCallout.addAction(_newCustomAction);
    }, 1000);
}
var context = null;
var web = null;
/**
* function to load the list and get the GUID
* @param {string} targetLibrary [name of the list]
* @return NA
*/
function getGuid(targetLibrary, listitemid) {
    //var targetSiteUrl = '/' + entityVersion + '/' + siteVersion;
    var targetSiteUrl = siteVersion;

    var context = null;

    //getting the product site client content
    context = new SP.ClientContext(targetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(targetLibrary);
    context.load(list);
    tempListId = listitemid;
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethod), Function.createDelegate(this, this.onFailureMethod));
}

// on success build the url for version history with GUID and list item id
function onSuccessMethod(sender, args) {
    var listGuid = list.get_id();
    var url = document.URL;
    var CurrentUrl = (document.URL).split("/");
    var rootUrl = CurrentUrl[2];

    //var rootSite = entityVersion + '/' + siteVersion;
    var rootSite = siteVersion;

    //building te url for version history
    var test = '';
    if (isDocSet) {
        //test = CurrentUrl[0] + "//" + rootUrl + '/' + rootSite + '/_layouts/DocSetVersions.aspx?list=' + listGuid + '&ID=' + tempListId + '&IsDlg=1';
        test = rootSite + '/_layouts/DocSetVersions.aspx?list=' + listGuid + '&ID=' + tempListId + '&IsDlg=1';
    }
    else {
        //test = CurrentUrl[0] + "//" + rootUrl + '/' + rootSite + '/_layouts/Versions.aspx?list=' + listGuid + '&ID=' + tempListId + '&IsDlg=1';
        test = rootSite + '/_layouts/Versions.aspx?list=' + listGuid + '&ID=' + tempListId + '&IsDlg=1';
    }
    ExecuteOrDelayUntilScriptLoaded(function () {
        SP.UI.ModalDialog.showModalDialog({ url: test });
        $('.ms-dlgFrame').load(function () {
            for (var i = 0; i < frames.length; i++) {
                $(".ms-unselectedtitle", frames[i].document).removeAttr('onmouseover');
                $(".ms-unselectedtitle td:last-of-type", frames[i].document).hide();
                $('td.ms-propertysheet', frames[i].document).each(function (index, value) {
                    var colName = $.trim($(this).text());
                    if (colName == 'PolicyYear') {
                        var yearValue = $(this).nextAll().first().text().replace(',', '');
                        $(this).nextAll().first().text(yearValue);
                    }
                    if (colName == 'Region' || colName == 'eFileNote' || colName == 'IsSpotlight') {
                        $(this).parent().hide();
                    }
                });
            }
        });
        return false;
    }, "sp.js");
}

//on failure
function onFailureMethod(sender, args) {
    console.log('getting guid failed');
    ULSOnError(args.get_message(), document.location.href, 0);
}

function getDocSetId(passType, href, targetLibrary, targetFolder) {
    var id = 0;
    //var targetSiteUrl = '/' + entityVersion + '/' + siteVersion;
    var targetSiteUrl = siteVersion;
    var context = null;
    context = new SP.ClientContext(targetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(targetLibrary);

    //Added by Jyoti
    var serverUrl = _spPageContextInfo.webAbsoluteUrl;
    var fileRef = href;
    var itemFileRef = '';
    var camlQuery = SP.CamlQuery.createAllItemsQuery();
    var folderUrl = targetSiteUrl + '/' + targetLibrary;
    camlQuery.set_folderServerRelativeUrl(folderUrl);
    var listItems = list.getItems(camlQuery);
    context.load(listItems);

    //var fileRef = targetSiteUrl + "/" + targetLibrary + "/" + targetFolder;
    /*fileRef = decodeURIComponent(fileRef);
    var camlString = "<View><Query><Where><Eq><FieldRef Name='FileRef' /><Value Type='Text'>" + fileRef + "</Value></Eq>";
    camlString += "</Where></Query><RowLimit>1</RowLimit><ViewFields><FieldRef Name='ID' /></ViewFields></View>";
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(camlString);
    listItems = list.getItems(camlQuery);
    context.load(listItems, "Include(ID)");*/
    context.executeQueryAsync(function () {
        count = listItems.get_count();
        if (count > 0) {
            var enumerator = listItems.getEnumerator();
            while (enumerator.moveNext()) {
                var currentItem = enumerator.get_current();
                itemFileRef = serverUrl + currentItem.get_item('FileRef');
                if (itemFileRef == fileRef) {
                    id = currentItem.get_item('ID');
                }
            }
            var ready = Liberty.DocumentProperties.ready(passType, id, href, 'View');
        }
    },
    function (sender, args) {
        console.log('error in getting docset id');
        ULSOnError(args.get_message(), document.location.href, 0);
    });
}