/*Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
/*
*File Description:
*Provides the list of documents present for the selected eFile in a tabel format.
*JQuery DataTable plugin functionality is utilized.
*Paging, sorting , filtering, search datatable are avaliable.
*Custom Security trimming is implemented
*'Create New Document' functionality is also present.
*/

//Global Variables
ULS.enable = true;
var currentUserID;
var categoryTagsArray = [];
var prodSiteUrl, folderPath, libPath;
var curDocPolicyIDField = 'EFPolicyNumberOWSTEXT';
var curDocSubmissionIDField = 'EFSubmissionNumberOWSTEXT';
var entityType, targetSiteUrl;
var currentUserGroups = "";
var globalCounter = 0;
var callCounter = 0;
var rowID = 0;
var filterFlag = false;
var entityEnum = {
    Account: 0,
    AccountPrincipal: 1,
    Agency: 2,
    CBR_Bond: 3,
    Principal: 4,
    eFile: 5
};
var targetLibrary;
/*
*Intial call to load required jquery datatable plugins and construct the datatable
*The datatable contains the list of documents present for the selected eFile
*/
$(document).ready(function () {
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        $.getScript("/Style%20Library/ECM/scripts/jquery.dataTables.js", function () {
            $.getScript('/Style%20Library/ECM/scripts/dataTables.getColumnData.js', function () {
                var oTable = $("#DocsTable").dataTable(
                 {
                     "iDisplayLength": 25,
                     "bPaginate": true,
                     "bLengthChange": false,
                     "bFilter": true,
                     "bSort": true,
                     "bInfo": true,
                     "bAutoWidth": false,
                     "bJQueryUI": true,
                     "sPaginationType": "full_numbers",
                     "aaSorting": [[8, 'desc']],
                     "aoColumns": null,
                     "oLanguage": {
                         "sEmptyTable": "Loading documents...",
                         "sSearch": "   ",
                         "sInfo": "",
                         "sInfoFiltered": "",
                         "sInfoEmpty": "",
                         "oPaginate": {
                             "sNext": '<span class="ms-promlink-button-image" id="PagingImageLink"><img src="/Style%20Library/ECM/images/rightsmall.png"></span>',
                             "sPrevious": '<span class="ms-promlink-button-image" id="PagingImageLink"><img src="/Style%20Library/ECM/images/leftsmall.png"></span>'
                         }
                     },
                     "sDom": '<"top"ifl>t<"bottom"pi>',
                     "fnInitComplete": function () {
                         $("#DocsTable_last").addClass('ms-promlink-button-enabled').show();
                         $("#DocsTable_first").addClass('ms-promlink-button-enabled').show();
                     },
                     "fnDrawCallback": function (oSettings) {
                         /*Added to resolve defect TFS#104726 -Add Total Number of Pages Returned on all Search Results Pages*/
                         var iPage = Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength);
                         var iTotalPages = Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength);
                         var htmlString = "";

                         if (iTotalPages > 1) {
                             htmlString = 'You are viewing page ' + (iPage + 1) + ' of ' + iTotalPages + '.';
                             $('#ViewCurrentPage').html(htmlString);
                         }
                         if (oSettings.fnRecordsDisplay() == 0) {
                             $('.dataTables_empty').text("No documents associated with this eFile.");
                         }
                         var pageCount = $("#PageNumbers").children().length;
                         if (pageCount > 1) {
                             $(".bottom").show();

                         } else {
                             $(".bottom").hide();
                         }
                         createCallouts();
                         $(".fg-button").bind('click', paginateScroll);
                     }
                 }
                );
                $(".bottom").hide();
                oTable.fnFilterOnReturn();
                // Initial Call to assign classes
                ProcessEntity();
                $('.imgNoFilter').show()
                $('.imgFilter').hide()
                $("h3[title='']").addClass('active');
            });
        });
    });

    //getting the document group from config list and updating the global array
    //used to keep a counter of the documents- used in dragDrop
    var docGroupList = getFromConfigList('DocumentGroups');
    docGroupList = docGroupList.split(',');
    for (i = 0; i < docGroupList.length; i++) {
        {
            categoryTagsArray.push(new groupCountItem(docGroupList[i], 0));
        }

    }
    function paginateScroll() {
        $('#s4-workspace').scrollTop($('#s4-workspace')[0].scrollHeight + $('#MSOZoneCell_WebPartWPQ1')[0].scrollHeight - $('#MSOZoneCell_WebPartWPQ2')[0].scrollHeight - $('#MSOZoneCell_WebPartWPQ3')[0].scrollHeight);
        $(".fg-button").unbind('click', paginateScroll);
        $(".fg-button").bind('click', paginateScroll);
    }
    function groupCountItem(group, count) {
        this.Group = group;
        this.Count = count;
    }
});

/*
*jquery datatable plugin empty call
*/
function showcolumns() {
}

/*
*Redirects the page to specified url path
@param url {string} [url path]
@return NA
*/
function docRedirect(url) {
    var decodeUrl = decodeURIComponent(url);
    window.location.href = decodeUrl;
}

/*
*Construct table heading and call the Search REST api to fetch the url path of eFile
@return NA
*/
function ProcessEntity() {
    $('.dataTables_filter label').append('<input type="button" class="gs-ecm-searchbutton" id="goFilter"/><br><br>');
    // Adding table heading
    $('.dataTables_filter').attr("style", "display:inline-block");
    $('.dataTables_filter').attr("id", "SearchBox");
    $('.dataTables_filter').attr("class", "gs-ecm-searchbox fg-toolbar");
    $('.gs-ecm-document-tabs').insertAfter('.top');
    $('#DocsTable_paginate').attr("class", "ms-srch-Paging");
    $('#DocsTable_paginate').attr("style", "display:inline-block");
    $('.dataTables_info').attr("class", "ms-srch-resultscount ms-srch-resultFooter gs-ecm-results ms-srch-result dataTables_info");
    $('.dataTables_info').attr("style", "display:inline-block");
    $('#DocsTable_paginate').append('<br><br>');
    /*Added to resolve defect TFS#104726 -Add Total Number of Pages Returned on all Search Results Pages*/
    $('.bottom').append('<div id="ViewCurrentPage"></div>');
    var url = document.location.href;
    var entityName = url.substring((url.toLowerCase().indexOf('?') + 1), url.toLowerCase().indexOf('='));
    entityName = entityName.charAt(0).toUpperCase() + entityName.slice(1).toLowerCase();
    var entityID = WBgetQueryStringParameter(entityName);
    var searchFieldName, searchFieldID, folderName;
    var parentFolder = '';
    var accountId = '';
    searchFieldName = 'gs-ecm' + entityName.toLowerCase() + 'ID';
    searchFieldID = entityID;
    var policyLocation = WBgetQueryStringParameter("polLoc");
    policyLocation = decodeURIComponent(policyLocation);
    _TMPtargetSiteUrl = policyLocation;
    var _newTemp = _TMPtargetSiteUrl.split('/');
    var _newFileTargetLibrary = _newTemp[5];
    var _newParentFolder = "";
    var _newFolderName = _newTemp[6];
    if (_TMPtargetSiteUrl == null || _TMPtargetSiteUrl == undefined || _TMPtargetSiteUrl == "") {
        // Call to search rest api to get the policy specific site collection path/details
        WBgetSiteCollectionURLArray(searchFieldName, searchFieldID).then(
            function (scData) {
                _TMPtargetSiteUrl = getTargetSiteUrl(scData);
                var folderName = _TMPtargetSiteUrl.substring(_TMPtargetSiteUrl.lastIndexOf("/") + 1);
                var baseUrl = _TMPtargetSiteUrl.slice(0, _TMPtargetSiteUrl.lastIndexOf("/"));
                var targetLibName = baseUrl.substring(baseUrl.lastIndexOf("/") + 1);
                var parentFolder = '';
                targetSiteUrl = baseUrl.slice(0, baseUrl.lastIndexOf("/"));
                if (targetSiteUrl == '') {
                    $(".dataTables_empty").text("User does not have permission to view this document set or document set does not exist.");
                    return;
                }

                // Get the documents from target eFile 
                ProcessLibraries(entityName, entityID, targetSiteUrl, folderName, parentFolder, targetLibName);

            }
        )
    }
    else {
        _TMPtargetSiteUrl = _newTemp[0] + "/" + _newTemp[1] + "/" + _newTemp[2] + "/" + _newTemp[3] + "/" + _newTemp[4]
        ProcessLibraries(entityName, entityID, _TMPtargetSiteUrl, _newFolderName, parentFolder, _newFileTargetLibrary);
    }
}


/*
*Get Current Userpermission Groups and call ProcessDocSet
@param entityName {string} [Name of the target querystring]
@param entityID {string} [current eFile number]
@param targetSiteUrl {string} [Regional site url path where the eFile is present]
@param folderName {string} [current eFile folder name]
@param parentFolder {string} [current eFile parent folder name]
@param targetLibName {string} [current eFile list name]

@return NA
*/
function ProcessLibraries(entityName, entityID, targetSiteUrl, folderName, parentFolder, targetLibName) {

    var lastFlag = false;
    var firstFlag = true;
    var DocLibs = new Array(targetLibName);

    for (var i in DocLibs) {
        callCounter = DocLibs.length;


        if (i == (DocLibs.length - 1)) {

            lastFlag = true;
        }
        //Construct 
        ProcessDocSet(entityName, entityID, targetSiteUrl, DocLibs[i], folderName, parentFolder, firstFlag, lastFlag);


        firstFlag = false;
    }
}


/*
*Constructs the eFile url path and calls getFiles
@param entityName {string} [Name of the target querystring]
@param entityID {string} [current eFile number]
@param targetSiteUrl {string} [Regional site url path where the eFile is present]
@param folderName {string} [current eFile folder name]
@param parentFolder {string} [current eFile parent folder name]
@param firstFlag {string} [Flag to check loop start count ]
@param lastFlag {string} [Flag to check loop finish count]
@return NA
*/
function ProcessDocSet(entityName, entityID, targetSiteUrl, docLib, folderName, parentFolder, firstFlag, lastFlag) {

    var UrlParts = targetSiteUrl.split("/");
    var ServerRelativeUrl = UrlParts[3] + "/" + UrlParts[4];


    if (parentFolder == "") {
        var DocSetPath = "/" + ServerRelativeUrl + "/" + docLib + "/" + folderName;
    } else {
        var DocSetPath = "/" + ServerRelativeUrl + "/" + docLib + "/" + parentFolder + "/" + folderName;
    }
    //Set Metadata field name
    switch (entityName.toLowerCase()) {
        case 'policynumber':
            var curTaxonomyField = 'EFeFileDocumentGroup';
            var curAdditionalField = 'EFeFileDocumentType';
            var curTitleField = entityName;
            break;

        default:
            var DocLibs = new Array("ERROR");
            break;
    }


    // Get the list items and load them.
    var clientContext = new SP.ClientContext(targetSiteUrl);
    getFiles(clientContext, targetSiteUrl, DocSetPath, docLib, curTaxonomyField, curAdditionalField, curTitleField, firstFlag, lastFlag).then(
       function () {
           callCounter--;
       }
       )

}

// Get each document with in the document set and render the table 
function getFiles(clientContext, targetSiteUrl, DocSetPath, docLib, curTaxonomyField, curAdditionalField, curTitleField, firstFlag, lastFlag) {


    var mydeferred = $.Deferred();
    var xFolder = clientContext.get_web().getFolderByServerRelativeUrl(DocSetPath);
    var xFiles = xFolder.get_files();
    clientContext.load(xFiles, 'Include(ListItemAllFields)');

    clientContext.executeQueryAsync(
    function () {

        var curCounter = xFiles.get_count();
        if (curCounter == 0) {
            $('input.gs-ecm-th-select').attr('disabled', 'disabled');
            $('.dataTables_empty').text("No documents associated with this eFile."); $('#textSearchBox').attr("disabled", "disabled");
            //set intial count to '0'
            for (var i = 0; i < categoryTagsArray.length; i++) {
                $('#' + categoryTagsArray[i].Group.toString().replace(' ', '') + ' .gs-ecm-document-count').html('0');
            }
            $('#G-All #folder-header').text('0');
        }
        //alert("Document Count " + curCounter);
        globalCounter = globalCounter + curCounter;
        var enumerator = xFiles.getEnumerator();
        var totalCount = 0;
        while (enumerator.moveNext()) {

            var curFile = enumerator.get_current();
            totalCount++;
            // Loops through each document
            getItemInfo(clientContext, targetSiteUrl, curFile, curTaxonomyField, curAdditionalField, curTitleField, enumerator, firstFlag, lastFlag)
            globalCounter--;
            console.log("getItemInfo----->>>Count :" + callCounter + " -- " + lastFlag + " -- " + curCounter + " -- " + globalCounter);
            if (globalCounter == 0) {
                createCallouts();
                createDropdowns(firstFlag, lastFlag);
                positionFilters();
                addUniqueRowID();
                //createDropdowns(firstFlag, lastFlag);
            }
            setTimeout(function () {

                //setting the count in the dragDrop zone

                for (var i = 0; i < categoryTagsArray.length; i++) {
                    $('#' + categoryTagsArray[i].Group.toString().replace(' ', '') + ' .gs-ecm-document-count').html(categoryTagsArray[i].Count);
                }
                $('#G-All #folder-header').text(totalCount);
            }, 100);
        }
        mydeferred.resolve();
    },
        function (sender, args) {
            mydeferred.reject();
            ULSOnError(args.get_message(), document.location.href, 0);
        });


    return mydeferred.promise();


}

//get document information - loops for each document
function getItemInfo(clientContext, targetSiteUrl, curFile, curTaxonomyField, curAdditionalField, curTitleField, enumerator, firstFlag, lastFlag) {
    var curDocument = curFile.get_listItemAllFields();

    //get the values using CSOM “get_item()” method
    var curFileType = curDocument.get_item('File_x0020_Type');
    var curTyping = Liberty.Utilities.docTypeParse(curFileType, 2);
    var curTypeGraphic = curTyping[1];
    var curName = curDocument.get_item('FileLeafRef');
    var curModified = curDocument.get_item('Modified');
    var curCreated = curDocument.get_item('Created');
    var curModifiedstr = new Date(curModified);


    var curCreatedstr = new Date(curCreated);

    var curModifiedUserId = curDocument.get_item('Editor').get_lookupValue().toString();
    var curAuthor = curDocument.get_item('Author').get_lookupValue().toString();
    var curMetadata = curDocument.get_item(curTaxonomyField);
    var curDocStatus = curDocument.get_item('EFDocumentStatus');
    var curEmailTo = curDocument.get_item('EFEmailTo');

    //Updated with if to fix Defect: 101498 User is unable to sort the documents in eFile details page by clicking Email From and Email to columns
    if (curEmailTo != null && curEmailTo.indexOf("<") != -1 && curEmailTo.indexOf(">") != -1) {
        curEmailTo = curEmailTo.substring(0, curEmailTo.indexOf("<"));
    }
    var curSubject = curDocument.get_item('EFSubject');
    if (curSubject == null) {
        curSubject = "";
    }
    var curEmailDate = '';
    if (curDocument.get_item('EFEmailDate') != null) {
        var curEmailDateTemp = new Date(curDocument.get_item('EFEmailDate'));
        curEmailDate = curEmailDateTemp.format("MMM dd, yyyy")

    }
    var curEmailFrom = curDocument.get_item('EFEmailFrom');
    //Updated with if to fix Defect: 101498 User is unable to sort the documents in eFile details page by clicking Email From and Email to columns
    if (curEmailFrom != null && curEmailFrom.indexOf("<") != -1 && curEmailFrom.indexOf(">") != -1) {
        curEmailFrom = curEmailFrom.substring(0, curEmailFrom.indexOf("<"));
    }
    var curDocTypeItem = curDocument.get_item("EFeFileDocumentType");
    var curDocType = null;


    if (curDocTypeItem == null) {
        curDocType = "";
    } else {
        curDocType = curDocTypeItem;
    }


    var curDocCategory = curDocument.get_item("EFeFileDocumentGroup");

    //looping through the documents and incrementing the count
    if (curDocCategory) {
        for (var l = 0; l < categoryTagsArray.length; l++) {
            if (curDocCategory.toString().toLowerCase() == categoryTagsArray[l].Group.toString().toLowerCase()) {
                categoryTagsArray[l].Count += 1;
                break;
            }
        }
    }

    var curDocGroup = null;

    if (curDocCategory == null) {
        curDocGroup = "";
    } else {
        curDocGroup = curDocCategory;
    }


    var curEditor = curDocument.get_item('Editor').get_lookupValue().toString();

    var curEntity = curDocument.get_item("EFPolicyNumber");
    var curCheckout = curDocument.get_item('CheckoutUser');
    var curInsured = curDocument.get_item('EFInsuredName');

    var curFileSize = curDocument.get_item('File_x0020_Size');


    var curPath = curDocument.get_item('FileRef');
    var UrlParts = targetSiteUrl.split("/");
    var ServerUrl = UrlParts[0] + "//" + UrlParts[2];
    var curUrl = ServerUrl + curPath;
    //curUrl = curUrl.replace("'", "%27");
    //Added by Vaibhav to fix apostrophe issue in document name 
    curUrl = curUrl.replace(/'/g, '%27');


    var curUrlLocal = encodeURIComponent(curUrl);
    curNameLocal = '<a href="javascript:void(0)" class="documentUrl" onclick="javascript:docRedirect(\'' + curUrlLocal + '\');">' + curName + '</a>';
    var curEditorName = curEditor;
    var curEditorSip = curDocument.get_item('Editor').get_lookupId().toString();
    var curCheckName;
    var fileType = '<img src="' + curTypeGraphic + '"><span style="display:none">' + curFileType + '</span>';
    var ListItemID = curDocument.get_id();
    if (curCheckout == "" || curCheckout == null) {
        curCheckName = "";
    }
    else {
        curCheckName = curDocument.get_item('CheckoutUser').get_lookupValue().toString();
        fileType = '<img src="' + curTypeGraphic + '"><img src="/_layouts/15/images/checkoutoverlay.gif" class="ms-vb-icon-overlay" alt="' + curName + '" Checked Out To:' + curCheckName + ' title="' + curName + ' Checked Out To: ' + curCheckName + '"><span style="display:none">' + curFileType + '</span>';
    }
    var curCheckSip = "";


    // Variable to display the call out

    var curEllipsis = '<div id="Item_Default"><div data-listitemid="' + ListItemID + '" data-rowid="' + (globalCounter + 1) + '" data-entityname="' + curDocCategory + '" data-account="' + curDocCategory + '" data-agency="' + curEntity + '" data-bond="' + curEntity + '" data-principal="' + curInsured + '" data-transprinc="' + curInsured + '" data-filetype="' + curFileType + '" data-lockuser="' + curCheckSip + '" data-lockusername="' + curCheckName + '" data-modby="' + curModified + '" data-modname="' + curEditor + '"   data-moddate="' + curModified + '" data-title="' + curName + '" data-href="' + curUrl + '"   data-path="' + curUrl + '" class="callout" id="' + (globalCounter + 1) + '"class="callout" id="' + (globalCounter + 1) + '" name="Item" data-displaytemplate="DefaultItem"><a title="Open Menu" class="ms-lstItmLinkAnchor ms-ellipsis-a"><img data-title="' + curName + '" class="ms-ellipsis-icon" src="/_layouts/15/images/spcommon.png?rev=23"></a></div></div>';
    var checkTag = '<input type="checkbox" class="gs-ecm-document-check" data-size="' + curFileSize + '" data-locked="false" />';

    //Added false to avoid redraw of table. Resolves the defect TFS#104352 - ECM US_Efiles with a high count of documents are taking too long to load
    $("#DocsTable").dataTable().fnAddData([
         checkTag,
         fileType,
         curNameLocal,
         curEllipsis,
         curDocType,
         curDocStatus,
         curDocGroup,
         curModifiedUserId,
         curModifiedstr.format("MMM dd, yyyy"),
         curCreatedstr.format("MMM dd, yyyy"),
         curEmailTo,
         curSubject,
         curEmailFrom,
         curEmailDate
    ], false);
}

// Load the current user to set security trimming on folders.        
function getCurrentUserGroup() {

    // Set variables. 
    var currentUserStr = "";
    var deferred = $.Deferred();
    var ctx = new SP.ClientContext.get_current();
    var web = ctx.get_web();
    var currentUser = web.get_currentUser();
    var userGroupTitle = '';
    var errorMessage = 'Failed to load user data. Please contact your system administrator.';

    // Load current user.
    ctx.load(currentUser);
    ctx.executeQueryAsync(successUser, failUser);

    function successUser() {
        var userGroups = currentUser.get_groups();
        ctx.load(userGroups);
        ctx.executeQueryAsync(successUserGroups, failUserGroups);

        // Get the user's group membership.
        function successUserGroups() {

            // Check if user is in more than one group.
            var userGroupsEnum = userGroups.getEnumerator();

            // Check if user is in at least one group.
            if (userGroupsEnum.moveNext()) {
                var curGroup = userGroupsEnum.get_current();
                userGroupTitle = curGroup.get_title();
                currentUserGroups = currentUserGroups + ";" + curGroup.get_title();
            }
            else {
                //displayWarningMessage(errorMessage);
            }

            deferred.resolve();
        }

        // Notify user if their personal information could not be loaded.
        function failUserGroups(sender, args) {
            //  displayWarningMessage(errorMessage);
            // ko.applyBindings(new TaxonomyViewModel(userGroupTitle), $('#taxDD #groups')[0]);
            deferred.reject();
            ULSOnError(args.get_message(), document.location.href, 0);
        }
    }

    // Notify the user if their personal information could not be loaded.
    function failUser() {
        // displayWarningMessage(errorMessage);
        deferred.reject();
        ULSOnError(args.get_message(), document.location.href, 0);
    }

    return deferred.promise();
}


function WBgetQueryStringParameter(paramToRetrieve) {

    var params = document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0].toLowerCase() == paramToRetrieve.toLowerCase()) {
            strParams = singleParam[1].split("#")[0];
            break;
        }
    }
    return strParams;
}



function getTargetSiteUrl(scData) {
    var urls = scData.d.query.PrimaryQueryResult.RelevantResults.Table.Rows.results;
    if (urls.length == 0)
        return '';

    var result = urls[0].Cells.results[2].Value;
    folderName = result.substr(result.lastIndexOf("/") + 1);
    var baseUrl = result.slice(0, result.lastIndexOf("/"));


    if (entityType == entityEnum.CBR_Bond ||
        entityType == entityEnum.AccountPrincipal) {
        parentFolder = baseUrl.substr(baseUrl.lastIndexOf("/") + 1);
        baseUrl = baseUrl.slice(0, baseUrl.lastIndexOf("/"));
    }

    baseUrl = baseUrl.slice(0, baseUrl.lastIndexOf("/"));

    return result;
}

function WBgetSiteCollectionURLArray(searchFieldName, searchFieldID) {



    var searchParameter = curDocPolicyIDField + ':' + searchFieldID + ' OR ' + curDocSubmissionIDField + ':' + searchFieldID;

    var url = _spPageContextInfo.webAbsoluteUrl + "/_api/search/query?querytext='" + searchParameter + "%20iscontainer:true'&selectproperties='path'";

    var deferred = $.ajax({
        url: url,
        method: "GET",
        headers: {
            "accept": "application/json;odata=verbose"
        }
    });

    return deferred.promise();
}


//lync presence needs unique row IDs
function addUniqueRowID() {

    $('.gs-ecm-lync-placeholder').each(function (index) {
        $(this).data("rowid", Math.floor((Math.random() * 1000000) + 1));
    });
}
// Creates filter drop down for each th - gets called for each column
function createDropdowns(firstFlag, lastFlag) {
    var filterBox;

    $("thead th").each(function (i) {
        if ($('.filter_column.filter_date_range').length > 0) return;
        //skip 1st (checkbox) and 4th column (callout)
        if (i > 0 && i != 3) {
            var columnName = $(this).text();
            var cellValue = $(this).find(">div.DataTables_sort_wrapper>a").text();
            // get unique column data based on index
            var filterValues = $("#DocsTable").dataTable().fnGetColumnData(i);
            var classArray = $(this).attr('class').split(" ");
            var className = classArray[1];
            var columnHeader = $(this);
            var filterDiv = "";
            if (String(cellValue).indexOf('Date') != -1 || String(cellValue) === 'Created') {
                filterDiv += "<div class='gs-ecm-custom-filters ms-ref-refiner " + className + "' style='text-transform:none;font-weight:normal;border:1px #999 solid;position:absolute;z-index:100;background-color:#FFF;display:block;color:black;font-size:13px;font-family:Arial,sans-serif'>";
                filterDiv += "<div class='gs-ecm-columnheaders-actions' style='padding:5px 0px 5px 10px'>"
                filterDiv += "<div id='SubmitValue' style='width:220px'>";
                filterDiv += "<div class='gs-ecm-columnheaders-actions-close'></div>";
                filterDiv += "<div id='submit'>";
                filterDiv += "<a class='gs-ecm-columnheaders-actions-apply dRange' style='padding:5px 15px;margin-right:5px'>Apply</a>";
                filterDiv += "<a class='gs-ecm-columnheaders-actions-clear' style='padding:5px 15px;margin-right:5px'>Clear</a>";
                filterDiv += "</div></div></div>";
                filterDiv += '<div class="gs-ecm-daterange" ><div class="frm-group"><label for="fromDate">From</label><input type="text" class="startDate " name="from" value="" readonly /></div><div class="frm-group"><label for="toDate">To</label><input type="text" class="endDate"  readonly  name="to" value="" /></div></div>';
            } else {
                //create filter HTML
                filterDiv += "<div class='gs-ecm-custom-filters ms-ref-refiner " + className + "' style='text-transform:none;font-weight:normal;border:1px #999 solid;position:absolute;z-index:100;background-color:#FFF;display:block;color:black;font-size:13px;font-family:Arial,sans-serif'>";
                filterDiv += "<div class='gs-ecm-columnheaders-actions' style='padding:5px 0px 5px 10px'>"
                filterDiv += "<div id='SubmitValue' style='width:220px'>";
                filterDiv += "<div class='gs-ecm-columnheaders-actions-close'></div>";
                filterDiv += "<div id='submit'>";
                filterDiv += "<a class='gs-ecm-columnheaders-actions-apply' style='padding:5px 15px;margin-right:5px'>Apply</a>";
                filterDiv += "<a class='gs-ecm-columnheaders-actions-clear' style='padding:5px 15px;margin-right:5px'>Clear</a>";
                filterDiv += "</div></div></div>";
                filterDiv += '<div class="gs-ecm-all-filters" onclick="selectAll(this)"><span class="gs-ecm-sqr-filters"><span class="gs-ecm-sqrfill-filters"></span></span> <label>Select All</label></div>'
                filterDiv += "<div class='gs-ecm-columnheaders-filters' style='padding:5px 0px 5px 10px;border-top:1px #999 solid;max-height:180px;overflow-y:auto'>";
            }
            //enumerate through filter values
            var filterValueArray = [];
            for (j = 0; j < filterValues.length; j++) {
                filterValue = filterValues[j];
                if (i < 13) {
                    if (i != 10 && i != 11 && filterValue.toString().indexOf("<") >= 0) {
                        filterValue = $(filterValue).text();
                    }
                    filterValueArray.push(filterValue);
                }
                //split up Additional and Keyword filters
                if (i > 12) {
                    var taxValues = filterValue.split(';');
                    for (var m = 0; m < taxValues.length - 1; m++) {
                        filterValueArray.push(taxValues[m]);
                    }
                }
            }
            //sort and add to div
            //Updated filterValueArray.sort as below to fix Defect 101497:Filter drop down display values in descending order in My eFiles page Spotlight Web part
            filterValueArray.sort(function (a, b) {
                var x = a.toLowerCase();
                var y = b.toLowerCase();
                return ((x < y) ? -1 : ((x > y) ? 1 : 0));
            });
            for (var k = 0; k < filterValueArray.length; k++) {
                if (String(cellValue).indexOf('Date') == -1 && String(cellValue) !== 'Created')
                    filterDiv += "<div class='gs-ecm-filter-row' id='Value' style='padding:4px 0'><input class='gs-ecm-checkbox' type='checkbox' onclick='selectStates()'><label style='color:#666666' class='ms-ref-name ms-displayInlineBlock ms-ref-ellipsis'>" + filterValueArray[k] + "</label></div>"
            }
            filterDiv += "</div></div>";
            $(this).find('.gs-ecm-custom-filters').remove();
            $(this).prepend(filterDiv);
        }

        //hide filters to start
        $('.gs-ecm-custom-filters').hide();
        //open filters on click
        filterBox = $(this).children('.gs-ecm-custom-filters');
        var dropdownLink = $(this).children().children('.gs-ecm-dropdown-link');
        $(document).mousedown(function (e) {
            var container = $('.gs-ecm-custom-filters,#ui-datepicker-div');
            if (!container.is(e.target) // if the target of the click isn't the container...
            && container.has(e.target).length === 0) // ... nor a descendant of the container
            {
                container.each(function () {
                    $(this).hide();
                })
            }
        });
        $(document).mouseup(function (e) {
            var container = $(".startDate,.endDate");
            if (container.is(e.target)) // ... nor a descendant of the container
            {
                $('#ui-datepicker-div').show()
            }
        });

        dropdownLink.click(function (e) {
            e.stopPropagation();
            var container = $('.gs-ecm-custom-filters');
            container.each(function () { $(container).hide(); })
            $(this).parent().prev('.gs-ecm-custom-filters').toggle();
            efileDetailsRefinerMobile(dropdownLink);
        });
        $("input.startDate,input.endDate").
        datepicker({
            dateFormat: "M dd, yy",
            changeMonth: true,
            changeYear: true,
            yearRange: '1900:2100'
        });
        //get checked values for apply button
        var applybutton = $(this).find('.gs-ecm-columnheaders-actions-apply').not('.dRange');
        var applyDatebutton = $(this).find('.gs-ecm-columnheaders-actions-apply.dRange');
        var filters = $(this).find('.gs-ecm-columnheaders-filters');
        applyDatebutton.click(function (e) {
            e.stopPropagation();
            var startDate = $('.startDate:visible').val();
            var endDate = $('.endDate:visible').val();
            if ($('.startDate:visible').val().length == 0 && $('.endDate:visible').val().length > 0) {
                startDate = $('.endDate:visible').val();
            } else if ($('.startDate:visible').val().length > 0 && $('.endDate:visible').val().length == 0) {
                endDate = $('.startDate:visible').val();
            }
            $('.startDate:visible').val(startDate);
            $('.endDate:visible').val(endDate);
            var checkedValues = new Array();
            startDate = new Date(startDate);
            startDate = startDate.format("MM/dd/yyyy");
            endDate = new Date(endDate);
            endDate = endDate.format("MM/dd/yyyy");
            var dateStart = parseDateValue(startDate);
            var dateEnd = parseDateValue(endDate);
            var columnIndex = $(this).parents('.gs-ecm-ref-target').index();
            var data = $("#DocsTable").dataTable().fnGetData();
            for (var j = 0; j < data["length"]; j++) {
                var adate = new Date(data[j][columnIndex]);
                adate = adate.format("MM/dd/yyyy");
                var evalDate = parseDateValue(adate);
                if (evalDate >= dateStart && evalDate <= dateEnd) {
                    checkedValues.push(data[j][columnIndex]);
                }
            }
            if (checkedValues.length == 0) {
                checkedValuesString = "''";
            }
            else
                checkedValuesString = checkedValues.join("|");
            $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false);

            if ($("#DocsTable").find('.dataTables_empty').length) {
                $('.dataTables_empty').text("No results were found.");
            }

            // Function for converting a mm/dd/yyyy date value into a numeric string for comparison (example 08/12/2010 becomes 20100812
            function parseDateValue(rawDate) {
                var dateArray = rawDate.split("/");
                var parsedDate = dateArray[2] + dateArray[0] + dateArray[1];
                return parsedDate;
            }

            //rangeFilter(trElm);
            dropdownLink.prev('a').addClass("filtered");
            $(this).closest('.gs-ecm-custom-filters').toggle();
        });
        //apply checked filters
        applybutton.click(function (e) {
            e.stopPropagation();
            var checkedValues = new Array();
            filters.children().each(function () {
                if ($(this).children(".gs-ecm-checkbox").is(":checked")) {
                    var value = $(this).text();
                    checkedValues.push("^" + replaceSpecialCharacters(unescape(value)) + "$");
                }
            });
            if ($('.uploader.active').length > 0 && $(this).closest('th').hasClass('gs-ecm-th-category')) {
                $('.uploader').removeClass('active');
                $('h3.gs-ecm-document-header').addClass('active');
            }
            checkedValuesString = checkedValues.join("|"); //join multiple values with the "|" regex OR operator

            //Added to resolve the defect TFS#95891 and 98092 - Remove the special characters, so that user can filter if the name contains special characters
            if (checkedValuesString.length > 0) { $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false); }
            else { $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false); }

            toggleIcons(null);
            positionFilters();
            addUniqueRowID();
            createCallouts();
            $(this).closest('.gs-ecm-custom-filters').toggle();
        });

        //clear values and checkboxes
        var clearbutton = $(this).find('.gs-ecm-columnheaders-actions-clear');
        clearbutton.click(function (e) {
            e.stopPropagation();
            $(this).parents(".gs-ecm-columnheaders-actions").siblings().find(".gs-ecm-checkbox").removeAttr("checked");
            $(this).parents(".gs-ecm-columnheaders-actions").siblings().find(".gs-ecm-sqrfill-filters").removeClass('solidfill intfill');
            checkedValuesString = "";
            if ($(this).closest('th').hasClass('gs-ecm-th-category')) {
                $('.uploader.active, h3.gs-ecm-document-header').removeClass('active');
                $("h3[title='']").addClass('active');
            }
            if ($(this).siblings().hasClass('dRange')) {
                $('.startDate:visible').val("")
                $('.endDate:visible').val("")
            }

            $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false);
            toggleIcons(null);
            positionFilters();
            addUniqueRowID();
            createCallouts();
            //createDropdowns();
            //emailButtons();
            $(this).closest('.gs-ecm-custom-filters').toggle();
        });

        //close button functionality
        var closebutton = $(this).find('.gs-ecm-columnheaders-actions-close');
        closebutton.click(function (e) {
            e.stopPropagation();
            //clear checkboxes if not filtered
            if (!columnHeader.find('.gs-ecm-filter-icon').length && !columnHeader.find('.filtered').length) {
                filters.children().each(function () {
                    $(this).children(".gs-ecm-checkbox").prop("checked", false);
                });
                filters.parent().find('.gs-ecm-sqrfill-filters').removeClass('solidfill intfill');
            }
            $(this).closest('.gs-ecm-custom-filters').hide();
        });

        //stops sorting when you click filters
        $('.gs-ecm-custom-filters').click(function (e) {
            e.stopPropagation();
        });

        //unbind click event for certain column headers
        $('.gs-ecm-disable-sort').unbind("click");

        //toggle icons when sorted
        $(this).click(function (e) {
            var sortInfo = $(this)[0].getAttribute("aria-sort");
            toggleIcons(sortInfo);
            addUniqueRowID();
            createCallouts();
            ProcessImn();
        });

        function toggleIcons(sortInfo) {
            //remove icons
            if (sortInfo == null) {
                dropdownLink.prev('a').removeClass("filtered");
                if (dropdownLink.prev('a').length == 0) {
                    $('.imgNoFilter').show()
                    $('.imgFilter').hide()
                }
            }
            //see if any filters are checked
            var checkedCount = 0;
            filters.children().each(function () {
                if ($(this).children(".gs-ecm-checkbox").prop("checked")) {
                    checkedCount++;
                }
            });

            //determine which icon to display
            if (checkedCount > 0 && sortInfo) {
                $('.sortIcon').remove();
                iconClass = "descending";
                if (sortInfo == "ascending") {
                    iconClass = "ascending";
                }
                dropdownLink.prev('a').before("<span class='sortIcon " + iconClass + "'>");
                if (dropdownLink.prev('a').length == 0) {
                    dropdownLink.prev('img').prev().before("<span class='sortIcon " + iconClass + "'>");
                }
            } else if (sortInfo) {
                $('.sortIcon').remove();
                iconClass = "descending";
                if (sortInfo == "ascending") {
                    iconClass = "ascending";
                }
                dropdownLink.prev('a').before("<span class='sortIcon " + iconClass + "'>");
                if (dropdownLink.prev('a').length == 0) {
                    dropdownLink.prev('img').prev().before("<span class='sortIcon " + iconClass + "'>");
                }
            }
            else if (checkedCount > 0) {
                dropdownLink.prev('a').addClass("filtered");
                if (dropdownLink.prev('a').length == 0) {
                    $('.imgNoFilter').hide()
                    $('.imgFilter').show()
                }
            }
        }

        //re-add lync presence on paging
        $('.ui-button').click(function () {
            addUniqueRowID();
            createCallouts();

        });

        //add search button functionality
        $('#goFilter').click(function (e) {
            $("#DocsTable").dataTable().fnFilter($('#textSearchBox').val());
            createDropdowns();
        });

        //sort descending by date
        if (i == 8) {
            $("#DocsTable").dataTable().fnSort([[8, 'desc']]);
            //dropdownLink.before("<span class='gs-ecm-sort-icon gs-ecm-sort-s'>");
        }

        //check for newly added document and move to top of table
        var lastAdded = sessionStorage.wblastadded;
        if (lastAdded != "" && lastAdded != null) {
            var row = $("a:contains(" + lastAdded + ")").parent().parent();
            row.insertAfter($(".gs-ecm-resultsgrid tr:first"));
            sessionStorage.wblastadded = "";
        }


    });

    //Drag Drop Filtering on click on document groups
    var url = document.URL;
    var tValue = "";
    var documentGroup = readCookie("DocumentGroup");
    if (documentGroup != null && documentGroup != "#") {

        $("#DocsTable").dataTable().fnFilter(documentGroup, 6, true, false); //turn on regex, turn off smart filter
        //add class to filter data according to document group
        //$('th.gs-ecm-th-category div.DataTables_sort_wrapper>a').addClass('filtered');
        $('h3.gs-ecm-document-header').removeClass('active');
        $("div[title='" + documentGroup + "']").addClass('active');
        var categoryValues = $('div.gs-ecm-th-category .gs-ecm-columnheaders-filters').find('label');
        for (var i = 0; i < categoryValues.length; i++) {
            if ($(categoryValues[i]).text() == documentGroup) {
                $(categoryValues[i]).prev().prop("checked", true);
            }
        }
        $('div.gs-ecm-th-category .gs-ecm-sqrfill-filters').addClass('intfill');
        $('div.gs-ecm-th-category').siblings().find('a').first().addClass('filtered');

        //toggleIcons(null);
        positionFilters();
        addUniqueRowID();
        createCallouts();
        //emailButtons();
        if (filterBox.length > 0)
            filterBox.hide();
        if ($(".dataTables_empty").length > 0) {
            $('.gs-ecm-dropdown-link').css('text-decoration', 'none !important');
            $('.gs-ecm-dropdown-link').css('pointer-events', 'none');
            $('.gs-ecm-dropdown-link').css('Cursor', 'Default');
        }
        // }
        document.cookie = "DocumentGroup=#; path=/";
    }
    //$("h3[title='" + tValue + "']").addClass('active');
}
//function added to resolve the defect TFS#95891 and 98092
function replaceSpecialCharacters(pattern) {
    var specials = new RegExp("[$+?^()\\[\\]{}\\\\]", "g"); // .*+?|()[]{}\$
    return pattern.replace(specials, "\\$&");
}
// position the filters for each header <th>
function positionFilters() {
    reposition();
    var resizeTimer;

    //Event to handle resizing

    $(window).resize(function () {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(reposition, 100);
    });

    function reposition() {
        $('.gs-ecm-custom-filters').each(function (e) {
            var targetIcon = $(this).parent().find('.gs-ecm-dropdown');
            $(this).position({
                "my": "right top",
                "at": "right top-10%",
                "collision": "fit none",
                "of": targetIcon,
            });
        });
    }
}

/**
* Function to read the document cookie
* @param {string} name [name of the cookie to read]
*/
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

/*
Refreshes an element's contents on a user action, showing a modal dialog during the refresh
elementId  The id of the container element
qs         The Query String to append to the current URL
title      The title to show for the dialog
msg        The message to show in the dialog
*/

function refreshElement(elementId, qs, title, msg) {

    var elementObj = $("#" + elementId);
    var infoDialog = $("<div><div>" + msg + "</div><div class='aaa-please-wait'></div></div>").dialog({
        open: function (event, ui) {
            $(".ui-dialog-titlebar-close").hide();  // Hide the close X
            $(this).css("overflow-y", "visible");   // Fix for the scrollbar in IE
        },
        autoOpen: false,
        title: title,
        modal: true
    });
    infoDialog.dialog("open");

    elementObj.fadeOut("slow", function () {
        $.ajax({
            async: false,
            url: window.location.pathname + qs,
            complete: function (xData) {
                newHtml = $(xData.responseText).find("#" + elementId).html();
                elementObj.html(newHtml);
            }
        });
    }).fadeIn("slow", function () {
        infoDialog.dialog("close");
    });
}
function fnResetAllFilters() {
    var oTable = $('.dataTable').dataTable();
    var oSettings = oTable.fnSettings();
    for (iCol = 0; iCol < oSettings.aoPreSearchCols.length; iCol++) {
        oSettings.aoPreSearchCols[iCol].sSearch = '';
    }
    $('input:checkbox').removeAttr('checked');
    $('.DataTables_sort_wrapper').find('a').removeClass("filtered");
    $('.sortIcon').remove();
    $('.imgNoFilter').show();
    $('.imgFilter').hide();

    oSettings.oPreviousSearch.sSearch = '';
    oTable.fnDraw();
    createDropdowns();
    var pageurl = window.location.href;
    $('.uploader.active').removeClass('active');
    $('.gs-ecm-document-header').addClass('active');
    $("#DocsTable").dataTable().fnFilter('', 6, true, false);
    $('th.gs-ecm-th-category div.DataTables_sort_wrapper>a').removeClass('filtered');
    if (pageurl.indexOf('#') > -1) {
        var splitUrl = pageurl.split('#');
        window.location.href = splitUrl[0];
    }
}






function createFile(templatename, extension) {
    var docname = 'Document';;

    prodSiteUrl = '/' + newEfileUrl.split('/')[3] + '/' + newEfileUrl.split('/')[4];
    folderPath = '/' + newEfileUrl.split('/')[3] + '/' + newEfileUrl.split('/')[4] + '/' + newEfileUrl.split('/')[5] + '/' + newEfileUrl.split('/')[6] + '/';
    libPath = newEfileUrl.split('/')[3] + '/' + newEfileUrl.split('/')[4] + '/' + newEfileUrl.split('/')[5];
    targetLibrary = newEfileUrl.split('/')[5];
    var clientContext;
    var oWebsite;
    var oList;
    var fileCreateInfo;
    var fileContent;
    getCurrentUserID();

    clientContext = new SP.ClientContext(prodSiteUrl);
    oWebsite = clientContext.get_web();
    oList = oWebsite.get_lists().getByTitle(targetLibrary);
    var folder = clientContext.get_web().getFolderByServerRelativeUrl(newEfileUrl);
    // Create a date object with the current time
    var now = new Date();
    var date = [now.getMonth() + 1, now.getDate(), now.getFullYear()];
    var time = [now.getHours(), now.getMinutes(), now.getSeconds()];
    time[0] = (time[0] < 12) ? time[0] : time[0] - 12;
    time[0] = time[0] || 12;

    // If seconds and minutes are less than 10, add a zero
    for (var i = 1; i < 3; i++) {
        if (time[i] < 10) {
            time[i] = "0" + time[i];
        }
    }

    //CoreInvoke approach
    //  <a onclick=CoreInvoke('createNewDocumentWithRedirect2', event, 'https://tst-gsefilemanager.lmig.com/ca/spc-do-01/eFileLibrary/Forms/eFileDcoument/eFile_doc_template.dotx', 'https://tst-gsefilemanager.lmig.com/ca/spc-do-01/eFileLibrary/1124163 Alberta Ltd--14--PRL--S460199','SharePoint.OpenDocuments', false,'https://tst-gsefilemanager.lmig.com/ca/spc-do-01/_layouts/15/CreateNewDocument.aspx?id=https%3A%2F%2Ftst-gsefilemanager.lmig.com%2Fca%2Fspc-do-01%2FeFileLibrary%2FForms%2eFileDcoument %2Ftemplate.dotx', false, 1, 'ms-word');" >My New Document office webapp</a>
    if (templatename == 'template') {
        var encodedURL = encodeURI(newEfileUrl.split('/')[0] + '//' + newEfileUrl.split('/')[2] + '/' + libPath + '/Forms/eFileDocument/' + templatename + '.dotx');
        CoreInvoke('createNewDocumentWithRedirect2', event, newEfileUrl.split('/')[0] + '//' + newEfileUrl.split('/')[2] + '/' + libPath + '/Forms/eFileDocument/' + templatename + '.dotx', newEfileUrl, 'SharePoint.OpenDocuments', false, prodSiteUrl + '/_layouts/15/CreateNewDocument.aspx?id=' + encodedURL, false, 1, 'ms-word');
        $('.ms-dlgFrame').load(function () {
            for (var i = 0; i < frames.length; i++) {
                $('td.ms-formlabel', frames[i].document).each(function (index, value) {
                    var colName = $.trim($(this).text());
                    if (colName == 'EmailDate' || colName == 'EmailTo' || colName == 'EmailFrom' || colName == 'EmailCC') {
                        $(this).parent().hide();
                    }
                });
            }
        });
    }
    else {
        // Return the formatted string
        var dateTime = date.join("-") + "_" + time.join("-");

        // copyto approach
        newDocName = 'New' + docname + '_' + currentUserID + "_" + dateTime + "." + extension;
        var url = prodSiteUrl + "/_api/web/getfilebyserverrelativeurl('" + prodSiteUrl + "/eFileTemplates/Templates/" + templatename + "." + extension + "')/copyto(strnewurl='" + targetLibrary + "/" + encodeURIComponent(folderName) + "/" + newDocName + "', boverwrite=true)";
        $.ajax({
            url: prodSiteUrl + "/_api/contextinfo",
            type: "POST",
            contentType: "application/x-www-url-encoded",
            dataType: "json",
            headers: { "Accept": "application/json; odata=verbose", },
            success: function (data) {
                if (data.d) {
                    var digest = data.d.GetContextWebInformation.FormDigestValue;
                    $("#__REQUESTDIGEST").val(digest);
                    $.ajax({
                        url: url,
                        type: "POST",
                        headers: {
                            "accept": "application/json;odata=verbose",
                            "X-RequestDigest": digest,
                        },
                        success: function (data) {
                            var itemIdForDoc = getDocId();
                        },
                        error: function (err) {
                            console.log('Error: ' + err.responseText);
                            ULSOnError(err, document.location.href, 0);
                        }
                    });
                }
            },
            error: function (err) {
                console.log('Error: ' + err.responseText);
                ULSOnError(err, document.location.href, 0);
            }
        });
    }
}
function successHandler() {
    var itemIdForDoc = getDocId();
}

function errorHandler() {
    console.log('new OneNote creation failed' + arguments[1].get_message());
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}
function getDocId() {
    var targetSiteUrl = prodSiteUrl;
    var documentUri = folderPath + newDocName;
    var url = targetSiteUrl + "/_api/web/lists/getByTitle(@TargetLibrary)/items?$filter=FileRef eq '" + documentUri + "'&" +
      "@TargetLibrary='" + targetLibrary + "'";

    $.ajax({
        url: url,
        method: "GET",
        async: false,
        cache: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (x, y, z) {
            var results = JSON.parse(z.responseText);
            if (results.d.results.length == 1) {
                itemIdForDoc = results.d.results[0].Id;
                $('.new-docPolicy').text('New Document');
                // $('.new-docPolicy1').text('New Document');

                LoadEditPopUp(itemIdForDoc, libPath);

            }
            else {
            }
        },
        error: function (c, k, r) {   // Error method
            console.log('------> ERROR:\n' + c.responseText);
            ULSOnError(c.responseText, document.location.href, 0);
        }

    });
    return itemIdForDoc;
}
function LoadEditPopUp(itemIdForDoc, libraryPath) {
    var options = SP.UI.$create_DialogOptions();
    options.height = 1000;
    options.width = 600;
    options.title = 'Document Properties';
    options.url = '/' + libraryPath + '/Forms/EditForm.aspx?ID=' + itemIdForDoc;
    options.dialogReturnValueCallback = callbackFunction;
    SP.UI.ModalDialog.showModalDialog(options);
    $('.ms-dlgFrame').load(function () {
        for (var i = 0; i < frames.length; i++) {
            $('td.ms-formlabel', frames[i].document).each(function (index, value) {
                var colName = $.trim($(this).text());
                if (colName == 'EmailDate' || colName == 'EmailTo' || colName == 'EmailFrom' || colName == 'EmailCC') {
                    $(this).parent().hide();
                }
            });
        }
    });
}
function callbackFunction(dialogResult) {
    if (dialogResult == SP.UI.DialogResult.OK) {
        SP.UI.ModalDialog.showWaitScreenWithNoClose('Re-loading documents', '');
        SP.UI.ModalDialog.RefreshPage(dialogResult);
    }
}

//get user id
function getCurrentUserID() {
    var userid = _spPageContextInfo.userId;
    var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";
    var requestHeaders = { "accept": "application/json;odata=verbose" };
    $.ajax({
        url: requestUri,
        async: false,
        cache: false,
        contentType: "application/json;odata=verbose",
        headers: requestHeaders,
        success: onSuccess,
        error: onError
    });
}
function onSuccess(data, request) {
    var Logg = data.d;

    //get login id
    var loginName = Logg.LoginName.split('|')[1];
    var loginId = loginName.split('\\')[1];
    currentUserID = loginId;
}
function onError(error) {
    console.log("error in getting current user id");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}

function DismissErrDlg() { ULSiIp:; var a = window.top.g_childDialog; a && a.close(0) }

//ecm_policydetailsUtils.js starts
/**
* Description: This file is used to get and set values for Spotlight, Confidentiality, Note, UW stage, Claims and Version History.
* Loads the values for CEWP in details page.
* Pages Referencing: PolicyDetails.aspx
*/

var isChecked, spotCurID, claimChecked;
var policyNo, pExp, pInc;
var spotTargetSiteUrl;
var listTitle;
var spotCurID = getParams('policynumber');
var curSearchIDField = 'EFPolicyNumberOWSTEXT';
var curSubIDField = 'EFSubmissionNumberOWSTEXT';
var spotlightresults;
var newEfileUrl;
var dropId = 0;
var itemId = 0, confCheck, auditSet, auditGroupName, spotCheck;

//Confidential global
var groupName = '';
var targetRoleDefinitionName = 'Contribute';
var groupId, id;
var targetRoleDefinitionId;
var firsTime = true;
var region = '';
var productLine = '';
ULS.enable = true;

/**
* Gets the eFile Number from the url
* @param {string} name  [policynumber from the querystring]
 * @return {string} results [eFile number]
*/
function getParams(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search.toLowerCase());
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

/**
* function called on page load to get query string variables and decode URL components
* @return NA
*/
var polLocation;
var sp_id_loc;
function getCorrectSpId() {
    var itemdeferred = $.Deferred();
    var arr = polLocation.split('/');
    var DocSetPath = '/' + arr[3] + '/' + arr[4] + '/' + arr[5] + '/' + arr[6];
    var targetSiteUrl = arr[0] + '//' + arr[2] + '/' + arr[3] + '/' + arr[4];
    var clientContext = new SP.ClientContext(targetSiteUrl);
    xFolder = clientContext.get_web().getFolderByServerRelativeUrl(DocSetPath);
    fldValues = xFolder.get_listItemAllFields();
    clientContext.load(xFolder);
    clientContext.load(fldValues);
    clientContext.executeQueryAsync(
    function (sender, args) {
        sp_id_loc = fldValues.get_item('ID');
        var $hiddenInput = $('<input/>', { type: 'hidden', id: 'hdnSpId', value: sp_id_loc });
        $hiddenInput.appendTo('body');
        $hiddenInput.appendTo('body');
        itemdeferred.resolve();
    },
    function (sender, args) {
        console.log('request failed ' + args.get_message() + '\n' + args.get_stackTrace());
        itemdeferred.reject('request failed ' + args.get_message() + '\n' + args.get_stackTrace());
    }
    );
    return itemdeferred.promise();
}

$(document).ready(function () {
    sp_id_loc = WBgetQueryStringParameter("SpID");
    var isDoc = WBgetQueryStringParameter("IsDoc");
    polLocation = WBgetQueryStringParameter("polLoc");
    polLocation = decodeURIComponent(polLocation);
    if (isDoc != undefined && isDoc != '') {
        if ($('#hdnSpId').length == 0) {
            var p = getCorrectSpId();
            p.done(function () {
                getInitialValues();
            });
            p.fail(function (result) {
                var error = result;
                console.log(error);
            });
        }
        else {
            sp_id_loc = $('#hdnSpId').val();
            getInitialValues();
        }
    }
    else {
        getInitialValues();
    }
});

function getInitialValues() {
    if (polLocation.length == 0) {
        // render the policy details page
        spotlightgetTargetPaths();
    }
    else {
        // render policy details page from my new efiles page
        var temp = polLocation;
        var arrayspotTargetSiteUrl = temp.split('/');

        //setting the product site url, list Title and region
        spotTargetSiteUrl = "/" + arrayspotTargetSiteUrl[3] + "/" + arrayspotTargetSiteUrl[4];
        newEfileUrl = arrayspotTargetSiteUrl[0] + "/" + arrayspotTargetSiteUrl[1] + "/" + arrayspotTargetSiteUrl[2] + "/" + arrayspotTargetSiteUrl[3] + "/" + arrayspotTargetSiteUrl[4] + "/" + arrayspotTargetSiteUrl[5] + "/" + arrayspotTargetSiteUrl[6];
        region = arrayspotTargetSiteUrl[3];
        productLine = arrayspotTargetSiteUrl[4].split('-')[0];
        listTitle = arrayspotTargetSiteUrl[5];

        //load the values for spotlight,claims,confidentiality,uwstage and note
        loadValues(listTitle);

        //checking for readonly user permission
        getPermissionForReadOnly(sp_id_loc, listTitle);
    }
}


/**
* Get the target paths for the document sets associated with the entity.
* @return NA
*/
function spotlightgetTargetPaths() {
    // Create new client context and keyword query variables. 
    var spotCtx = SP.ClientContext.get_current();
    var spotKwQuery = new Microsoft.SharePoint.Client.Search.Query.KeywordQuery(spotCtx);

    // Set query parameters.
    spotKwQuery.get_selectProperties().add('Path');
    spotKwQuery.set_queryText(curSearchIDField + ':' + spotCurID + ' OR ' + curSubIDField + ':' + spotCurID);
    var searchExecutor = new Microsoft.SharePoint.Client.Search.Query.SearchExecutor(spotCtx);
    spotlightresults = searchExecutor.executeQuery(spotKwQuery);
    spotCtx.executeQueryAsync(onspotQuerySuccess, displayspotlightErrorMessage);
}

// Add all target library paths to array.
function onspotQuerySuccess() {
    var spotReturnedResult = spotlightresults.m_value.ResultTables[0].ResultRows;

    // target library path was found, let the user know the webpart is unavailable.
    if (spotReturnedResult.length == 0) {
        console.log("webpart is unavailable");
    }
    else {
        if (spotReturnedResult[0] !== null) {
            var temp = spotReturnedResult[0].Path;
            var arrayspotTargetSiteUrl = temp.split('/');

            //setting the product site url, list Title and region
            spotTargetSiteUrl = "/" + arrayspotTargetSiteUrl[3] + "/" + arrayspotTargetSiteUrl[4];
            newEfileUrl = arrayspotTargetSiteUrl[0] + "/" + arrayspotTargetSiteUrl[1] + "/" + arrayspotTargetSiteUrl[2] + "/" + arrayspotTargetSiteUrl[3] + "/" + arrayspotTargetSiteUrl[4] + "/" + arrayspotTargetSiteUrl[5] + "/" + arrayspotTargetSiteUrl[6];
            region = arrayspotTargetSiteUrl[3];
            productLine = arrayspotTargetSiteUrl[4].split('-')[0];
            listTitle = arrayspotTargetSiteUrl[5];

            //load the values for spotlight,claims,confidentiality,uwstage and note
            loadValues(listTitle);

            //checking for readonly user permission
            var hasPerm = sp_id_loc;
            getPermissionForReadOnly(hasPerm, listTitle);
        }
    }
}

// Function to replace the web part with an error message when the web part cannot be loaded.
function displayspotlightErrorMessage() {
    $('#loading').replaceWith('<div "gs-ecm-drag-drop-fail">This app part is currently unavailable. Please try again later.' +
    ' If this message persists please contact your system administrator. </div>');
}

/**
* Onclick function for UWStage
* Rest Api call to get id of the particular listItem.
* @return NA
*/
function setDropDown() {
    getPermissionDropDown(sp_id_loc);
}

/**
* function to check whether the user has permission to edit the list item.
* JSOM call to get a value that specifies the effective permissions on the
* list item that are assigned to the current user.
* @param {string} dropId [id of the particular list item] 
* @return NA
*/
function getPermissionDropDown() {
    var context = null;

    //Get the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethodDropDown), Function.createDelegate(this, this.onFailureMethodDropDown));

}
//On Success function
function onSuccessMethodDropDown(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {

        //user has permission to edit the list
        updateValue();
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }

}
//On failure 
function onFailureMethodDropDown() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}
/**
* function to update the UW stage for particular id in the list.
* @param {string} dropId [id of the particular list item]
* @return NA
*/
function updateValue() {
    var clientContext = null;
    var web = null;
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    this.oListItem = eFileList.getItemById(sp_id_loc);
    selectedVal = $("#stage option:Selected").text();

    //setting the UW stage with new value
    oListItem.set_item('EFUWStage', selectedVal);
    oListItem.update();
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededUpdateDrop), Function.createDelegate(this, this.onQueryFailedUpdateDrop));
}
//on success function
function onQuerySucceededUpdateDrop() {
}
//On failure
function onQueryFailedUpdateDrop(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}

/**
* function called on page load to retrieve the values
* for spotLight,Confidentiality,claims,note and UW stage.
* Rest Api call to get id of the particular listItem
* @param {string} listName  [name of the list]
* @return NA
 */
var srcCurrentUserID;
function loadValues(listName) {
    getUserLoginID();
    checkUserIdLoaded();
    getValue(sp_id_loc);
}

/**
* function to load the list item and
* JSOM call to check whether the item has unique security or 
* inherits its role assignments from a parent object.
* @return NA
*/
var deptChoiceField;
function getValue(id) {
    var clientContext = null;
    var web = null;

    //Get the product site client context
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    deptChoiceField = clientContext.castTo(eFileList.get_fields().getByInternalNameOrTitle('EFUWStage'), SP.FieldChoice);
    clientContext.load(deptChoiceField);
    this.oListItem = eFileList.getItemById(id);
    clientContext.load(oListItem);
    clientContext.load(oListItem, 'HasUniqueRoleAssignments');
    srcCurrentUserId = $('#currLoginId').val();
    productCurrentUserId = web.ensureUser(srcCurrentUserId);
    clientContext.load(productCurrentUserId);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceedDrop), Function.createDelegate(this, this.onQueryFailDrop));
}

//on success function
function onQuerySucceedDrop() {
    this.fillDropDown();

    //getting the spotlight item and setting the image
    var spUserId = productCurrentUserId.get_id();
    var check = oListItem.get_item('EFIsSpotlight');
    var lookupValueColl = new Array();
    var found = false;
    var lookupValueColl = oListItem.get_item('EFSpotlightUsers');
    if (lookupValueColl != null) {
        for (var i = 0; i < lookupValueColl.length; i++) {
            var lookupObject = lookupValueColl[i];
            //to get the id of the lookup field.
            lookUpId = lookupObject.get_lookupId();
            if (!found) {
                if (spUserId == lookUpId) {
                    found = true;
                    spotCheck = true;
                    $('#img').attr('src', '/Style%20Library/ECM/images/spotlight.png');
                    break;
                }
                else {
                    spotCheck = false;
                    $('#img').attr('src', '/Style%20Library/ECM/images/GreyStar.png');
                }
            }
        }
    }
    else {
        spotCheck = false;
        $('#img').attr('src', '/Style%20Library/ECM/images/GreyStar.png');
    }
    //getting the hasClaims item and setting the style
    //var claimCheck = oListItem.get_item('EFHasActiveClaims');
    /*if (claimCheck == true || claimCheck == 'Yes') {
        $("#setClaimImg").addClass('imgChecked');
        $('#setClaimImg').css('background-position', '-16px -236px');
    }
    else if (claimCheck == 'No' || claimCheck == false) {
        $("#setClaimImg").removeClass('imgChecked');
        $('#setClaimImg').removeAttr('style');
    }*/
    //getting the UW stage item and setting the dropdown value
    var selectedVal = oListItem.get_item('EFUWStage');
    $("#stage option").each(function (index, obj) {
        if ($(obj).val() == selectedVal) {
            $(obj).attr('selected', 'selected');
            $('.customSelect .selectVal').text($("#stage :selected").val());
        }
    })

    //getting the EfileNote item and setting the image
    var efNote = oListItem.get_item('EFeFileNote');
    if (efNote != null) {
        $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes-o.jpg');
    }
    else {
        $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes.jpg');
    }
    $('.note-flyout>textarea').val(efNote);

    //getting the items to be dispalyed in the CEWP
    //var sNo = oListItem.get_item('EFSubmissionNumber');
    //$("#eF-dtls-snum").html(sNo);

    var pNo = oListItem.get_item('EFPolicyNumber');
    $("#eF-dtls-pnum").html(pNo);

    var inName = oListItem.get_item('EFInsuredName');
    $('#eF-dtls-insname').html(inName);
    var insuredCode = oListItem.get_item('EFInsuredCode');
    if (insuredCode !== null || insuredCode != undefined) {
        insuredCode = insuredCode.replace(/\./g, ' ');
        insuredCode = insuredCode.replace(/,/g, ' ');
        var aa, bb, cc, dd;
        aa = (insuredCode.indexOf('@') == -1) ? 10000 : insuredCode.indexOf('@');
        bb = (insuredCode.indexOf('#') == -1) ? 10000 : insuredCode.indexOf('#');
        cc = (insuredCode.indexOf('$') == -1) ? 10000 : insuredCode.indexOf('$');
        dd = (insuredCode.indexOf('!') == -1) ? 10000 : insuredCode.indexOf('!');
        var _arr = [aa, bb, cc, dd];
        var minimum = Math.min.apply(Math, _arr);
        if (minimum > -1 && minimum <= insuredCode.length) {
            insuredCode = insuredCode.substr(0, minimum) + ' ' + insuredCode.substr(minimum + 1);
        }
    }
    insuredCode = encodeURIComponent(insuredCode);

    var insurednameURL = "/Pages/InsuredPage.aspx?InsuredCode=" + insuredCode + "*&";
    $('#eF-dtls-insname').attr("href", insurednameURL);

    var brComp = oListItem.get_item('EFIntermediaryName');
    $("#eF-dtls-intermediaryName").html(brComp);

    var uw = oListItem.get_item('EFUnderwriter');
    if (uw != null) {
        $("#eF-dtls-uw").html(uw.get_lookupValue());
    }

    var uwa = oListItem.get_item('EFUnderwritingAssistant');
    if (uwa != null) {
        $("#eF-dtls-uwa").html(uwa.get_lookupValue());
    }

    var branch = oListItem.get_item('EFBranchName');
    $("#eF-dtls-branch").html(branch);

    var product = oListItem.get_item('EFProduct');
    $("#eF-dtls-prdt").html(product);

    //Replaced the old code to resolve the local date time issue. Now dates are displaying based on server timezone.
    //Bug Fix for Ticket TFS#80526
    var ctx = new SP.ClientContext(spotTargetSiteUrl);
    var currentWeb = ctx.get_web();
    pInc = oListItem.get_item('EFPolicyInceptionDate');
    pExp = oListItem.get_item('EFPolicyExpiryDate');
    var incepDateStr = SP.Utilities.Utility.formatDateTime(ctx, currentWeb, pInc, SP.Utilities.DateTimeFormat.dateOnly);
    var expDateStr = SP.Utilities.Utility.formatDateTime(ctx, currentWeb, pExp, SP.Utilities.DateTimeFormat.dateOnly);
    ctx.executeQueryAsync(
	function (sender, data) {
	    if (pInc !== '') {
	        var incDate = new Date(incepDateStr.m_value);
	        //formatting the date to month, day and year
	        incDate = incDate.format("MMM d, yyyy");
	        $("#eF-dtls-incpDt").html(incDate);
	    }
	    if (pExp !== '') {
	        var expDate = new Date(expDateStr.m_value);
	        //formatting the date to month, day and year
	        expDate = expDate.format("MMM d, yyyy");
	        $("#eF-dtls-expDt").html(expDate);
	    }
	},
	function (sender, args) {
	    ULSOnError(args.get_message(), document.location.href, 0);
	}
	);

    var mtrStatus = oListItem.get_item('EFMasterStatus');
    $("#eF-dtls-ms").html(mtrStatus);
    //if policy number is null then set the submission number as PolicyNumber
    if (pNo == null) {
        policyNo = sNo;
        $('#markClaims').removeAttr('onclick');
        $('#markClaims').removeAttr('href');
        $('#markClaims').css('text-decoration', 'none !important');
        $('#markClaims').css('color', '#ccc');
        $('#markClaims').css('pointer-events', 'none');
        $('#markClaims').css('Cursor', 'Default');
    }
    else {
        policyNo = pNo;
    }
    $('#hdnEFileNumber').val(policyNo);
    //ULSOnError("ecm_policydetailsutils end time", new Date(), 0);

    //setting the icon for confidential based on role assignment
    confCheck = oListItem.get_item('EFIsConfidential');
    if (confCheck == true || confCheck == 'Yes') {
        $('a#confidentialtext').css('background-image', 'url(/Style%20Library/ECM/images/lock.png)');
    }
    else if (confCheck == 'No' || confCheck == false) {
        $('a#confidentialtext').css('background-image', 'url(/Style%20Library/ECM/images/lock-o.png)');
    }

    var disabledProdCodes;
    var siteUrl = document.URL.toLowerCase().split('/pages/')[0];
    $.ajax({
        url: siteUrl + "/_api/web/lists/getbytitle('efileConfigList')/items?$filter=Title eq 'Disable_Confidential_Codes'&$select=Value",
        type: "GET",
        async: false,
        cache: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            disabledProdCodes = data.d.results[0].Value;
            var currentProduct = product.toLowerCase();;
            disabledProdCodes = disabledProdCodes.toLowerCase();
            if (disabledProdCodes.indexOf(currentProduct) > -1) {
                $("#confidentialtext").removeAttr("onclick");
                $('#confidentialtext').removeAttr('href');
                $('#confidentialtext').css('text-decoration', 'none !important');
                $('#confidentialtext').css('color', '#ccc');
                $('#confidentialtext').css('pointer-events', 'none');
                $('#confidentialtext').css('Cursor', 'Default');
            }
        },
        error: function (data) {
            console.log(JSON.stringify(data));
            ULSOnError(JSON.stringify(data), document.location.href, 0);
        }
    });
}
function onQueryFailDrop(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}

//On success function to fill the drop down values
function fillDropDown() {
    var choices = deptChoiceField.get_choices();
    var ddlCategory = document.getElementById('stage');
    if (ddlCategory !== null) {
        for (var i = 0; i < choices.length; i++) {
            var theOption = new Option();
            theOption.text = choices[i];
            ddlCategory.options[i] = theOption;
        }
    }
}

/**
* Onclick function for SpotLight
* Rest Api call to get id of the particular listItem.
* @return NA
*/
var id = 0;
function setListItem() {
    getSpotlightPermissions();
}

/**
* function to check whether the user has permission to edit the list item.
* JSOM call to get a value that specifies the effective permissions on the
* list item that are assigned to the current user.
* @param {string} id [id of the list item]
* @return NA
*/
function getSpotlightPermissions() {
    var context = null;

    //Get the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onSpotSuccessMethod), Function.createDelegate(this, this.onSpotFailureMethod));

}

//on success set the respective images for spotlight
function onSpotSuccessMethod(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {

        //user has permission to edit and set the spotlight image
        if (spotCheck) {
            $('#img').attr('src', '/Style%20Library/ECM/images/GreyStar.png');
        }
        else {
            $('#img').attr('src', '/Style%20Library/ECM/images/spotlight.png');
        }
        updateList();
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }

}

//on failure function
function onSpotFailureMethod() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}
/**
* function to update the spot light for particular id in the list.
* @param {string} id [id of the list item]
* @return  NA
*/
var currentUserSpotID;
function updateList() {
    var clientContext = null;
    var web = null;
    var users = '';
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    oListItem = eFileList.getItemById(sp_id_loc);
    clientContext.load(oListItem);
    currentProductUser = web.ensureUser(srcCurrentUserId);
    clientContext.load(currentProductUser);
    clientContext.executeQueryAsync(function () {
        var _spUserID = currentProductUser.get_id();
        var spotUsers = oListItem.get_item('EFSpotlightUsers');
        if (spotUsers != null) {
            for (var i = 0; i < spotUsers.length; i++) {
                var lookupObject = spotUsers[i];
                //to get the id of the lookup field.
                lookUpId = lookupObject.get_lookupId();
                if (lookUpId != _spUserID) {
                    users += ";#" + lookUpId + ";#";
                }
            }
        }
        //change of spotlight image
        if (!spotCheck) {
            isChecked = 'Yes';
            users += ";#" + _spUserID + ";#";
            $('#img').attr('src', '/Style%20Library/ECM/images/spotlight.png');
        }
        else {
            isChecked = 'No';
            $('#img').attr('src', '/Style%20Library/ECM/images/GreyStar.png');
        }

        oListItem.set_item('EFSpotlightUsers', users);
        //oListItem.set_item('EFIsSpotlight', isChecked);
        oListItem.update();
        clientContext.executeQueryAsync(function () {
        },
        function (sender, args) {
            console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            ULSOnError(args.get_message(), document.location.href, 0);
        });
    },
    function (sender, args) {
        console.log("error in spot  call" + args.get_message());
    });
}

/**
* Onclick function for claims
* Rest Api call to get id of the particular listItem.
* @return NA
*/
var claimId = 0;
function setClaim() {
    getClaimPermissions(sp_id_loc);
}

/**
* function to check whether the user has permission to edit the list item.
* JSOM call to get a value that specifies the effective permissions on the
* list item that are assigned to the current user.
* @param {string} id [id of the list item]
* @return NA
*/
function getClaimPermissions() {
    var context = null;
    //Get the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onClaimSuccessMethod), Function.createDelegate(this, this.onClaimFailureMethod));

}

//on success set the respective styles for claims
function onClaimSuccessMethod(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {
        if ($("#setClaimImg").hasClass('imgChecked')) {
            $("#setClaimImg").removeClass('imgChecked');
            $('#setClaimImg').css('background-position', '-16px -236px');

        }
        else {
            $("#setClaimImg").addClass('imgChecked');
            $('#setClaimImg').removeAttr('style');

        }
        updateClaim();
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }

}
//on failure
function onClaimFailureMethod() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}

/**
* function to update the has claims for particular id in the list.
* @param {string} claimId [id of the list item]
* @return  NA
*/
function updateClaim() {
    var clientContext = null;
    var web = null;
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    this.oListItem = eFileList.getItemById(sp_id_loc);
    if ($("#setClaimImg").hasClass('imgChecked')) {
        claimChecked = 'Yes';
        $('#setClaimImg').css('background-position', '-16px -236px');

        //setting the eFileExpiration date to null
        oListItem.set_item('EFeFileExpirationDate', null);
    }
    else {
        claimChecked = 'No';
        $('#setClaimImg').removeAttr('style');

        //setting the eFileExpiration date with policy Expiration date
        oListItem.set_item('EFeFileExpirationDate', pExp);
    }
    oListItem.set_item('EFHasActiveClaims', claimChecked);
    oListItem.update();
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededClaim), Function.createDelegate(this, this.onQueryFailedClaim));

}
//on success
function onQuerySucceededClaim() {
}
//on failure
function onQueryFailedClaim(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}

/**
* Onclick function for efileNote
* Rest Api call to get id of the particular listItem.
* @return NA
*/
var noteId = 0;
function setNote() {
    getNotePermissions();
}

/**
* function to check whether the user has permission to edit the list item.
* JSOM call to get a value that specifies the effective permissions on the
* list item that are assigned to the current user.
* @param {string} noteId [id of the listItem] 
* @return NA
*/
function getNotePermissions() {
    var context = null;
    //Get the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onNoteSuccessMethod), Function.createDelegate(this, this.onNoteFailureMethod));

}
//on sucess update efileNote if user has permission
function onNoteSuccessMethod(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {
        //user has permission to edit
        updateNote();
    }
    else {
        var efPolUrl = _spPageContextInfo.siteAbsoluteUrl + spotTargetSiteUrl + "/_api/web/lists/getbytitle('" + listTitle + "')/items(" + sp_id_loc + ")?$select=EFeFileNote";
        $.ajax({
            url: efPolUrl,
            method: "GET",
            headers: {
                "Accept": "application/json;odata=verbose"
            },
            success: function (data) {
                var noteVal = '';
                if (data.d.EFeFileNote != null) {
                    noteVal = data.d.EFeFileNote;
                }
                $('.note-flyout>textarea').val(noteVal);
                //change of note image
                if (noteVal.length > 0) {
                    $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes-o.jpg');
                }
                else {
                    $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes.jpg');
                }
                alert("User has no edit permission. Please contact Administrator.");
            },
            error: function (data) {
                console.log(JSON.stringify(data));
            }
        });
    }
}
//on failure
function onNoteFailureMethod() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}

/**
* function to update the has eFileNote for particular id in the list.
* @param {string} noteId [id of the listItem] 
* @return NA
*/
function updateNote() {
    var clientContext = null;
    var web = null;
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    this.oListItem = eFileList.getItemById(sp_id_loc);
    //get the value from the flyout and update
    var details = $('.note-flyout>textarea').val();
    details = $.trim(details);
    $('.note-flyout>textarea').val(details);
    oListItem.set_item('EFeFileNote', details);
    //change of note image
    if (details.length > 0) {
        $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes-o.jpg');
    }
    else {
        $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes.jpg');
    }
    oListItem.update();
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededNote), Function.createDelegate(this, this.onQueryFailedNote));

}

//on success
function onQuerySucceededNote() {
}
//on failure
function onQueryFailedNote(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}


/**
* Onclick function for confidentiality
* Rest Api call to get id of the particular listItem.
* @return NA
*/
function getListItem() {
    assignPermission();
}

/**
* function to check whether the user has permission to edit the list item.
* JSOM call to check  whether the item has unique security or inherits its role assignments from a parent object
* @return NA
*/
function assignPermission() {
    var context = null;
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'HasUniqueRoleAssignments');
    context.load(listItem, 'EffectiveBasePermissions');
    listPermGroups = listItem.get_roleAssignments().get_groups();
    context.load(listPermGroups);
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethodDrop), Function.createDelegate(this, this.onFailureMethodDrop));
}
//on sucess 
function onSuccessMethodDrop(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {
        // if (!listItem.get_hasUniqueRoleAssignments()) {

        if (confCheck == false || confCheck == 'No') {
            if (!listItem.get_hasUniqueRoleAssignments()) {

                //has edit permission and doesnt have unique role assignments,audit not set
                auditSet = false;
            }
            else if (listItem.get_hasUniqueRoleAssignments()) {

                //has edit permission and have unique role assignments, audit set
                auditSet = true;
            }
            getConfidentialGroupName(confCheck);

        }

            //marking as not confidential
        else {

            //getting the groups and checking if the audit group is present
            var groupsEnum = listPermGroups.getEnumerator();
            while (groupsEnum.moveNext()) {
                var group = groupsEnum.get_current();
                groupName += group.get_title() + ';';
            }

            //getting the audit group from config list
            auditGroupName = getFromConfigList('AuditingGroupName');
            auditGroupName = auditGroupName.replace("|region|", region);
            if (groupName.indexOf(auditGroupName) > -1) {
                auditSet = true;
            }
            else {
                auditSet = false;
            }
            getConfidentialGroupName(confCheck);
            // updateListforConf(id, false);
        }
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }
}
//on failure
function onFailureMethodDrop() {
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
    console.log("assignPermission failed");
}
var confidentialGroups = [];
//function to get the confidential Group name from the list- efileConfigList
function getConfidentialGroupName(confCheck) {
    var clientContext = new SP.ClientContext.get_current();

    siteUrl = document.URL.toLowerCase().split('/pages/')[0];

    $.ajax({

        url: siteUrl + "/_api/web/lists/getbytitle('efileConfigList')/items?$filter=(Title eq 'ConfidentialConGroupName') or ((Title eq 'ConfidentialReadGroupName')) &$select=Value",
        type: "GET",
        async: false,
        cache: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            confConGroupName = data.d.results[0].Value;
            confReadGroupName = data.d.results[1].Value;
            //replacing the region with respective region as per the eFile
            confConGroupName = confConGroupName.replace("|region|", region);
            confConGroupName = confConGroupName.replace("|product|", productLine);
            confReadGroupName = confReadGroupName.replace("|region|", region);
            confReadGroupName = confReadGroupName.replace("|product|", productLine);

            confidentialGroups.push(confConGroupName);
            confidentialGroups.push(confReadGroupName);
            getGroupId(confCheck);
        },
        error: function (data) {
            console.log(JSON.stringify(data));
        }

    });

}
var confGroupId = [];
// Getting the ID of the target group.
function getGroupId(confCheck) {
    for (j = 0; j < confidentialGroups.length; j++) {
        $.ajax({
            url: spotTargetSiteUrl + '/_api/web/sitegroups/getbyname(\'' + confidentialGroups[j] + '\')/id',
            type: 'GET',
            async: false,
            cache: false,
            headers: { 'accept': 'application/json;odata=verbose' },
            success: function (responseData) {
                groupId = responseData.d.Id;
                //confGroupId.push(groupId);
                confGroupId.push({ name: confidentialGroups[j], id: groupId });
            },
            error: errorHandler
        });
    }
    //marking the efile as confidential
    if (confCheck == false || confCheck == 'No') {
        $('a#confidentialtext').css('background-image', 'url(/Style%20Library/ECM/images/lock.png)');
        updateListforConf(true);
    }
        //marking the efile as not confidential
    else {
        $('a#confidentialtext').css('background-image', 'url(/Style%20Library/ECM/images/lock-o.png)');
        updateListforConf(false);
    }
}

function errorHandler(xhr, ajaxOptions, thrownError) {
    alert('Request failed: ' + xhr.status + '\n' + thrownError + '\n' + xhr.responseText);
}

/**
* update the Confidential column  for particular id and breaking the role inheritance
* @param {string} id [id of the particular list item] 
 * @param {bool} flag [true or false based on permission]
* @return NA
*/
function updateListforConf(flag) {
    var clientContext = null;
    var web = null;

    //getting the product site client context
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    this.oListItem = eFileList.getItemById(sp_id_loc);

    //marking the efile as confidential
    if (flag == true) {

        //setting the isCOnfidential column in the list
        oListItem.set_item('EFIsConfidential', "Yes");
        oListItem.update();
        confCheck = "Yes";
        if (auditSet == false) {
            for (j = 0; j < confGroupId.length; j++) {
                //Creates unique role assignments
                oListItem.breakRoleInheritance(false);
                var collGroup = web.get_siteGroups();
                var oGroup = collGroup.getById(confGroupId[j].id);
                var collRoleDefinitionBinding = SP.RoleDefinitionBindingCollection.newObject(clientContext);

                // giving current user Contribute permissions to the item.
                oUser = clientContext.get_web().get_currentUser();
                if (confGroupId[j].name.indexOf('read') > -1) {
                    collRoleDefinitionBinding.add(clientContext.get_web().get_roleDefinitions().getByName('Read‐Only LIU Employees'));
                }
                else {
                    collRoleDefinitionBinding.add(clientContext.get_web().get_roleDefinitions().getByName('Contributor'));
                }
                oListItem.get_roleAssignments().add(oGroup, collRoleDefinitionBinding);
            }
            //Removes the role assignment object from the parent role assignment collection.
            principal = oListItem.get_roleAssignments().getByPrincipal(oUser);
            principal.deleteObject();

        }
            //audit is set, so add only confidential group
        else if (auditSet == true) {
            var collGroup = web.get_siteGroups();
            var oGroup = collGroup.getById(confGroupId[j].id);
            var collRoleDefinitionBinding = SP.RoleDefinitionBindingCollection.newObject(clientContext);

            // giving current user Contribute permissions to the item.
            oUser = clientContext.get_web().get_currentUser();
            collRoleDefinitionBinding.add(clientContext.get_web().get_roleDefinitions().getByName('Contributor'));
            oListItem.get_roleAssignments().add(oGroup, collRoleDefinitionBinding);
        }
    }

    //marking the efile as not confidential
    if (flag == false) {
        for (j = 0; j < confGroupId.length; j++) {
            //Audit is not set, reset the inheritance
            if (auditSet == false) {
                //Removing the local role assignments, re-inherit role assignments from the parent object.
                oListItem.resetRoleInheritance();
            }
                //audit is set, so remove only confidential group
            else if (auditSet == true) {
                var collGroup = web.get_siteGroups();
                var oGroup = collGroup.getById(confGroupId[j]);
                principal = oListItem.get_roleAssignments().getByPrincipal(oGroup);
                principal.deleteObject();
            }
        }
        oListItem.set_item('EFIsConfidential', "No");
        confCheck = "No";
        oListItem.update();
        confGroupId = [];
    }
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededUpdateListforConf), Function.createDelegate(this, this.onQueryFailedUpdateListforConf));
}
//on success
function onQuerySucceededUpdateListforConf() {
}
//on failure
function onQueryFailedUpdateListforConf(sender, args) {
    console.log('Request failed updateListforConf. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}
/// End Confidential functions


//// Start of VersionHistory Functions
//on click function for version history
function getVersionHistory() {
    getGuidDocSet();
}

//function to load the list and get the GUID
function getGuidDocSet() {
    var context = null;
    var web = null;

    //getting the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    context.load(list);
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethodDocSet), Function.createDelegate(this, this.onFailureMethodDocSet));
}
// on success build the url for version history with GUID and list item id
function onSuccessMethodDocSet(sender, args) {
    var listGuid = list.get_id();
    var url = document.URL;
    var CurrentUrl = (document.URL).split("/");
    var rootUrl = CurrentUrl[2];
    var test = CurrentUrl[0] + "//" + rootUrl + spotTargetSiteUrl + '/_layouts/DocSetVersions.aspx?list=' + listGuid + '&ID=' + sp_id_loc + '&IsDlg=1';

    //Using the DialogOptions class.
    var options = SP.UI.$create_DialogOptions();
    options.title = "eFile Version History";
    options.width = 600;
    options.height = 1000;
    options.url = test;

    //modal pop up for version history
    ExecuteOrDelayUntilScriptLoaded(function () {
        SP.UI.ModalDialog.showModalDialog(options);

        $('.ms-dlgFrame').load(function () {
            for (var i = 0; i < frames.length; i++) {
                $(".ms-unselectedtitle", frames[i].document).removeAttr('onmouseover');
                $(".ms-unselectedtitle td:last-of-type", frames[i].document).hide();
                $('td.ms-propertysheet', frames[i].document).each(function (index, value) {
                    var colName = $.trim($(this).text());
                    if (colName == 'PolicyYear') {
                        var yearValue = $(this).nextAll().first().text().replace(',', '');
                        $(this).nextAll().first().text(yearValue);
                    }
                    if (colName == 'Region') {
                        $(this).parent().hide();
                    }
                });
            }
        });

        return false;
    }, "sp.js");
}
function onFailureMethodDocSet(sender, args) {
    ULSOnError(args.get_message(), document.location.href, 0);
}

////End of Version History functions

/**
* function to check whether the user has permission to edit the list item
* @param {string} hasPerm  [id of the list item]
 * @param {string} targetLibrary [name of the list]
* @return NA
*/
//uncomment the following code for read only users once conflict with drag and drop is resolved
function getPermissionForReadOnly(hasPerm, listTitle) {
    var context = null;
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    this.listItem = list.getItemById(hasPerm);
    context.load(this.listItem, 'EffectiveBasePermissions');

    context.executeQueryAsync(function () {
        try {

            var perms = listItem.get_effectiveBasePermissions();
            if (perms.has(SP.PermissionKind.editListItems)) {
            }
            else {
                isUsrReadOnly = true;
                //hiding the note and disabling the efilkeDocument click for read only users

                $('.new-docPolicy').hide();
                //$('.new-docPolicy1').hide();
                $('.gs-ecm-actions-container').hide();
                $('.captureVersion').hide();

                //alert("User does not have edit permission");
            }
        }
        catch (e) {
        }
    }, function () {
        console.log("failed");
    });
}

//function called on click of capture version to get item id and open modal pop up
function setCaptureHistory() {
    itemId = sp_id_loc;
    setCaptureHistoryForDragDrop();
}

/**
* function to set the capture version for the document set
* @return NA
*/
function setCaptureHistoryForDragDrop() {
    var context = null;

    context = new SP.ClientContext(productSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    context.load(list);
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethodforDragDrop), Function.createDelegate(this, this.onFailureMethodforDragDrop));
}

//on success
function onSuccessMethodforDragDrop(sender, args) {
    var listGuid = list.get_id();
    var url = document.URL;
    var CurrentUrl = (document.URL).split("/");
    var rootUrl = CurrentUrl[2];
    var captureUrl = CurrentUrl[0] + "//" + rootUrl + spotTargetSiteUrl + '/_layouts/CreateDocSetVersion.aspx?list={' + listGuid + '}&ID=' + itemId;

    //Using the DialogOptions class.
    var optionsCapture = SP.UI.$create_DialogOptions();
    optionsCapture.title = "eFile Capture Version";
    optionsCapture.width = 600;
    optionsCapture.height = 1000;
    optionsCapture.url = captureUrl;
    SP.UI.ModalDialog.showModalDialog(optionsCapture);
    $('.ms-dlgFrame').load(function () {
        for (var i = 0; i < frames.length; i++) {
            $("#CreateOk", frames[i].document).click(function (e) {
                $('.ms-dlgFrame').load(function () {
                    for (var k = 0; k < frames.length; k++) {
                        $(".ms-unselectedtitle", frames[k].document).removeAttr('onmouseover');
                        $(".ms-unselectedtitle td:last-of-type", frames[k].document).hide();
                    }
                });
            });
        }
    });
    return false;
}

//on failure
function onFailureMethodforDragDrop(sender, args) {
    console.log('capture version failed');
    ULSOnError(args.get_message(), document.location.href, 0);
}
//ecm_policydetailsUtils.js ends

//ecm_gs_callout.js
/**
 * Description: This file is used to attach callout for each eFile in the page.
 * Loads the values inside the callout.
 * Pages Referencing: PolicyDetails.aspx
*/

//Global Variables
var fileNameDel = 0;
var targetSiteDel = 0;
var targetLibraryDel = 0;
var targetFolderDel = 0;
var efileNumber = 0;
var efileLink = 0;
var pathDel = 0;
var typeDel = 0;
var fileNameDoc = 0;
var modByNameDel = 0;
var entityVersion = 0;
var siteVersion = 0;
var folderVersion = 0;
var hrefDel = document.URL;
var targetRootDel = 0;
var urlRoot = 0;
ULS.enable = true;
//call createCallouts once sp.js is loaded
//ExecuteOrDelayUntilScriptLoaded(createCallouts, "SP.init.js");
SP.SOD.executeFunc("SP.init.js", null, createCallouts);
/**
* Loading the required scripot for callouts
 * @return NA
*/
function createCallouts() {
    SP.SOD.executeFunc('callout.js', 'SP.ClientContext', loadScripts);
    function loadScripts() {
        var scriptbase = _spPageContextInfo.webAbsoluteUrl + '/_layouts/15/';
        $.getScriptOnce(scriptbase + 'callout.js', function () {
        });
        $.getScriptOnce(scriptbase + 'mquery.js', function () {
        });

    }

    //call CreateCallOutPopup once callout.js is loaded
    ExecuteOrDelayUntilScriptLoaded(CreateCallOutPopup, "callout.js");
}
/**
* creating callout body
* @return NA
*/
function CreateCallOutPopup() {
    setTimeout(function () {

        //getting the current context
        var ctx = SP.ClientContext.get_current();
        var web = ctx.get_web();
        var count = 0;
        $(".callout").each(function (index) {
            count++;

            //getting values from the CEWP for each Efile
            var href = $(this).data('href');
            var title = $(this).data('title');
            var docTitle = $(this).data('title');
            var modBy = $(this).data('modby');
            var ccID = $(this).data('ccid');
            var modByName = $(this).data('modname');
            var modDate = $(this).data('modby');
            var lockUser = $(this).data('lockuser');
            var lockUserName = $(this).data('lockusername');
            var category = $(this).data('account');
            var insured = $(this).data('principal');
            var type = $(this).data('filetype');
            itemId = WBgetQueryStringParameter("SpID");
            var isDoc = WBgetQueryStringParameter("IsDoc");
            if (isDoc != undefined && isDoc != '') {
                itemId = $('#hdnSpId').val();
            }
            var itemIdForDoc = $(this).data('listitemid');
            var entityName;
            var display;

            //modify title div to make text visible                         
            title = "<div style='color:#000000;'>" + title + "</div>";
            var content = "<div><br>" + type + " file<br></div>";


            // getting the product site url and splitting           
            /*var entity = href.split('/');
            var entityValue = entity[3];
            urlRoot = entity[2];

            //path is server relative url
            var path = href.substring(href.toLowerCase().indexOf(entityValue), href.length);
            var parts = path.split('/');

            // Set variables for file lookup.
            var targetRootSite = parts[0];
            var targetSite = parts[1];
            var targetLibrary = parts[2];
            var targetFolder = parts[3];
            var fileName = parts[parts.length - 1];

            // Set target folder correctly for CB and APUW libraries.
            if (parts.length > 5) {
                targetFolder += '/' + parts[4];
            }*/
            //Jyoti : Corrections in url
           
            var path = href;
            var entity = path.split('/');
            var entityValue = entity[3];

            var fullPath = path;
            //path = path.substring(path.toLowerCase().indexOf(entityValue), path.length);
            var parts = path.split('/');
            var partsLength = parts.length;
            var fileName = parts[parts.length - 1];
            // Set variables for file lookup.
            var targetRootSite = parts[0] + '/' + parts[1] + '/' + parts[2];
            var targetSite = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4];
            var targetLibrary = parts[5];
                     
            var targetFolder = parts[6];

            //Get the source library path
            var libraryPath = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4] + '/' + parts[5];
            //set up display and query variables based on entity type
            //For Accounts:
            var passType = "Account";
            entityName = targetFolder;

            //fiel preview url
            var file = web.getFileByServerRelativeUrl(path);
            var iframeCheck = href.substr(href.lastIndexOf('.'));
            iframeCheck = iframeCheck.toLowerCase();

            //Iframe creation for PDF previews
            if (iframeCheck == ".pdf") {
                content = "<object data='" + href + "' type='application/pdf' width='400px' height='300px' ></object>";
            }

            //Iframe creation for OWA previews
            if (iframeCheck == ".docx" || iframeCheck == ".doc" || iframeCheck == ".xlsx" || iframeCheck == ".pptx" || iframeCheck == ".one" || iframeCheck == ".ppt" || iframeCheck == ".xls") {
                var sourcedoc = '/' + targetRootSite + '/' + targetSite + '/' + targetLibrary + '/' + targetFolder + '/' + fileName;
                sourcedoc = encodeURIComponent(sourcedoc);
                content = "<iframe style='width:379px; height:252px;' src='" + _spPageContextInfo.webAbsoluteUrl + "/" + targetRootSite + "/" + targetSite + "/_layouts/15/WopiFrame.aspx?sourcedoc=" + sourcedoc + "&action=interactivepreview&wdSmallView=1' frameborder='0'></iframe><div></div>";
            }

            //Build content display div by div
            //Changed by with Lync presence
            content = content + "<div>Changed By: <span> <span class='ms-imnSpan'><a href='#' onclick='IMNImageOnClick(event);return false;' class='ms-imnlink ms-spimn-presenceLink' >";
            content = content + "<span class='ms-spimn-presenceWrapper ms-imnImg ms-spimn-imgSize-10x10'><img name='imnmark' title='' ShowOfflinePawn='1' class='ms-spimn-img ms-spimn-presence-disconnected-10x10x32' src='/_layouts/15/images/spimn.png?rev=23' alt='User Presence' sip=" + modBy + " id=" + ccID + " />";
            content = content + "</span></a></span><span><a href='#' onclick='IMNImageOnClick(event);return false;' class='ms-imnlink' tabIndex='-1'>";
            content = content + "<img name='imnmark' title='' ShowOfflinePawn='1' class=' ms-hide' src='/_layouts/15/images/spimn.png?rev=23' alt='User Presence' sip=" + modBy + " id=" + ccID + " />";

            //modified by/date/time
            modDate = new Date(modDate);
            var modDateFormat = modDate.format("MMM dd, yyyy");
            content = content + "</a>" + modByName + " on " + modDateFormat + "</span></span></div>";

            //Checked out status
            //Checked out displays who has locked the doc with Lync presence
            if (lockUserName !== "" || lockUser !== "") {
                display = 1;
            }

                //Checked in shows default message
            else {
                display = 0;
            }
            content = content + "<div>Insured Name: " + insured + "</div>";
            content = content + "<div>Category: " + category + "</div>";

            //set up calloutmanager variables - location, ID, orientation, etc
            var targetElement = this;
            var calloutOptions = new CalloutOptions();
            calloutOptions.ID = 'callout' + count;
            calloutOptions.launchPoint = targetElement;
            calloutOptions.beakOrientation = 'leftRight';
            calloutOptions.content = content;
            calloutOptions.title = title;
            calloutOptions.contentWidth = 450;
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Tablet PC/i.test(navigator.userAgent)) {
                calloutOptions.openOptions.event = 'click';
            } else {
                calloutOptions.openOptions.event = 'hover';
            }
            var myCustomCallout = CalloutManager.createNewIfNecessary(calloutOptions);

            //callout footer creation
            var menuEntries = new Array();

            //View Properties
            var menuEntry1 = new CalloutActionMenuEntry('Inherited eFile Properties', function (action, selectedEntryIndex) {
                //Jyoti : Bug fix wrong spid
                //var ready = Liberty.DocumentProperties.ready(passType, itemId, href, 'View');
                entityVersion = targetRootSite;
                siteVersion = targetSite;
                getDocSetId(passType, href, targetLibrary, targetFolder);
            });
            menuEntries.push(menuEntry1);

            //Edit properties
            var menuEntry2 = new CalloutActionMenuEntry('Edit Document Properties', function (action, selectedEntryIndex) {
                entityVersion = targetRootSite;
                siteVersion = targetSite;
                folderVersion = targetFolder;
                efileLink = href;
                efileNumber = entityName;

                //check for permission for edit properties
                getPermissionEdit(itemId, targetLibrary, itemIdForDoc);
            });
            menuEntries.push(menuEntry2);

            //Check in/check out
            if (display == 1) {
                var menuEntry5 = new CalloutActionMenuEntry('Check In', function (action, selectedEntryIndex) {
                    var context;
                    var oweb;
                    var fileUrl;
                    var fileToDelete;

                    /*getting the client contxt of product site
                    context = new SP.ClientContext('/' + targetRootSite + '/' + targetSite);
                    oweb = context.get_web();
                    file = oweb.getFileByServerRelativeUrl(targetSiteUrl + '/' + targetLibrary + '/' + targetFolder + '/' + fileName);*/

                    //Jyoti : corrections
                    context = new SP.ClientContext(targetSite);
                    oweb = context.get_web();
                    var serverUrl = _spPageContextInfo.siteAbsoluteUrl;
                    var link = href.replace(_spPageContextInfo.siteAbsoluteUrl, "");
                    file = oweb.getFileByServerRelativeUrl(link);
                    context.load(file);
                    context.executeQueryAsync(function () {
                        //checking in the file
                        file.checkIn();
                        context.executeQueryAsync(Function.createDelegate(this, successHandler), Function.createDelegate(this, errorHandler));
                    }, errorHandler);
                    function successHandler() {
                        alert("File checked in.");
                        location.reload();
                    }
                    function errorHandler() {
                        console.log("File checkin failed. Error message:" + arguments[1].get_message());
                        if (arguments[1].get_message() == 'Access denied. You do not have permission to perform this action or access this resource.') {
                            alert("User does not have permission to perform this action or access this resource.");
                        }
                        else if (arguments[1].get_message() == 'You must fill out all required properties before checking in this document.') {
                            alert("You must fill out all required properties before checking in this document.");
                        }
                        else {
                            alert("Checkin failed. You might not have this file checked out anymore.");
                        }

                        ULSOnError(arguments[1].get_message(), document.location.href, 0);
                    }
                });

                //Display "Check out" when doc is checked in
            } else {
                var menuEntry5 = new CalloutActionMenuEntry('Check Out', function (action, selectedEntryIndex) {
                    var context;
                    var oweb;
                    var fileUrl;
                    var fileToDelete;

                    /*gettint the product site client context
                    context = new SP.ClientContext('/' + targetRootSite + '/' + targetSite); 
                    oweb = context.get_web();
                    //file = oweb.getFileByServerRelativeUrl('/' + targetRootSite + '/' + targetSite + '/' + targetLibrary + '/' + targetFolder + '/' + fileName);
                    //file = href;
                    */
                    //Jyoti corrections
                    context = new SP.ClientContext(targetSite);
                    oweb = context.get_web();
                    var serverUrl = _spPageContextInfo.siteAbsoluteUrl;
                    var link = href.replace(_spPageContextInfo.siteAbsoluteUrl, "");
                    file = oweb.getFileByServerRelativeUrl(link);
                    context.load(file);
                    context.executeQueryAsync(function () {
                        //checking out the file
                        file.checkOut();
                        context.executeQueryAsync(Function.createDelegate(this, successHandler), Function.createDelegate(this, errorHandler));
                    }, errorHandler);
                    function successHandler() {
                        alert("File checked out.");
                        location.reload();
                    }
                    function errorHandler() {
                        console.log("File checkout failed. Error message:" + arguments[1].get_message());
                        if (arguments[1].get_message() == 'Access denied. You do not have permission to perform this action or access this resource.') {
                            alert("User do not have permission to perform this action or access this resource.");
                        }
                        else {
                            alert("Checkout failed. This file may already be checked out.");
                        }
                        ULSOnError(arguments[1].get_message(), document.location.href, 0);
                    }

                });
            }
            menuEntries.push(menuEntry5);

            //Download a copy option
            var menuEntry6 = new CalloutActionMenuEntry('Download A Copy', function (action, selectedEntryIndex) {
                window.location.href = href;
            });
            menuEntries.push(menuEntry6);

            //Delete file
            var menuEntry7 = new CalloutActionMenuEntry('Delete', function (action, selectedEntryIndex) {
                entityVersion = targetRootSite;
                siteVersion = targetSite;
                folderVersion = targetFolder;
                targetRootDel = targetRootSite;
                fileNameDel = fileName;
                targetSiteDel = targetSite;
                targetLibraryDel = targetLibrary;
                targetFolderDel = targetFolder;
                pathDel = path;
                typeDel = type;
                modByNameDel = modByName;

                //checking permission for delete
                getPermissionDelete(itemId, targetLibraryDel);
            });
            menuEntries.push(menuEntry7);

            //Version History
            var menuEntry8 = new CalloutActionMenuEntry('Version History', function (action, selectedEntryIndex) {
                fileNameDoc = docTitle;
                entityVersion = targetRootSite;
                siteVersion = targetSite;
                folderVersion = targetFolder;
                //getting the guid of the list
                var listGuid = getGuid(targetLibrary, itemIdForDoc);
            });
            menuEntries.push(menuEntry8);

            //attaching the footer to callout body
            var menuActionOptions = new CalloutActionOptions();
            menuActionOptions.menuEntries = menuEntries;
            var menuAction = new CalloutAction(menuActionOptions);

            //don't add more actions if 2 already exist
            if (myCustomCallout.getActionMenu().getActions().length < 1) {
                myCustomCallout.addAction(menuAction);
            }
        });

        var targetElement = document.getElementById('test');
        var calloutOptions = new CalloutOptions();
        calloutOptions.ID = 'callout1';
        calloutOptions.launchPoint = targetElement;
        calloutOptions.beakOrientation = 'leftRight';
        calloutOptions.content = 'This is the content';
        calloutOptions.title = 'This is a custom callout';
        calloutOptions.contentWidth = 450;
        calloutOptions.openOptions.event = 'click';
        var myCustomCallout = CalloutManager.createNewIfNecessary(calloutOptions);
        var customAction = new CalloutActionOptions();
        customAction.text = 'Action 1';
        customAction.onClickCallback = function (event, action) {
            console.log("This is JavasCript alert on Custom Action");
        };

        var _newCustomAction = new CalloutAction(customAction);
        myCustomCallout.addAction(_newCustomAction);

    }, 500);
}

/**
* function to load the list and get the GUID
* @param {string} targetLibrary [name of the list]
* @return NA
*/
var web = null;
function getGuid(targetLibrary, itemIdForDoc) {
    var targetSiteUrl = siteVersion;
    var context = null;

    //getting the product site client content
    context = new SP.ClientContext(targetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(targetLibrary);
    context.load(list);
    tmpItemIdForDoc = itemIdForDoc;
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethod), Function.createDelegate(this, this.onFailureMethod));
}

// on success build the url for version history with GUID and list item id
function onSuccessMethod(sender, args) {
    var listGuid = list.get_id();
    var CurrentUrl = (document.URL).split("/");
    //Jyoti correction
    /*var rootUrl = CurrentUrl[2];
    var rootSite = entityVersion + '/' + siteVersion;*/

    //building te url for version history
    var test = siteVersion + '/_layouts/Versions.aspx?list=' + listGuid + '&ID=' + tmpItemIdForDoc + '&IsDlg=1';
    //Using the DialogOptions class.
    var options = SP.UI.$create_DialogOptions();
    options.title = "Document Version History";
    options.width = 600;
    options.height = 1000;
    options.url = test;

    ExecuteOrDelayUntilScriptLoaded(function () {

        //modal pop up 
        SP.UI.ModalDialog.showModalDialog(options);
        $('.ms-dlgFrame').load(function () {
            for (var i = 0; i < frames.length; i++) {
                $('td.ms-propertysheet', frames[i].document).each(function (index, value) {
                    var colName = $.trim($(this).text());
                    if (colName == 'PolicyYear') {
                        var yearValue = $(this).nextAll().first().text().replace(',', '');
                        $(this).nextAll().first().text(yearValue);
                    }
                    if (colName == 'Region') {
                        $(this).parent().hide();
                    }
                });
                $("td.ms-vb:contains('(more...)')", frames[i].document).text('(Click on "View" under the context menu to see more details...)');
            }
        });
        return false;
    }, "sp.js");
}
//on failure
function onFaiureMethodl(sender, args) {
    console.log('version history failed');
    ULSOnError(args.get_message(), document.location.href, 0);
}

/**
* function to check whether the user has permission to delete the list item
* @param {string} dropId [id of the document]
* @param {string} targetLibraryDel [name of the list]
* @return NA
*/
function getPermissionDelete(dropId, targetLibraryDel) {
    var targetSiteUrl = siteVersion;
    var context = null;

    //getting the product site client content
    context = new SP.ClientContext(targetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(targetLibraryDel);
    listItem = list.getItemById(dropId);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethodDelete), Function.createDelegate(this, this.onFailureMethodDelete));

}
//on sucess check for permission and call delete function
function onSuccessMethodDelete(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.deleteListItems)) {

        //user has delete permission 
        deleteSuccess();
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }
}

function onFailureMethodDelete() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}

/**
* function to delete the document
* @return NA
*/
function deleteSuccess() {
    fileName = fileNameDel;
    targetSite = targetSiteDel;
    targetLibrary = targetLibraryDel;
    targetFolder = targetFolderDel;
    targetRoot = targetRootDel;
    var answer = confirm("Are you sure you want to delete " + fileName + "?");
    if (answer) {
        var context;
        var oweb;
        var fileToDelete;

        //getting the product site client context
        context = new SP.ClientContext(targetSite);
        oweb = context.get_web();
        var clientContext = new SP.ClientContext.get_current();
        var web = clientContext.get_web();
        siteUrl = clientContext.get_url();
        var link = targetSite.replace(_spPageContextInfo.siteAbsoluteUrl, "");
        fileToDelete = oweb.getFileByServerRelativeUrl(link + '/' + targetLibrary + '/' + targetFolder + '/' + fileName);
        context.load(fileToDelete);
        context.executeQueryAsync(function () {
            fileToDelete.recycle();
            context.executeQueryAsync(Function.createDelegate(this, successHandlerDeleteDoc), Function.createDelegate(this, errorHandlerDeleteDoc));
        }, errorHandlerDeleteDoc);

        function successHandlerDeleteDoc() {
           // createRecycleListItem();
            alert("File deleted successfully");

            //refresh the page after deleting
            window.location.href = hrefDel;

        }

        function errorHandlerDeleteDoc() {
            console.log("File delete failed. Error message:" + arguments[1].get_message());
            alert("File delete failed. This file may have already been deleted.");
            ULSOnError(arguments[1].get_message(), document.location.href, 0);
        }


    } else { }
}

/**
* function to add the deleted item to the recycle bin
* @return NA
*/
function createRecycleListItem() {
    var modByName = modByNameDel;
    var clientContext = new SP.ClientContext();

    //getting the recycle bin list
    var oList = clientContext.get_web().get_lists().getByTitle('Recycle Bin');
    var itemCreateInfo = new SP.ListItemCreationInformation();
    this.oListItem = oList.addItem(itemCreateInfo);
    var path = pathDel;
    var type = typeDel;
    var officeSite = path.split("/")[0];
    //var recycleBinURL = _spPageContextInfo.webAbsoluteUrl + "/" + targetRootDel + "/" + officeSite + "/_layouts/15/RecycleBin.aspx";
    var recycleBinURL = siteVersion + "/_layouts/15/RecycleBin.aspx";
    var recycleBinHTML = "<a class='gs-ecm-recyclebin-link' data-url='" + recycleBinURL + "'>Open Office Site Recycle Bin </a>";
    var recycleBinFilename = path.replace(/^.*[\\\/]/, '');
    var link = path.replace(_spPageContextInfo.siteAbsoluteUrl, "");
    //setting the attributes for the deleted item
    oListItem.set_item('Title', recycleBinFilename);
    oListItem.set_item('FileType', type);
    oListItem.set_item('OriginalPath', link);
    oListItem.set_item('LastModifiedBy', modByName);
    oListItem.set_item('RecycleBinURL', recycleBinHTML);
    oListItem.update();
    clientContext.load(oListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, onQuerySucceededRecycle), Function.createDelegate(this, onQueryFailedRecycle));
}
//on success
function onQuerySucceededRecycle() {
    console.log('Item created: ' + oListItem.get_id());
}
//on failure
function onQueryFailedRecycle(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}

/**
* function to check whether the user has permission to edit the list item
* @param {string} itemId  [id of the list item]
 * @param {string} targetLibrary [name of the list]
* @return NA
*/
function getPermissionEdit(itemId, targetLibrary, itemIdForDoc) {
    //var targetSiteUrl = '/' + entityVersion + '/' + siteVersion;
    //Jyoti : corrections
    var targetSiteUrl = siteVersion;
    var context = null;

    //getting the product site client context
    context = new SP.ClientContext(targetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(targetLibrary);
    this.listItem = list.getItemById(itemId);
    context.load(listItem, 'EffectiveBasePermissions');
    tmpDocId = itemIdForDoc;
    context.executeQueryAsync(Function.createDelegate(this, this.onSuccessMethodEdit), Function.createDelegate(this, this.onFailureMethodEdit));
}

//on success open the edit properties modal dialogues
function onSuccessMethodEdit(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    var passType = "Account";
    var href = efileLink;

    var entityName = efileNumber;
    if (perms.has(SP.PermissionKind.editListItems)) {

        //user has edit permission, call edit doc function to open d modal dialogue
        var ready = Liberty.DocumentProperties.ready(passType, tmpDocId, href, 'Edit');
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }

}
//on failure
function onFailureMethodEdit() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}
//callout ends

//ecm_emailDocuments.js
/**
 * Description: This file is used to email the link and attachments for the documents.
 * The code works only in IE browser
 * Pages Referencing: eFile Details Page
*/


/**
* Sending HTML formatted Outlook email from IE using ActiveX object
* @param {string} documentUrl [url of the documents]
* @param {string} attachFlag [flag to determine whether it is email link or attachment]
* @return NA
*/
 ULS.enable = true;
function openOutlookClinet(documentUrl, attachFlag) {

    //Reference to Outlook.Application 
    var theApp;

    //Outlook.mailItem
    var theMailItem;

    //Create a object of Outlook.Application
    try {
        var attach = [];
        attach = documentUrl;

        //define an Outlook Application object using ActiveXObject which works only in IE browser
        theApp = new ActiveXObject("Outlook.Application");
        var objNS = theApp.GetNameSpace('MAPI');
        theMailItem = theApp.CreateItem(0);

        //sending the document link, attaching the links to the body of the mailItem
        if (attachFlag == false) {
            for (var i = 0; i < documentUrl.length; i++) {
                theMailItem.Body = theMailItem.Body + "\n" + (documentUrl[i]);
            }
        }

            //attaching the documents to the mailItem
        else if (attachFlag == true) {
            for (var j = 0; j < attach.length; j++) {
                theMailItem.Attachments.add(attach[j]);
            }
        }

        //displaying the mailItem
        theMailItem.display();
    }

    //catching the error
    catch (err) {
        alert("Outlook configuration error." + err.message);
        ULSOnError(err, document.location.href, 0);
    }
}

function getDocSetId(passType, href, targetLibrary, targetFolder) {
    var id = 0;
    //var targetSiteUrl = '/' + entityVersion + '/' + siteVersion;
    var targetSiteUrl = siteVersion;
    var context = null;
    context = new SP.ClientContext(targetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(targetLibrary);

    //Added by Jyoti
    var serverUrl = _spPageContextInfo.webAbsoluteUrl;
    var fileRef = href;
    var itemFileRef = '';
    var camlQuery = SP.CamlQuery.createAllItemsQuery();
    var folderUrl = targetSiteUrl + '/' + targetLibrary;
    camlQuery.set_folderServerRelativeUrl(folderUrl);
    var listItems = list.getItems(camlQuery);
    context.load(listItems);

    //var fileRef = targetSiteUrl + "/" + targetLibrary + "/" + targetFolder;
    /*fileRef = decodeURIComponent(fileRef);
    var camlString = "<View><Query><Where><Eq><FieldRef Name='FileRef' /><Value Type='Text'>" + fileRef + "</Value></Eq>";
    camlString += "</Where></Query><RowLimit>1</RowLimit><ViewFields><FieldRef Name='ID' /></ViewFields></View>";
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml(camlString);
    listItems = list.getItems(camlQuery);
    context.load(listItems, "Include(ID)");*/
    context.executeQueryAsync(function () {
        count = listItems.get_count();
        if (count > 0) {
            var enumerator = listItems.getEnumerator();
            while (enumerator.moveNext()) {
                var currentItem = enumerator.get_current();
                itemFileRef = serverUrl + currentItem.get_item('FileRef');
                if (itemFileRef == fileRef) {
                    id = currentItem.get_item('ID');
                }
            }
            var ready = Liberty.DocumentProperties.ready(passType, id, href, 'View');
        }
    },
    function (sender, args) {
        console.log('error in getting docset id');
        ULSOnError(args.get_message(), document.location.href, 0);
    });
}
/**
* Common Onclick function to email the link and attachment
* @param {string} attachFlag [flag to determine whether it is email link or attachment]
* @return NA
*/
function addEmailItem(attachFlag) {
    try {
        var docUrl = "";
        var docTitle = "";
        var docSize;
        var docNameArray = [];
        var docUrlArray = [];
        var checkedOutArray = [];

        //get URLs and names of selected documents
        $('input.gs-ecm-document-check').each(function () {
            if ($(this).prop('checked') == true) {
                var tempDocUrl = $(this).parent().nextAll().eq(1).children().attr('onclick');
                var splitTag = tempDocUrl.split('\'')[1];

                //decoding the encoded document url
                var decodeUrl = decodeURIComponent(splitTag);
                docUrl = decodeUrl;
                docTitle = "<b>" + docUrl.substring(docUrl.lastIndexOf('/') + 1) + "</b>";
                docUrl = docUrl.replace(/ /g, '%20');
                docSize = parseInt($(this).data('size'));

                //call to utilities function to format size
                docSize = Liberty.Utilities.formatFileSize(docSize);

                //attaching the docSize
                if (attachFlag) {
                    docTitle += " <i> " + docSize + "</i>";
                }
                if ($(this).data("locked") == true) {
                    checkedOutArray.push(docTitle);
                }

                //pushing the documents url into array
                docNameArray.push(docTitle);
                docUrlArray.push(docUrl);

            }
        });

        if (checkedOutArray.length > 0) {
            if (confirm("One or more documents is checked out. Continue sending these documents?")) {
                //continue
            } else {
                return;
            }
        }

        //check if it is email link or attachment and calling openOutlookClinet
        if (attachFlag == false) {
            openOutlookClinet(docUrlArray, false);
        }
        if (attachFlag == true) {
            openOutlookClinet(docUrlArray, true);
        }
    }

    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}
//ecm_emailDocuments endsk