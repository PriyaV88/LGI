﻿/*Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
/**        
        * Funcion performing a search via QS parameter or JSON
        * @return NA
*/
ULS.enable = true;
doSearch = function (searchType) {
    try {
        var searchCriteria = getSearchCriteria(searchType);
        var qsParam = "#Default=";
        var qsArray = window.location.href.split(qsParam);
        var strRootUrl = qsArray[0];
        if (searchType == "complete search") {
            var pageURL = window.location.href;
            if (pageURL.indexOf("eFileDocuments") > 0) {
                strRootUrl = _spPageContextInfo.webAbsoluteUrl + "/Pages/eFileDocuments.aspx";
            }
            else {
                strRootUrl = _spPageContextInfo.webAbsoluteUrl + "/Pages/ResultsPage.aspx";
            }
        }

        //IF JSON SEARCH OBJECT EXISTS:
        replaceQueryString(strRootUrl, searchCriteria);
        //redirect to the search results page with the search parameters as query string. 
        window.location = addSearchTermParameter(strRootUrl, searchType);
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}
var Liberty = window.Liberty || {};
ULS.enable = true;
//content sources
//central dev/QA
var agencyCS = "int-suretyworkbench_bcs_agencies",
	accountCS = "int-suretyworkbench_bcs_accounts",
	aprincipalCS = "int-suretyworkbench_bcs_ap",
	tprincipalCS = "int-suretyworkbench_bcs_tp",
	bondCS = "int-suretyworkbench_bcs_bonds",
	CBRCS = "int-suretyworkbench_bcs_cbr",
	internalCS = "int-suretyworkbench";
//format date like mm/dd/yyyy
var dateRender = function (a) {
    if (!Srch.U.n(a) && !a.isEmpty && Date.isInstanceOfType(a.value)) {
        var b = Srch.U.$C(String.format("cc_ValueRendererDateFormat_{0}", a.managedPropertyName), false);
        if (Srch.U.w(b)) b = "ShortDatePattern";
        return SP.Utilities.HttpUtility.htmlEncode(Srch.U.toFormattedDate(a.value, b))
    }
    else return Srch.ValueInfo.Renderers.defaultRenderedValueHtmlEncoded(a)
};

Liberty.Utilities = function () {
    try {
        var getUrlValue = function (name) {
            var hash;
            var hashes = window.location.search.replace('?', '').split('&');
            for (var i = 0; i < hashes.length; i++) {
                hash = hashes[i].split('=');
                if (hash[0].trim().toLowerCase() == name.trim().toLowerCase())
                    return decodeURIComponent(hash[1]);
            }
        }

        var getPage = function () {
            var file, n;
            file = window.location.pathname;
            n = file.lastIndexOf('/');
            if (n >= 0) {
                file = file.substring(n + 1);
            }
            return file.replace('.aspx', '');
        }

        var loadingImage = "<img src='/_layouts/15/images/loadingcirclests16.gif' />";

        var formatFileSize = function (fileSize) {
            var oneKB = 1024;
            var oneMB = oneKB * oneKB;
            var size = 0;
            if (fileSize > oneMB)
                size = (Math.round((fileSize / oneMB) * 10) / 10) + " MB";
            else if (fileSize > oneKB)
                size = (Math.round((fileSize / oneKB) * 10) / 10) + " KB";
            else
                size = fileSize + " B";

            return size;
        }
        var docTypeParse = function (type, basePage) {

            var link = "test";
            var pic = "/_layouts/15/images/ictxt.gif";
            if (type == "docx" || type == "doc" || type == "docm" || type == "dot" || type == "dotx") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_Word_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_Word_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_Word_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_Word_HoverPanel.js";
                }
                pic = "/_layouts/15/images/icdocx.png";
            } else if (type == "xlsx" || type == "xls" || type == "xlsb" || type == "xlsm") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_Excel_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_Excel_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_Excel_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_Excel_HoverPanel.js";
                }
                pic = "/_layouts/15/images/icxlsx.png";
            } else if (type == "ppt" || type == "pptx" || type == "pptm") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_PowerPoint_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_PowerPoint_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_PowerPoint_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_PowerPoint_HoverPanel.js";
                }
                pic = "/_layouts/15/images/icpptx.png";
            } else if (type == "pdf") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_PDF_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_PDF_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_PDF_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_PDF_HoverPanel.js";
                }
                pic = "/_layouts/15/images/icpdf.png";
            } else if (type == "tiff" || type == "tif" || type == "jpg" || type == "jpeg" || type == "bmp" || type == "png") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_Picture_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_Picture_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_Picture_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_Picture_HoverPanel.js";
                }
                pic = "/_layouts/15/images/icpng.gif";
            } else if (type == "one") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_OneNote_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_OneNote_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_OneNote_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_OneNote_HoverPanel.js";
                }
                pic = "/_layouts/15/images/icone.png";
            } else if (type == "zip") {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_Default_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_Default_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_Default_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_Default_HoverPanel.js";
                }
                pic = "/_layouts/15/images/iczip.gif";
            } else if (type == "aspx") {
                pic = "/_layouts/15/images/DOCLINK.gif";
            } else if (type == "msg") {
                pic = "/_layouts/15/images/icmsg.png";
            } else {
                if (basePage == 1) {
                    link = "wb_accountDocs_Item_Default_HoverPanel.js";
                } else if (basePage == 2) {
                    link = "wb_agenciesDocs_Item_Default_HoverPanel.js";
                } else if (basePage == 3) {
                    link = "wb_cbrBondDocs_Item_Default_HoverPanel.js";
                } else {
                    link = "wb_principalsDocs_Item_Default_HoverPanel.js";
                }
            }
            return [link, pic];

        };
        return {
            formatFileSize: formatFileSize,
            getUrlValue: getUrlValue,
            loadingImage: loadingImage,
            docTypeParse: docTypeParse,
            getPage: getPage,
        };
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}();

/**
 * Description: This file is used to achieve Search functionality - to search for an eFile or document across the eFile manager site,
                using the search box loacted on the top-right corner of  all the pages .
 * Pages Referencing: All Pages.
*/

/**        
        * Funcion to Get search criteria based on current page.
        * @param {string} searchType  [Search type - Complete Search]
        * @return {string} searchCriteria [Term that needs to be searched]
*/
function getSearchCriteria(searchType) {
    try {
        var searchTerms = (searchType == "complete search") ? document.getElementById('srchCompleteCriteria').value : document.getElementById('srchCriteria').value;
        searchTerms = searchTerms.trim();

        if (searchTerms == "") {
            searchTerms = "*";
        }
        var searchCriteria = searchTerms;
        return searchCriteria;
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**        
        * Funcion to add Search Criteria To JSON.
        * @param {string} url  [Target Url - Search Results page]
        * @param {string} searchType  [Search type - Complete Search]
        * @return {string} jsonObject [Search criteria as JSON object]
*/
function addSearchTermParameter(url, searchType) {
    try {
        var searchTermParameter = "k=";
        if (document.getElementById('srchCompleteCriteria').value == '*' || document.getElementById('srchCompleteCriteria').value == '') {
            var searchTermParameter = "k=";
            if (searchType == "complete search") {
                searchTermParameter += encodeURIComponent(document.getElementById('srchCompleteCriteria').value) + "&";
            }
            else {
                searchTermParameter += encodeURIComponent(document.getElementById('srchCriteria').value);
            }
            //var searchTermParameter = "k=" +
            //      encodeURIComponent(((searchType == "complete search") ? document.getElementById('srchCompleteCriteria').value + "&" : document.getElementById('srchCriteria').value));

        }
        else if (searchType == "complete search") {
            searchTermParameter += encodeURIComponent(document.getElementById('srchCompleteCriteria').value) + "*&";
        }
        else {
            searchTermParameter += encodeURIComponent(document.getElementById('srchCriteria').value);
        }
        //encodeURIComponent(((searchType == "complete search") ? document.getElementById('srchCompleteCriteria').value + "*&" : document.getElementById('srchCriteria').value));


        if (url.indexOf("k=") > -1) {
            var tempUrlArray = url.split("k=");
            url = tempUrlArray[0] + searchTermParameter + tempUrlArray[1].substring(tempUrlArray[1].indexOf("&"));
        }
        else {
            if (url.indexOf("?") < 0) {
                url = url.replace(".aspx", ".aspx?");
            }

            url = url.substring(0, url.indexOf("?") + 1) + searchTermParameter + url.substring(url.indexOf("?") + 1);
        }

        return url.replace("&&", "&");
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**        
        * Function to add/update querystring parameter for search
        * @param {string} url  [Target Url - Search Results page]
        * @param {string} value  [Search type - Complete Search]
        * @return {string} newURL [Target Url - Search Results page with the Query string Parameter]
*/
function replaceQueryString(url, value) {
    try {
        var delimiterIndex = url.indexOf("k=");
        var preURL = (delimiterIndex > 0) ? url.substr(0, delimiterIndex - 1) : url;
        var delimiter = '&';

        var jsonObj = {};
        jsonObj.k = value;

        var newURL = preURL + ((preURL.indexOf("?") > 0) ? delimiter : "");
        return newURL;
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**        
        * Post render function to update search input box with keyword parameter.	
        * @param {string} searchType [Search type - Complete Search]
        * @return NA
*/
function searchPostRender(searchType) {
    try {
        $(document).ready(function () {
            var searchText = getUrlValue("k");
            if (searchText !== "" && searchText !== null) {
                if (searchText == "*") {
                    searchText = "";
                }

                document.getElementById('srchCriteria').value = searchText;
                document.getElementById('goButton').focus();
            }

            if (getUrlValue("SearchText") == 1) {
                $(".gs-ecm-text-search-chk").prop('checked', true);
            }

            //hook up enter button
            $("#srchCriteria").keyup(function (event) {
                if (event.keyCode == 13) {
                    $("#goButton").click();
                }
            });

        });
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**        
        * Function to get the search term.	
        * @param {string} name [Query string parameter - 'K']
        * @return [search term - query string parameter value]
*/
var getUrlValue = function (name) {
    try {
        var hash;
        var hashes = window.location.search.replace('?', '').split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            if (hash[0].trim().toLowerCase() == name.trim().toLowerCase())
                return decodeURIComponent(hash[1]);
        }
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}
/**
* Description: This file is used to sort in all display templates, add lync presence.
* Loads the values inside the callout.
* Pages Referencing: All pages
*/

/**
* function called on page load to trigger the search click with the Enter key in the search text box
* used in all pages
 * @return NA
*/
ULS.enable = true;
$(document).ready(function () {
    try {

        //setting the WOPISession to policyDetails url
        if (window.location.href.indexOf('PolicyDetails') != -1) {
            var policyUrl = document.location.href;
            if (policyUrl.indexOf('polLoc=') > -1) {
                policyUrl = policyUrl.split('polLoc=');
                var cookieUrl = policyUrl[0] + 'polLoc=' + encodeURIComponent(policyUrl[1]);
                createCookie('WOPISessionContext', cookieUrl);

            }
            else {
                createCookie('WOPISessionContext', policyUrl);
            }
        }
        else {
            createCookie('WOPISessionContext', '#');
        }

        //hook up enter button
        $("#srchCriteriaAllDocs").keyup(function (event) {
            if (event.keyCode == 13) {
                $("#goButtonSiteSearch").click();
            }
        });
        $(document).delegate("#srchCompleteCriteria", 'keydown', function (e) {
            var kcode = e.keyCode || e.which;
            if (kcode == 13) {
                return false;
            }
        });
        $(document).delegate("#srchCompleteCriteria", 'keyup', function (e) {
            var kcode = e.keyCode || e.which;
            if (kcode == 13) {
                $('#srchCompleteCriteria+.gs-ecm-searchbutton').trigger('click');
            }
        });
        // remove webpart tooltip
        $('div.ms-webpart-chrome-title span.js-webpart-titleCell[title]').removeAttr('title');

        //Remove Recent Activities title tooltip
        $(".js-webpart-titleCell:has(span:contains('Recent Activities'))").attr("title", "");
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
});

function createCookie(name, value) {
    document.cookie = name + "=" + value + "; path=/";
}

/**
* Getting the search url from the list and redirecting to respective page
* used in result pages and search centre link
 * @return NA
*/
function searchRedirect(key) {
    try {
        var advSearchUrl = getFromConfigList(key);
        window.location.href = advSearchUrl;
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* Getting the value from the configList using the key
* @param {string} key [key value of the list]
* @return {string} searchSiteUrl [value of the list]
*/
function getFromConfigList(key) {
    var searchSiteUrl;

    //list name
    var listName = 'efileConfigList';
    var siteUrl = document.URL.toLowerCase().split('/pages/')[0];
    $.ajax({
        url: siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items?$filter=Title eq '" + key + "'&$select=Value",
        type: "GET",
        async: false,
        cache: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (data) {
            searchSiteUrl = data.d.results[0].Value;
        },
        error: function (data) {
            console.log(JSON.stringify(data));
            ULSOnError(JSON.stringify(data), document.location.href, 0);
        }
    });
    return searchSiteUrl;
}
/**
* Enable email links while browser is IE
* used in policy details pages
 * @return NA
*/
setTimeout(function () {

    //adding css styles
    $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button, .gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').css({ color: '#ddd', cursor: 'default' });
    $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button, .gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').attr('onclick', ' ').unbind('click');
    $('.gs-ecm-resultsgrid').on('click', 'input.gs-ecm-document-check', activateEmailLinks);
}, 1000);

function activateEmailLinks() {
    if ($('input.gs-ecm-document-check').filter(':checked').length > 0 && (navigator.appName == 'Microsoft Internet Explorer' || (!!navigator.userAgent.match(/Trident.*rv[ :]*11\./)))) {
        $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button, .gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').css({ color: '#004d9c', cursor: 'pointer' });
        $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button').attr('onclick', 'addEmailItem(false);');
        $('.gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').attr('onclick', 'addEmailItem(true);');
        $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button, .gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').on('click', function (e) {
            e.preventDefault();
        });
    } else {
        $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button, .gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').css({ color: '#ddd', cursor: 'default' });
        $('.gs-ecm-inpage-flyout .gs-ecm-sendlink-button, .gs-ecm-inpage-flyout .gs-ecm-sendattachment-button').attr('onclick', ' ').unbind('click');
    }
}

/**
* Onclick function called when user clicks check all documents
* checks all the document present in the CEWP
* used in policy details pages
 * @return NA
*/
function checkAllDocs() {
    try {
        var checkAll = $(".gs-ecm-th-select").data("checkall");
        if (checkAll == false) {
            $(".gs-ecm-th-select").data("checkall", true);
        }
        if (checkAll == true) {
            $(".gs-ecm-th-select").data("checkall", false);
        }

        $('input.gs-ecm-document-check').each(function () {
            $(this).prop('checked', !checkAll);
        });
        activateEmailLinks();
        $(".gs-ecm-th-select").toggleClass('active');
        //$('.gs-ecm-sendlink-button').attr("disabled", checkAll);
        //$('.gs-ecm-sendattachment-button').attr("disabled", checkAll);

    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* Function to add the Lync presence to UW and UWA
* called from the control of display templates
* used in all display templates
 * @return NA
*/
function addLyncPresence() {
    var count = 0;
    var size = $(".gs-ecm-lync-placeholder").size();
    try {
        $(".gs-ecm-lync-placeholder").each(function () {
            var nnumber = ($(this).data("nnumber").length > 0) ? $(this).data("nnumber").split('|')[0].trim() : "";
            var rowID = $(this).data("rowid");
            var name = $(this).data("name");

            //span ID's need to be unique
            var lyncID1 = "imn_" + (rowID + 1) + ",type=sip";
            var lyncID2 = "imn_" + (rowID + 2) + ",type=sip";
            var placeholder = $(this);
            var workmail;
            var lyncHTML;

            //check if an Nnumber or Email is being passed
            if (nnumber.indexOf("@") < 0 && nnumber != "" && nnumber != null) {
                var searchLyncSource = _spPageContextInfo.webAbsoluteUrl + "/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName=@v,propertyName='WorkEmail')?@v='lm\\" + nnumber + "'";

                $.ajax({
                    url: searchLyncSource,
                    method: "GET",
                    headers: {
                        "accept": "application/json; odata=verbose",
                    },
                    success: function (data) {
                        workmail = data.d.GetUserProfilePropertyFor;

                        //build the html required
                        lyncHTML = buildLyncHTML(rowID, workmail, lyncID1, lyncID2, name);
                        if (name != "" && name != null) {

                            //add HTML to page
                            placeholder.replaceWith(lyncHTML);
                        }

                        //SharePoint function to resolve SIP
                        ProcessImn();
                    },
                    error: function (jqxr, errorCode, errorThrown) {
                        console.log(jqxr.responseText);
                        ULSOnError(jqxr.responseText, document.location.href, 0);
                    }
                });
            }
            else {
                workmail = nnumber;
                lyncHTML = buildLyncHTML(rowID, workmail, lyncID1, lyncID2, name);
                if (name != "" && name != null) {

                    //add HTML to page
                    placeholder.replaceWith(lyncHTML);
                }

                //SharePoint function to resolve SIP
                ProcessImn();
            }
        });
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* function used to build the html for the Lync Presence 
* @param {string} rowID [row id of the lync placeholder]
* @param {string} workmail [email id of the UW or UWA]
* @param {string} lyncID1 [unique id created using the row id]
* @param {string} lyncID2 [unique id created using the row id]
* @param {string} name [name of UW or UWA]
 * @return {string} html
*/
function buildLyncHTML(rowID, workmail, lyncID1, lyncID2, name) {
    try {
        if (workmail == "" || workmail === null) {
            workmail = name;
        }
        var html = "<span>" +
        "<span class='ms-imnSpan'>" +
        "<a href='#' onclick='IMNImageOnClick(event);return false;' class='ms-imnlink ms-spimn-presenceLink' >" +
        "<span class='ms-spimn-presenceWrapper ms-imnImg ms-spimn-imgSize-10x10'>" +
        "<img name='imnmark' title='' ShowOfflinePawn='0' class='gs-ecm-lync ms-spimn-img ms-spimn-presence-disconnected-10x10x32 gs-ecm-presence' src='/_layouts/15/images/spimn.png?rev=23' alt='User Presence' sip='" + workmail + "' id='" + lyncID1 + "'/>" +
        "</span>" +
        "</a>" +
        "</span>" +
        "<span>" +
        "<a href='#' onclick='IMNImageOnClick(event);return false;' class='ms-imnlink' tabIndex='-1'>" +
        //name attribute needs to be unique
        "<img name='imnmark" + rowID + "' title='' ShowOfflinePawn='0' class='gs-ecm-lync ms-hide gs-ecm-presence' src='/_layouts/15/images/spimn.png?rev=23' alt='User Presence' sip='" + workmail + "' id='" + lyncID2 + "' />" +
        "</a>" +
        "</span>" +
        "</span>";
        return html;
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* function to sort the column in all display templates except for home page
* constructs the respective JSON url and refreshes the page
* @param {string} managedProperty [Managed Property name]
 * @return NA
*/
sortColumn = function (managedProperty) {
    try {
        var a = Srch.ScriptApplicationManager.get_current().queryGroups['Default'];
        var queryState = a.dataProvider.get_currentQueryState();
        //taking the current url
        var qs = window.location.href;
        var targetUrl;
        var jsonText;
        var qsParam = "#Default=";

        //split the query String from #Default
        var qsArray = window.location.href.split(qsParam);
        var strRootUrl = qsArray[0];

        //If JSON object exists
        if (qsArray.length > 1) {
            var jsonObj = {};
            var strJSON = qsArray[1];
            var a = JSON.stringify(queryState);
            jsonObj = JSON.parse(decodeURIComponent(a));
            //If sort object exists
            if (jsonObj.o) {
                if (jsonObj.o[0].d == 0 && jsonObj.o[0].p == managedProperty) {
                    jsonObj.o[0].d = 1;
                } else {
                    jsonObj.o[0].d = 0;
                }
                jsonObj.o[0].p = managedProperty;
            }
            else {
                jsonObj.o = [];
                jsonObj.o.push({ "d": 0, "p": managedProperty });
            }
        }
        else {
            var searchQuery = Liberty.Utilities.getUrlValue("k");
            var jsonObj = {};
            jsonObj.o = [];
            jsonObj.o.push({ "d": 0, "p": managedProperty });

            //If search query exists,add to json object
            if (searchQuery) {
                jsonObj.k = searchQuery;
            }
            if (queryState.s >= 1) {
                jsonObj.s = queryState.s;
            }
        }

        delete jsonObj.d;
        delete jsonObj.e;
        delete jsonObj.l;
        delete jsonObj.m;
        delete jsonObj.x;
        if (queryState.s < 1) {
            delete jsonObj.s;
        }

        if (queryState.r == null) {
            delete jsonObj.r;
        }
        if (queryState.k == null) {
            delete jsonObj.k;
        }


        jsonText = JSON.stringify(jsonObj);
        if (location.pathname.indexOf('/ResultsPage.aspx') > -1) {
            var str = /([&])+/.exec(location.search);
            if (/([&])+/.test(location.search)) {
                strRootUrl = String(strRootUrl).replace(str[0], str[1])
                targetUrl = strRootUrl + "#Default=" + jsonText;
            }
            else {
                targetUrl = strRootUrl + "&#Default=" + jsonText;
            }
        }
        else {
            targetUrl = strRootUrl + "#Default=" + jsonText;
        }
        //setting the url and reloading the page
        document.getElementById(managedProperty).setAttribute('href', targetUrl);
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* function to sort the column in home page with 2 display templates
* constructs the respective JSON url and refreshes the page
* @param {string} managedProperty [Managed Property name]
* @param {string} queryGroupName [QueryGroupName of the particular webpart]
 * @return NA
*/
sortHomeColumn = function (managedProperty, queryGroupName) {
    try {
        //getting the querygroup name from the input tag
        var webPartid = ($('#' + queryGroupName).val());
        var firstQryGpName = Srch.ScriptApplicationManager.get_current().queryGroups[webPartid];
        var firstQuerystate = firstQryGpName.dataProvider.get_currentQueryState();
        var secondWebpartid = $('.wpQueryGroupName:not(#' + queryGroupName + ')').val();
        var secondQryGpName;
        var secondQuerystate;
        if (secondWebpartid != undefined) {
            secondQryGpName = Srch.ScriptApplicationManager.get_current().queryGroups[secondWebpartid];
            secondQuerystate = secondQryGpName.dataProvider.get_currentQueryState();
        }

        //taking the current url
        var qs = window.location.href;
        var strRootUrl = qs.split('#')[0]
        var targetUrl;
        var str;
        var qsParam = "#" + webPartid + "=";

        var jsonFirst = getJSONFromDataprovider(firstQuerystate, webPartid, managedProperty);
        var jsonSecond = '';
        if (secondWebpartid != undefined) {
            jsonSecond = getJSONFromDataprovider(secondQuerystate, secondWebpartid, null);
        }
        targetUrl = strRootUrl + jsonFirst + jsonSecond;

        //setting the url and reloading the page
        window.location = targetUrl;
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}

/**
* function to sort the column in home page with 2 display templates
* constructs the respective JSON url and refreshes the page
* @param {string} managedProperty [Managed Property name]
* @param {string} webpartid [QueryGroupName of the particular webpart]
* @param {string} entry [Current state]
 * @return NA
*/
function getJSONFromDataprovider(entry, webpartid, managedProperty) {
    var qsParam = "#" + webpartid + "=";
    var jsonObj = {};
    var jsonString = JSON.stringify(entry);
    jsonObj = JSON.parse(decodeURIComponent(jsonString));
    var qsArray = window.location.href.split(qsParam);
    var strRootUrl = qsArray[0];
    if (qsArray.length > 1) {
        var strJSON = qsArray[1];
        //var jsonObj = {};
        if (qsArray[1].indexOf('#')) {
            str = qsArray[1].split("#");
            strJSON = str[0];
        }
        //If sort object exists
        if (managedProperty != null) {
            if (jsonObj.o) {
                if (jsonObj.o[0].d == 0 && jsonObj.o[0].p == managedProperty) {
                    jsonObj.o[0].d = 1;
                } else {
                    jsonObj.o[0].d = 0;
                }
                jsonObj.o[0].p = managedProperty;
            }
            else {
                jsonObj.o = [];
                jsonObj.o.push({ "d": 0, "p": managedProperty });
            }
        }
    }
    else {
        if (managedProperty != null) {
            var jsonObj = {};
            jsonObj.o = [];
            jsonObj.o.push({ "d": 0, "p": managedProperty });
        }

    }
    if (entry.s >= 1) {
        jsonObj.s = entry.s;
    }
    delete jsonObj.d;
    delete jsonObj.e;
    delete jsonObj.l;
    delete jsonObj.m;
    delete jsonObj.x;
    if (entry.s < 1) {
        delete jsonObj.s;
    }

    if (entry.r == null) {
        delete jsonObj.r;
    }
    if (entry.k == null) {
        delete jsonObj.k;
    }
    if (jsonObj.o == null) {
        delete jsonObj.o;
    }

    var jsonText = JSON.stringify(jsonObj);
    var targetUrl = "#" + webpartid + "=" + jsonText;
    return targetUrl;
}
/**
*function to show audit buttons to users who are part of 
*grant access groups
*audit groups to be added to eFileConfigList
*/
function ShowOrHideAuditButtons() {

    siteUrl = document.URL.toLowerCase().split('/pages/')[0];

    $.ajax({
        url: siteUrl + "/_api/web/lists/getbytitle('efileConfigList')/items?$filer= Title eq AuditGrantAccessGroups",
        method: "GET",
        headers: {
            "Accept": "application/json;odata=verbose"
        },
        success: function (data) {
            $.each(data.d.results, function (index, item) {
                if (item.Title == "AuditGrantAccessGroups") {
                    var listItem = item.Value;
                    IsCurrentUserMemberOfGroup(listItem);
                }
            });
        },
        error: function (data) {
            console.log(JSON.stringify(data));
            ULSOnError(JSON.stringify(data), document.location.href, 0);
        }

    });

}

function IsCurrentUserMemberOfGroup(groupName) {

    var groups = groupName.split(';');
    var currentContext = SP.ClientContext.get_current();
    var currentWeb = currentContext.get_web();

    var currentUser = currentContext.get_web().get_currentUser();
    var currentUserGroups = currentUser.get_groups();
    currentContext.load(currentUserGroups);


    var allGroups = currentWeb.get_siteGroups();
    currentContext.load(allGroups);

    var caGroup = allGroups.getByName(groups[0]);
    currentContext.load(caGroup, "Title");

    var usGroup = allGroups.getByName(groups[1]);
    currentContext.load(usGroup, "Title");

    currentContext.executeQueryAsync(function () {
        var userInGroup = false;
        var usGroupUserEnumerator = currentUserGroups.getEnumerator();
        while (usGroupUserEnumerator.moveNext()) {
            var usGroupUser = usGroupUserEnumerator.get_current();
            if (usGroupUser.get_title() == caGroup.get_title() || usGroupUser.get_title() == usGroup.get_title()) {
                userInGroup = true;
                break;
            }
        }
        OnComplete(userInGroup);
    }, function (sender, args) {
        $("#myNewAuditFormButton").hide();
        $("#myViewAuditFormButton").hide();
    });


}

function OnComplete(isPresent) {
    if (isPresent) {

        $("#myNewAuditFormButton").show();
        $("#myViewAuditFormButton").show();
    }
}

//get user id
function getUserLoginID() {
    if ($('#currLoginId').val() == '') {
        var userid = _spPageContextInfo.userId;
        var loginId;
        var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";
        var requestHeaders = { "accept": "application/json;odata=verbose" };
        $.ajax({
            url: requestUri,
            async: false,
            cache: false,
            contentType: "application/json;odata=verbose",
            headers: requestHeaders,
            success: function (data) {
                var Logg = data.d;

                //get login id
                var loginName = Logg.LoginName;
                if (Logg.LoginName.indexOf('|') > -1) {
                    loginName = Logg.LoginName.split('|')[1];
                }
                if (loginName.indexOf('\\') > -1) {
                    loginId = loginName.split('\\')[1];
                }
                $('#currLoginId').val(loginId);
            },
            error: function (data) {
                console.log("error in getting current user id");
                ULSOnError(arguments[1].get_message(), document.location.href, 0);
            }
        });
    }
}

function checkUserIdLoaded() {
    if ($('#currLoginId').val() == '') {
        window.setTimeout("checkUserIdLoaded()", 10);
    }
}

/**
*function to highlight the columnn where sort is applied
*adding classes acoording to ascending or descending sort
*/
function applyFilter(val, containerId) {
    if (val != null) {
        if (val.r != null && val.r.length > 0) {
            var filterVal = val.r;
            filterVal.forEach(function (entry) {
                var filterPropertyName = entry.n;
                if (filterPropertyName == "EFAuditorsOWSUSER" || filterPropertyName == "EFUnderwriterOWSUSER" || filterPropertyName == "EFUnderwriterMultiRefOWSUSER") {
                    filterPropertyName = filterPropertyName.replace("USER", "TEXT");
                }
                $('#' + containerId).find('#' + filterPropertyName).addClass("filtered");
            });
        }
        if (val.o != null && val.o.length > 0) {
            var sortName = val.o[0].p;
            var sortDir = val.o[0].d;
            if (!Srch.U.e(sortName)) {
                var asc = "descending";
                if (sortDir == 0)
                    asc = "ascending";
                $('#' + containerId).find('#' + sortName).prev().addClass(asc);
            }
        }
    }
}
$(function () {
    var url = _spPageContextInfo.webAbsoluteUrl + "/Documents/eFileNavigation/ecm_globalNav.xml";
    $.ajax({
        type: "GET",
        url: url,
        dataType: "xml",
        success: function (xml) {
            var ul_main = $("<ul />", {
                "class": "ms-core-suiteLinkList",
                "id": "menu"
            });
            $(xml).find("menu").each(function () {
                if ($(this).children().length) {
                    var ulSub = $("<ul />");
                    $(this).children().each(function () {
                        ulSub.append("<li class='ms-core-suiteLink'><a class='ms-core-suiteLink-a' href=" + $(this).attr("url") + " target=" + $(this).attr("target") + ">" + $(this).text() + "</a></li>");
                    });
                    var li = $("<li class='ms-core-suiteLink'><a class='ms-core-suiteLink-a' href=" + $(this).attr("url") + " target=" + $(this).attr("target") + ">" + $(this).attr("name") + "</a></li>");
                    ul_main.append(li.append(ulSub));
                }
                else ul_main.append("<li class='ms-core-suiteLink'><a class='ms-core-suiteLink-a' href=" + $(this).attr("url") + " target=" + $(this).attr("target") + ">" + $(this).attr("name") + "</a></li>");
            });
            $("#suiteBarLeft").append(ul_main);
            // Adding caret to global navigation 
            $('.ms-core-suiteLinkList#menu>li>ul')
	        .has(':parent')
	        .parent()
	        .find('>a.ms-core-suiteLink-a')
	        .append('<span class="caret" ></span>');

        }
    });
});

/*****************************************************     Help      ***********************************************************************************/

$(document).ready(function () {
    $('span#ms-help a').attr('href', '#');
});
function ecmContexualNavigation() {
    retriveHelpUrlFromList();
}

function retriveHelpUrlFromList() {
    var helpSiteUrl = _spPageContextInfo.webAbsoluteUrl + '/sites/help'; // window.location.origin + '/sites/help';
    var helpClientContext = new SP.ClientContext(helpSiteUrl);
    //var helpClientContext =  SP.ClientContext.get_current();
    var oHelpMapingList = helpClientContext.get_web().get_lists().getByTitle('Mapping List');
    var helpCamlQuery = new SP.CamlQuery();

    var currentPageUrl = _spPageContextInfo.webAbsoluteUrl;
    helpCamlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name=\'PageUrl\'/>' +
        '<Value Type=\'Text\'>' + currentPageUrl + '</Value></Eq></Where></Query><RowLimit>1</RowLimit></View>');
    this.collListItem = oHelpMapingList.getItems(helpCamlQuery);

    helpClientContext.load(collListItem);
    helpClientContext.executeQueryAsync(Function.createDelegate(this, this.onHelpQuerySucceeded), Function.createDelegate(this, this.onHelpQueryFailed));

    return false;
}
function onHelpQuerySucceeded(sender, args) {
    var helpListItemInfo = '';
    var helpListItemEnumerator = collListItem.getEnumerator();
    while (helpListItemEnumerator.moveNext()) {
        var helpListItem = helpListItemEnumerator.get_current();
        helpListItemInfo = helpListItem.get_item('HelpUrl');
    }
    if (helpListItemInfo != '') {
        var helpUrl = helpListItemInfo + "?IsDlg=1";
        var height = $(window).height();
        height = Math.floor(height * 0.8);
        var width = $(window).width();
        width = Math.floor(width * 0.8);
        var left = $(window).width() - width - 5;
        window.open(helpUrl, "Help", "width=" + width + ",height=" + height + ",status=no,toolbar=no,scrollbars=yes,resizable=yes,left=" + left + ",top=0");
    }
    else {
        TopHelpButtonClick('HelpHome', event); return false;
    }
}
function onHelpQueryFailed(sender, args) {
    alert('Request failed. ' + args.get_message() +
        '\n' + args.get_stackTrace());
    TopHelpButtonClick('HelpHome', event); return false;
}

/*****************************************************     Help  End    ***********************************************************************************/

/**
 * Description: This file is used to Open the  OOTB View/Edit properties page as dialog pop-up, On-click of the View/Edit properties button in the ECB menu.
 * Pages Referencing: PolicyDetails.aspx, InsuredPage.aspx, myhome.aspx, allhome.aspx, ResultsPage.aspx (Search Results page), eFileDocuments.aspx,
                      LegacyDocumentsSearch.aspx, TemplatesSearch.aspx.
*/

var Liberty = window.Liberty || {};

/**        
        * Funcion to open the OOTB page
        * @return NA
*/
Liberty.DocumentProperties = function () {
    /**
        * Get the current file path.
        * Trigger funcion to load all the necessary .js files
        * Trigger funcion to to get the  traget eFile/Document ID
        * Trigger funcion to open the OOTB page
        * @param {string} type  [Type of eFile]
        * @param {string} id [eFile Number]
        * @param {string} path  [path of the eFile/Document]
        * @param {string} formType [Type of the Form - View form / Edit Form]
        * @return NA
    */
    var ready = function (type, id, path, formType) {
        ULS.enable = true;
        var entity = path.split('/');
        var entityValue = entity[3];

        var fullPath = path;
        //path = path.substring(path.toLowerCase().indexOf(entityValue), path.length);
        var parts = path.split('/');
        var partsLength = parts.length;
        // Set variables for file lookup.
        var targetRootSite = parts[0] + '/' + parts[1] + '/' + parts[2];
        var targetSite = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4];
        var libraryName = parts[5];

        //Jyoti :  No use of target folder
        //var targetFolder = parts[3];

        //Get the source library path
        var libraryPath = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4] + '/' + parts[5];
        //Get the source library eFile path(for eFile level - View Form)
        //var DisplayPath = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3];

        //Jyoti : no use of parts length
        /*if (parts.length = 5) {
            //Get the source document path(for Document level - Edit/View form)
            var EditPath = parts[0] + '/' + parts[1] + '/' + parts[2] + '/' + parts[3] + '/' + parts[4];
        }
        //Jyoti: do not know what is this
        // Set target folder correctly for CB and APUW libraries.
        if (parts.length > 5) {
            targetFolder += '/' + parts[4];
        }*/


        SP.SOD.executeFunc('sp.js', 'SP.ClientContext', loadScripts);

        /**
            * Function to load all the necessary .js files
            * @return NA
        */
        function loadScripts() {
            var scriptbase = _spPageContextInfo.webAbsoluteUrl + '/_layouts/15/';

            if (formType.toLowerCase() == 'view') {
                getFile(libraryPath, partsLength);
            }
            else {
                getEditFile(libraryPath, partsLength);
            }
        }

        /**
            * Funcion to to get the  traget eFile ID
            * @param {string} libraryPath [source library path]
            * @return NA
        */
        function getFile(libraryPath, partsLength) {

            //Rest URL get the ID of the current Item.
            //var url = "/" + targetRootSite + "/" + targetSite + "/_api/web/lists/getByTitle(@TargetLibrary)/items(@spId)/folder/ListItemAllFields?";
            var url = targetSite + "/_api/web/lists/getByTitle(@TargetLibrary)/items(@spId)/folder/ListItemAllFields?";
            url += "@TargetLibrary='" + libraryName + "'&";
            url += "@spId='" + id + "'";

            if (partsLength == 8) {
                url = targetSite + "/_api/web/lists/getByTitle(@TargetLibrary)/items(@spId)/file/ListItemAllFields?";
                url += "@TargetLibrary='" + libraryName + "'&";
                url += "@spId='" + id + "'";
            }

            //Trigger Ajax call
            $.ajax({
                url: url,
                method: "GET",
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": $("#__REQUESTDIGEST").val()
                },
                success: function (x, y, z) {   //getFile success method
                    var results = JSON.parse(z.responseText);
                    var ItemID = results.d.Id;

                    //Function call to load the View/Edit Form
                    LoadOOTBForm(ItemID, libraryPath, partsLength);
                },
                error: function (c, k, r) {   //getFile Error method
                    console.log('------> ERROR:\n' + c.responseText);
                    ULSOnError(c.responseText, document.location.href, 0);
                }
            });
        }

        /**
            * Funcion to to get the  traget document ID
            * @param {string} libraryPath [source library path]
            * @return NA
        */
        function getEditFile(libraryPath, partsLength) {

            //Rest URL get the ID of the current Item.
            var url = targetSite + "/_api/web/lists/getByTitle(@TargetLibrary)/items(@spId)/file/ListItemAllFields?";
            //var url = "/" + targetRootSite + "/" + targetSite + "/_api/web/lists/getByTitle(@TargetLibrary)/items(@spId)/file/ListItemAllFields?";
            url += "@TargetLibrary='" + libraryName + "'&";
            url += "@spId='" + id + "'";

            //Trigger Ajax call
            $.ajax({
                url: url,
                method: "GET",
                headers: {
                    "Accept": "application/json;odata=verbose",
                    "content-type": "application/json;odata=verbose",
                    "X-RequestDigest": $("#__REQUESTDIGEST").val()
                },
                success: function (x, y, z) {   //getEditFile success method
                    var results = JSON.parse(z.responseText);
                    var ItemID = results.d.Id;

                    //Function call to load the View/Edit Form
                    LoadOOTBForm(ItemID, libraryPath, partsLength);
                },
                error: function (c, k, r) {   //getEditFile Error method
                    console.log('------> ERROR:\n' + c.responseText);
                    ULSOnError(c.responseText, document.location.href, 0);
                }
            });
        }

        /**
            * Funcion to open the OOTB page as a Pop-up
            * @param {string} docItemID  [current eFile/document ID]
            * @param {string} libraryPath [source library path]
            * @return NA
        */
        function LoadOOTBForm(docItemID, libraryPath, partsLength) {

            //Initialize SP Dialog
            var options = SP.UI.$create_DialogOptions();
            options.height = 1000;
            options.width = 600;

            if (formType.toLowerCase() == 'view') {
                options.title = 'eFile Properties';

                if (partsLength == 8) {
                    options.title = 'Inherited eFile Properties';
                }
                else {
                    options.title = 'eFile Properties';
                }
                //URL for View Form
                //options.url = '/' + libraryPath + '/Forms/DispForm.aspx?ID=' + docItemID;
                options.url = libraryPath + '/Forms/DispForm.aspx?ID=' + docItemID;
            }
            else {
                options.title = 'Edit Document Properties';
                //URL for Edit Form
                //options.url = '/' + libraryPath + '/Forms/EditForm.aspx?ID=' + docItemID;
                options.url = libraryPath + '/Forms/EditForm.aspx?ID=' + docItemID;
            }

            options.args = { FullPath: fullPath };
            //Add callback function to dialog
            options.dialogReturnValueCallback = callbackFunction;
            //Open dialog
            SP.UI.ModalDialog.showModalDialog(options);
            //Hide ribbon from dialog
            $('.ms-dlgFrame').load(function () {
                for (var i = 0; i < frames.length; i++) {
                    $('td.ms-formlabel', frames[i].document).each(function (index, value) {
                        var colName = $.trim($(this).text());
                        if (colName == 'EmailDate' || colName == 'EmailTo' || colName == 'EmailFrom' || colName == 'EmailCC' || colName == 'Region' || colName == 'eFileNote' || colName == 'IsSpotlight') {
                            $(this).parent().hide();
                        }
                    });
                    $('#s4-ribbonrow', frames[i].document).hide();
                    //$('.ms-formtable tr:first', frames[i].document).hide();
                    $('.ms-formtable a[name=SPBookmark_FileLeafRef]', frames[i].document).closest('tr').hide();
                    $('.ms-formtable a[name=SPBookmark__dlc_DocIdUrl]', frames[i].document).closest('tr').hide();
                    var tmp = $('.ms-formtable a[name=SPBookmark_EFPolicyYear]', frames[i].document).closest('tr').find('td.ms-formbody').text().replace(',', '');
                    $('.ms-formtable a[name=SPBookmark_EFPolicyYear]', frames[i].document).closest('tr').find('td.ms-formbody').text(tmp);
                }
            });

        }

        /**
            * Funcion to Close the dialog pop up and reload the page.
            * @param {object} dialogResult  [SP.UI.ModalDialog object]
            * @return NA
        */
        function callbackFunction(dialogResult) {
            if (dialogResult == SP.UI.DialogResult.OK) {
                SP.UI.ModalDialog.showWaitScreenWithNoClose('Re-loading documents', '');
                //SP.UI.ModalDialog.RefreshPage(dialogResult);
                window.location.reload();
            }
        }
    };
    return {
        ready: ready
    };
}();

var spotTargetSiteUrl, listTitle, sp_id_loc, currentRow;

/**
* function to check whether the user has permission to edit the list item.
* JSOM call to get a value that specifies the effective permissions on the
* list item that are assigned to the current user.
* @param {string} id [id of the list item]
* @return NA
*/
function setSpotLight(obj) {
    // var href = $(obj).closest('tr').find('td:eq(3)>div>div').attr('data-href');
    var href = $(obj).closest('tr').find(".gs-ecm-entity-item-link").next().find('>div>div').attr('data-href')
    sp_id_loc = $(obj).closest('tr').find(".gs-ecm-entity-item-link").next().find('>div>div').attr('data-listitemid');
    var productArray = href.split('/');
    spotCheck = $(obj).children().attr('spotSet');
    spotTargetSiteUrl = "/" + productArray[3] + "/" + productArray[4];
    listTitle = productArray[5];
    currentRow = obj;
    var context = null;

    //Get the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onSpotSuccessMethod), Function.createDelegate(this, this.onSpotFailureMethod));

}

//on success set the respective images for spotlight
function onSpotSuccessMethod(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {
        updateList();
    }
    else {
        alert("User has no edit permission.Please contact Administrator.");
    }

}

//on failure function
function onSpotFailureMethod() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}
/**
* function to update the spot light for particular id in the list.
* @param {string} id [id of the list item]
* @return  NA
*/

var currentUserSpotID;
function updateList() {
    var clientContext = null;
    var web = null;

    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    oListItem = eFileList.getItemById(sp_id_loc);
    clientContext.load(oListItem);
    srcCurrentUserId = $('#currLoginId').val();
    currentProductUser = web.ensureUser(srcCurrentUserId);
    clientContext.load(currentProductUser);
    clientContext.executeQueryAsync(function () {
        var _spUserID = currentProductUser.get_id();
        var spotUsers = oListItem.get_item('EFSpotlightUsers');
        var users = '';
        if (spotUsers != null) {
            for (var i = 0; i < spotUsers.length; i++) {
                var lookupObject = spotUsers[i];
                //to get the id of the lookup field.
                lookUpId = lookupObject.get_lookupId();
                if (lookUpId != _spUserID) {
                    users += ";#" + lookUpId + ";#";
                }
            }
        }
        //change of spotlight image
        if (spotCheck == false || spotCheck == 'No') {
            isChecked = 'Yes';
            users += ";#" + _spUserID + ";#";
            $("#img").removeClass('imgChecked');
            $(currentRow).find('img').attr('src', '/Style%20Library/ECM/images/spotlight.png');
            $(currentRow).find('img').attr('spotset', 'Yes');
        }
        else {
            isChecked = 'No';
            $("#img").addClass('imgChecked');
            $(currentRow).find('img').attr('src', '/Style%20Library/ECM/images/GreyStar.png');
            $(currentRow).find('img').attr('spotset', 'No');
        }
        oListItem.set_item('EFSpotlightUsers', users);
        oListItem.update();
        clientContext.executeQueryAsync(function () {
        },
        function (sender, args) {
            console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
            ULSOnError(args.get_message(), document.location.href, 0);
        });
    },
    function (sender, args) {
        console.log("error in spot  call" + args.get_message());
    });
}
/**
* function to check whether the user has permission to edit the list item.
* JSOM call to get a value that specifies the effective permissions on the
* list item that are assigned to the current user.
* @param {string} noteId [id of the listItem] 
* @return NA
*/
var currentRow;
function setNote(obj) {
    var href = $(obj).closest('tr').find(".gs-ecm-entity-item-link").next().find('>div>div').attr('data-href')
    sp_id_loc = $(obj).closest('tr').find(".gs-ecm-entity-item-link").next().find('>div>div').attr('data-listitemid');
    confCheck = $(obj).children().attr('confSet');
    var productArray = href.split('/');
    spotTargetSiteUrl = "/" + productArray[3] + "/" + productArray[4];
    listTitle = productArray[5];
    currentRow = obj;
    region = productArray[3];
    productLine = productArray[4].split('-')[0];;
    currentRow = obj;
    var context = null;
    //Get the product site client context
    context = new SP.ClientContext(spotTargetSiteUrl);
    web = context.get_web();
    list = web.get_lists().getByTitle(listTitle);
    listItem = list.getItemById(sp_id_loc);
    context.load(listItem);
    context.load(listItem, 'EffectiveBasePermissions');
    context.executeQueryAsync(Function.createDelegate(this, this.onNoteSuccessMethod), Function.createDelegate(this, this.onNoteFailureMethod));

}
//on sucess update efileNote if user has permission
function onNoteSuccessMethod(sender, args) {
    var perms = listItem.get_effectiveBasePermissions();
    if (perms.has(SP.PermissionKind.editListItems)) {
        //user has permission to edit
        updateNote();
    }
    else {
        var efPolUrl = _spPageContextInfo.siteAbsoluteUrl + spotTargetSiteUrl + "/_api/web/lists/getbytitle('" + listTitle + "')/items(" + sp_id_loc + ")?$select=EFeFileNote";
        $.ajax({
            url: efPolUrl,
            method: "GET",
            headers: {
                "Accept": "application/json;odata=verbose"
            },
            success: function (data) {
                var noteVal = '';
                if (data.d.EFeFileNote != null) {
                    noteVal = data.d.EFeFileNote;
                }
                $('.note-flyout>textarea').val(noteVal);
                //change of note image
                if (noteVal.length > 0) {
                    $(currentRow).find('img').attr('src', '/Style%20Library/ECM/images/notes-o.png');
                    // $('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes-o.jpg');
                }
                else {
                    $(currentRow).find('img').attr('src', '/Style%20Library/ECM/images/notes.png');
                    //$('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes.jpg');
                }
                alert("User has no edit permission. Please contact Administrator.");
            },
            error: function (data) {
                console.log(JSON.stringify(data));
            }
        });
    }
}
//on failure
function onNoteFailureMethod() {
    console.log("failed");
    ULSOnError(arguments[1].get_message(), document.location.href, 0);
}

/**
* function to update the has eFileNote for particular id in the list.
* @param {string} noteId [id of the listItem] 
* @return NA
*/
function updateNote() {
    var clientContext = null;
    var web = null;
    clientContext = new SP.ClientContext(spotTargetSiteUrl);
    web = clientContext.get_web();
    var eFileList = web.get_lists().getByTitle(listTitle);
    this.oListItem = eFileList.getItemById(sp_id_loc);
    //get the value from the flyout and update
    //var details = $('.note-flyout>textarea').val();

    var details = $(currentRow).parent().find('textarea').val();
    details = $.trim(details);
    //$('.note-flyout>textarea').val(details);
    $(currentRow).parent().find('textarea').text(details);
    oListItem.set_item('EFeFileNote', details);
    //change of note image
    if (details.length > 0) {
        $(currentRow.parentNode.parentNode).find('img').attr('src', '/Style%20Library/ECM/images/notes-o.jpg');
        //$(currentRow).find('img').attr('src', '/Style%20Library/ECM/images/notes-o.png');
        //$('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes-o.jpg');
    }
    else {
        $(currentRow.parentNode.parentNode).find('img').attr('src', '/Style%20Library/ECM/images/notes.jpg');
        // $(currentRow).find('img').attr('src', '/Style%20Library/ECM/images/notes.png');
        //$('#setNoteImage').attr('src', '/Style%20Library/ECM/images/notes.jpg');
    }
    oListItem.update();
    clientContext.executeQueryAsync(Function.createDelegate(this, this.onQuerySucceededNote), Function.createDelegate(this, this.onQueryFailedNote));

}

//on success
function onQuerySucceededNote() {
}
//on failure
function onQueryFailedNote(sender, args) {
    console.log('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    ULSOnError(args.get_message(), document.location.href, 0);
}