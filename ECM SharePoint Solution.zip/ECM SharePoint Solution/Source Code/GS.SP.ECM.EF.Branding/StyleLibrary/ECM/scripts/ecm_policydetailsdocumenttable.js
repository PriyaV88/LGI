﻿/*
*File Description:
*Provides the list of documents present for the selected eFile in a tabel format.
*JQuery DataTable plugin functionality is utilized.
*Paging, sorting , filtering, search datatable are avaliable.
*Custom Security trimming is implemented
*'Create New Document' functionality is also present.
*/

//Global Variables
var currentUserID;
var prodSiteUrl, folderPath, libPath;
var curDocPolicyIDField = 'EFPolicyNumberOWSTEXT';
var curDocSubmissionIDField = 'EFSubmissionNumberOWSTEXT';
var entityType, targetSiteUrl;
var currentUserGroups = "";
var globalCounter = 0;
var callCounter = 0;
var rowID = 0;
var filterFlag = false;
var entityEnum = {
    Account: 0,
    AccountPrincipal: 1,
    Agency: 2,
    CBR_Bond: 3,
    Principal: 4,
    eFile: 5
};


/*
*Intial call to load required jquery datatable plugins and construct the datatable
*The datatable contains the list of documents present for the selected eFile
*/
$(document).ready(function () {
    SP.SOD.executeFunc('sp.js', 'SP.ClientContext', function () {
        $.getScript('/_layouts/SP.UI.Dialog.js', function () {
        });
        $.getScript("/Style%20Library/ECM/scripts/jquery.dataTables.js", function () {
            $.getScript('/Style%20Library/ECM/scripts/dataTables.getColumnData.js', function () { 
                var oTable = $("#DocsTable").dataTable(
                 {
                     "iDisplayLength": 4,
                     "bPaginate": true,
                     "bLengthChange": false,
                     "bFilter": true,
                     "bSort": true,
                     "bInfo": true,
                     "bAutoWidth": false,
                     "bJQueryUI": true,
                     "sPaginationType": "full_numbers",
                     "aoColumns": null,
                     "oLanguage": {
                         "sEmptyTable": "Loading documents...",
                         "sSearch": "   ",
                         "sInfo": "_START_-_END_ of _TOTAL_ results",
                         "sInfoFiltered": "",
                         "sInfoEmpty": "",
                         "oPaginate": {
                             "sNext": '<span class="ms-promlink-button-image" id="PagingImageLink"><img src="/Style%20Library/ECM/images/rightsmall.png"></span>',
                             "sPrevious": '<span class="ms-promlink-button-image" id="PagingImageLink"><img src="/Style%20Library/ECM/images/leftsmall.png"></span>'
                         }
                     },
                     "sDom": '<"top"ifl>t<"bottom"pi>',
                     "fnInitComplete": function () {




                     },
                     "fnDrawCallback": function () {
                         var pageCount = $("#PageNumbers").children().length;
                         if (pageCount > 1) {
                             $(".bottom").show();
                         } else {
                             $(".bottom").hide();
                         }
                         createCallouts();

                     }
                 }
                );
                $(".bottom").hide();
                oTable.fnFilterOnReturn();
                // Initial Call to assign classes
                ProcessEntity();
            });
        });
    });
});

/*
*jquery datatable plugin empty call
*/
function showcolumns() {
}

/*
*Redirects the page to specified url path
@param url {string} [url path]
@return NA
*/
function docRedirect(url) {
    var decodeUrl = decodeURIComponent(url);
    window.location.href = decodeUrl;
}

/*
*Construct table heading and call the Search REST api to fetch the url path of eFile
@return NA
*/
function ProcessEntity() {

    $('.dataTables_filter label').append('<input type="button" class="gs-ecm-searchbutton" id="goFilter"/><br><br>');

    // Adding table heading
    $('.dataTables_filter').attr("style", "display:inline-block");
    $('.dataTables_filter').attr("id", "SearchBox");
    $('.dataTables_filter').attr("class", "gs-ecm-searchbox fg-toolbar");
    $('.gs-ecm-document-tabs').insertAfter('.top');
    $('#DocsTable_paginate').attr("class", "ms-srch-Paging");
    $('#DocsTable_paginate').attr("style", "display:inline-block");
    $('.dataTables_info').attr("class", "ms-srch-resultscount ms-srch-resultFooter gs-ecm-results ms-srch-result dataTables_info");
    $('.dataTables_info').attr("style", "display:inline-block");
    $('#DocsTable_paginate').append('<br><br>');
    var url = document.location.href;
    var entityName = url.substring((url.toLowerCase().indexOf('?') + 1), url.toLowerCase().indexOf('='));
    entityName = entityName.charAt(0).toUpperCase() + entityName.slice(1).toLowerCase();
    var entityID = WBgetQueryStringParameter(entityName);
    var searchFieldName, searchFieldID, folderName;
    var parentFolder = '';
    var accountId = '';
    searchFieldName = 'gs-ecm' + entityName.toLowerCase() + 'ID';
    searchFieldID = entityID;

    // Call to search rest api to get the policy specific site collection path/details
    WBgetSiteCollectionURLArray(searchFieldName, searchFieldID).then(
        function (scData) {
            _TMPtargetSiteUrl = getTargetSiteUrl(scData);
            var folderName = _TMPtargetSiteUrl.substring(_TMPtargetSiteUrl.lastIndexOf("/") + 1);
            var baseUrl = _TMPtargetSiteUrl.slice(0, _TMPtargetSiteUrl.lastIndexOf("/"));
            var parentFolder = '';
            targetSiteUrl = baseUrl.slice(0, baseUrl.lastIndexOf("/"));
            if (targetSiteUrl == '') {
                $(".dataTables_empty").text("User does not have permission to view this document set or document set does not exist.");

                return;
            }

            // Get the documents from target eFile 
            ProcessLibraries(entityName, entityID, targetSiteUrl, folderName, parentFolder);

        }
    )
}


/*
*Get Current Userpermission Groups and call ProcessDocSet
@param entityName {string} [Name of the target querystring]
@param entityID {string} [current eFile number]
@param targetSiteUrl {string} [Regional site url path where the eFile is present]
@param folderName {string} [current eFile folder name]
@param parentFolder {string} [current eFile parent folder name]
@return NA
*/
function ProcessLibraries(entityName, entityID, targetSiteUrl, folderName, parentFolder) {

    var lastFlag = false;
    var firstFlag = true;

    // Get current user group data.
    getCurrentUserGroup().then(
        function () {

            console.log("Group: " + currentUserGroups);

            console.log(currentUserGroups);
            var DocLibs = new Array("eFileLibrary");

            for (var i in DocLibs) {
                callCounter = DocLibs.length;


                if (i == (DocLibs.length - 1)) {

                    lastFlag = true;
                }
                //Constructs the eFile url path and calls getFiles 
                ProcessDocSet(entityName, entityID, targetSiteUrl, DocLibs[i], folderName, parentFolder, firstFlag, lastFlag);


                firstFlag = false;
            }
        }
    );


}

/*
*Constructs the eFile url path and calls getFiles
@param entityName {string} [Name of the target querystring]
@param entityID {string} [current eFile number]
@param targetSiteUrl {string} [Regional site url path where the eFile is present]
@param folderName {string} [current eFile folder name]
@param parentFolder {string} [current eFile parent folder name]
@param firstFlag {string} [Flag to check loop start count ]
@param lastFlag {string} [Flag to check loop finish count]
@return NA
*/
function ProcessDocSet(entityName, entityID, targetSiteUrl, docLib, folderName, parentFolder, firstFlag, lastFlag) {

    var UrlParts = targetSiteUrl.split("/");
    var ServerRelativeUrl = UrlParts[3] + "/" + UrlParts[4];


    if (parentFolder == "") {
        var DocSetPath = "/" + ServerRelativeUrl + "/" + docLib + "/" + folderName;
    } else {
        var DocSetPath = "/" + ServerRelativeUrl + "/" + docLib + "/" + parentFolder + "/" + folderName;
    }
    //Set Category field name
    switch (entityName.toLowerCase()) {
        case 'policynumber':
            var curTaxonomyField = 'EFeFileDocumentGroup';
            var curAdditionalField = 'EFeFileDocumentType';
            var curTitleField = entityName;
            break;

        default:
            var DocLibs = new Array("ERROR");
            break;
    }


    // Get the list items and load them.
    var clientContext = new SP.ClientContext(targetSiteUrl);
    getFiles(clientContext, targetSiteUrl, DocSetPath, docLib, curTaxonomyField, curAdditionalField, curTitleField, firstFlag, lastFlag).then(
       function () {
           callCounter--;
           console.log("getFiles----->>>> Count :" + callCounter + " -- " + lastFlag + " -- " + globalCounter);
       }
       )

}

// Get each document with in the document set and render the table 
function getFiles(clientContext, targetSiteUrl, DocSetPath, docLib, curTaxonomyField, curAdditionalField, curTitleField, firstFlag, lastFlag) {


    var mydeferred = $.Deferred();
    var xFolder = clientContext.get_web().getFolderByServerRelativeUrl(DocSetPath);
    //alert ("xFolder - " + xFolder);
    var xFiles = xFolder.get_files();
    clientContext.load(xFolder);
    clientContext.load(xFiles);

    clientContext.executeQueryAsync(
    function () {

        var curCounter = xFiles.get_count();
        if (curCounter == 0) { $('.dataTables_empty').text("No documents associated with this eFile."); }
        //alert("Document Count " + curCounter);
        globalCounter = globalCounter + curCounter;
        var enumerator = xFiles.getEnumerator();

        while (enumerator.moveNext()) {

            var curFile = enumerator.get_current();

            // Loops through each document
            getItemInfo(clientContext, targetSiteUrl, curFile, curTaxonomyField, curAdditionalField, curTitleField, enumerator, firstFlag, lastFlag).then(
           function () {
               globalCounter--;
               console.log("getItemInfo----->>>Count :" + callCounter + " -- " + lastFlag + " -- " + curCounter + " -- " + globalCounter);
               if (globalCounter == 0) {
                   createCallouts();
                   emailButtons();
                   createDropdowns(firstFlag, lastFlag);
                   positionFilters();
                   addUniqueRowID();

               }
           });

        }
        mydeferred.resolve();
    },
        function (sender, args) {
            mydeferred.reject();
        });


    return mydeferred.promise();


}

//get document information - loops for each document
function getItemInfo(clientContext, targetSiteUrl, curFile, curTaxonomyField, curAdditionalField, curTitleField, enumerator, firstFlag, lastFlag) {
    var itemdeferred = $.Deferred();

    var curDocument = curFile.get_listItemAllFields();

    clientContext.load(curDocument);
    clientContext.executeQueryAsync(
       function () {

           console.log("---> " + curTitleField);

           //get the values using CSOM “get_item()” method
           var curFileType = curDocument.get_item('File_x0020_Type');
           var curTyping = Liberty.Utilities.docTypeParse(curFileType, 2);
           var curTypeGraphic = curTyping[1];
           var curName = curDocument.get_item('FileLeafRef');
           var curModified = curDocument.get_item('Modified');
           var curCreated = curDocument.get_item('Created');
           var curModifiedstr = new Date(curModified);


           var curCreatedstr = new Date(curCreated);

           var curModifiedUserId = curDocument.get_item('Editor').get_lookupValue().toString();
           var curAuthor = curDocument.get_item('Author').get_lookupValue().toString();
           var curMetadata = curDocument.get_item(curTaxonomyField);
           var curDocStatus = curDocument.get_item('EFDocumentStatus');
           var curEmailTo = curDocument.get_item('EFEmailTo');
           var curEmailDate = '';
           if (curDocument.get_item('EFEmailDate') != null) {
               var curEmailDateTemp = new Date(curDocument.get_item('EFEmailDate'));
               curEmailDate = curEmailDateTemp.format("MMM d, yyyy")

           }
           var curEmailFrom = curDocument.get_item('EFEmailFrom');
           var curDocTypeItem = curDocument.get_item("EFeFileDocumentType");
           var curDocType = null;


           if (curDocTypeItem == null) {
               curDocType = "";
           } else {
               curDocType = curDocTypeItem;
           }


           var curDocCategory = curDocument.get_item("EFeFileDocumentGroup");
           var curDocGroup = null;

           if (curDocCategory == null) {
               curDocGroup = "";
           } else {
               curDocGroup = curDocCategory;
           }


           var curEditor = curDocument.get_item('Editor').get_lookupValue().toString();

           var curEntity = curDocument.get_item("EFPolicyNumber");
           var curCheckout = curDocument.get_item('CheckoutUser');
           var curInsured = curDocument.get_item('EFInsuredName');

           var curFileSize = curDocument.get_item('File_x0020_Size');


           var curPath = curDocument.get_item('FileRef');
           var UrlParts = targetSiteUrl.split("/");
           var ServerUrl = UrlParts[0] + "//" + UrlParts[2];
           var curUrl = ServerUrl + curPath;
           curUrl = curUrl.replace("'", "%27");

           var curUrlLocal = encodeURIComponent(curUrl);
           curNameLocal = '<a href="javascript:void(0)" class="documentUrl" onclick="javascript:docRedirect(\'' + curUrlLocal + '\');">' + curName + '</a>';
           var curEditorName = curEditor;
           var curEditorSip = curDocument.get_item('Editor').get_lookupId().toString();
           var curCheckName;
           if (curCheckout == "" || curCheckout == null) {
               curCheckName = "";
           }
           else {
               curCheckName = curDocument.get_item('CheckoutUser').get_lookupValue().toString();
           }
           var curCheckSip = "";


           // Variable to display the call out

           var curEllipsis = '<div id="Item_Default"><div data-rowid="' + (globalCounter + 1) + '" data-entityname="' + curDocType + '" data-account="' + curDocType + '" data-agency="' + curEntity + '" data-bond="' + curEntity + '" data-principal="' + curInsured + '" data-transprinc="' + curInsured + '" data-filetype="' + curFileType + '" data-lockuser="' + curCheckSip + '" data-lockusername="' + curCheckName + '" data-modby="' + curModified + '" data-modname="' + curEditor + '"   data-moddate="' + curModified + '" data-title="' + curName + '" data-href="' + curUrl + '"   data-path="' + curUrl + '" class="callout" id="' + (globalCounter + 1) + '"class="callout" id="' + (globalCounter + 1) + '" name="Item" data-displaytemplate="DefaultItem"><a title="Open Menu" class="ms-lstItmLinkAnchor ms-ellipsis-a"><img data-title="' + curName + '" class="ms-ellipsis-icon" src="/_layouts/15/images/spcommon.png?rev=23"></a></div></div>';
           var checkTag = '<input type="checkbox" class="gs-ecm-document-check" data-size="' + curFileSize + '" data-locked="false" />';


           var fileType = '<img src="' + curTypeGraphic + '"><span style="display:none">' + curFileType + '</span>';

           $("#DocsTable").dataTable().fnAddData([
                checkTag,
                fileType,
                curNameLocal,
                curEllipsis,
                curDocType,
                curDocStatus,
                curDocGroup,
                curModifiedUserId,
                curModifiedstr.format("MMM d, yyyy"),
                curCreatedstr.format("MMM d, yyyy"),
                curEmailTo,
                curEmailFrom,
                curEmailDate
           ]);

           itemdeferred.resolve();
       },
       function (sender, args) {
           itemdeferred.reject();
       });


    return itemdeferred.promise();


}

// Load the current user to set security trimming on folders.        
function getCurrentUserGroup() {

    // Set variables. 
    var currentUserStr = "";
    var deferred = $.Deferred();
    var ctx = new SP.ClientContext.get_current();
    var web = ctx.get_web();
    var currentUser = web.get_currentUser();
    var userGroupTitle = '';
    var errorMessage = 'Failed to load user data. Please contact your system administrator.';

    // Load current user.
    ctx.load(currentUser);
    ctx.executeQueryAsync(successUser, failUser);

    function successUser() {
        var userGroups = currentUser.get_groups();
        ctx.load(userGroups);
        ctx.executeQueryAsync(successUserGroups, failUserGroups);

        // Get the user's group membership.
        function successUserGroups() {

            // Check if user is in more than one group.
            var userGroupsEnum = userGroups.getEnumerator();

            // Check if user is in at least one group.
            if (userGroupsEnum.moveNext()) {
                var curGroup = userGroupsEnum.get_current();
                userGroupTitle = curGroup.get_title();
                currentUserGroups = currentUserGroups + ";" + curGroup.get_title();
                //  console.log("Group: " + userGroupTitle);
            }
            else {
                //displayWarningMessage(errorMessage);
            }

            deferred.resolve();
        }

        // Notify user if their personal information could not be loaded.
        function failUserGroups(sender, args) {
            //  displayWarningMessage(errorMessage);
            // ko.applyBindings(new TaxonomyViewModel(userGroupTitle), $('#taxDD #groups')[0]);
            deferred.reject();
        }
    }

    // Notify the user if their personal information could not be loaded.
    function failUser() {
        // displayWarningMessage(errorMessage);
        deferred.reject();
    }

    return deferred.promise();
}


function WBgetQueryStringParameter(paramToRetrieve) {

    var params = document.URL.split("?")[1].split("&");
    // var params = URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0].toLowerCase() == paramToRetrieve.toLowerCase()) {
            strParams = singleParam[1].split("#")[0];
            break;
        }
    }
    return strParams;
}



function getTargetSiteUrl(scData) {
    //alert(scData);
    var urls = scData.d.query.PrimaryQueryResult.RelevantResults.Table.Rows.results;
    //alert("URLS" + urls);
    if (urls.length == 0)
        return '';

    var result = urls[0].Cells.results[2].Value;
    folderName = result.substr(result.lastIndexOf("/") + 1);
    var baseUrl = result.slice(0, result.lastIndexOf("/"));


    if (entityType == entityEnum.CBR_Bond ||
        entityType == entityEnum.AccountPrincipal) {
        parentFolder = baseUrl.substr(baseUrl.lastIndexOf("/") + 1);
        baseUrl = baseUrl.slice(0, baseUrl.lastIndexOf("/"));
    }

    baseUrl = baseUrl.slice(0, baseUrl.lastIndexOf("/"));

    return result;
}

function WBgetSiteCollectionURLArray(searchFieldName, searchFieldID) {



    var searchParameter = curDocPolicyIDField + ':' + searchFieldID + ' OR ' + curDocSubmissionIDField + ':' + searchFieldID;

    var url = _spPageContextInfo.webAbsoluteUrl + "/_api/search/query?querytext='" + searchParameter + "%20iscontainer:true'&selectproperties='path'";

    var deferred = $.ajax({
        url: url,
        method: "GET",
        headers: {
            "accept": "application/json;odata=verbose"
        }
    });

    return deferred.promise();
}


//lync presence needs unique row IDs
function addUniqueRowID() {

    //console.log("Adding Unique Row");
    $('.gs-ecm-lync-placeholder').each(function (index) {
        $(this).data("rowid", Math.floor((Math.random() * 1000000) + 1));
    });
}
// Creates filter drop down for each th - gets called for each column
function createDropdowns(firstFlag, lastFlag) {


    $("thead th").each(function (i) {
        //skip 1st (checkbox) and 4th column (callout)
        if (i > 0 && i != 3) {
            var columnName = $(this).text();
            // get unique column data based on index
            var filterValues = $("#DocsTable").dataTable().fnGetColumnData(i);
            var classArray = $(this).attr('class').split(" ");
            var className = classArray[1];
            var columnHeader = $(this);

            //create filter HTML
            var filterDiv = "";
            filterDiv += "<div class='gs-ecm-custom-filters ms-ref-refiner " + className + "' style='text-transform:none;font-weight:normal;border:1px #999 solid;position:absolute;z-index:100;background-color:#FFF;display:block;color:black;font-size:13px;font-family:Arial,sans-serif'>";
            filterDiv += "<div class='gs-ecm-columnheaders-actions' style='padding:5px 0px 5px 10px'>"
            filterDiv += "<div id='SubmitValue' style='width:220px'>";
            filterDiv += "<div class='gs-ecm-columnheaders-actions-close'></div>";
            filterDiv += "<div id='submit'>";
            filterDiv += "<a class='gs-ecm-columnheaders-actions-apply' style='padding:5px 15px;margin-right:5px'>Apply</a>";
            filterDiv += "<a class='gs-ecm-columnheaders-actions-clear' style='padding:5px 15px;margin-right:5px'>Clear</a>";
            filterDiv += "</div></div></div>";
            filterDiv += "<div class='gs-ecm-columnheaders-filters' style='padding:5px 0px 5px 10px;border-top:1px #999 solid;max-height:250px;overflow-y:auto'>";

            //enumerate through filter values
            var filterValueArray = [];
            for (j = 0; j < filterValues.length; j++) {
                filterValue = filterValues[j];
                if (i < 9) {
                    if (filterValue.toString().indexOf("<") >= 0) {
                        filterValue = $(filterValue).text();
                    }
                    filterValueArray.push(filterValue);
                }
                //split up Additional and Keyword filters
                if (i > 8) {
                    var taxValues = filterValue.split(';');
                    for (var m = 0; m < taxValues.length - 1; m++) {
                        filterValueArray.push(taxValues[m]);
                    }
                }
            }
            //sort and add to div
            filterValueArray.sort();
            for (var k = 0; k < filterValueArray.length; k++) {
                filterDiv += "<div class='gs-ecm-filter-row' id='Value' style='padding:4px 0'><input class='gs-ecm-checkbox' type='checkbox'><label style='color:#666666' class='ms-ref-name ms-displayInlineBlock ms-ref-ellipsis'>" + filterValueArray[k] + "</label></div>"
            }
            filterDiv += "</div></div>";
            $(this).prepend(filterDiv);
        }

        //hide filters to start
        $('.gs-ecm-custom-filters').hide();




        //open filters on click
        var filterBox = $(this).children('.gs-ecm-custom-filters');
        var dropdownLink = $(this).children().children('.gs-ecm-dropdown-link');
        dropdownLink.mousedown(function (e) {
            e.stopPropagation();
            filterBox.toggle();
        });

        //get checked values for apply button
        var applybutton = $(this).find('.gs-ecm-columnheaders-actions-apply');
        var filters = $(this).find('.gs-ecm-columnheaders-filters');

        //apply checked filters
        applybutton.click(function (e) {
            var checkedValues = new Array();
            filters.children().each(function () {
                if ($(this).children(".gs-ecm-checkbox").is(":checked")) {
                    var value = $(this).text();
                    checkedValues.push(value);
                }
            });
            checkedValuesString = checkedValues.join("|"); //join multiple values with the "|" regex OR operator
            $("#DocsTable").dataTable().fnFilter(checkedValuesString, i, true, false); //turn on regex, turn off smart filter
            toggleIcons(null);
            positionFilters();
            addUniqueRowID();
            //addLyncPresence();
            createCallouts();
            emailButtons();
            filterBox.hide();
            e.stopPropagation();
        });

        //clear values and checkboxes
        var clearbutton = $(this).find('.gs-ecm-columnheaders-actions-clear');
        clearbutton.click(function (e) {
            $("#DocsTable").dataTable().fnFilter("", i);
            filters.children().each(function () {
                $(this).children(".gs-ecm-checkbox").prop("checked", false);
            });
            toggleIcons(null);
            positionFilters();
            addUniqueRowID();
            // addLyncPresence();
            createCallouts();
            emailButtons();
            filterBox.hide();
            e.stopPropagation();
        });

        //close button functionality
        var closebutton = $(this).find('.gs-ecm-columnheaders-actions-close');
        closebutton.click(function (e) {
            //clear checkboxes if not filtered
            if (!columnHeader.find('.gs-ecm-filter-icon').length) {
                filters.children().each(function () {
                    $(this).children(".gs-ecm-checkbox").prop("checked", false);
                });
            }
            filterBox.hide();
            e.stopPropagation();
        });

        //stops sorting when you click filters
        $('.gs-ecm-custom-filters').click(function (e) {
            e.stopPropagation();
        });

        //unbind click event for certain column headers
        $('.gs-ecm-disable-sort').unbind("click");

        //toggle icons when sorted
        $(this).click(function (e) {
            var sortInfo = $(this)[0].getAttribute("aria-sort");
            toggleIcons(sortInfo);
            addUniqueRowID();
            //addLyncPresence();
            createCallouts();
            emailButtons();
            ProcessImn();
        });

        function toggleIcons(sortInfo) {
            //remove icons
            dropdownLink.prev('.gs-ecm-filter-icon').remove();
            dropdownLink.prev('.gs-ecm-sort-icon').remove();

            //see if any filters are checked
            var checkedCount = 0;
            filters.children().each(function () {
                if ($(this).children(".gs-ecm-checkbox").prop("checked")) {
                    checkedCount++;
                }
            });

            //determine which icon to display
            if (checkedCount > 0 && sortInfo) {
                $('.gs-ecm-sort-icon').remove();
                iconClass = "gs-ecm-filter-s";
                if (sortInfo == "ascending") {
                    iconClass = "gs-ecm-filter-n";
                }
                dropdownLink.before("<span class='gs-ecm-filter-icon gs-ecm-filtersort-icon " + iconClass + "'>");
            } else if (sortInfo) {
                $('.gs-ecm-sort-icon').remove();
                $('.gs-ecm-filtersort-icon').removeClass('gs-ecm-filter-s gs-ecm-filter-n').addClass('gs-ecm-filter');
                iconClass = "gs-ecm-sort-s";
                if (sortInfo == "ascending") {
                    iconClass = "gs-ecm-sort-n";
                }
                dropdownLink.before("<span class='gs-ecm-sort-icon " + iconClass + "'>");
            }
            else if (checkedCount > 0) {
                iconClass = "gs-ecm-filter";
                dropdownLink.before("<span class='gs-ecm-filter-icon " + iconClass + "'>");
            }
        }


        //re-add lync presence on paging
        $('.ui-button').click(function () {
            addUniqueRowID();
            // addLyncPresence();
            createCallouts();
            emailButtons();

        });

        //add search button functionality
        $('#goFilter').click(function (e) {
            $("#DocsTable").dataTable().fnFilter($('#textSearchBox').val());
        });

        //sort descending by date
        if (i == 8) {
            $("#DocsTable").dataTable().fnSort([[8, 'desc']]);
            dropdownLink.before("<span class='gs-ecm-sort-icon gs-ecm-sort-s'>");
        }

        //check for newly added document and move to top of table
        var lastAdded = sessionStorage.wblastadded;
        if (lastAdded != "" && lastAdded != null) {
            var row = $("a:contains(" + lastAdded + ")").parent().parent();
            row.insertAfter($(".gs-ecm-resultsgrid tr:first"));
            sessionStorage.wblastadded = "";
        }


    });

    //Drag Drop Filtering on click on document groups
    var url = document.URL;
    var tValue = "";
    if (url.indexOf("#Default=") != -1) {
        var jsonString = decodeURIComponent(url.substr(url.indexOf("#Default=") + 9));
        var str = JSON.stringify(jsonString);
        var jsonObj = JSON.parse(jsonString);
        tValue = jsonObj.r[0].t.toString().replace(/"/g, '');

        if (tValue != parseInt(tValue)) {
            $("#DocsTable").dataTable().fnFilter(tValue, 6, true, false); //turn on regex, turn off smart filter
            toggleIcons(null);
            positionFilters();
            addUniqueRowID();
            createCallouts();
            emailButtons();
            filterBox.hide();
        }


    }

}
// position the filters for each header <th>
function positionFilters() {
    reposition();
    var resizeTimer;

    //Event to handle resizing

    $(window).resize(function () {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(reposition, 100);
    });

    function reposition() {
        $('.gs-ecm-custom-filters').each(function (e) {
            var targetIcon = $(this).parent().find('.gs-ecm-dropdown');
            $(this).position({
                "my": "right top",
                "at": "right top-10%",
                "collision": "fit none",
                "of": targetIcon,
            });
        });
    }
}

/*
Refreshes an element's contents on a user action, showing a modal dialog during the refresh
elementId  The id of the container element
qs         The Query String to append to the current URL
title      The title to show for the dialog
msg        The message to show in the dialog
*/

function refreshElement(elementId, qs, title, msg) {

    var elementObj = $("#" + elementId);
    var infoDialog = $("<div><div>" + msg + "</div><div class='aaa-please-wait'></div></div>").dialog({
        open: function (event, ui) {
            $(".ui-dialog-titlebar-close").hide();  // Hide the close X
            $(this).css("overflow-y", "visible");   // Fix for the scrollbar in IE
        },
        autoOpen: false,
        title: title,
        modal: true
    });
    infoDialog.dialog("open");

    elementObj.fadeOut("slow", function () {
        $.ajax({
            async: false,
            url: window.location.pathname + qs,
            complete: function (xData) {
                newHtml = $(xData.responseText).find("#" + elementId).html();
                elementObj.html(newHtml);
            }
        });
    }).fadeIn("slow", function () {
        infoDialog.dialog("close");
    });
}
function fnResetAllFilters() {
    var oTable = $('.dataTable').dataTable();
    var oSettings = oTable.fnSettings();
    for (iCol = 0; iCol < oSettings.aoPreSearchCols.length; iCol++) {
        oSettings.aoPreSearchCols[iCol].sSearch = '';
    }
    $('input:checkbox').removeAttr('checked');
    oSettings.oPreviousSearch.sSearch = '';
    oTable.fnDraw();
}


//////


function createFile() {
    $('.new-docPolicy').text('Creating Document...');
    prodSiteUrl = '/' + newEfileUrl.split('/')[3] + '/' + newEfileUrl.split('/')[4];
    folderPath = '/' + newEfileUrl.split('/')[3] + '/' + newEfileUrl.split('/')[4] + '/' + newEfileUrl.split('/')[5] + '/' + newEfileUrl.split('/')[6] + '/';
    libPath = newEfileUrl.split('/')[3] + '/' + newEfileUrl.split('/')[4] + '/' + newEfileUrl.split('/')[5];

    var clientContext;
    var oWebsite;
    var oList;
    var fileCreateInfo;
    var fileContent;
    getCurrentUserID();

    clientContext = new SP.ClientContext(prodSiteUrl);
    oWebsite = clientContext.get_web();
    oList = oWebsite.get_lists().getByTitle("eFileLibrary");
    var folder = clientContext.get_web().getFolderByServerRelativeUrl(newEfileUrl);

    fileCreateInfo = new SP.FileCreationInformation();
    // Create a date object with the current time
    var now = new Date();
    var date = [now.getMonth() + 1, now.getDate(), now.getFullYear()];
    var time = [now.getHours(), now.getMinutes(), now.getSeconds()];
    time[0] = (time[0] < 12) ? time[0] : time[0] - 12;
    time[0] = time[0] || 12;

    // If seconds and minutes are less than 10, add a zero
    for (var i = 1; i < 3; i++) {
        if (time[i] < 10) {
            time[i] = "0" + time[i];
        }
    }

    // Return the formatted string
    var dateTime = date.join("-") + "_" + time.join("-");
    newDocName = 'New Document_' + currentUserID + '_' + dateTime + '.docx';

    fileCreateInfo.set_url(newDocName);
    fileCreateInfo.set_content(new SP.Base64EncodedByteArray());
    //fileContent = "The content of my new file";
    //for (var i = 0; i < fileContent.length; i++) {

    //    fileCreateInfo.get_content().append(fileContent.charCodeAt(i));
    //}

    this.newFile = folder.get_files().add(fileCreateInfo);

    clientContext.load(this.newFile);
    clientContext.load(folder);

    clientContext.executeQueryAsync(
        Function.createDelegate(this, successHandler),
        Function.createDelegate(this, errorHandler)
    );
}
function successHandler() {
    var itemIdForDoc = getDocId();
    // var popUpPath='/us/spc-do-01/eFileLibrary/POL11111/'+newDocName;
}

function errorHandler() {
    console.log('new document creation failed' + arguments[1].get_message());
    // resultpanel.innerHTML = "Request failed: " + arguments[1].get_message();
}
function getDocId() {
    var targetSiteUrl = prodSiteUrl;
    var documentUri = folderPath + newDocName;
    var url = targetSiteUrl + "/_api/web/lists/getByTitle(@TargetLibrary)/items?$filter=FileRef eq '" + documentUri + "'&" +
              "@TargetLibrary='" + targetLibrary + "'";

    $.ajax({
        url: url,
        method: "GET",
        async: false,
        cache: false,
        headers: {
            "Accept": "application/json;odata=verbose",
            "content-type": "application/json;odata=verbose",
            "X-RequestDigest": $("#__REQUESTDIGEST").val()
        },
        success: function (x, y, z) {
            var results = JSON.parse(z.responseText);
            if (results.d.results.length == 1) {
                itemIdForDoc = results.d.results[0].Id;
                $('.new-docPolicy').text('New Document');
                LoadEditPopUp(itemIdForDoc, libPath);

            }
            else {
            }
        },

    });
    return itemIdForDoc;
}
function LoadEditPopUp(itemIdForDoc, libraryPath) {
    console.log('Populate form function reached.');
    var options = SP.UI.$create_DialogOptions();
    options.height = 1000;
    options.width = 600;
    options.title = 'Document Properties';
    options.url = '/' + libraryPath + '/Forms/EditForm.aspx?ID=' + itemIdForDoc;
    console.log('/' + libraryPath + '/Forms/EditForm.aspx?ID=' + itemIdForDoc);


    // options.args = { FullPath: fullPath };
    options.dialogReturnValueCallback = callbackFunction;
    SP.UI.ModalDialog.showModalDialog(options);
}
function callbackFunction(dialogResult) {
    if (dialogResult == SP.UI.DialogResult.OK) {
        SP.UI.ModalDialog.showWaitScreenWithNoClose('Re-loading documents', '');
        SP.UI.ModalDialog.RefreshPage(dialogResult);
    }
}

//get user id
function getCurrentUserID() {
    var userid = _spPageContextInfo.userId;
    var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";
    var requestHeaders = { "accept": "application/json;odata=verbose" };
    $.ajax({
        url: requestUri,
        async: false,
        cache: false,
        contentType: "application/json;odata=verbose",
        headers: requestHeaders,
        success: onSuccess,
        error: onError
    });
}
function onSuccess(data, request) {
    var Logg = data.d;

    //get login id
    var loginName = Logg.LoginName.split('|')[1];
    var loginId = loginName.split('\\')[1];
    currentUserID = loginId;
}
function onError(error) {
    console.log("error in getting current user id");
}

//////
//////

