/* This file is currently associated to an HTML file of the same name and is drawing content from it.  Until the files are disassociated, you will not be able to move, delete, rename, or make any other changes to this file. */

function DisplayTemplate_445c2a4a43fe4dc59fcd1faae625dfb6(ctx) {
  var ms_outHtml=[];
  var cachePreviousTemplateData = ctx['DisplayTemplateData'];
  ctx['DisplayTemplateData'] = new Object();
  DisplayTemplate_445c2a4a43fe4dc59fcd1faae625dfb6.DisplayTemplateData = ctx['DisplayTemplateData'];

  ctx['DisplayTemplateData']['TemplateUrl']='~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fSearch\u002fItem_Details.js';
  ctx['DisplayTemplateData']['TemplateType']='Item';
  ctx['DisplayTemplateData']['TargetControlType']=['SearchResults'];
  this.DisplayTemplateData = ctx['DisplayTemplateData'];

  ctx['DisplayTemplateData']['ManagedPropertyMapping']={'Link URL':['Path'], 'Title':['Title'], 'ModifiedBy':['ModifiedBy'], 'EditorOWSUSER':['EditorOWSUSER'], 'Filename':['Filename'], 'PolicyNoOWSTEXT':['PolicyNoOWSTEXT'], 'InsuredNameOWSTEXT':['InsuredNameOWSTEXT'], 'PolicyInceptionDateOWSDATE':['PolicyInceptionDateOWSDATE'], 'PolicyStartDateOWSDATE':['PolicyStartDateOWSDATE'], 'PolicyEndDateOWSDATE':['PolicyEndDateOWSDATE'], 'FunctionalAreaOWSTEXT':['FunctionalAreaOWSTEXT'], 'ProductOWSTEXT':['ProductOWSTEXT'], 'UnderwriterOWSUSER':['UnderwriterOWSUSER'], 'UnderwritingAssistantOWSUSER':['UnderwritingAssistantOWSUSER'], 'CountryOWSTEXT':['CountryOWSTEXT'], 'RegionOWSTEXT':['RegionOWSTEXT'], 'PolicyYearOWSTEXT':['PolicyYearOWSTEXT'], 'SubmissionNoOWSTEXT':['SubmissionNoOWSTEXT'], 'SPContentType':['SPContentType']};
  var cachePreviousItemValuesFunction = ctx['ItemValues'];
  ctx['ItemValues'] = function(slotOrPropName) {
    return Srch.ValueInfo.getCachedCtxItemValue(ctx, slotOrPropName)
};

ms_outHtml.push('',''
); 
        if(!$isNull(ctx.CurrentItem) && !$isNull(ctx.ClientControl)){
            var id = ctx.ClientControl.get_nextUniqueId();
            var itemId = id + Srch.U.Ids.item;
			var hoverId = id + Srch.U.Ids.hover;
			var hoverUrl = "~sitecollection/_catalogs/masterpage/Display Templates/Search/Item_Default_HoverPanel.js";
            $setResultItem(itemId, ctx.CurrentItem);
			if(ctx.CurrentItem.IsContainer){
				ctx.CurrentItem.csr_Icon = Srch.U.getFolderIconUrl();
			}
			ctx.currentItem_ShowHoverPanelCallback = Srch.U.getShowHoverPanelCallback(itemId, hoverId, hoverUrl);
            ctx.currentItem_HideHoverPanelCallback = Srch.U.getHideHoverPanelCallback();
            
            function getUserComponent(data, component){ 
			if(component===undefined){ 
    		component = 'name'; 
   	 } 
    
    var editorEmail = ""; 
    var editorDisplayName =""; 

    if(!$isEmptyString(data)){ 
    	var editorIdentifiers = data.split(" | "); 
           
        if(!$isNull(editorIdentifiers[0])){ 
        	editorEmail = editorIdentifiers[0]; 
        } 
        if(!$isNull(editorIdentifiers[1])){ 
            editorDisplayName = editorIdentifiers[1]; 
        } 
  	} 
     
    if(component == 'email'){ 
        return editorEmail; 
    } else if(component == 'name'){     
        return editorDisplayName; 
    } else{ 
        return "Invalid component!!.." 
    } 
}


            var startdate = $getItemValue(ctx, "PolicyStartDateOWSDATE");
            var enddate = $getItemValue(ctx, "PolicyEndDateOWSDATE");
	        var inceptiondate = $getItemValue(ctx, "PolicyInceptionDateOWSDATE");
	        var subno = $getItemValue(ctx, "SubmissionNoOWSTEXT");
	        var Underwriter=  $getItemValue(ctx, "UnderwriterOWSUSER");
	        var UnderwritingAssistant=  $getItemValue(ctx, "UnderwritingAssistantOWSUSER");
			var insuredname = $getItemValue(ctx, "InsuredNameOWSTEXT");
			var insurednameURL = "/sites/eFileManager/Pages/InsuredPage.aspx?InsuredName="+ insuredname ;
			var modBy = getUserComponent(ctx.CurrentItem.EditorOWSUSER, 'email');
			var nnumber = modBy;
			var rowID=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
			rowID = parseInt(rowID);
			var rnnumber;
		if (ctx.CurrentItem.UnderwriterOWSUSER!= null){
			rnnumber = ctx.CurrentItem.UnderwriterOWSUSER.toLowerCase();
		}
		var rrowID=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
		rrowID = parseInt(rrowID);rnnumber
		
		var rlyncID1= "imn_"+(rrowID+1)+",type=sip";
		var rlyncID2= "imn_"+(rrowID+2)+",type=sip";
		var rnnum;
		if (ctx.CurrentItem.UnderwritingAssistantOWSUSER!= null){
			rnnum = ctx.CurrentItem.UnderwritingAssistantOWSUSER.toLowerCase();
		}
		var rrowID1=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
		rrowID1 = parseInt(rrowID1);rnnum
		var rlyncID3= "imn_"+(rrowID1+1)+",type=sip";
		var rlyncID4= "imn_"+(rrowID1+2)+",type=sip"

			//Add account name to breadcrumbs
     	    //replaceBreadcrumbLabel(ctx.CurrentItem.InsuredNameOWSTEXT);
     	    
     	    //Create link to document page
     	    var docLink = "../Pages/PolicyDetails.aspx?PolicyNumber="
			     	    + ctx.CurrentItem.PolicyNoOWSTEXT
			     	    + "&InsuredName="
			     	    + encodeURIComponent(ctx.CurrentItem.InsuredNameOWSTEXT)
			     	    + "#Default="
			     	    + addFiltersToJSON("eFile", createJSONQuery(true, false, "PolicyNoOWSTEXT", ctx.CurrentItem.PolicyNoOWSTEXT));
	     	    
     	    replaceDocLink(docLink,"Account Documents");



ms_outHtml.push(''
,'		<div class="gs-ecm-entitydetails">'
,'			<div class="gs-ecm-entitydetails-column1">'
,'				<div class="gs-ecm-entitydetails-label">Submission Number</div>'
,'				<div class="gs-ecm-entitydetails-value">',subno,'</div>'
,'				<div class="gs-ecm-entitydetails-label">Policy Number</div>'
,'				<div class="gs-ecm-entitydetails-value">',ctx.CurrentItem.PolicyNoOWSTEXT,'</div>'
,'				<div class="gs-ecm-entitydetails-label">Insured Name</div>'
,'				<div class="gs-ecm-entitydetails-value"><a href="', insurednameURL ,'">', insuredname ,'</a></div>'
,''
,'				'
,'			</div> '
,'			<div class="gs-ecm-entitydetails-column2">'
,'				<div class="gs-ecm-entitydetails-label">Department</div>'
,'				<div class="gs-ecm-entitydetails-value">',ctx.CurrentItem.FunctionalAreaOWSTEXT,'</div>'
,'				<div class="gs-ecm-entitydetails-label">Product</div>'
,'				<div class="gs-ecm-entitydetails-value">',ctx.CurrentItem.ProductOWSTEXT,'</div>'
,''
,'						'
,'			</div>'
,'			<div class="gs-ecm-entitydetails-column3">'
,'				<div class="gs-ecm-entitydetails-label">Underwriter</div>'
,'				<div class="gs-ecm-entitydetails-value">'
,'				<span class="gs-ecm-lync-placeholder" data-nnumber="',rnnumber,'" data-rowid="',rrowID,'" data-name="', Underwriter,'"></span> '
,'				', Underwriter,'</div>'
,'				<div class="gs-ecm-entitydetails-label">Underwriting Assistant</div>'
,'                <div class="gs-ecm-entitydetails-value">'
,'                <span class="gs-ecm-lync-placeholder" data-nnumber="',rnnum,'" data-rowid="',rrowID1,'" data-name="', UnderwritingAssistant,'"></span> '
,'				',UnderwritingAssistant,'</div>'
,'			</div>'
,'					'
,'			<div class="gs-ecm-entitydetails-column3">'
,'				<div class="gs-ecm-entitydetails-label">Region/Country</div>'
,'				<div class="gs-ecm-entitydetails-value">',ctx.CurrentItem.CountryOWSTEXT,'</div>'
,'			    <div class="gs-ecm-entitydetails-label">Effective Date</div>'
,'				<div class="gs-ecm-entitydetails-value">',inceptiondate,'</div>'
,'				'
,'			</div>		  		  '
,'		</div>		 '
); 
$addRenderContextCallback(ctx, "OnPostRender", function(){
	
		//call user profile service and add lync presence 
        EnsureScriptFunc("clienttemplates.js", "RenderUserFieldWorker", function() { 
        	addLyncPresence();
        	
        });
		
	
});

         } 
         
         
        

ms_outHtml.push(''
,'    '
);

  ctx['ItemValues'] = cachePreviousItemValuesFunction;
  ctx['DisplayTemplateData'] = cachePreviousTemplateData;
  return ms_outHtml.join('');
}
function RegisterTemplate_445c2a4a43fe4dc59fcd1faae625dfb6() {

if ("undefined" != typeof (Srch) &&"undefined" != typeof (Srch.U) &&typeof(Srch.U.registerRenderTemplateByName) == "function") {
  Srch.U.registerRenderTemplateByName("Item_Default", DisplayTemplate_445c2a4a43fe4dc59fcd1faae625dfb6);
}

if ("undefined" != typeof (Srch) &&"undefined" != typeof (Srch.U) &&typeof(Srch.U.registerRenderTemplateByName) == "function") {
  Srch.U.registerRenderTemplateByName("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fSearch\u002fItem_Details.js", DisplayTemplate_445c2a4a43fe4dc59fcd1faae625dfb6);
}
//
    $includeCSS("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fSearch\u002fItem_Details.js", "http://vddp23g-cf436d0:1234/sites/eFileManager/Style Library/ECM/css/ecm_2col.css");
    //
}
RegisterTemplate_445c2a4a43fe4dc59fcd1faae625dfb6();
if (typeof(RegisterModuleInit) == "function" && typeof(Srch.U.replaceUrlTokens) == "function") {
  RegisterModuleInit(Srch.U.replaceUrlTokens("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fSearch\u002fItem_Details.js"), RegisterTemplate_445c2a4a43fe4dc59fcd1faae625dfb6);
}