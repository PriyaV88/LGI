/* This file is currently associated to an HTML file of the same name and is drawing content from it.  Until the files are disassociated, you will not be able to move, delete, rename, or make any other changes to this file. */

function DisplayTemplate_fd2e76be4ea343b4b049e76fc8c39d76(ctx) {
  var ms_outHtml=[];
  var cachePreviousTemplateData = ctx['DisplayTemplateData'];
  ctx['DisplayTemplateData'] = new Object();
  DisplayTemplate_fd2e76be4ea343b4b049e76fc8c39d76.DisplayTemplateData = ctx['DisplayTemplateData'];

  ctx['DisplayTemplateData']['TemplateUrl']='~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fContent Web Parts\u002fHomeAllEfile_Item_copy\u00281\u0029.js';
  ctx['DisplayTemplateData']['TemplateType']='Item';
  ctx['DisplayTemplateData']['TargetControlType']=['Content Web Parts'];
  this.DisplayTemplateData = ctx['DisplayTemplateData'];

  ctx['DisplayTemplateData']['ManagedPropertyMapping']={'Link URL':['Path'], 'Title':['Title'], 'Filename':['Filename'], 'EFeFileTypeOWSCHCS':['EFeFileTypeOWSCHCS'], 'EFStageOWSCHCS':['EFStageOWSCHCS'], 'EFSubmissionNoOWSTEXT':['EFSubmissionNoOWSTEXT'], 'EFPolicyNoOWSTEXT':['EFPolicyNoOWSTEXT'], 'EFInsuredNameOWSTEXT':['EFInsuredNameOWSTEXT'], 'EFFunctionalAreaOWSTEXT':['EFFunctionalAreaOWSTEXT'], 'EFProductOWSTEXT':['EFProductOWSTEXT'], 'EFUnderwriterOWSUSER':['EFUnderwriterOWSUSER'], 'EFUnderwritingAssistantOWSUSER':['EFUnderwritingAssistantOWSUSER'], 'EFCountryOWSTEXT':['EFCountryOWSTEXT'], 'EFPolicyYearOWSTEXT':['EFPolicyYearOWSTEXT'], 'ContentType':['ContentType'], 'FileExtension':['FileExtension'], 'CheckoutUserOWSUSER':['CheckoutUserOWSUSER'], 'ModifiedOWSDATE':['ModifiedOWSDATE'], 'ModifiedBy':['ModifiedBy'], 'EditorOWSUSER':['EditorOWSUSER'], 'CommentsOWSMTXT':['CommentsOWSMTXT'], 'EFBrokerNameOWSTEXT':['EFBrokerNameOWSTEXT'], 'EFPolicyInceptionDateOWSDATE':['EFPolicyInceptionDateOWSDATE']};
  var cachePreviousItemValuesFunction = ctx['ItemValues'];
  ctx['ItemValues'] = function(slotOrPropName) {
    return Srch.ValueInfo.getCachedCtxItemValue(ctx, slotOrPropName)
};

ms_outHtml.push('',''
,''
);
        
        console.log(ctx.CurrentItem);
	function getUserComponent(data, component){ 
	if(component===undefined){ 
    	component = 'name'; 
    } 
    
    var editorEmail = ""; 
    var editorDisplayName =""; 

    if(!$isEmptyString(data)){ 
    	var editorIdentifiers = data.split(" | "); 
           
        if(!$isNull(editorIdentifiers[0])){ 
        	editorEmail = editorIdentifiers[0]; 
        } 
        if(!$isNull(editorIdentifiers[1])){ 
            editorDisplayName = editorIdentifiers[1]; 
	        } 
	  	} 
	     
	    if(component == 'email'){ 
	        return editorEmail; 
	    } else if(component == 'name'){     
	        return editorDisplayName; 
	    } else{ 
	        return "Invalid component!!.." 
	    } 
}
		var linkURL = $getItemValue(ctx, "Link URL");
		    linkURL.overrideValueRenderer($urlHtmlEncode);
		//debugger;
		    var docName = $getItemValue(ctx, "Filename")+"";
		var titleToolTip = "";
		docName = docName.substr(0, docName.lastIndexOf('.'));
		if(docName.length > 55){
			titleToolTip = docName;
			docName = docName.substr(0,54) + "...";
		}
	
		
		var encodedId = $htmlEncode(ctx.ClientControl.get_nextUniqueId() + "_row_"); 
		
		var icon= '<img src="/sites/eFileManager/images/eFileIcon.png"/><span style="display:none"></span>';
		var policynumber = $getItemValue(ctx, "EFPolicyNoOWSTEXT");
		var number='';
		var subnumber = $getItemValue(ctx, "EFSubmissionNoOWSTEXT");
		var insuredname = $getItemValue(ctx, "EFInsuredNameOWSTEXT");
		var Underwriter=  $getItemValue(ctx, "EFUnderwriterOWSUSER");
		var UnderwritingAssistant=  $getItemValue(ctx, "EFUnderwritingAssistantOWSUSER");
		var product = $getItemValue(ctx, "EFProductOWSTEXT");
		var country = $getItemValue(ctx, "EFCountryOWSTEXT");
		var year=  $getItemValue(ctx, "EFPolicyYearOWSTEXT");
		var eFileType = $getItemValue(ctx, "EFeFileTypeOWSCHCS");
		var UWProcessStage= $getItemValue(ctx, "EFStageOWSCHCS");
		 var spotlight = $getItemValue(ctx, "EFIsSpotlightOWSBOOL");
			if(spotlight  =="Yes")
{
spotlight = '<img src="/sites/eFileManager/Style%20Library/ECM/images/spotlight.png"/><span style="display:none"></span>';
}
else{
spotlight = '<img src="/sites/eFileManager/Style%20Library/ECM/images/GreyStar.png"/><span style="display:none"></span>';
}


		
		
		var pNo = policynumber.toString();
		if(policynumber !=null){
		if( pNo =='')
		{
			number=subnumber;
			
		}
		else
		{
			number=policynumber;
			
		}
		}
		else
		{
			number=subnumber;
			
		}
		
		
		var policyURL = "/sites/eFileManager/Pages/PolicyDetails.aspx?PolicyNumber="+ number
		var insuredURL = "/sites/eFileManager/Pages/InsuredPage.aspx?InsuredName="+ insuredname
		
		//var acountURL = "../Pages/AccountDetails.aspx?InsuredID="+account ;
		var description = "<b>Name:</b> " + "<a href='" + linkURL + "'>" + docName + "</a>";
		
		//Get user N number and remove LM\
		var modPIN2 = ($getItemValue(ctx, "EFUnderwriterOWSUSER"));
		var modPIN1 = modPIN2.toString();
		var modPIN = modPIN1.toLowerCase();
		
		
		//lync presence variables
		var nnumber;
		if (ctx.CurrentItem.EFUnderwriterOWSUSER!= null){
			nnumber = ctx.CurrentItem.EFUnderwriterOWSUSER.toLowerCase();
		}
		var rowID=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
		rowID = parseInt(rowID);nnumber
		
		var lyncID1= "imn_"+(rowID+1)+",type=sip";
		var lyncID2= "imn_"+(rowID+2)+",type=sip";


		//Get user N number and remove LM\
		var modPIN3 = ($getItemValue(ctx, "EFUnderwritingAssistantOWSUSER"));
		var modPIN4 = modPIN3.toString();
		var modPIN5 = modPIN4.toLowerCase();
		
		//callout
		var entityName = $getItemValue(ctx, "EFPolicyNoOWSTEXT");
		var contentSource = $getItemValue(ctx, "ContentType"); 
		var account = $getItemValue(ctx, "EFPolicyNoOWSTEXT");
		var contentType = $getItemValue(ctx, "FileExtension");
		var modDate =  $getItemValue(ctx, "ModifiedOWSDATE");
 		var modDatePass =  $getItemValue(ctx, "ModifiedBy");
 		 		var brokerName=  $getItemValue(ctx, "EFBrokerNameOWSTEXT");
 		var functionalArea=  $getItemValue(ctx, "EFFunctionalAreaOWSTEXT");
 		var policyInceptionDate=  $getItemValue(ctx, "EFPolicyInceptionDateOWSDATE");

  		var modBy = getUserComponent(ctx.CurrentItem.EditorOWSUSER, 'email');
		var modByName = getUserComponent(ctx.CurrentItem.EditorOWSUSER, 'name');
		var underwritername = getUserComponent(ctx.CurrentItem.EFUnderwriterOWSUSER, 'name');
		var path = $getItemValue(ctx, "Path");	
		var comments = $getItemValue(ctx, "CommentsOWSMTXT");

		var lockUser = getUserComponent(ctx.CurrentItem.CheckoutUserOWSUSER, 'email');
		var lockUserName = getUserComponent(ctx.CurrentItem.CheckoutUserOWSUSER, 'name');
		var cc2ID = "imn_2" + encodedId + ",type=sip";
		
		var locked = false;
		if (lockUser != "" && lockUser != null){
			locked = true;
		}
		var id = ctx.ClientControl.get_nextUniqueId();
		var itemId = id + Srch.U.Ids.item;
		var docName1 = $getItemValue(ctx, "Filename")

		
		
		//lync presence variables
		var nnum;
		if (ctx.CurrentItem.EFUnderwritingAssistantOWSUSER!= null){
			nnum = ctx.CurrentItem.EFUnderwritingAssistantOWSUSER.toLowerCase();
		}
		var rowID1=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
		rowID1 = parseInt(rowID1);nnum
		
		var lyncID3= "imn_"+(rowID1+1)+",type=sip";
		var lyncID4= "imn_"+(rowID1+2)+",type=sip";
		
		



		
		ms_outHtml.push(''
,''
,'        <tr class="gs-ecm-entity-item" id="', encodedId ,'" data-listitemid="', ctx.CurrentItem.ListItemID ,'">'
,'			<td>', icon ,'</td>                    '
,'            <td class="gs-ecm-entity-item-link" data-href="', policyURL ,'"><a href="', policyURL ,'">', number ,'</a></td> '
,'            '
,'                       <td>'
,'			<div id="Item_Default"> '
,'			'
,''
,'<div data-rowid="',rowID,'" data-entityname="',entityName,'" data-contentsource="',contentSource,'" data-brokername="',brokerName,'" data-subnumber="',subnumber ,'" data-insuredname="',insuredname ,'" data-product="',product ,'" data-functionalarea="',functionalArea ,'" data-policyinceptiondate="',policyInceptionDate ,'" data-underwriter="',underwritername ,'" data-modby="',modDate,'" data-modname="',modByName,'" data-stage="',UWProcessStage ,'" data-title="', docName1 ,'" data-href="', linkURL ,'" data-comments="', comments ,'" data-path="',path,'" class="callout" id="', $htmlEncode(itemId) ,'" name="Item" data-displaytemplate="DefaultItem">'
,''
,'			<a title="Open Menu" class="ms-lstItmLinkAnchor ms-ellipsis-a">'
,'             <img data-title="', number ,'" data-href="', policyURL ,'" class="ms-ellipsis-icon" src="/_layouts/15/images/spcommon.png?rev=23" />'
,'			</a>'
,''
,'            </div>'
,'       		</div>'
,''
,'            </td>'
,''
,'            <td class="gs-ecm-entity-item-link" data-href="', insuredURL ,'"><a href="', insuredURL ,'">', insuredname ,'</a></td>  '
,'            <td>'
,'				<span class="gs-ecm-lync-placeholder" data-nnumber="',nnumber,'" data-rowid="',rowID,'" data-name="', Underwriter,'">'
,''
,'				</span> '
,'			', Underwriter,''
,'			</td> '
,'            <td><span class="gs-ecm-lync-placeholder" data-nnumber="',nnum,'" data-rowid="',rowID1,'" data-name="', UnderwritingAssistant,'">'
,''
,'				</span> '
, UnderwritingAssistant,'</td>'
,''
,'            <td>', product ,'</td>'
,'            <td>', country ,'</td>'
,'            <td>', year,'</td>'
,' 			<td>', eFileType ,'</td>'
,'            <td>', UWProcessStage ,'</td>'
,'         	<td>', spotlight ,'</td>'
,'         </tr>'
,'    '
);

  ctx['ItemValues'] = cachePreviousItemValuesFunction;
  ctx['DisplayTemplateData'] = cachePreviousTemplateData;
  return ms_outHtml.join('');
}
function RegisterTemplate_fd2e76be4ea343b4b049e76fc8c39d76() {

if ("undefined" != typeof (Srch) &&"undefined" != typeof (Srch.U) &&typeof(Srch.U.registerRenderTemplateByName) == "function") {
  Srch.U.registerRenderTemplateByName("Item_Default", DisplayTemplate_fd2e76be4ea343b4b049e76fc8c39d76);
}

if ("undefined" != typeof (Srch) &&"undefined" != typeof (Srch.U) &&typeof(Srch.U.registerRenderTemplateByName) == "function") {
  Srch.U.registerRenderTemplateByName("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fContent Web Parts\u002fHomeAllEfile_Item_copy\u00281\u0029.js", DisplayTemplate_fd2e76be4ea343b4b049e76fc8c39d76);
}

}
RegisterTemplate_fd2e76be4ea343b4b049e76fc8c39d76();
if (typeof(RegisterModuleInit) == "function" && typeof(Srch.U.replaceUrlTokens) == "function") {
  RegisterModuleInit(Srch.U.replaceUrlTokens("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fContent Web Parts\u002fHomeAllEfile_Item_copy\u00281\u0029.js"), RegisterTemplate_fd2e76be4ea343b4b049e76fc8c39d76);
}