/* This file is currently associated to an HTML file of the same name and is drawing content from it.  Until the files are disassociated, you will not be able to move, delete, rename, or make any other changes to this file. */

function DisplayTemplate_3f4931d7bceb442eba17615f7479276e(ctx) {
  var ms_outHtml=[];
  var cachePreviousTemplateData = ctx['DisplayTemplateData'];
  ctx['DisplayTemplateData'] = new Object();
  DisplayTemplate_3f4931d7bceb442eba17615f7479276e.DisplayTemplateData = ctx['DisplayTemplateData'];

  ctx['DisplayTemplateData']['TemplateUrl']='~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fContent Web Parts\u002fInsuredItem.js';
  ctx['DisplayTemplateData']['TemplateType']='Item';
  ctx['DisplayTemplateData']['TargetControlType']=['Content Web Parts'];
  this.DisplayTemplateData = ctx['DisplayTemplateData'];

  ctx['DisplayTemplateData']['ManagedPropertyMapping']={'eFileTypeOWSCHCS':['eFileTypeOWSCHCS'], 'BrokerNameOWSTEXT':['BrokerNameOWSTEXT'], 'StageOWSCHCS':['StageOWSCHCS'], 'SubmissionNoOWSTEXT':['SubmissionNoOWSTEXT'], 'PolicyNoOWSTEXT':['PolicyNoOWSTEXT'], 'InsuredNameOWSTEXT':['InsuredNameOWSTEXT'], 'FunctionalAreaOWSTEXT':['FunctionalAreaOWSTEXT'], 'ProductOWSTEXT':['ProductOWSTEXT'], 'UnderwriterOWSUSER':['UnderwriterOWSUSER'], 'UnderwritingAssistantOWSUSER':['UnderwritingAssistantOWSUSER'], 'CountryOWSTEXT':['CountryOWSTEXT'], 'PolicyYearOWSTEXT':['PolicyYearOWSTEXT']};
  var cachePreviousItemValuesFunction = ctx['ItemValues'];
  ctx['ItemValues'] = function(slotOrPropName) {
    return Srch.ValueInfo.getCachedCtxItemValue(ctx, slotOrPropName)
};

ms_outHtml.push('',''
,''
);
		var linkURL = $getItemValue(ctx, "Link URL");
		    linkURL.overrideValueRenderer($urlHtmlEncode);
		//debugger;
		    var docName = $getItemValue(ctx, "Filename")+"";
		var titleToolTip = "";
		docName = docName.substr(0, docName.lastIndexOf('.'));
		if(docName.length > 55){
			titleToolTip = docName;
			docName = docName.substr(0,54) + "...";
		}
		
		
		var encodedId = $htmlEncode(ctx.ClientControl.get_nextUniqueId() + "_row_"); 
		
		var icon= '<img src="/sites/eFileManager/images/eFileIcon.png"/><span style="display:none"></span>';
		var policynumber = $getItemValue(ctx, "PolicyNoOWSTEXT");
		var number='';
		var subnumber = $getItemValue(ctx, "SubmissionNoOWSTEXT");
		var insuredname = $getItemValue(ctx, "InsuredNameOWSTEXT");
		var Underwriter=  $getItemValue(ctx, "UnderwriterOWSUSER");
		var UnderwritingAssistant=  $getItemValue(ctx, "UnderwritingAssistantOWSUSER");
		var product = $getItemValue(ctx, "ProductOWSTEXT");
		var country = $getItemValue(ctx, "CountryOWSTEXT");
		var year=  $getItemValue(ctx, "PolicyYearOWSTEXT");
		var eFileType = $getItemValue(ctx, "eFileTypeOWSCHCS");
		var UWProcessStage= $getItemValue(ctx, "StageOWSCHCS");
		var brokerName=  $getItemValue(ctx, "BrokerNameOWSTEXT");
		//var spotlight='<img src="http://vddp23g-cf436d0:1234/sites/eFileManager/Style%20Library/ECM/images/spotlight.png"/><span style="display:none"></span>';
		var spotlight= "";
		
		var pNo = policynumber.toString();
		if(policynumber !=null){
		if( pNo =='')
		{
			number=subnumber;
			spotlight = '<img src="http://vddp23g-cf436d0:1234/sites/eFileManager/Style%20Library/ECM/images/GreyStar.png"/><span style="display:none"></span>';
		}
		else
		{
			number=policynumber;
			spotlight = '<img src="http://vddp23g-cf436d0:1234/sites/eFileManager/Style%20Library/ECM/images/spotlight.png"/><span style="display:none"></span>';
		}
		}
		else
		{
		number=subnumber;
		spotlight = '<img src="http://vddp23g-cf436d0:1234/sites/eFileManager/Style%20Library/ECM/images/GreyStar.png"/><span style="display:none"></span>';
		}
		
		var lock= '<img src="http://vddp23g-cf436d0:1234/sites/eFileManager/Style%20Library/ECM/images/lock.png"/><span style="display:none"></span>';

		var policyURL = "/sites/eFileManager/Pages/PolicyDetails.aspx?PolicyNumber="+ number
		var insuredURL = "/sites/eFileManager/Pages/PolicyDetails.aspx?InsuredName="+ insuredname
		
		//var acountURL = "../Pages/AccountDetails.aspx?InsuredID="+account ;
		var description = "<b>Name:</b> " + "<a href='" + linkURL + "'>" + docName + "</a>";
		var insurednameURL = "/sites/eFileManager/Pages/AccountDetails.aspx?AccountName="+ insuredname ;
			
		//Get user N number and remove LM\
		var modPIN2 = ($getItemValue(ctx, "UnderwriterOWSUSER"));
		var modPIN1 = modPIN2.toString();
		var modPIN = modPIN1.substring(3).toLowerCase();
		
		
		//lync presence variables
		var nnumber;
		if (ctx.CurrentItem.UnderwriterOWSUSER!= null){
			nnumber = ctx.CurrentItem.UnderwriterOWSUSER.toLowerCase();
		}
		var rowID=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
		rowID = parseInt(rowID);nnumber
		
		var lyncID1= "imn_"+(rowID+1)+",type=sip";
		var lyncID2= "imn_"+(rowID+2)+",type=sip";


		//Get user N number and remove LM\
		var modPIN3 = ($getItemValue(ctx, "UnderwritingAssistantOWSUSER"));
		var modPIN4 = modPIN3.toString();
		var modPIN5 = modPIN4.substring(3).toLowerCase();
		
		
		//lync presence variables
		var nnum;
		if (ctx.CurrentItem.UnderwritingAssistantOWSUSER!= null){
			nnum = ctx.CurrentItem.UnderwritingAssistantOWSUSER.toLowerCase();
		}
		var rowID1=ctx.ClientControl.get_nextUniqueId().split("_csr").pop();
		rowID1 = parseInt(rowID1);nnum
		
		var lyncID3= "imn_"+(rowID1+1)+",type=sip";
		var lyncID4= "imn_"+(rowID1+2)+",type=sip";

		ms_outHtml.push(''
,''
,'         <tr class="gs-ecm-entity-item" id="', encodedId ,'" data-listitemid="', ctx.CurrentItem.ListItemID ,'">'
,'			<td>', icon ,'</td>                    '
,'            <td class="gs-ecm-entity-item-link" data-href="', policyURL ,'"><a href="', policyURL ,'">', number ,'</a></td>     '
,'          <td>'
,'				<span class="gs-ecm-lync-placeholder" data-nnumber="',nnumber,'" data-rowid="',rowID,'" data-name="', Underwriter,'">'
,''
,'				</span> '
,'			', Underwriter,''
,'			</td> '
,'            <td><span class="gs-ecm-lync-placeholder" data-nnumber="',nnum,'" data-rowid="',rowID1,'" data-name="', UnderwritingAssistant,'">'
,''
,'				</span> '
, UnderwritingAssistant,'</td>'
,'            <td>', product ,'</td>'
,'            <td>', country ,'</td>'
,'            <td>', year,'</td>'
,' 			<td>', eFileType ,'</td>'
,'            <td>', UWProcessStage ,'</td>'
,'             <td>', brokerName,'</td>'
,'         	<td>', spotlight ,'</td>'
,'         	<td>', lock,'</td>'
,'         </tr>'
,'    '
);

  ctx['ItemValues'] = cachePreviousItemValuesFunction;
  ctx['DisplayTemplateData'] = cachePreviousTemplateData;
  return ms_outHtml.join('');
}
function RegisterTemplate_3f4931d7bceb442eba17615f7479276e() {

if ("undefined" != typeof (Srch) &&"undefined" != typeof (Srch.U) &&typeof(Srch.U.registerRenderTemplateByName) == "function") {
  Srch.U.registerRenderTemplateByName("Item_Default", DisplayTemplate_3f4931d7bceb442eba17615f7479276e);
}

if ("undefined" != typeof (Srch) &&"undefined" != typeof (Srch.U) &&typeof(Srch.U.registerRenderTemplateByName) == "function") {
  Srch.U.registerRenderTemplateByName("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fContent Web Parts\u002fInsuredItem.js", DisplayTemplate_3f4931d7bceb442eba17615f7479276e);
}

}
RegisterTemplate_3f4931d7bceb442eba17615f7479276e();
if (typeof(RegisterModuleInit) == "function" && typeof(Srch.U.replaceUrlTokens) == "function") {
  RegisterModuleInit(Srch.U.replaceUrlTokens("~sitecollection\u002f_catalogs\u002fmasterpage\u002fDisplay Templates\u002fContent Web Parts\u002fInsuredItem.js"), RegisterTemplate_3f4931d7bceb442eba17615f7479276e);
}