﻿/*Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company*/
/*global SP, window, document, $, Microsoft*/
/*jslint maxlen: 150 */

/* KNOWN ISSUES: 

>>> [LOW] Error messages should be read from a SharePoint list rather than hardcoded as strings.
>>> [LOW] Folder URL is not set for bond entity types.
 
*/


ULS.enable = true;

//function called on click of document group in the right filter
function filterCategory(obj) {
    $('.uploader.active, h3.gs-ecm-document-header').removeClass('active');
    $(obj).closest('.uploader').addClass('active');
    $("#DocsTable").dataTable().fnFilter(obj.text, 6, true, false);
    $('th.gs-ecm-th-category div.DataTables_sort_wrapper>a').addClass('filtered');
    $('th.gs-ecm-th-category').find("input").prop("checked", false);
    var labels = $('th.gs-ecm-th-category').find("label");
    for (var i = 0; i < labels.length; i++) {
        if ($(labels[i]).text() == obj.text) {
            var currlabel = $(labels[i]);
            currlabel.prev('input').prop("checked", true);
            $('th.gs-ecm-th-category').find(".gs-ecm-sqrfill-filters").addClass('intfill');
        }
}
}

//function called on click of ALL in the right filter
function showAllFolders(obj) {
    $('.uploader.active').removeClass('active');
    $(obj).closest('.gs-ecm-document-header').addClass('active');
    $("#DocsTable").dataTable().fnFilter('', 6, true, false);
    $('th.gs-ecm-th-category div.DataTables_sort_wrapper>a').removeClass('filtered');
    $('th.gs-ecm-th-category').find("input").prop("checked", false);
    $('th.gs-ecm-th-category').find(".gs-ecm-sqrfill-filters").removeClass('solidfill intfill');
}
var Liberty = window.Liberty || {};
Liberty.DragDropTaxonomy = function () {
    try {
        var load = function () {
            //ULSOnError("ecm_dragdropzone start time", new Date(), 0);
            // Helper variables.
            var targetTermGroup = 'LM', targetTermSet = '';
            var curID = getParams('policynumber');
            var curAccountID = '', curTaxonomyField = "", curDocSetName = curID, parentTargetLibrary = '';;
            var curIDField = '', curSearchIDField = 'EFPolicyNumberOWSTEXT', curSubIDField = 'EFSubmissionNumberOWSTEXT';
            var targetLibraryPaths = [], curPrincipalID = '', policyRegion = "", results = null;
            var polLocation;
            function getQueryTargetPaths() {
                polLocation = WBgetQueryStringParameter("polLoc");
                polLocation = decodeURIComponent(polLocation);
            }
            getQueryTargetPaths();
            if (polLocation.length == 0) {
                getTargetPaths();
            }
            else {
                targetLibraryPaths.push(polLocation);
                var arrayDDTargetSiteUrl = polLocation.split('/');
                parentTargetLibrary = arrayDDTargetSiteUrl[5];
                curDocSetName = arrayDDTargetSiteUrl[6];
                curID = curDocSetName;
                curIDField = arrayDDTargetSiteUrl[3];
                //setWebProperty();

                // Once target library paths are captured, check for empty variables.
                if (!checkForValues()) {
                    displayErrorMessage();
                } else getCurrentUser();
            }

            // Get the target paths for the document sets associated with the entity.		
            function getTargetPaths() {

                // Create new client context and keyword query variables. 
                var ctx = SP.ClientContext.get_current(), kwQuery = new Microsoft.SharePoint.Client.Search.Query.KeywordQuery(ctx);

                // Set query parameters.
                kwQuery.get_selectProperties().add('Path');
                kwQuery.set_queryText(curSearchIDField + ':' + curID + ' OR ' + curSubIDField + ':' + curID + ' iscontainer:true');

                // Execute search query.
                var searchExecutor = new Microsoft.SharePoint.Client.Search.Query.SearchExecutor(ctx);
                results = searchExecutor.executeQuery(kwQuery);
                ctx.executeQueryAsync(onQuerySuccess, displayErrorMessage);
            }

            // Add all target library paths to array.
            function onQuerySuccess() {
                var returnedResult = results.m_value.ResultTables[0].ResultRows;

                if (returnedResult[0].Path !== null && returnedResult[0].Path.indexOf("/ca/") > 0) {
                    policyRegion = "Canada";
                } else if (returnedResult[0].Path !== null && returnedResult[0].Path.indexOf("/us/") > 0) {
                    policyRegion = "US";
                }
                // GetTermStoreIdByName(policyRegion);
                //  var det = GetTermStoreDetails();

                targetTermSet = policyRegion;
                curTaxonomyField = policyRegion;
                curIDField = policyRegion;

                // If no target library path was found, let the user know the webpart is unavailable.
                if (returnedResult.length === 0) {
                    $('#loading').replaceWith('<div "gs-ecm-drag-drop-fail">User does not have permission to view this ' + targetTermSet.toLowerCase() +
                                              ' or a document set for this ' + targetTermSet.toLowerCase() + ' does not exist. Please try again later.' +
                                              'If this message persists please contact your system administrator.  </div>');
                } else {
                    for (var i = 0; i < returnedResult.length; i++) {
                        targetLibraryPaths.push(returnedResult[i].Path);
                        var arrayDDTargetSiteUrl = returnedResult[i].Path.split('/');
                        parentTargetLibrary = arrayDDTargetSiteUrl[5];
                        curDocSetName = arrayDDTargetSiteUrl[6];
                    }

                    //setWebProperty();

                    // Once target library paths are captured, check for empty variables.
                    if (!checkForValues()) {
                        displayErrorMessage();
                    } else getCurrentUser();
                }
            }
            var _docGroups = "";
            // Load the current user to set security trimming on folders.        
            function getCurrentUser() {
                // setTimeout(function () {
                var key = "DocumentGroups";
                var listName = 'efileConfigList';

                var siteUrl = document.URL.toLowerCase().split('/pages/')[0];
                $.ajax({
                    url: siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items?$filter=(Title eq '" + key + "')&$select=Value",
                    type: "GET",
                    async: true,
                    cache: false,
                    headers: {
                        "Accept": "application/json;odata=verbose",
                        "X-RequestDigest": $("#__REQUESTDIGEST").val()
                    },
                    success: function (data) {
                        _docGroups = data.d.results[0].Value;
                        var userGroupTitle = '';
                        ko.applyBindings(new TaxonomyViewModel(userGroupTitle), $('#taxDD #groups')[0]);
                    },
                    error: function (data) {
                        console.log(JSON.stringify(data));
                        ULSOnError(JSON.stringify(data), document.location.href, 0);
                    }
                });
            }

            /***** CREATE VIEW MODEL BASED ON TERM STORE STRUCTURE *****/
            // Set view model variables.
            var self = this;
            self.groups = ko.observableArray([]);
           
            // Create a KO view model to dynamically load the folders.
            function TaxonomyViewModel() {

                var self = this;
                self.groups = ko.observableArray([]);
                var taxonomyTagsArray = new Array();

                group = new Group("All", "All", [], false);

                _docGroups = _docGroups.split(',');
                for (i = 0; i < _docGroups.length; i++) {
                    group.isLeaf(true);
                    var allowed = '';
                    allowed = 'gs-ecm-document-item';
                    if (allowed != '') {
                        group.Folders().push(new Folder(_docGroups[i], _docGroups[i], _docGroups[i], parentTargetLibrary, allowed));
                        taxonomyTagsArray.push(new folderCountItem(_docGroups[i], 0));
                    }
                }
                if (group.Folders().length > 0) {
                    self.groups.push(group);
                }
               
            }

            /***** HELPER FUNCTIONS *****/

            // Function to pull parameters from page URL.
            function getParams(name) {
                name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
                var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search.toLowerCase());
                return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
            }



            // Function to add a warning message to the web part when something fails to load correctly.
            function displayWarningMessage(message) {
                $('#loading').after('<div class="gs-ecm-drag-drop-fail" style="display:none">' + message + '</div>');
            }

            // Function to replace the web part with an error message when the web part cannot be loaded.
            function displayErrorMessage() {
                $('#loading').replaceWith('<div "gs-ecm-drag-drop-fail">This app part is currently unavailable. Please try again later.' +
                                          ' If this message persists please contact your system administrator. </div>');
            }

            // Check for values in required variables.
            function checkForValues() {
                if (targetTermGroup == '' || curID == '' || curIDField == '' ||
                     curDocSetName == '' || targetLibraryPaths.length < 1) {
                    return false;
                }
                else return true;
            }

            // Remove leading dash from each element to aid in comparison with user groups
            function createGroupArray(splitString) {
                var replaceChars = { '-': '', ',-': ',' };
                splitString = splitString.replace(/ +/g, '').replace(/^-|,-+/g, function (match) { return replaceChars[match]; });
                return splitString.split(",");
            }

            /***** OBJECT DEFINITIONS *****/

            // Function to create a folder count item to be used to track document tags.
            function folderCountItem(GUID, count) {
                this.GUID = GUID;
                this.Count = count;
            }

            // Function to create a new group object to represent a folder heading.
            function Group(id, title, folders, isLeaf) {
                this.ID = ko.observable('G-' + id);
                this.Title = ko.observable(title);
                this.Folders = ko.observableArray(folders);
                this.isLeaf = ko.observable(isLeaf);
            }

            // Function to create a folder object to represent a draggable folder region.
            function Folder(id, title, parentTitle, targetLibrary, dragAllowed) {

                this.ID = ko.observable(id.replace(/\s/g, ''));
                this.Title = ko.observable(title);
                this.TargetLibrary = ko.observable(targetLibrary);
                this.DragAllowed = ko.observable(dragAllowed);
                var page = Liberty.Utilities.getPage();
                page = page.replace("Details", "");
                var URLParams = $(".gs-ecm-documentspage-link").attr("href");
                URLParams = URLParams.substring(URLParams.lastIndexOf("?") + 1, URLParams.lastIndexOf("#"));
                var querySubstring = title;
                if (title.toLowerCase() != parentTitle.toLowerCase())
                    querySubstring = parentTitle + ':' + title;
                this.Url = _spPageContextInfo.webAbsoluteUrl + '/Pages/PolicyDetails.aspx' + location.search;
                // this.Url = _spPageContextInfo.webAbsoluteUrl + '/Pages/' + page + 'Documents.aspx?PolicyNo=' + curID + '&CntType=' + title;
                //  this.Url += '#Default=' + encodeURIComponent('{"r":[{"n":"wbPrimaryClassLabel","t":["\\"' + querySubstring + '\\""],"o":[{"d":1,"p":"ModifiedOWSDATE"}],"m":{"\\"' + querySubstring + '\\"":"' + querySubstring + '"}}' +',{"n":"wb' + entityType + 'ID","t":["\\"' + curID + '\\""]}]}');
                // this.Url += '#Default=' + encodeURIComponent('{"r":[{"n":"EFDocumentGroupOWSTAXID","t":["\\"' + querySubstring + '\\""],"o":[{"d":1,"p":"ModifiedOWSDATE"}],"m":{"\\"' + querySubstring + '\\"":"' + querySubstring + '"}}' + ',{"n":"EFPolicyNumberOWSTEXT","t":["\\"' + curID + '\\""]}]}');
            }

            /***** KNOCKOUT BINDINGS *****/

            // Custom KO binding to make each folder a draggable region for uploading.
            ko.bindingHandlers.setUploader = {
                update: function (element) {

                    var uploadDiv = new Liberty.DragDropUploader.create($(element).attr("id"), targetTermSet, targetLibraryPaths, curDocSetName, curAccountID, curPrincipalID);
                }
            };

            // Custom KO binding to apply an accordion effect to each folder heading.
            ko.bindingHandlers.setAccordion = {
                init: function (element) {
                    var panel = $(element).next();
                    $(element).click(function () {
                        $(panel).slideToggle('slow');
                        $(element).toggleClass('selected');
                    });
                }
            };

            /** store web url in web properties **/
            function setWebProperty() {
                var ctx = new SP.ClientContext.get_current();
                var web = ctx.get_web();
                this.properties = web.get_allProperties();
                if (targetLibraryPaths != null && targetLibraryPaths.length > 0) {
                    this.properties.set_item(curID, targetLibraryPaths[0]);
                }
                ctx.load(web);
                web.update();
                ctx.executeQueryAsync(Function.createDelegate(this, getWebProperty), Function.createDelegate(this, failedGettingProperty));
            }
            function getWebProperty() {
                console.log(this.properties.get_item(curID));
            }
            function failedGettingProperty() {
                console.log("Get web property failed");
                ULSOnError(arguments[1].get_message(), document.location.href, 0);
            }

        };

        return {
            load: load,
        };
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}();


//dragdropUploader starts
/* KNOWN ISSUES:

>>> [LOW] Error messages should be stored in a SharePoint list rather than hardcoded into an array.    
>>> [LOW] Unique icons for uncommon file types are not included in the popup window's left panel.

>>> [HIGH] Enterprise Keywords input by the user are not being applied to files. 


ERIN YOU WERE FIXING THE DUPLICATE FILE NAME BUG REMEMBER */
var itemId = 0;
var productSiteUrl;
ULS.enable = true;
var Liberty = window.Liberty || {};
var loadingFolders;
Liberty.DragDropUploader = function () {
    try {
        loadingFolders = Liberty.Utilities.loadingImage + '&nbsp;<span style="vertical-align:top;">Loading folders...</span>';

        var uploader = function (divid, targetTermSet, targetLibraryPaths, curDocSetName, curAccountID, curPrincipalID) {
            /***** GATHER REQUIRED INFORMATION *****/

            // Get the target library and target web.
            var targetLibrary = '';
            var targetSiteUrl = '';
            var folderClasses = $('#' + divid.replace(/\s/g, '')).attr('class');
            var allClasses = folderClasses.split(' ');
            for (var i = 0; i < allClasses.length; i++) {
                if (allClasses[i].toLowerCase().indexOf('target-library-') != -1) {
                    targetLibrary = allClasses[i].substring((allClasses[i].toLowerCase().indexOf('target-library-') + 15), allClasses[i].length);
                    for (var j = 0; j < targetLibraryPaths.length; j++) {
                        if (targetLibraryPaths[j].toLowerCase().indexOf(targetLibrary.toLowerCase()) != -1) {
                            var targetPathDetails = targetLibraryPaths[j].toLowerCase().split("/");
                            targetSiteUrl = '/' + targetPathDetails[3] + '/' + targetPathDetails[4];
                            productSiteUrl = targetSiteUrl;
                        }
                    }
                }
            }
           
            // Once all the folders have been created, display the web part.
            $('#loading').hide();
            $(".gs-ecm-document-section").hide();
            $('.gs-ecm-drag-drop-fail').css("display", "inline");
            $('#gs-ecm-document-container').show('slow');

            // Set variables.
            var isSearchBox = '';
            var maxFileSize = 52428800;
            var errorList = [new Error('-2130575257', 'Duplicate business record.'),
                             new Error('-2130575245', 'Invalid file name.'),
                                   new Error('-2147221018', 'Illegal file type.')];

            // Check if a user has permission to tag with the current taxonomy term.
            var dragClass = 'gs-ecm-document-drag';
            if (folderClasses.toLowerCase().indexOf('-readonly') != -1)
                dragClass = 'gs-ecm-document-drag-readonly';

            /***** SET DRAGGING ACTIONS *****/

            this.uploadDragEnter = function (e) {
                highlightDragArea();
                e.stopPropagation();
                e.preventDefault();
            };
            this.uploadDragExit = function (e) {
                e.stopPropagation();
                e.preventDefault();
            };
            this.uploadDragOver = function (e) {
                e.stopPropagation();
                e.preventDefault();
            };
            this.uploadDrop = function (e) {
                e.stopPropagation();
                e.preventDefault();
                var files = e.originalEvent.dataTransfer.files;
                var fileCounter = 0;
                if (files.length == 0) {
                    alert("Please drag and drop a valid file.");
                    $('#folders').children().each(function () { $(this).removeClass('over'); });
                }
                else
                    getPermissionForReadOnly(targetLibrary);

                function getPermissionForReadOnly(listTitle) {
                    var context = null;
                    context = new SP.ClientContext(spotTargetSiteUrl);
                    web = context.get_web();
                    list = web.get_lists().getByTitle(listTitle);
                    // this.listItem = list.getItemById(hasPerm);
                    context.load(list, 'EffectiveBasePermissions');

                    context.executeQueryAsync(function () {
                        try {

                            var perms = list.get_effectiveBasePermissions();
                            if (perms.has(SP.PermissionKind.editListItems)) {


                                /***** RENDER POPUP WINDOW WITH FORM FOR FIRST FILE *****/

                                var options = SP.UI.$create_DialogOptions();
                                options.title = 'Upload Files';
                                if (files.length == 1)
                                    options.width = 600;
                                else
                                    options.width = 1000;

                                options.url = '/Style Library/HTML/DragDropPopup.aspx?IsDlg=1';
                                options.args = { TargetTermSet: targetTermSet };
                                options.dialogReturnValueCallback = updateFolderCount;
                                SP.SOD.execute('sp.ui.dialog.js', 'SP.UI.ModalDialog.showModalDialog', options);
                                //ExecuteOrDelayUntilScriptLoaded(function () {  SP.UI.ModalDialog.showModalDialog(options);}, "sp.ui.dialog.js");
                                //SP.SOD.execute('sp.js', 'SP.UI.ModalDialog.showModalDialog', options);
                                function updateFolderCount(dialogResult, returnValue) {
                                    //increment file count when files successfully added                      
                                    window.location.reload();
                                }
                                var iframe = $('iframe');
                                iframe.load(function () {

                                    var uploadFunction = function () {
                                        var button = $('iframe').contents().find('#' + this.id);
                                        startNextUpload(button);
                                    };

                                    if (files.length == 1) {
                                        iframe.contents().find('#gs-ecm-right-upload-popup-panel').addClass('gs-ecm-right-singleupload');
                                    }



                                    // Display all the file titles in the left panel of the window.
                                    for (var i = 0; i < files.length; i++) {
                                        var fileType = files[i].type;
                                        var fileName = files[i].name;
                                        var fileExtension = '';
                                        if (fileName.lastIndexOf('.') != -1) {
                                            fileType = files[i].name.substring(files[i].name.lastIndexOf('.') + 1, files[i].name.length);
                                            fileName = files[i].name.substring(0, files[i].name.lastIndexOf('.'));
                                            fileExtension = files[i].name.substring(files[i].name.lastIndexOf('.'), files[i].length);
                                        }
                                        else fileType = fileType.split('/')[0];
                                        var fileIcon = getFileIcon(fileType);

                                        if (files.length == 1) {
                                            iframe.contents().find('#gs-ecm-single-doc').css('display', 'inline');
                                            iframe.contents().find('.gs-ecm-single-file-icon').append('<img src="_layouts/15/images/' + fileIcon + '"/>');
                                            iframe.contents().find('#gs-ecm-single-file-name').html(fileName);
                                            iframe.contents().find('#gs-ecm-single-doc-status').append('<div id="gs-ecm-upload-status-file-0" class="gs-ecm-uploading-status"></div>');
                                        }
                                        else {
                                            iframe.contents().find('#gs-ecm-status-box').append('<div id="gs-ecm-file-num-' + i + '" class="gs-ecm-file-name">' +
                                                   '<span class="gs-ecm-file-meta-status"></span><span class="gs-ecm-file-icon">' +
                                                   '<img src="_layouts/15/images/' + fileIcon + '" /></span>' +
                                                   '<span id="gs-ecm-file-name-' + i + '">' + fileName + '</span>' +
                                                   '<span id="gs-ecm-file-extension-' + i + '">' + fileExtension + '</span><div id="gs-ecm-upload-status-file-' + i +
                                                   '" class="gs-ecm-uploading-status"></div></div>');
                                        }
                                    }

                                    initializeButtons();
                                    resetForm(0);

                                    /***** FUNCTIONS TO HANDLE UPLOAD PROCESS WHEN 'NEXT' BUTTON IS CLICKED *****/
                                    function validFormData(fileData) {

                                        var valid = false;
                                        fileData.Name = replaceInvalidCharacters(fileData.Name);

                                        //if (fileData.DocGroup.indexOf(notLookedUpGUID) != -1 ||
                                        //    fileData.DocGroup.indexOf(doesNotExistGUID) != -1)
                                        //    alert('Please enter a valid Document Group.');
                                        //else if (fileData.DocType.indexOf(notLookedUpGUID) != -1 ||
                                        //        fileData.DocType.indexOf(doesNotExistGUID) != -1 || fileData.DocType == null || fileData.DocType == "")
                                        //    alert('Please enter a valid Document Type.');
                                        if (fileData.DocGroup == "Select" || fileData.DocGroup == "select") {
                                            alert('Please select a valid Document Group.');
                                        }
                                        else if (fileData.DocType == "Select" || fileData.DocType == "select") {
                                            alert('Please select a valid Document Type.');
                                        }
                                        else {
                                            valid = true;
                                        }
                                        return valid;
                                    }

                                    function replaceInvalidCharacters(fileName) {
                                        var res = fileName.replace(/[~#%&*{}\/\\:<>?|"]/g, '');
                                        if (res.charAt(0) == '.') {
                                            res = res.substring(1, res.length);
                                        }
                                        if (res.charAt(res.length - 1) == '.') {
                                            res = res.substring(0, res.length - 1);
                                        }

                                        if (res.match(/(\.\.)/)) {
                                            res = res.replace(/\.+/g, '.');
                                        }
                                        return res;
                                    }


                                    // Initiate upload process for an individual file.
                                    function uploadFile(file, fileName, fileData, fileIndex) {
                                        this.file = file;
                                        this.fileName = fileName;
                                        this.fileData = fileData;
                                        this.fileIndex = fileIndex;

                                        // Convert user input dates to ISO strings.
                                        // fileData.ReceiptDate = convertDateStrToISO(this.fileData.ReceiptDate);
                                        // fileData.BusinessDate = convertDateStrToISO(this.fileData.BusinessDate);
                                        iframe.contents().find('#gs-ecm-upload-status-file-' + (this.fileIndex)).text('Uploading...');

                                        iframe.contents().find('#gs-ecm-file-num-' + (this.fileIndex) + ' .gs-ecm-file-meta-status').addClass('gs-ecm-file-meta-status-loading');
                                        iframe.contents().find('#gs-ecm-single-doc-status .gs-ecm-file-meta-status').addClass('gs-ecm-file-meta-status-loading');

                                        // if (fileData.Keywords == '') {
                                        this.fileIndex++;
                                        addFileToLibrary(this.file, targetLibrary, (this.fileData.Name + this.fileData.Extension), this.fileIndex, this.fileData);

                                        // Upload the file to the correct document set in a given site collection and library.
                                        function addFileToLibrary(file, libraryName, docName, fileIndex, fileData) {
                                            if (file.size > maxFileSize) {
                                                updateFinishedFileStatus('File size is too big.', (fileIndex - 1), false);
                                                return;
                                            }
                                            getFileBuffer(file).then(
                                                   function (arrayBuffer) {
                                                       var sp_id_loc = WBgetQueryStringParameter("SpID");
                                                       var isDoc = WBgetQueryStringParameter("IsDoc");
                                                       if (isDoc != undefined && isDoc != '') {
                                                           sp_id_loc = $('#hdnSpId').val();
                                                       }
                                                       var addUrl = targetSiteUrl + "/_api/web/lists/getByTitle(@TargetLibrary)/items(@spId)/";

                                                       addUrl += "folder/files/add(url=@TargetFileName,overwrite='true')?";
                                                       addUrl += "@TargetLibrary='" + targetLibrary + "'&";
                                                       addUrl += "@TargetFileName='" + docName + "'&";
                                                       //addUrl += "@TargetFolderName='" + encodeURIComponent(curDocSetName) + "'";
                                                       addUrl += "@spId='" + sp_id_loc + "'";

                                                       $.ajax({
                                                           url: targetSiteUrl + "/_api/contextinfo",
                                                           type: "POST",
                                                           contentType: "application/x-www-url-encoded",
                                                           dataType: "json",
                                                           headers: { "Accept": "application/json; odata=verbose", },
                                                           success: function (data) {
                                                               if (data.d) {
                                                                   var digest = data.d.GetContextWebInformation.FormDigestValue;
                                                                   //$("#__REQUESTDIGEST").val(digest);
                                                                   $.ajax({
                                                                       url: addUrl,
                                                                       type: "POST",
                                                                       data: arrayBuffer,
                                                                       processData: false,
                                                                       headers: {
                                                                           "accept": "application/json;odata=verbose",
                                                                           "X-RequestDigest": digest,
                                                                           "content-length": arrayBuffer.byteLength
                                                                       },
                                                                       success: function (data) {
                                                                           getDocumentListItem(libraryName, fileIndex, fileData, data.d.ListItemAllFields.__deferred.uri);
                                                                       },
                                                                       error: function (c, k, r) {
                                                                           var errorCodeStartIndex = c.responseText.toLowerCase().indexOf('{\"code\":\"') + 9;
                                                                           var errorCodeEndIndex = c.responseText.indexOf(',');
                                                                           var errorCode = c.responseText.substring(errorCodeStartIndex, errorCodeEndIndex);
                                                                           //var errorMsg = 'Unknown error ' + errorCode + '.';
                                                                           var errorMsg = 'Unknown error ' + libraryName + ' ' + docName + ' ' + fileIndex + ' ' + errorCode;
                                                                           for (var i = 0; i < errorList.length; i++) {
                                                                               if (errorList[i].Code.toString().toLowerCase() == errorCode.toLowerCase()) {
                                                                                   errorMsg = errorList[i].Message;
                                                                                   break;
                                                                               }
                                                                           }
                                                                           updateFinishedFileStatus(errorMsg, (fileIndex - 1), false);
                                                                       }
                                                                   });
                                                               }
                                                           },
                                                           error: function (err) {
                                                               console.log(JSON.stringify(err));
                                                           }
                                                       });
                                                   },
                                                   function (err) {
                                                       updateFinishedFileStatus(err, (fileIndex - 1), false);
                                                   }
                                               );
                                        }

                                        function getFileBuffer(file) {
                                            var deferred = $.Deferred();
                                            var reader = new FileReader();
                                            reader.onload = function (e) {
                                                deferred.resolve(e.target.result);
                                            };
                                            reader.onerror = function (e) {
                                                deferred.reject(e.target.error);
                                            };
                                            reader.readAsArrayBuffer(file);
                                            return deferred.promise();
                                        }

                                        function getDocumentListItem(listName, fileIndex, fileData, documentUri) {
                                            var id = 0;
                                            var url = documentUri;
                                            $.ajax({
                                                url: url,
                                                method: "GET",
                                                headers: {
                                                    "Accept": "application/json;odata=verbose",
                                                    "content-type": "application/json;odata=verbose",
                                                    "X-RequestDigest": $("#__REQUESTDIGEST").val()
                                                },
                                                success: function (x, y, z) {
                                                    var results = JSON.parse(z.responseText);
                                                    if (results.d.Id.length != 0) {
                                                        id = results.d.Id;
                                                        console.timeEnd("get uploaded file");
                                                        console.time("update file metadata");
                                                        updateListItemMetadata(listName, id, fileIndex, fileData);
                                                    }
                                                    else {
                                                        updateFinishedFileStatus('File metadata cannot be updated.', (fileIndex - 1), false);
                                                    }
                                                },
                                                error: function (c, k, r) {
                                                    var errorCodeStartIndex = c.responseText.toLowerCase().indexOf('{\"code\":\"') + 9;
                                                    var errorCodeEndIndex = c.responseText.indexOf(',');
                                                    var errorCode = c.responseText.substring(errorCodeStartIndex, errorCodeEndIndex);
                                                    var errorMsg = 'Unknown error ' + errorCode + '.';
                                                    for (var i = 0; i < errorList.length; i++) {
                                                        if (errorList[i].Code.toString().toLowerCase() == errorCode.toLowerCase()) {
                                                            errorMsg = errorList[i].Message;
                                                        }
                                                    }
                                                    updateFinishedFileStatus(errorMsg, (fileIndex - 1), false);
                                                }
                                            });
                                        }

                                        function updateListItemMetadata(listName, itemId, fileIndex, fileData) {
                                            var context = new SP.ClientContext(targetSiteUrl);
                                            //var context = SP.ClientContext.get_current();
                                            var targetWeb = context.get_web();
                                            context.load(targetWeb);
                                            context.executeQueryAsync(updateMetadata, failure);
                                            function updateMetadata() {
                                                var library = targetWeb.get_lists().getByTitle(listName);
                                                var item = library.getItemById(itemId);
                                                item.set_item("EFeFileDocumentGroup", fileData.DocGroup);
                                                item.set_item("EFeFileDocumentType", fileData.DocType);
                                                item.set_item("EFDocumentStatus", fileData.DocStatus);
                                                item.set_item("EFDocumentTitle", fileData.Name);
                                                item.update();
                                                context.load(item);
                                                //context.load(term);
                                                context.executeQueryAsync(success1, fail);

                                                function success1() {

                                                    console.timeEnd("update file metadata");
                                                    var polNumber = WBgetQueryStringParameter("PolicyNumber");
                                                    var Url = _spPageContextInfo.webAbsoluteUrl + '/Pages/PolicyDetails.aspx' + location.search;
                                                    //Url += '#DefaultUpload=' + encodeURIComponent('{"r":[{"n":"EFDocumentGroupOWSTAXID","t":["\\"' + fileData.DocGroup + '\\""],"o":[{"d":1,"p":"ModifiedOWSDATE"}],"m":{"\\"' + fileData.DocGroup + '\\"":"' + fileData.DocGroup + '"}}' + ',{"n":"EFPolicyNumberOWSTEXT","t":["\\"' + polNumber + '\\""]}]}');
                                                    document.cookie = "DocumentGroup=" + fileData.DocGroup + ";path=/";
                                                    updateFinishedFileStatus('File ' + (fileIndex) + ' of ' + files.length + ' uploaded successfully.', (fileIndex - 1), true);
                                                    if (fileIndex == files.length) {
                                                        function closePopup() {
                                                            //SP.UI.ModalDialog.commonModalDialogClose(1, 1);
                                                            window.location.href = Url;
                                                            window.location.reload(true);
                                                        }

                                                        //wait for 2 second before the pop up fades out
                                                        $('.ms-dlgContent').fadeOut();
                                                        setTimeout(function () { closePopup() }, 2000);
                                                    }
                                                    //context.executeQueryAsync(success2, fail);
                                                }

                                                function fail(sender, args) {
                                                    console.log("Call failed. Error: " +
                                                        args.get_message());

                                                    var errorMessage = args.get_message();
                                                    if (errorMessage.toLowerCase().indexOf('the specified name is already in use.') != -1)
                                                        errorMessage = 'Duplicate business record.';
                                                    else
                                                        // errorMessage = 'Unknown error.';
                                                        updateFinishedFileStatus(errorMessage, (fileIndex - 1), false);
                                                }
                                            }
                                        }
                                    }


                                    function checkDocumentExists(fileName) {

                                        var documentUri = targetSiteUrl + "/" + targetLibrary + "/";

                                        if (targetTermSet == 'Account Principal') {
                                            documentUri += curAccountID + "/";
                                        }
                                        if (targetTermSet.toLowerCase() == 'cbr-bond') {
                                            documentUri += curPrincipalID + "/";
                                        }
                                        documentUri += encodeURIComponent(curDocSetName) + "/";
                                        documentUri += fileName;

                                        var url = targetSiteUrl + "/_api/web/getfilebyserverrelativeurl('" + documentUri + "')/ListItemAllFields";


                                        var deferred = $.ajax({
                                            url: url,
                                            method: "GET",
                                            headers: {
                                                "Accept": "application/json;odata=verbose",
                                                "content-type": "application/json;odata=verbose",
                                                "X-RequestDigest": $("#__REQUESTDIGEST").val()
                                            }
                                        });
                                        return deferred.promise();
                                    }

                                    /***** POPUP WINDOW HELPER FUNCTIONS ******/

                                    // Get the icon to match a file type.  
                                    function getFileIcon(type) {
                                        type = type.toLowerCase();
                                        if (type == "docx" || type == "doc" || type == "docm" || type == "dot" || type == "dotx")
                                            return 'icdocx.png';
                                        else if (type == "xlsx" || type == "xls" || type == "xlsb" || type == "xlsm")
                                            return 'icxlsx.png';
                                        else if (type == "ppt" || type == "pptx" || type == "pptm")
                                            return 'icpptx.png';
                                        else if (type == "one")
                                            return 'icone.png';
                                        else if (type == "pdf")
                                            return 'icpdf.png';
                                        else if (type == "image" || type == "tiff" || type == "tif" || type == "jpg" || type == "jpeg" || type == "bmp" || type == "png")
                                            return 'icpng.gif';
                                        else if (type == "text" || type == 'txt' || type == 'plain' || type == 'js' || type == 'javascript' || type == 'css')
                                            return 'ictxt.gif';
                                        else if (type == "zip")
                                            return 'iczip.gif';
                                        else
                                            return 'icgen.gif';
                                    }

                                    // Initialize the button functionality when the form opens.
                                    function initializeButtons() {
                                        var nextButton = iframe.contents().find('#gs-ecm-next-button');
                                        var finishButton = iframe.contents().find('#gs-ecm-finish-button');
                                        var closeButton = iframe.contents().find('#gs-ecm-close-button');
                                        var exitButton = $('#dlgTitleBtns a');
                                        var returnData = {};
                                        $(exitButton).attr('href', '');

                                        // Set default actions for buttons.
                                        finishButton.click(uploadFunction);
                                        closeButton.click(function () {
                                            returnData.fileCount = fileCounter;
                                            returnData.elementID = $(uploadBox).attr('id');
                                            iframe = $(document); // Prevent script from trying to modify an empty reference once iframe is closed. 
                                            SP.UI.ModalDialog.commonModalDialogClose(0, returnData);
                                        });

                                        exitButton.click(function () {
                                            returnData.fileCount = fileCounter;
                                            returnData.elementID = $(uploadBox).attr('id');
                                            iframe = $(document); // Prevent script from trying to modify an empty reference once iframe is closed.\
                                            SP.UI.ModalDialog.commonModalDialogClose(0, returnData);
                                        });

                                        // Modify buttons for single document upload.
                                        if (files.length == 1) {
                                            nextButton.hide();
                                            closeButton.text('Cancel');
                                            finishButton.text('Upload');
                                            finishButton.removeAttr('disabled');
                                            iframe.contents().find('#gs-ecm-left-upload-popup-panel').css("display", "none");
                                        }
                                        else {
                                            nextButton.click(function () {
                                                var button = iframe.contents().find('#' + this.id);
                                                startNextUpload(button);
                                            });
                                        }
                                    }

                                    function startNextUpload(button) {
                                        console.time("upload file");
                                        button.addClass('gs-ecm-button-disabled');
                                        button.unbind('click');
                                        var fileData = getFormData();
                                        if (validFormData(fileData)) {
                                            iframe.contents().find('#gs-ecm-file-name-' + fileCounter).text(fileData.Name);
                                            uploadFile(files[fileCounter], fileData.Name + fileData.Extension, fileData, fileCounter);
                                            fileCounter++;
                                            if (fileCounter < files.length) {
                                                resetForm(fileCounter);
                                            }
                                            if (fileCounter == files.length) {
                                                iframe.contents().find('#gs-ecm-close-button').html('Close');
                                            }
                                            if (fileCounter < (files.length - 1)) {
                                                iframe.contents().find('#gs-ecm-next-button').removeClass('gs-ecm-button-disabled');
                                                iframe.contents().find('#gs-ecm-next-button').click(uploadFunction);
                                            }
                                        }
                                        else {
                                            button.removeClass('gs-ecm-button-disabled');
                                            button.click(uploadFunction);
                                        }
                                    }

                                    // Clear the form and set default values to match the current file.
                                    function resetForm(fileIndex) {

                                        // Manage button functionality.
                                        if (fileIndex == (files.length - 1)) {
                                            iframe.contents().find('#gs-ecm-next-button').unbind('click');
                                            iframe.contents().find('#gs-ecm-next-button').addClass('gs-ecm-button-disabled');
                                            iframe.contents().find('#gs-ecm-finish-button').removeAttr('disabled');
                                            iframe.contents().find('#gs-ecm-finish-button').removeClass('gs-ecm-button-disabled');
                                        }
                                        if (fileIndex > 0) {
                                            iframe.contents().find('#gs-ecm-file-num-' + (fileIndex - 1)).removeClass('gs-ecm-file-name-current');
                                        }
                                        iframe.contents().find('#gs-ecm-file-num-' + fileIndex).addClass('gs-ecm-file-name-current');


                                        iframe.contents().find('#ctl00_PlaceHolderMain_ctl03editableRegion').html('');

                                        iframe.contents().find('#ctl00_PlaceHolderMain_wbDocumentSecondClassPicker input').val('');


                                        // Set default values.
                                        var fileExtension = '';
                                        var fileName = files[fileIndex].name;
                                        if (fileName.lastIndexOf('.') != -1) {
                                            fileExtension = fileName.substr(fileName.lastIndexOf('.'));
                                            fileName = files[fileIndex].name.substring(0, fileName.lastIndexOf('.'));
                                        }

                                        var termTitle = $('#' + divid).attr('Title');
                                        iframe.contents().find('#gs-ecm-document-name-field').val(fileName);
                                        iframe.contents().find('#gs-ecm-document-extension-field').val(fileExtension);
                                        iframe.contents().find('#ctl00_PlaceHolderMain_ctl01editableRegion').text(termTitle);

                                        var listName = 'efileConfigList';
                                        var _docGroups = "";
                                        var _docTypes = "";
                                        var siteUrl = document.URL.toLowerCase().split('/pages/')[0];
                                        var _docGroupKey = "DocumentGroups";
                                        var _docTypeKey = "DocumentTypes";
                                        iframe.contents().find('#lm-document-status-field').find('option:first').attr('selected', 'selected');
                                        iframe.contents().find('#lm-document-group-field').empty();
                                        iframe.contents().find('#lm-document-type-field').empty();

                                        $.ajax({
                                            url: siteUrl + "/_api/web/lists/getbytitle('" + listName + "')/items?$filter=(Title eq '" + _docGroupKey + "') or (Title eq '" + _docTypeKey + "')&$select=Value",
                                            type: "GET",
                                            async: false,
                                            cache: false,
                                            headers: {
                                                "Accept": "application/json;odata=verbose",
                                                "X-RequestDigest": $("#__REQUESTDIGEST").val()
                                            },
                                            success: function (data) {
                                                _docGroups = data.d.results[0].Value;
                                                _docGroups = _docGroups.split(',');
                                                for (i = 0; i < _docGroups.length; i++) {
                                                    iframe.contents().find('#lm-document-group-field').append($('<option>', {
                                                        value: _docGroups[i],
                                                        text: _docGroups[i]
                                                    }));
                                                }
                                                iframe.contents().find('#lm-document-group-field').val(termTitle);

                                                _docTypes = data.d.results[1].Value;
                                                _docTypes = _docTypes.split(',');
                                                for (i = 0; i < _docTypes.length; i++) {
                                                    iframe.contents().find('#lm-document-type-field').append($('<option>', {
                                                        value: _docTypes[i],
                                                        text: _docTypes[i]
                                                    }));
                                                }
                                            },
                                            error: function (data) {
                                                console.log(JSON.stringify(data));
                                            }
                                        });

                                    }


                                    // Capture the user's input from the form.
                                    function getFormData() {
                                        var fileName = iframe.contents().find('#gs-ecm-document-name-field').val().replace(/'/g, "");
                                        var fileExtension = iframe.contents().find('#gs-ecm-document-extension-field').val();
                                        var docStatus = iframe.contents().find('#lm-document-status-field').val();
                                        var docGroup = iframe.contents().find('#lm-document-group-field').val();
                                        var docType = iframe.contents().find('#lm-document-type-field').val();
                                        var formData = new FileMetadata(fileName, fileExtension, docStatus, docGroup, docType);
                                        return formData;
                                    }

                                    // Add the correct status and icon to a document name in the left popup panel depending on 
                                    // whether or not it was successfully uploaded.
                                    function updateFinishedFileStatus(message, fileIndex, succeeded) {

                                        var multiFileStatus = iframe.contents().find('#gs-ecm-file-num-' + fileIndex + ' .gs-ecm-file-meta-status');
                                        var singleFileStatus = iframe.contents().find('#gs-ecm-single-doc-status .gs-ecm-file-meta-status');

                                        iframe.contents().find('#gs-ecm-upload-status-file-' + fileIndex).text(message);
                                        multiFileStatus.removeClass('gs-ecm-file-meta-status-loading');
                                        singleFileStatus.removeClass('gs-ecm-file-meta-status-loading');
                                        multiFileStatus.removeClass('gs-ecm-file-meta-status-failed');
                                        singleFileStatus.removeClass('gs-ecm-file-meta-status-failed');

                                        if (succeeded) {
                                            multiFileStatus.addClass('gs-ecm-file-meta-status-complete');
                                            singleFileStatus.addClass('gs-ecm-file-meta-status-complete');

                                        }
                                        else {
                                            multiFileStatus.addClass('gs-ecm-file-meta-status-failed');
                                            singleFileStatus.addClass('gs-ecm-file-meta-status-failed');
                                        }
                                    }

                                    // Default failure function when any executeQueryAsync call fails. 
                                    function failure(sender, args) {
                                        var errorMessage = args.get_message();
                                        console.log(errorMessage);
                                        ULSOnError(args.get_message(), document.location.href, 0);
                                    }
                                });
                            }
                            else {
                                alert('Sorry, you don\'t have permission to drag files into that folder.');
                            }
                        }
                        catch (e) {
                        }
                    }, function () {
                        console.log("failed");
                    });
                }

            };

            /***** OBJECT DEFINITIONS & ADDITIONAL HELPER FUNCTIONS *****/

            // Function to create an error object for lookup when a file upload fails.
            function Error(code, message) {
                this.Code = code;
                this.Message = message;
                ULSOnError(message, document.location.href, 0);
            }

            // Function to capture metadata from the form and apply it to file.
            function FileMetadata(name, extension, docStatus, docGroup, docType) {
                this.Name = name;
                this.Extension = extension;
                this.DocStatus = docStatus;
                //  this.ReceiptDate = receiptDate;
                this.DocGroup = docGroup;
                //this.BusinessDate = busDate;
                this.DocType = docType;
                // this.Keywords = keywords;
                //  this.NPPI = nppi;
                // this.Comments = comments;
            }

            // Apply jquery effec to highlight folder when users hover over them.
            function highlightDragArea() {
                $(uploadBox).stop(true, true).addClass(dragClass);
                $(uploadBox).switchClass(dragClass, "uploader");
            }




            /***** BIND CUSTOM DRAGGING ACTIONS TO THE CURRENT DIV *****/
            var uploadBox = $("#" + divid);
            uploadBox.bind({
                dragenter: this.uploadDragEnter,
                dragexit: this.uploadDragExit,
                dragover: this.uploadDragOver,
                drop: this.uploadDrop
            });

            if (divid.toLowerCase().indexOf("search") > -1) { isSearchBox = "search"; }
        };
        return {
            create: uploader,
            loadingFolders: loadingFolders,
        };
    }
    catch (err) {
        ULSOnError(err, document.location.href, 0);
    }
}();
