﻿/* KNOWN ISSUES: 

>>> [LOW] Error messages should be read from a SharePoint list rather than hardcoded as strings.
>>> [LOW] Folder URL is not set for bond entity types.
 
>>> [MEDIUM] 'documentSetTotals' function may cause performance issues. */

var Liberty = window.Liberty || {};
Liberty.DragDropTaxonomy = function () {

    // Main function to render the drag and drop folders.
    var load = function () {

        /***** GATHER INITIAL DATA *****/

        // Helper variables.
        var url = document.location.href;
        var endID = url.length;
        if (url.toLowerCase().indexOf('&') != -1) endID = url.toLowerCase().indexOf('&');

        // Term store variables.
        var targetTermGroup = 'Workbench';
        var targetTermSet = url.substring((url.toLowerCase().indexOf('pages/') + 6), url.toLowerCase().indexOf('details.aspx'));
        targetTermSet = targetTermSet.charAt(0).toUpperCase() + targetTermSet.slice(1).toLowerCase();

        // Entity variables.
        var curID = getParams(targetTermSet.toLowerCase() + 'id');
        var curName = $('#wb-breadcrumbRow span:last-child').text().trim();
        var curAccountID = '';
        var curPrincipalID = '';
        var curAccountName = '';
        var curIDField = targetTermSet;
        var curSearchIDField = 'wb' + targetTermSet + 'ID';
        //var curSearchIDField = targetTermSet + 'IDOWSTEXT';
        var curTaxonomyField = targetTermSet;
        var curDocSetName = curID;

        // Array to store target library paths.
        var targetLibraryPaths = new Array();

        // Fix variables for 'Principal' entity types.
        if (targetTermSet.toLowerCase() == 'principal') {
            if (getParams('accountid') != '') {
                targetTermSet = 'Account Principal';
                curSearchIDField = 'wbPrincipalID';
                curTaxonomyField = 'Account_x0020_Principal';
                curAccountID = getParams('accountid');
                curAccountName = $('#wb-breadcrumbRow span:nth-child(3)').text().trim();
            }
            else {
                targetTermSet = 'Transactional Principal';
                curIDField = 'TransactionalPrincipal';
                curSearchIDField = 'wbPrincipalID';
                curTaxonomyField = 'Transactional_x0020_Principal';
            }
        }

        // Fix variables for 'CBR-Bond' entity types.     
        if (targetTermSet.toLowerCase() == 'bond') {
            targetTermSet = 'CBR-Bond';
            curSearchIDField = 'wbBondID';
            curTaxonomyField = 'CBR_x002d_Bond';
        }

		// Fix variables for 'CBR-Bond' entity types.     
        if (targetTermSet.toLowerCase() == 'bondrequest') {
            targetTermSet = 'CBR-Bond';
            curSearchIDField = 'wbCBRID';
            curTaxonomyField = 'CBR_x002d_Bond';
        }

        getTargetPaths();

        // Get the target paths for the document sets associated with the entity.		
        function getTargetPaths() {

            // Create new client context and keyword query variables. 
            var ctx = SP.ClientContext.get_current();
            var kwQuery = new Microsoft.SharePoint.Client.Search.Query.KeywordQuery(ctx);

            // Set query parameters.
            kwQuery.set_hiddenConstraints("contenttype:\"" + targetTermSet + " Document Set\"");
            kwQuery.get_selectProperties().add('ContentType');
            kwQuery.get_selectProperties().add(curSearchIDField);

            // Capture additional ID property if entity is type CBR-Bond.
            if (targetTermSet.toLowerCase() == 'cbr-bond') {
                kwQuery.get_selectProperties().add('wbCBRID');
                kwQuery.get_selectProperties().add('wbPrincipalID');
            }
            kwQuery.set_queryText(curSearchIDField + ':' + curDocSetName);
            
           // console.log(curSearchIDField + ':' + curDocSetName + " -- DocType: " + targetTermSet );

            // Execute search query.
            var searchExecutor = new Microsoft.SharePoint.Client.Search.Query.SearchExecutor(ctx);
            results = searchExecutor.executeQuery(kwQuery);
            ctx.executeQueryAsync(onQuerySuccess, displayErrorMessage);
        }

        // Add all target library paths to array.
        function onQuerySuccess() {
            var returnedResult = results.m_value.ResultTables[0].ResultRows;         

            // If no target library path was found, let the user know the webpart is unavailable.
            if (returnedResult.length == 0) {
                $('#loading').replaceWith('<div "wb-drag-drop-fail">User does not have permission to view this ' + targetTermSet.toLowerCase() + 
	                					  ' or a document set for this ' +  targetTermSet.toLowerCase() +  ' does not exist. Please try again later.' +
	                					  'If this message persists please contact your system administrator.  </div>');
        	}
            else {
                for (var i = 0; i < returnedResult.length; i++) {
                    targetLibraryPaths.push(returnedResult[i].Path);
                }

                // Modify the target document set name if the entity is type CBR-Bond.
                if (targetLibraryPaths.length == 1 && targetLibraryPaths[0].toLowerCase().indexOf('/cb/') != -1) {
                	var libraryPath = targetLibraryPaths[0].toLowerCase();
                	libraryPath = libraryPath.substr(libraryPath.indexOf('/cb/') + 4);
					curPrincipalID = libraryPath.substring(0, libraryPath.indexOf('/'));
                    if (targetLibraryPaths[0].toLowerCase().indexOf('bond') != -1)
                        curDocSetName = 'bond' + returnedResult[0].wbBondID;
                    else if (targetLibraryPaths[0].toLowerCase().indexOf('cbr') != -1)
                        curDocSetName = 'cbr' + returnedResult[0].wbCBRID;
                }

                // Once target library paths are captured, check for empty variables.
                if (!checkForValues())
                    displayErrorMessage();
                else getCurrentUser();
            }
        }

        // Load the current user to set security trimming on folders.        
        function getCurrentUser() {

            // Set variables.       
            var ctx = new SP.ClientContext.get_current();
            var web = ctx.get_web();
            var currentUser = web.get_currentUser();
            var userGroupTitle = '';
            var errorMessage = 'Failed to load user data. Please contact your system administrator.';

            // Load current user.
            ctx.load(currentUser);
            ctx.executeQueryAsync(successUser, failUser);

            function successUser() {
                var userGroups = currentUser.get_groups();
                ctx.load(userGroups);
                ctx.executeQueryAsync(successUserGroups, failUserGroups);

                // Get the user's group membership.
                function successUserGroups() {

                    // Check if user is in more than one group.
                    //if (userGroups.get_count() > 1)
                        //displayWarningMessage(errorMessage);
                    var userGroupsEnum = userGroups.getEnumerator();

                    // Check if user is in at least one group.
                    if (userGroupsEnum.moveNext()) {
                        var curGroup = userGroupsEnum.get_current().get_title();
                        userGroupTitle = curGroup.substr(curGroup.search(/\d\d\d/) + 4);                                                            
                    }
                    else { displayWarningMessage(errorMessage); }

                    ko.applyBindings(new TaxonomyViewModel(userGroupTitle), $('#taxDD #groups')[0]);
                }

                // Notify user if their personal information could not be loaded.
                function failUserGroups(sender, args) {
                    displayWarningMessage(errorMessage);
                    ko.applyBindings(new TaxonomyViewModel(userGroupTitle), $('#taxDD #groups')[0]);
                }
            }

            // Notify the user if their personal information could not be loaded.
            function failUser() {
                displayWarningMessage(errorMessage);
                ko.applyBindings(new TaxonomyViewModel(userGroupTitle), $('#taxDD #groups')[0]);
            }
        }

        /***** CREATE VIEW MODEL BASED ON TERM STORE STRUCTURE *****/

        // Create a KO view model to dynamically load the folders.
        function TaxonomyViewModel(userGroup) {

            // Set view model variables.
            var self = this;
            var groupsDiv = $('#wb-document-container');
            self.groups = ko.observableArray([]);
            var taxonomyTagsArray = new Array();

            // Set term store variables.
            var clientContext = SP.ClientContext.get_current();
            var session = SP.Taxonomy.TaxonomySession.getTaxonomySession(clientContext);
            
            var termStores = session.get_termStores();
            var termStore = termStores.getByName(Liberty.Utilities.getTermStoreName());
  			
            // Load the term store.
            clientContext.load(termStore);
            clientContext.executeQueryAsync(successDefaultTermStore, failureDefaultTermStore);
            var LM_Terms;

            // Get all the term store groups.
            function successDefaultTermStore() {
                var groups = termStore.get_groups();
                clientContext.load(groups);

                // Find the term store group that matches the targetTermGroup variable.
                clientContext.executeQueryAsync(
                    function () {
                        var groupsEnum = groups.getEnumerator();
                        while (groupsEnum.moveNext()) {
                            var currentGroup = groupsEnum.get_current();
                            var groupName = currentGroup.get_name();
                            if (groupName.toLowerCase() === targetTermGroup.toLowerCase()) {
                                LM_Terms = currentGroup.get_termSets();
                                clientContext.load(LM_Terms);
                                clientContext.executeQueryAsync(successTermSets, failureTermSets);
                            }
                        }
                    },
                    function () {
                        displayErrorMessage();
                    });

                var parents;
                var terms;
                var theTerms;
                var group;

                // Load all the term sets from the term group.
                function successTermSets() {
                    var theTerms = LM_Terms.getEnumerator();
                    while (theTerms.moveNext()) {
                        var currentTerm = theTerms.get_current();
                        if (currentTerm.get_name().toLowerCase() === targetTermSet.toLowerCase()) {
                            parents = currentTerm.get_terms();
                            clientContext.load(parents);
                            clientContext.executeQueryAsync(successTermParents, failureTermParents);
                        }
                    }
                }
                function failureTermSets() {
                    displayErrorMessage();
                }

                var parentName = '';
                var parentGUID = '';
                var parentWriteUsers = '';
                var parentReadUsers = '';
                var parentTargetLibrary = '';

                // Get the next parent term, create a new 'Group' item to represent it,
                // and check for it's child terms.
                function successTermParents() {
                    if (theTerms == null)
                        theTerms = parents.getEnumerator();
                    var done = !theTerms.moveNext();
                    if (!done) {
                        var currentTerm = theTerms.get_current();
                        terms = currentTerm.get_terms();
                        group = new Group(currentTerm.get_id(), currentTerm.get_name(), [], false);
                        parentName = currentTerm.get_name();
                        parentGUID = currentTerm.get_id();
                        if (currentTerm.get_customProperties().write)
                            parentWriteUsers = currentTerm.get_customProperties().write;
                        if (currentTerm.get_customProperties().read)
                            parentReadUsers = currentTerm.get_customProperties().read;
                        if (currentTerm.get_customProperties().library)
                            parentTargetLibrary = currentTerm.get_customProperties().library;
                        clientContext.load(terms);
                        clientContext.executeQueryAsync(successTerms, failureTerms);
                    }
                    else {

                        // Once all the folders have been created, display the web part.
                        $('#loading').hide();
                        $(".wb-document-section").hide();
                        $('.wb-drag-drop-fail').css("display", "inline");
                        $('#wb-document-container').show('slow');

                        // Count the document tags.
                        var documentTagCounts = Liberty.DragDropTaxonomy.documentSetTotals(curTaxonomyField, taxonomyTagsArray, targetLibraryPaths);
                    }
                }
                function failureTermParents() {
                    displayErrorMessage();
                }

                // Iterate through all the child terms and create a 'Folder' item to represent it.
                function successTerms() {
                    try {
                        if (terms.get_count() == 0) {
                            group.isLeaf(true);
                            var allowed = '';
                            //var allowed = 'wb-document-item-readonly';
                            if (checkUserPermissions(parentWriteUsers, userGroup) && (parentWriteUsers != '')) {
                                allowed = 'wb-document-item';
                                
                            }
                            else if (checkUserPermissions(parentReadUsers, userGroup) && (parentReadUsers != ''))
                                allowed = 'wb-document-item-readonly';
                            if (allowed != '') {
                                group.Folders().push(new Folder(parentGUID, parentName, parentName, parentTargetLibrary, allowed));
                                taxonomyTagsArray.push(new folderCountItem(parentGUID, 0));
                            }
                        }
                        else {
                            var theTerms = terms.getEnumerator();
                            while (theTerms.moveNext()) {
                                var currentTerm = theTerms.get_current();
                                var dragAllowed = '';
                                var curTargetLibrary = '';
                                if (currentTerm.get_customProperties().write) {
                                    if (checkUserPermissions(currentTerm.get_customProperties().write, userGroup))
                                        dragAllowed = 'wb-document-item';
                                }
                                if (currentTerm.get_customProperties().read) {
                                    if (checkUserPermissions(currentTerm.get_customProperties().read, userGroup) && dragAllowed == '')
                                        dragAllowed = 'wb-document-item-readonly';
                                }
                                if (currentTerm.get_customProperties().library)
                                    curTargetLibrary = currentTerm.get_customProperties().library;
                                if (dragAllowed != '') {
                                    taxonomyTagsArray.push(new folderCountItem(currentTerm.get_id(), 0));
                                    group.Folders().push(new Folder(currentTerm.get_id(), currentTerm.get_name(), parentName, curTargetLibrary, dragAllowed));
                                }
                            }
                        }
                        if (group.Folders().length > 0)
                            self.groups.push(group);
                        successTermParents();
                    } catch (e) { };
                }
                function failureTerms() {
                    displayErrorMessage();
                }
            }
            function failureDefaultTermStore(sender, args) {
                displayErrorMessage();
            }
        }

        /***** HELPER FUNCTIONS *****/

        // Function to pull parameters from page URL.
        function getParams(name) {
            name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
            var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search.toLowerCase());
            return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        }

        // Function to add a warning message to the web part when something fails to load correctly.
        function displayWarningMessage(message) {
            $('#loading').after('<div class="wb-drag-drop-fail" style="display:none">' + message + '</div>');
        }

        // Function to replace the web part with an error message when the web part cannot be loaded.
        function displayErrorMessage() {
            $('#loading').replaceWith('<div "wb-drag-drop-fail">This app part is currently unavailable. Please try again later.' +
        							  ' If this message persists please contact your system administrator. </div>');
        }

        // Check for values in required variables.
        function checkForValues() {
            if (targetTermGroup == '' || targetTermSet == '' || curID == '' || curIDField == '' ||
				curTaxonomyField == '' || curDocSetName == '' || targetLibraryPaths.length < 1) {
                return false;
            }
            else return true;
        }

        // Function to check whether or not the current user is in any security groups that  
        // is allowed to drag files to a certain folder.
        function checkUserPermissions(allowedUsersString, curUserGroup) {
           	var allowedGroups = createGroupArray(allowedUsersString.toLowerCase());
            
            return (allowedGroups.indexOf(curUserGroup) > -1);
        }
        
        // Remove leading dash from each element to aid in comparison with user groups
        function createGroupArray(splitString) {
        	var replaceChars = {'-': '', ',-': ','};
        	splitString = splitString.replace(/ +/g, '').replace(/^-|,-+/g, function(match) {return replaceChars[match];})
        	return splitString.split(",");
        }

        /***** OBJECT DEFINITIONS *****/

        // Function to create a folder count item to be used to track document tags.
        function folderCountItem(GUID, count) {
            this.GUID = GUID;
            this.Count = count;
        }

        // Function to create a new group object to represent a folder heading.
        function Group(id, title, folders, isLeaf) {
            this.ID = ko.observable('G-' + id);
            this.Title = ko.observable(title);
            this.Folders = ko.observableArray(folders);
            this.isLeaf = ko.observable(isLeaf);
        }

        // Function to create a folder object to represent a draggable folder region.
        function Folder(id, title, parentTitle, targetLibrary, dragAllowed) {
            this.ID = ko.observable(id);
            this.Title = ko.observable(title);
            this.TargetLibrary = ko.observable(targetLibrary);
            this.DragAllowed = ko.observable(dragAllowed);
            var page = Liberty.Utilities.getPage();
            page = page.replace("Details","");
            var URLParams=$(".wb-documentspage-link").attr("href");
            URLParams = URLParams.substring(URLParams.lastIndexOf("?")+1,URLParams.lastIndexOf("#"));
            var entityType = page.replace('BondRequest','CBR');
            var querySubstring = title;
            if (title.toLowerCase() != parentTitle.toLowerCase())
                querySubstring = parentTitle + ':' + title;
            this.Url = _spPageContextInfo.webAbsoluteUrl + '/Pages/' + page+ 'Documents.aspx?' + URLParams;
            this.Url += '#Default=' + encodeURIComponent('{"r":[{"n":"wbPrimaryClassLabel","t":["\\"' + querySubstring + '\\""],"o":[{"d":1,"p":"ModifiedOWSDATE"}],"m":{"\\"' + querySubstring + '\\"":"' + querySubstring + '"}}'+
            ',{"n":"wb'+entityType+'ID","t":["\\"'+curID+'\\""]}]}');
        }

        /***** KNOCKOUT BINDINGS *****/

        // Custom KO binding to make each folder a draggable region for uploading.
        ko.bindingHandlers.setUploader = {
            update: function (element) {
                var uploadDiv = new Liberty.DragDropUploader.create($(element).attr("id"), targetTermSet, targetLibraryPaths, curID, curIDField, curTaxonomyField, curDocSetName, curAccountID, curPrincipalID);
            }
        }

        // Custom KO binding to apply an accordion effect to each folder heading.
        ko.bindingHandlers.setAccordion = {
            init: function (element) {
                var panel = $(element).next();
                $(element).click(function () {
                    $(panel).slideToggle('slow');
                    $(element).toggleClass('selected');
                });
            }
        }
    }

    /***** GET DOCUMENT TAG TOTALS *****/

    // Iterate through all documents associated with an entity and tally their taxonomy tags.
    var documentSetTotals = function (curTaxonomyField, taxonomyTagsArray, targetLibraryPaths) {
    
    	var deferredFolderArray = new Array();
    	var folders = new Array();
    	var targetSite = '';
    	
    	// Loop through each folder grouping folders on the same server into 1 load
    	for (var i = 0; i < targetLibraryPaths.length; i++) {
            var curPath = targetLibraryPaths[i].toLowerCase();
            curPath = curPath.substring(curPath.indexOf('sites'), curPath.length);
            var pathDetails = curPath.split('/');
            var nextTargetSite = '/' + pathDetails[0] + '/' + pathDetails[1];
            if (targetSite == '')
            	targetSite = nextTargetSite;
            if (targetSite == nextTargetSite) {
    			folders.push('/' + curPath);
    		}
    		else {
    			deferredFolderArray.push(processFolders(targetSite, folders));
    			folders = new Array();
				targetSite = '';
    		}
    	}
    	if (folders.length > 0)
    		deferredFolderArray.push(processFolders(targetSite, folders));

		$.when.apply($, deferredFolderArray).done(
	    	function () {
	        	for (var i = 0; i < taxonomyTagsArray.length; i++) {
                	$('#' + taxonomyTagsArray[i].GUID.toString() + ' .wb-document-count').html(taxonomyTagsArray[i].Count);
            	}
	        }
	    );
		
		function processFolders(targetSite, folders) {
        
        	var deferredA = $.Deferred();
        	var deferredItemArray = new Array();
			var folderFiles = new Array();
			
            // Get the list items and load them.
            var clientContext = new SP.ClientContext(targetSite);
            
            for (var i = 0; i < folders.length; i++) {
            	var xFolder =  clientContext.get_web().getFolderByServerRelativeUrl(folders[i]);
            	folderFiles[i] = xFolder.get_files();
    			clientContext.load(folderFiles[i]);
    		}

            clientContext.executeQueryAsync( 
            	// Loop through each folders files converting to items in groups of 50
            	function () {
            		var itemArray = new Array();
	            	var count = 0;
	            	var totalCount = 0;
            		for (var j = 0; j < folderFiles.length; j++) {
						var fileCount = folderFiles[j].get_count();
						totalCount += fileCount;
						if (fileCount > 0) {
							var enumerator =  folderFiles[j].getEnumerator();
 							while (enumerator.moveNext()) {
	            				itemArray.push(enumerator.get_current().get_listItemAllFields());
	            				if (++count == 50) {
	            					deferredItemArray.push(updateTotals(clientContext, itemArray));
	            					count = 0;
	            					itemArray = new Array();
								}		            		
	            			}	            			
	            		}	            		
					}
					if (totalCount == 0) {
						deferredA.resolve();
						return;
					}
						
					if (count > 0)
	            		deferredItemArray.push(updateTotals(clientContext, itemArray));

	           		$.when.apply($, deferredItemArray).done(
	    				function () {
	        				deferredA.resolve();
	       				}
	    			);
	            },
	          	function (sender, args) {
	                for (var i = 0; i < taxonomyTagsArray.length; i++)
	                    $('#' + taxonomyTagsArray[i].GUID + ' .wb-document-count').html('0');
	                deferredA.reject();
	            }
	        );
	        
	        return deferredA.promise();
        
        	function updateTotals(currentContext, itemArray) {
        		var deferred = $.Deferred();
 				
				for (var i = 0; i < itemArray.length; i++) {
    				currentContext.load(itemArray[i]);
    			}
		
 				currentContext.executeQueryAsync(
     				function () {
     					for (var i = 0; i < itemArray.length; i++) {
     						var curName = itemArray[i].get_item('FileLeafRef');
	                		var curMetadata = itemArray[i].get_item(curTaxonomyField + '_x0020_Primary_x0020_Classification');
	               			if (curMetadata != null) {
	                    		var curMetadataGUID = curMetadata.get_termGuid().toString().toLowerCase();
	                    		for (var l = 0; l < taxonomyTagsArray.length; l++) {
	                        		if (curMetadataGUID == taxonomyTagsArray[l].GUID.toString().toLowerCase()) {
	                            		taxonomyTagsArray[l].Count += 1;
	                           			break;
	                        		}
	                    		}
	                		}
	                	}
	                	deferred.resolve();
     				},
     				function (sender, args) {
     					deferred.reject();
     				}
     			);

 				return deferred.promise();
       		}
        }
    }

    return {
        load: load,
        documentSetTotals: documentSetTotals
    };
}();