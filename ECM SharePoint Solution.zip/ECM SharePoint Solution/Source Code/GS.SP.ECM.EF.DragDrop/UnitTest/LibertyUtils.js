﻿"use strict"

var Liberty = window.Liberty || {};

//content sources
//central dev/QA
var agencyCS = "int-suretyworkbench_bcs_agencies",
	accountCS = "int-suretyworkbench_bcs_accounts",
	aprincipalCS = "int-suretyworkbench_bcs_ap",
	tprincipalCS = "int-suretyworkbench_bcs_tp",
	bondCS = "int-suretyworkbench_bcs_bonds",
	CBRCS = "int-suretyworkbench_bcs_cbr",
	internalCS = "int-suretyworkbench";
//UAT
/*
var agencyCS = "int-suretyworkbench_bcs_agencies",
	accountCS = "int-suretyworkbench_bcs_accounts",
	aprincipalCS = "int-suretyworkbench_bcs_ap",
	tprincipalCS = "int-suretyworkbench_bcs_tp",
	bondCS = "int-suretyworkbench_bcs_bonds",
	CBRCS = "int-suretyworkbench_bcs_cbr",
	internalCS = "int-suretyworkbench";
*/
//PERF
/*
var agencyCS = "perf-suretyworkbench_bcs_agency",
	accountCS = "perf-suretyworkbench_bcs_account",
	aprincipalCS = "perf-suretyworkbench_bcs_ap",
	tprincipalCS = "perf-suretyworkbench_bcs_tp",
	bondCS = "perf-suretyworkbench_bcs_bond",
	CBRCS = "perf-suretyworkbench_bcs_cbr",
	internalCS = "perf-suretyworkbench";
*/
//PROD
/*
var agencyCS = "int-suretyworkbench_bcs_agencies",
	accountCS = "int-suretyworkbench_bcs_accounts",
	aprincipalCS = "int-suretyworkbench_bcs_ap",
	tprincipalCS = "int-suretyworkbench_bcs_tp",
	bondCS = "int-suretyworkbench_bcs_bonds",
	CBRCS = "int-suretyworkbench_bcs_cbr",
	internalCS = "int-suretyworkbench";
*/


//format date like mm/dd/yyyy
var dateRender = function(a){
	if(!Srch.U.n(a)&&!a.isEmpty&&Date.isInstanceOfType(a.value)){
		var b=Srch.U.$C(String.format("cc_ValueRendererDateFormat_{0}",a.managedPropertyName),false);
		if(Srch.U.w(b))b="ShortDatePattern";
		return SP.Utilities.HttpUtility.htmlEncode(Srch.U.toFormattedDate(a.value,b))
	}
	else return Srch.ValueInfo.Renderers.defaultRenderedValueHtmlEncoded(a)
};

Liberty.Utilities = function () {
	
	var documents = [];
	
	var getTermStoreName = function() {
	
		switch(document.location.hostname.toLowerCase()) {
			case "vddp23g-cf436d0":
				return "Managed Metadata Service";
				break;
			case "int-suretyworkbench.lmig.com":
				return "Connection to: Dev_SIRE_KC_SuretyWorkbench_MMS";
				break;
			case "tst-suretyworkbench.lmig.com":
				return "Connection to: TST_SIRE_KDC_SuretyWorkbench_MMS";
				break;
			case "perf-suretyworkbench.lmig.com":
				return "Connection to: Perf_SIRE_KDC_SuretyWorkbench_MMS";
				break;
			case "suretyworkbench.lmig.com":
				return "Connection to: SIRE_KDC_SuretyWorkbench_MMS";
				break;
			default:
				console.log("Function getTermStoreName in LibertyUtils.js could not find a value for: " + document.location.hostname);
				return "";
		}
	}
	
	var getTaxonomyIDs = function(targetTermSet) {
    	var mainDeferred = $.Deferred();
	    var workbenchTermGroupName = 'Workbench';
	    var systemTermGroupName = 'System';
	    var keywordTermSetName = 'Keywords';
        var termStore, workbenchTermGroup, systemTermGroup; 
		var termStoreID, termSetID, keywordTermsetID;
        
        var clientContext = SP.ClientContext.get_current();
        var session = SP.Taxonomy.TaxonomySession.getTaxonomySession(clientContext);
        
        alert("Function12");
        
        
        getTermStoreByName()
        .then(
            function (result) {
                return getTermGroups();
        }).then(
        	function (result) {
        		getTermSetIDs();
        		var data = {TermStoreID: termStoreID, 
						    TermSetID: termSetID,
						    KeywordTermsetID: keywordTermsetID};
                mainDeferred.resolve(data);
            },
            function (err) {
                mainDeferred.reject(err);
        });

		return mainDeferred.promise();
		        
		function getTermStoreByName() {
			var deferred = $.Deferred();
			
			var termStore = session.get_termStores();
			termStore = termStore.getByName(Liberty.Utilities.getTermStoreName());
			alert(Liberty.Utilities.getTermStoreName());
        	clientContext.load(termStore);
       	 	clientContext.executeQueryAsync(
       	 		function (result) {
       	 			var tsID = termStore.get_id().toString();
                    var re = /-/g;
            		termStoreID = tsID.replace(re, '');
            		
            		deferred.resolve(termStoreID);
                }, 
                function (sender, args) {
                    deferred.reject("Unable to retrieve term store: " + Liberty.Utilities.getTermStoreName());
                });

       	 	
       	 	return deferred.promise();
		}    
		
		function getTermGroups() {
			var deferred = $.Deferred();
			
			var groups = termStore.get_groups();
                clientContext.load(groups);

                // Find the term store group that matches the targetTermGroup variable.
             clientContext.executeQueryAsync(
             	function (result) {
                	var groupsEnum = groups.getEnumerator();
                	while (groupsEnum.moveNext()) {
                        var currentGroup = groupsEnum.get_current();
                        var groupName = currentGroup.get_name();
                        if(targetTermSet != '') {
                        	if (groupName.toLowerCase() === workbenchTermGroupName.toLowerCase()) {
                            	workbenchTermGroup = currentGroup.get_termSets(); 
                            	clientContext.load(workbenchTermGroup);
                        	}
                        }
                        if (groupName.toLowerCase() === systemTermGroupName.toLowerCase()) {
                            systemTermGroup = currentGroup.get_termSets(); 
                            clientContext.load(systemTermGroup);
                        }
                    }
                    clientContext.executeQueryAsync(
						function (result) {
							deferred.resolve(result);
						}, 
                        function (sender, args) {
                    		deferred.reject(args);
                		}
					);
                },
                function (sender, args) {
                    deferred.reject(args);
                }
            );
			return deferred.promise();
		}
       
       
        function getTermSetIDs() {
        
//        alert("GETTERMSET");
               		
        	if(targetTermSet != '') {
				var mainTerms = workbenchTermGroup.getEnumerator();
            	while (mainTerms.moveNext()) {
               		var currentTerm = mainTerms.get_current();

                	if (currentTerm.get_name().toLowerCase() === targetTermSet.toLowerCase()) {
                    	termSetID = currentTerm.get_id().toString();
                    	break;                            
                	}
            	}
            }
            
            var keywordTerms = systemTermGroup.getEnumerator();
            while (keywordTerms.moveNext()) {
                var currentTerm = keywordTerms.get_current();
                if (currentTerm.get_name().toLowerCase() === keywordTermSetName.toLowerCase()) {
                    keywordTermsetID = currentTerm.get_id().toString();
                    break;                            
                }
            }
		}   
    }
	var getContentSource = function(entityType){
		switch(entityType.toLowerCase()){
			case "agency":
				return agencyCS;
				break;
			case "account":
				return accountCS;
				break;
			case "account principal":
				return aprincipalCS;
				break;
			case "transactional principal":
				return tprincipalCS;
				break;
			case "bond":
				return bondCS;
				break;
			case "bond request":
				return CBRCS;
				break;
			case "internal":
				return internalCS;
				break;
			default:
				return "";
		}
	}

    var getUrlValue = function(name) {
        var hash;
        var hashes = window.location.search.replace('?','').split('&');
        for (var i = 0; i < hashes.length; i++) {
            hash = hashes[i].split('=');
            if (hash[0].trim().toLowerCase() == name.trim().toLowerCase())
                return decodeURIComponent(hash[1]);
        }
    }
    
    var getJSONObjectFromURL = function(url){
    	if(url.indexOf("#Default=") != -1){
    		var jsonString = url.substr(url.indexOf("#Default=")+9);
        	if(jsonString != ""){
				return $.parseJSON(jsonString);
			}
		}
		return $.parseJSON('{"r":[]}');
	}

    var getPage = function(){
    	var file,n;
		file = window.location.pathname;
		n = file.lastIndexOf('/');
		if (n >= 0) {
		    file = file.substring(n + 1);
		}
		return file.replace('.aspx','');
	}
	
	var getURLNoJSON = function(){
		var path = window.location.toString();
		if (path.indexOf('#Default=') >= 0)
		{
			path = path.substring(0, path.indexOf('#Default='));
		}
		return path;
	}

    var loadingImage = "<img src='../_layouts/15/images/loadingcirclests16.gif' />";
	
	var formatDetailsDate = function (dateStr){
		if(dateStr != null){
			if(dateStr.indexOf('T') > 0){
				var date = dateStr.substring(0, dateStr.indexOf('T'));
				date = date.split("-");
				return date[1] + "/" + date[2] + "/" + date[0];
			}else{
				return dateStr.split(" ")[0];
			}
		}else{
			return "";
		}
	}

	var formatDate = function(dateStr){
		var date = new Date(dateStr);
		return date.format("M/d/yy h:mm:ss tt");
	}
	
	var formatName = function(nameStr){
		var formattedName = encodeURI(nameStr).toString().replace(/%20/g,"&nbsp;").replace(/%0A/,"_ ");
		return decodeURI(formattedName);
	}

	var formatFileSize = function(fileSize){
		var oneKB = 1024;
		var oneMB = oneKB * oneKB;
		var size = 0;
		if(fileSize > oneMB)
			size = (Math.round((fileSize / oneMB)*10)/10) + " MB";
		else if(fileSize > oneKB)
			size = (Math.round((fileSize / oneKB)*10)/10) + " KB";
		else
			size = fileSize + " B";
			
		return size;
	}
	var extractClass = function(value){
		if (value != ""){
			var splitArr = value.split('|');
			var classStr = splitArr[3];
			return classStr.substring(0,classStr.indexOf(";"));
		}
		else{
			return "";
		}
	}
	var getTerm = function(termName, callback){
			var context = new SP.ClientContext.get_current();
			var rootWeb = context.get_site().get_rootWeb();
			context.load(rootWeb);
			context.executeQueryAsync(getTermItem,failure);
			
			function getTermItem(){
				var taxList = rootWeb.get_lists().getByTitle("TaxonomyHiddenList");
				var taxQuery = "<View Scope='RecursiveAll'>" +
								"<Query>" +
									"<Where>" +
										"<Eq>" +
											"<FieldRef Name='Title' /><Value Type='Text'>" + termName + "</Value>" +
										"</Eq>" +
									"</Where>" +
								"</Query>" +
								"</View>";
				
				var query = new SP.CamlQuery();
				query.set_viewXml(taxQuery);
				
				var terms = taxList.getItems(query);
				context.load(terms);
				context.executeQueryAsync(getItem,failure);
				
				function getItem(){
					var termEnum = terms.getEnumerator();
					termEnum.moveNext();
					var term = new Term(termName, termEnum.get_current().get_item("ID"), termEnum.get_current().get_item("IdForTerm"));
					callback(term);
				}
			}
			
			function Term(name, wssId, termId){
				this.Name = name,
				this.WssID = wssId,
				this.TermGUID = termId
			}
			
			function failure(sender, args) {
				console.log(args.get_message());
			}
	}
	
	var getCurrentUserNNum = function () {
	    if(window.sessionStorage){
	    	var nNum = sessionStorage.getItem("userNNum");
	    }
	    
	    if(nNum === null){
		    var userid = _spPageContextInfo.userId;
			var requestUri = _spPageContextInfo.webAbsoluteUrl + "/_api/web/getuserbyid(" + userid + ")";
			var requestHeaders = { "accept" : "application/json;odata=verbose" };
				
			$.ajax({
			  async : false,
			  url : requestUri,
			  contentType : "application/json;odata=verbose",
			  headers : requestHeaders,
			  success : onSuccess,
			  error : onError
			});
		}
		
		function onSuccess(data, request){
	  		var loginNameArray = data.d.LoginName.split('|');
	  		nNum = loginNameArray.pop();
	  		console.log(nNum);
	  		var arr = nNum.split("\\");
			arr[1] = arr[1].toUpperCase();
	  		
	  		nNum = hexEncodeString(arr.join('\\'));
	  		sessionStorage.setItem("userNNum", nNum);
		}
		
		function onError(error) {
		  console.log("Could not retrieve current user. Error Message: " + error);
		}
		
		return nNum;
	}
	
	var hexEncodeString = function (str){
		var encodedString = "";
		for(var i = 0; i < str.length; i++){
			encodedString += str.charCodeAt(i).toString(16);
		}
		return encodedString;
	}
	
    var hexDecodeString = function (str) {
		var arr = str.match(/.{1,2}/g);
		var strFinal = "";
		for(var i = 0; i < arr.length; i++){
			strFinal += String.fromCharCode(parseInt(arr[i],16))
		}
		return strFinal;
	}
    
   	var computeModified = function (modDate, contentsource) {

	 var rtnString;
	 var newString;
	 
	 
	 if(modDate != null && modDate != ""){
	 
			//Compute milliseconds from modDate
			var now1 = new Date();
			var now = new Date(now1.getTime());
			
			if (contentsource == internalCS) {
			var msTimeSinceModified = now - new Date(modDate).getTime();
			}
			else {
			var msTimeSinceModified = now - new Date(modDate).getTime() - 14400000;
			}

			
				
		
		   // Establish larger units based on milliseconds.
		   var msecondsPerMinute = 1000 * 60;
		   var msecondsPerHour = msecondsPerMinute * 60;
		   var msecondsPerDay = msecondsPerHour * 24;
		   var msecondsPerYear = msecondsPerDay * 365
			
		
		 	//Calculate how many days the msTimeSinceModified contains
		   var days = Math.floor( msTimeSinceModified / msecondsPerDay ); 
		   var hours = Math.floor( msTimeSinceModified / msecondsPerHour );
		   var minutes = Math.floor( msTimeSinceModified / msecondsPerMinute );
		   var years = Math.floor( msTimeSinceModified / msecondsPerYear );
		   
			if (minutes < 60) {
			  rtnString = minutes + " minute# ago";
			}
			
			else if (hours < 24) {
			   rtnString = hours + " hour# ago";
			}
			
			else if (days < 365) {
				rtnString = days + " day# ago";
			}
			
			else {
				rtnString = years + " year# ago";
			}
		
			 if (days == 1 || hours == 1 || minutes == 1 || years == 1){
		    	newString = rtnString.replace("#", " ");
		     }
		     else{
		         newString = rtnString.replace("#", "s");
		     }
		     
		 }
		 else{
		 
		 	newString = "no data";
		  
		 }
	 
			return newString ;
		}
	
	var scrubFileName = function (fileName) {
    	var scrubChar = [
                ["#", "No."], 
                ["%", "pct"],
                ["&", "and"], 
                ["*", "\'"],
                ["<", "LT"],
                [">", "GT"]
            ];
		var newStr = fileName;
        for (var i = 0; i < scrubChar.length; i++) {
        	newStr = newStr.replace(scrubChar[i][0], scrubChar[i][1]);
        }
        return newStr;
    }
    
    var getLibraries = function (groupList, entityName) {
    
     	var groups =  groupList.split(";");
		 var group = "";
		 var HO_flag = false;
		 
		 for(var i in groups)
		 {
		 	if(groups[i] != "")
		 	{
			 	group = groups[i];
			}
		 }

		var groupTMP = group.split("-");
		var user_group = groupTMP[groupTMP.length - 1];
		if(groupTMP[groupTMP.length - 2].toLowerCase() == "ho")
		{
			HO_flag = true;
		}
		

		switch (entityName.toLowerCase()) {
	        case 'account':
	        	if(HO_flag == true)
	        	{
	    			var DocLibs = new Array("AUW","AUWC");	        		
	        	}else if(user_group == "admin")
	        	{
	    			var DocLibs = new Array("AUW","AUWC","AC","ACC");
	    		}else if (user_group == "view")
	    		{
	    			var DocLibs = new Array("AUW","AC");
	    		}else if(user_group == "uw") 
	    		{
					var DocLibs = new Array("AUW","AUWC");	    			
	    		}
	    		else if(user_group == "claims") 
	    		{
					var DocLibs = new Array("AC","ACC");	    			
	    		}

		        break;
	        case 'agency':	
	   			if((user_group == "admin") || (user_group == "view"))
	        	{
	    			var DocLibs = new Array("AS","CA","AG");
	    		}else if (user_group == "agyadmin")
	    		{
	    			var DocLibs = new Array("AS","AG");
	    		}else if(user_group == "uw") 
	    		{
					var DocLibs = new Array("AG");	    			
	    		}
	    		else if(user_group == "-finance") 
	    		{
					var DocLibs = new Array("CA","AG");	    			
	    		}
	   		    break;
	        case 'bond':
	        	if((user_group == "admin")||(user_group == "view")||(user_group == "uw"))
	        	{
	    			var DocLibs = new Array("CB");
	    		}
	            break;
	        case 'bondrequest':
	           if((user_group == "admin")||(user_group == "view")||(user_group == "uw"))
	        	{
	    			var DocLibs = new Array("CB");
	    		}
	            break;
	        case 'principal':
	            var accountId = WBgetQueryStringParameter('accountid');
	            if (accountId != '') {
	            
	            	if((user_group == "admin")||(user_group == "view")||(user_group == "uw"))
		        	{
		    			var DocLibs = new Array("APUW");
		    		}
	            }
	            else {
				     	
				     	if(user_group == "admin")
			        	{
			    			var DocLibs = new Array("TPUW", "TPUWC","TPC","TPCC");
			    		}else if (user_group == "view")
			    		{
			    			var DocLibs = new Array("TPUW","TPUWC");
			    		}else if(user_group == "uw") 
			    		{
							var DocLibs = new Array("TPUW","TPUWC");	    			
			    		}
			    		else if(user_group == "claims") 
			    		{
							var DocLibs = new Array("TPC","TPCC");	    			
			    		}
	            }
	            break;
	        default:
	            	var DocLibs = new Array("ERROR");
	            break;
	        }    	
    	

        return DocLibs;
    }

    
	var docTypeParse = function(type, basePage) {
 
	var link = "test";
	var pic = "/_layouts/15/images/ictxt.gif";
	if (type == "docx" || type == "doc" || type == "docm" || type == "dot" || type == "dotx"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_Word_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_Word_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_Word_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_Word_HoverPanel.js";
		}
		pic = "/_layouts/15/images/icdocx.png";
	} else if (type == "xlsx" || type == "xls" || type == "xlsb" || type == "xlsm"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_Excel_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_Excel_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_Excel_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_Excel_HoverPanel.js";
		}
		pic = "/_layouts/15/images/icxlsx.png";
	} else if (type == "ppt" || type == "pptx" || type == "pptm"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_PowerPoint_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_PowerPoint_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_PowerPoint_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_PowerPoint_HoverPanel.js";
		}
		pic = "/_layouts/15/images/icpptx.png";
	} else if (type == "pdf"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_PDF_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_PDF_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_PDF_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_PDF_HoverPanel.js";
		}
		pic = "/_layouts/15/images/icpdf.png";
	} else if (type == "tiff" || type == "tif" || type == "jpg" || type == "jpeg" || type == "bmp" || type == "png"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_Picture_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_Picture_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_Picture_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_Picture_HoverPanel.js";
		}
		pic = "/_layouts/15/images/icpng.gif";
	} else if (type == "one"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_OneNote_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_OneNote_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_OneNote_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_OneNote_HoverPanel.js";
		}
		pic = "/_layouts/15/images/icone.png";
	} else if (type == "zip"){
		if (basePage == 1){
			link = "wb_accountDocs_Item_Default_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_Default_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_Default_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_Default_HoverPanel.js";
		}
		pic = "/_layouts/15/images/iczip.gif";
	} else if (type == "aspx"){
		pic = "/_layouts/15/images/DOCLINK.gif";
	} else if (type == "msg"){
		pic = "/_layouts/15/images/icmsg.png";
	} else {
		if (basePage == 1){
			link = "wb_accountDocs_Item_Default_HoverPanel.js";
		} else if (basePage == 2){
			link = "wb_agenciesDocs_Item_Default_HoverPanel.js";
		} else if (basePage == 3){
			link = "wb_cbrBondDocs_Item_Default_HoverPanel.js";
		} else {
			link = "wb_principalsDocs_Item_Default_HoverPanel.js";
		}
	}
	return [link, pic];

};

 return {
 		getContentSource:getContentSource,
        getUrlValue: getUrlValue,
        getJSONObjectFromURL: getJSONObjectFromURL,
        getPage: getPage,
        getURLNoJSON: getURLNoJSON,
        loadingImage: loadingImage,
        formatDetailsDate: formatDetailsDate,
		formatDate: formatDate,
		formatName: formatName,
		formatFileSize: formatFileSize,
		extractClass: extractClass,
		getTaxonomyIDs: getTaxonomyIDs,
		getTerm: getTerm,
		getTermStoreName: getTermStoreName,
		getCurrentUserNNum: getCurrentUserNNum,
		hexEncodeString: hexEncodeString,
		hexDecodeString: hexDecodeString,
		computeModified: computeModified,
		docTypeParse: docTypeParse,
		scrubFileName: scrubFileName,
		getLibraries: getLibraries		
    };
    

}();