﻿$webAppUrl=$args[0]
$ScriptPath=$args[1]
$solutionName=$args[2]

if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) 
{
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

$fqSolutionPath="$ScriptPath\Solutions\$solutionName"
$solution = Get-SPSolution | where-object {$_.Name -eq $solutionName}

# check to see if solution package has been installed
if ($solution -ne $null) {
    # Get Rid of it    
    . $ScriptPath\RemoveWSP.ps1 $webAppUrl $ScriptPath $solutionName
}

Add-SPSolution -LiteralPath $fqSolutionPath

$solution = Get-SPSolution | where-object {$_.Name -eq $solutionName}
if ($solution -ne $null) {
    while ( $solution.JobExists )
    {
        write-output "."
        sleep 1
    }
    write-output "Solution Added"

    Install-SPSolution -Identity $solutionName -GACDeployment -WebApplication $webAppUrl -Force
}
