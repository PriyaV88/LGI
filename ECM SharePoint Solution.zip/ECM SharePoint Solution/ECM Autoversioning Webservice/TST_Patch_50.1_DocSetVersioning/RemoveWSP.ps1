$webAppUrl=$args[0]
$ScriptPath=$args[1]
$solutionName=$args[2]

if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) 
{
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

$solution = Get-SPSolution | where-object {$_.Name -eq $solutionName}
# check to see if solution package has been installed
if ($solution -ne $null) {
    # check to see if solution package is currently deployed
    if($solution.Deployed -eq $true){
        
        Uninstall-SPSolution -Identity $solutionName -webapplication $webAppUrl -Confirm:$false         
        
        while ( $solution.JobExists )
        {
            write-output "."
            sleep 1
        }
        write-output "solution uninstalled"
    }
    
    Remove-SPSolution -Identity $solutionName -Confirm:$false 
	
    while ( $solution.JobExists )
    {
        write-output "."
        sleep 1
    }
    write-output "solution removed"
}

write-output "RemoveWSP Done"