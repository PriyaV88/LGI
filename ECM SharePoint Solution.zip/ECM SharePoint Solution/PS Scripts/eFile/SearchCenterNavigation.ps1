﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
<#**************************************************************************************************#
    Descritpion: Adding and deletiong navigation node from the Search Center Global Navigation
#**************************************************************************************************#>
#—————-PowerShell Addin ———————————————
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

#—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
	$dpo = $dp0

    #$dpo = $(get-location)
    echo $dpo
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    echo $index
    $logloc="$dpo".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

Function Main()
{
$csvPath = $("$dp0\SearchCenter-Navigation.csv")
$SiteCollections = Import-CSV $csvPath
write-log $date "message" "Fetched CSV file values." "Search Center" "Navigation - Addition and Deletion" 


Foreach($SC in $SiteCollections)
{   
	$Web = Get-SPWeb $SC.SiteURL
	$navSettings = New-Object Microsoft.SharePoint.Publishing.Navigation.WebNavigationSettings($Web)
	$navSettings.GlobalNavigation.Source = 1;
	$navSettings.Update()
    
    $SPWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($Web)  
    $AllowUnsafeUpdatesStatus = $Web.AllowUnsafeUpdates
    $Web.AllowUnsafeUpdates = $true
    $NavigationNodes = $Web.Navigation.TopNavigationBar

    try
    {
        for ($i = $NavigationNodes.Count-1; $i -ge 0; $i--)
        {
            write-host $NavigationNodes[$i].Title "heading deleting...... " -ForegroundColor Yellow
            $Web.Navigation.TopNavigationBar[$i].Delete()
            write-host "heading deleted successfully !!!." -ForegroundColor Green
        }
    }
    catch
    {
        write-host "Error: Please check the log file"  -ForegroundColor Red
        write-log $date "error" $_.Exception.Message "Search Center" "Navigation - Addition and Deletion" 
    }
      
    Write-Host ""
        $SPWeb.Navigation.GlobalIncludePages = $false
        $SPWeb.Navigation.CurrentIncludePages = $false
    
     $Web.update()
     $Web.AllowUnsafeUpdates = $AllowUnsafeUpdatesStatus
     $Web.Dispose()
    break
  }   

  Foreach($SC in $SiteCollections)
   {
    Write-Host $SC.Action
    Write-Host $SC.Code
    Write-Host $SC.NodeName
    Write-Host $SC.SiteURL
    Write-host $SC.LinkURL
       
   $Web = Get-SPWeb $SC.SiteURL
    
    $SPWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($Web)  
    $AllowUnsafeUpdatesStatus = $Web.AllowUnsafeUpdates
    $Web.AllowUnsafeUpdates = $true
    
    try
    {
       # Write-Host "Inside addition"
        if ($SC.Code -eq "0")
        {
            $message="Creating Heading:" +$SC.NodeName
            Write-Host  $message -ForegroundColor Yellow
            write-log $date "message" $message "Search Center" "Navigation - Addition and Deletion" 
            $CreateNavigationNodeMethod = [Microsoft.SharePoint.Publishing.Navigation.SPNavigationSiteMapNode]::CreateSPNavigationNode
            $headingNode = $CreateNavigationNodeMethod.Invoke($SC.NodeName, $SC.LinkURL, [Microsoft.SharePoint.Publishing.NodeTypes]::Heading, $web.Navigation.TopNavigationBar) 
            
            $message="Created Heading:" +$SC.NodeName
            Write-Host $message -ForegroundColor Green
            write-log $date "message" $message "Search Center" "Navigation - Addition and Deletion" 
        }
        if ($SC.Code -eq "1")
        {
            Write-Host "Creating 1 Link"
            $headingCollection = $headingNode.Children
            $linkNode = $CreateNavigationNodeMethod.Invoke($SC.NodeName, $SC.LinkURL, [Microsoft.SharePoint.Publishing.NodeTypes]::AuthoredLinkPlain, $headingCollection)
            Write-Host "Created"
        }
    }catch
    {
        write-host "Error: Please check the log file"  -ForegroundColor Red
        write-log $date "error" $_.Exception.Message "Search Center" "Navigation - Addition and Deletion" 
    }
      
    Write-Host ""
        $SPWeb.Navigation.GlobalIncludePages = $false
        $SPWeb.Navigation.CurrentIncludePages = $false
    
     $Web.update()
     $Web.AllowUnsafeUpdates = $AllowUnsafeUpdatesStatus
     #$SPWeb.AllowUnsafeUpdates = $AllowUnsafeUpdatesStatus
     $Web.Dispose()
     #write-log("Completed")cls
    }
  

}

Main