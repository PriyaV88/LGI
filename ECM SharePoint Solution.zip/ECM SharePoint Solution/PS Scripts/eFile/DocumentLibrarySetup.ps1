﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    $logloc="$dp0".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}


#add sharepoint cmdlets
Write-Host  "Document Library setup - Started "
write-log $date "message"  "Document Library setup - Started "  "GlobalCall" "DocumentLibrarySetup"


  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "DocumentLibrarySetup"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "DocumentLibrarySetup"


$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)


function AddDocumentLibrariesUsingContentTypes
{
	$dpo=Get-Location

    [xml]$xmldoc = Get-Content "$dp0\DocumentLibrarySetup.xml"
    write-log $date "message"  ("Loaded xml from location:"+ "$dp0\DocumentLibrarySetup.xml")  "GlobalCall" "DocumentLibrarySetup"
	$xpath = "/Deployment/DocumentLibraries/ContentTypes/ContentType"	
	$allContentTypePaths = $xmldoc.selectnodes($xpath)
	#$template = [Microsoft.SharePoint.SPListTemplateType]::DocumentLibrary
    #$listTemplate = [Microsoft.SharePoint.SPListTemplateType]::DocumentLibrary 
	if ($allContentTypePaths -ne $null)
	{
        try
        {
		    foreach($ContentTypePath in $allContentTypePaths)
	        {
                try
                {
			        # Content Type Name
			        $cttoAddName = $ContentTypePath.getattribute("Name")

                    $defaultCTName = $ContentTypePath.getattribute("DefaultCTName")

                    $hideCTName = $ContentTypePath.getattribute("HideCTName")
			
			        foreach ($childListNode in $ContentTypePath.Webs.ChildNodes)
                    {        
				        $subWebUrl = $childListNode.getattribute("Url")
				        if ($subWebUrl -eq "/")
				        {
					        $subWebUrl = $Deployment.WebAppURL.TrimEnd("/")
				        }
				        else
				        {
					        $subWebUrl = $xmldoc.Deployment.WebAppURL.TrimEnd("/") + "/"  + $childListNode.getattribute("Url")
				        }
				        
				        $subweb = Get-SPWeb -Identity $subWebUrl

                        Write-Host "Creating libraries started on " $subWebUrl -ForegroundColor Yellow               
				        foreach ($listNode in $childListNode.Lists.ChildNodes)
				        {                    
					        [string]$ListName = $listNode.getattribute("Name")
					        [string]$shouldRecreate = $listNode.getattribute("Recreate")
					        [bool]$alreadyExists = $false
					        if ($subweb.Lists[$ListName])
					        {
						        $alreadyExists = $true
						        write-host $subweb.Title "has a list called" $ListName -ForegroundColor Cyan	
						        if ($shouldRecreate -eq "true")
						        {
							        $splist = $subweb.Lists[$ListName]
							        write-log $date "message"  ("Delete existing list"+$ListName)  "AddDocumentLibrariesUsingContentTypes" "DocumentLibrarySetup"
							        $splist.Delete()
							        $subweb.Update()
                                    write-host "Deleted the list successfully" -ForegroundColor Green
						        }
					        }

					       if ($alreadyExists -eq $false -or ($alreadyExists -eq $true -and $shouldRecreate -eq "true"))
					       {			
                                $message="Creating list with name: "+$ListName
                                write-log $date "message" $message "AddDocumentLibrariesUsingContentTypes" "DocumentLibrarySetup"
                                $listTemplate = [Microsoft.SharePoint.SPListTemplateType]::DocumentLibrary
                                $template = [Microsoft.SharePoint.SPListTemplateType]::DocumentLibrary 
                                $subweb.Lists.Add($ListName, "Library", $template) 
                            
                                $subweb.Update()
                                $messages= $ListName+ " created successfully"
                                write-host $ListName " created successfully" -ForegroundColor Green
                                write-log $date "message" $messages "AddDocumentLibrariesUsingContentTypes" "DocumentLibrarySetup"
                           }

						    $splist = $subweb.Lists[$ListName]
						    $splist.ContentTypesEnabled = $true
						    $splist.Update()
                            write-host "Successfully enabled Content Types on the library" -ForegroundColor Green
                       
                            $customContentTypeArray = $cttoAddName.Split(",")                        
                        
                            write-host "Adding Content Types to the library started" -ForegroundColor Yellow
                            foreach($customContentType in $customContentTypeArray)
                            {
                                $cttoAdd = $subweb.AvailableContentTypes[$customContentType]                          
                                                    
                                if ($cttoAdd -ne $null)
                                {
                                    $existingCT = $splist.ContentTypes[$customContentType]
                                    if($existingCT -eq $null)
                                    {
                                        write-log $date "message" $ctmessage "AddDocumentLibrariesUsingContentTypes" "DocumentLibrarySetup"
                                        $ct = $splist.ContentTypes.Add($cttoAdd)
                                        $splist.Update()
                                        write-host "Added content type:-" $ctToAdd.Name " to list " $spList.Title -ForegroundColor DarkYellow
                                    }
                                }
                                else 
                                {
                                    write-host "Content Type with title:-" $customContentType " was not found in " $subWeb.Title -ForegroundColor Red
                                    $notfoundmsg="Content Type with title:-"+ $customContentType+ " was not found in "+ $subWeb.Title
                                    write-log $date "message" $notfoundmsg  "AddDocumentLibrariesUsingContentTypes" "DocumentLibrarySetup"
                                }
                            }

                            write-host "Adding Content Types to the library completed" -ForegroundColor Green
                            
                            $deleteDefaultCT = $listNode.getattribute("DeleteDefaultCT")

                            if ($deleteDefaultCT -eq 'true')
                            {
                                $ctToRemove = $splist.ContentTypes['Document']
                                if ($ctToRemove -ne $null)
                                {
                                    $splist.ContentTypes.Delete($ctToRemove.Id)
                                    $splist.Update()
                                    write-host "Removed default content type Document from the library" -ForegroundColor Green
                                }
                            }

                            $currentOrder = $splist.ContentTypes
                            $result = New-Object System.Collections.Generic.List[Microsoft.SharePoint.SPContentType]
                            foreach ($ct in $currentOrder)
                            {
                                 if ($ct.Name -eq $defaultCTName)
                                 {
                                    $result.Add($ct)
                                 }
                            }
                            $splist.RootFolder.UniqueContentTypeOrder = $result
                            $splist.RootFolder.Update()
                            write-host "Successfully set $defaultCTName as the default content type on the library" -ForegroundColor Green

                            if ($splist.EnableVersioning -eq $false)
                            {
                                $splist.EnableVersioning = $true
                                $splist.EnableMinorVersions = $false
                                $splist.Update()
                                write-host "Successfully enabled versioning on the library" -ForegroundColor Green
                            }

                            # Views
                            foreach ($nameView in $xmldoc.Deployment.DocumentLibraries.Views.View)
                            {
                                try
                                {
                                    $viewName = $nameView.Name
			                        $viewQuery = $nameView.Query.InnerXml
			                        [int]$rowLimit = $nameView.RowLimit
			                        $viewFields = New-Object System.Collections.Specialized.StringCollection
			                        foreach ($viewFieldNode in $nameView.ViewFields.ChildNodes)
			                        {
				                        $viewFieldName = $viewFieldNode.Name
				                        $viewfields.Add($viewFieldName)
			                        }

                                    $oldview = $splist.Views[$viewName]
                                    if($oldview)
				                    {
					                    write-log $date "message"  "View already exists. Deleting View:$viewName from $splist" "CreateEFileViews" "CreateEFileViews"
					                    $splist.Views.Delete($oldview.ID) 
				                    }

                                    write-host "Adding $viewName View to the libary: " $splist.Title
				                    $myListView = $splist.Views.Add($viewName, $viewFields, $viewQuery, $rowLimit, $True, $False, "HTML", $False)
				                    $myListView.Update()
                                    $splist.Update()

                                    if ($nameView.IsRecursive -ne $null -and $nameView.IsRecursive -eq "true")
                                    {
                                        $myListView.Scope = "Recursive"
                                        $myListView.Update()
                                    }

                                    if ($nameView.IsDefault -ne $null -and $nameView.IsDefault -eq "true")
                                    {
                                        $myListView.DefaultView = $true
                                        $myListView.Update()
                                    }
				
				                    write-host "Adding $viewName View to the library completed"                
                                }
                                catch
                                {
                                    write-log $date "error" $_.Exception.Message "createEfileLibraryfunc" "eFileLibrary"
                                }
                            }

                            # Create Index
                            foreach($InternalFldName in $xmldoc.Deployment.DocumentLibraries.Indexes.Index)
                            {
                                $fldToIndex = $splist.Fields.GetFieldByInternalName($InternalFldName.Name)
                                try
                                {
                                   $index = $splist.FieldIndexes.Item($fldToIndex.Id)
                                   Write-Host "The field $fldToIndex is already indexed" -ForegroundColor DarkGreen
                                }
                                catch
                                {
                                    $fldToIndex.Indexed = $true;    
                                    $splist.FieldIndexes.Add($fldToIndex);
                                    Write-Host ("The field {0} has been indexed" -f  $fldToIndex.Title) -ForegroundColor Yellow
                                }
                            }
							
							Start-Sleep -s 2                            
                        }

                        Write-Host  "Document Library setup - Completed on" $subWebUrl -ForegroundColor Magenta
                        $subweb.Dispose()
			        }
                }
                catch
                {
                    write-log $date "error" $_.Exception.Message "createEfileLibraryfunc" "eFileLibrary"
                }
            }
	    }
        catch
        {
            write-log $date "error" $_.Exception.Message "createEfileLibraryfunc" "eFileLibrary"
        }
    }    
}
 
AddDocumentLibrariesUsingContentTypes

Write-Host  "Document Library setup - Completed " -ForegroundColor Green
write-log $date "message"  "Document Library setup - Completed "  "GlobalCall" "DocumentLibrarySetup"