﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#—————-PowerShell Addin ———————————————
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}

$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    echo $dpo
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    echo $index
    $logloc="$dpo".Substring(0,$index)
    echo $logloc
    
    $EventMesages = $EventMesage -replace ",", "."

     $LogFilePath = "$logloc\ScriptExecLogs.csv"
   

    Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

Function Main()
{
$csvPath = $("$dp0\Navigation.csv")
$SiteCollections = Import-CSV $csvPath
write-log $date "message" "Fetched CSV file values." "Main" "Navigation_AdditionAndDeletion"

Foreach($SC in $SiteCollections)
{
    Write-Host $SC.Action
    Write-Host $SC.Code
    Write-Host $SC.NodeName
    Write-Host $SC.SiteURL
    Write-host $SC.LinkURL
    $Web = Get-SPWeb $SC.SiteURL
    
     $SPWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($Web)  
    $AllowUnsafeUpdatesStatus = $Web.AllowUnsafeUpdates
    $Web.AllowUnsafeUpdates = $true

    $NavigationNodes = $Web.Navigation.TopNavigationBar
    for ($i = $NavigationNodes.Count-1; $i -ge 0; $i--)
    {
        write-host $NavigationNodes[$i].Title "heading deleting...... " -ForegroundColor Yellow
        $Web.Navigation.TopNavigationBar[$i].Delete()
        write-host "heading deleted successfully !!!." -ForegroundColor Green
    }
    
    try{
    if($SC.Action -eq "Delete")
    {
        #write-log("Deleting Navigation Node")
        Write-Host "Deleting Navigation Node"
        
        $NavigationNodes = $Web.Navigation.TopNavigationBar
            
            foreach($node in $NavigationNodes) 
            {
            
                if($Node.Title -eq $SC.NodeName)#TeamSite")
                {
                    
                    #$node.IsVisible = $false
                    Write-Host("Deleted Node",$Node.Title)
                    $message="Deleted Node"+$Node.Title
                    write-log $date "message" $message "Main" "Navigation_AdditionAndDeletion"
                    $Node.Delete()
                    
                }
              
            }

        write-host("Deletion Completed")
    }
    }Catch
    {
        write-host "Error: Please check the log file"  -ForegroundColor Red
        #write-log ("!!ERROR while deleting!!",$error[0])
        write-log $date "error" $_.Exception.Message "Main" "Navigation_AdditionAndDeletion"
    }
    try
    {
    if($SC.Action -eq "Addition")
    {
        <#if ($SC.Code = "1")
        {
            
        }#>
        Write-Host "Inside addition"
        if ($SC.Code -eq "0")
        {
            Write-Host "Creating 0 Heading"
            $CreateNavigationNodeMethod = [Microsoft.SharePoint.Publishing.Navigation.SPNavigationSiteMapNode]::CreateSPNavigationNode
            $headingNode = $CreateNavigationNodeMethod.Invoke($SC.NodeName, $SC.LinkURL, [Microsoft.SharePoint.Publishing.NodeTypes]::Heading, $web.Navigation.TopNavigationBar) 
            Write-Host "Created"
        }
        if ($SC.Code -eq "1")
        {
            Write-Host "Creating 1 Link"
            $headingCollection = $headingNode.Children
            $linkNode = $CreateNavigationNodeMethod.Invoke($SC.NodeName, $SC.LinkURL, [Microsoft.SharePoint.Publishing.NodeTypes]::AuthoredLinkPlain, $headingCollection)
            Write-Host "Created"
        }
    }
    }catch
    {
        write-host "Error: Please check the log file"  -ForegroundColor Red
        write-log $date "error" $_.Exception.Message "Main" "Navigation_AdditionAndDeletion"
    }
    
    Write-Host ""
        $SPWeb.Navigation.GlobalIncludePages = $false
        $SPWeb.Navigation.CurrentIncludePages = $false
    
     $Web.update()
     $Web.AllowUnsafeUpdates = $AllowUnsafeUpdatesStatus
     #$SPWeb.AllowUnsafeUpdates = $AllowUnsafeUpdatesStatus
     $Web.Dispose()
     #write-log("Completed")

}


}
Main