﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#<summary>
#Write log to logfile
#</summary>
#<param name="date">Current date</parm>
#<param name="EventType">Type of Event (message)</parm>
#<param name="EventMesage">Description of the message</parm>
#<param name="functionName">Function Name</parm>
#<param name="Filename">File Name</parm>
#<returns></returns>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    $logloc="$dp0".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."
	
    $LogFilePath = "$dp0\ScriptExecLogs.csv"
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#add sharepoint cmdlets


  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "UpdateHelpMappingList"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "UpdateHelpMappingList"
 
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

function UpdateHelpMappingList
{
	$dpo=Get-Location
    try
    {
        [xml]$xmldoc = Get-Content "$dp0\UpdateHelpMappingList.xml"
        write-log $date "message"  ("Loaded xml from location:"+ "$dp0\UpdateHelpMappingList.xml")  "UpdateHelpMappingList" "UpdateHelpMappingList"

        $url = $xmldoc.Deployment.SiteCollectionURL.TrimEnd('/')
        Write-Host -f White "Url received:- $url"
        write-log $date "message" "Url received:- $url" "UpdateHelpMappingList" "UpdateHelpMappingList"

        $configListName = $xmldoc.Deployment.ConfigList
		
		$web = Get-SPWeb -Identity $url
        $list = $web.Lists[$configListName]
        
		foreach($entry in $xmldoc.Deployment.Entries.Entry)
	    {
            $spQuery = New-Object Microsoft.SharePoint.SPQuery;
            $title = $entry.PageUrl
            $spQuery.Query = "<Where>                              
                                <Eq><FieldRef Name='PageUrl' /><Value Type='Text'>$title</Value></Eq>
                             </Where>"

            $items=$list.GetItems($spQuery)
            $listItemsTotal = $items.Count; 
                     
            if($listItemsTotal -gt 0)
            {
                Write-Host -f Yellow "Entry with PageUrl:- $title already exists in the list, updating the same"
                write-log $date "message" "Entry with PageUrl:- $title already exists in the list, updating the same" "UpdateHelpMappingList" "UpdateHelpMappingList"
                $item = $items[0]
                $item["HelpUrl"] = $entry.HelpUrl
                $item.Update()
                write-host "Entry with PageUrl:- $title updated successfully" -ForegroundColor Green
                write-log $date "message" "Entry with PageUrl:- $title updated successfully" "UpdateHelpMappingList" "UpdateHelpMappingList"
            }
            else
            {
                Write-Host -f Yellow "Entry with PageUrl:- $title not found in the list, creating"
                write-log $date "message" "Entry with PageUrl:- $title not found in the list, creating" "UpdateHelpMappingList" "UpdateHelpMappingList"
                $item = $list.AddItem()
                $item["PageUrl"] = $entry.PageUrl
                $item["HelpUrl"] = $entry.HelpUrl
                $item.Update()
                write-host "Entry with PageUrl:- $title created successfully" -ForegroundColor Green
                write-log $date "message" "Entry with PageUrl:- $title created successfully" "UpdateHelpMappingList" "UpdateHelpMappingList"
            }
        }
		
		$web.Dispose()
        write-log $date "message" "Update mapping list Completed" "UpdateHelpMappingList" "UpdateHelpMappingList"
	}
	catch
	{
		Write-Host $_.Exception.Message
    	write-log $date "error" $_.Exception.Message "UpdateHelpMappingList" "UpdateHelpMappingList"
    }		
}

UpdateHelpMappingList