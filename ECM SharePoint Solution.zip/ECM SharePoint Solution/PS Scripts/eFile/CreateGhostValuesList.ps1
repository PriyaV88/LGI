﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#<summary>
#Write log to logfile
#</summary>
#<param name="date">Current date</parm>
#<param name="EventType">Type of Event (message)</parm>
#<param name="EventMesage">Description of the message</parm>
#<param name="functionName">Function Name</parm>
#<param name="Filename">File Name</parm>
#<returns></returns>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    $logloc="$dp0".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."
	
    $LogFilePath = "$dp0\ScriptExecLogs.csv"
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#add sharepoint cmdlets

  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "CreateGhostValuesList"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "CreateGhostValuesList"
 
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

function CreateGhostValuesList
{
	$dpo=Get-Location
    try
    {
        [xml]$xmldoc = Get-Content "$dp0\CreateGhostValuesList.xml"
        write-log $date "message"  ("Loaded xml from location:"+ "$dp0\CreateGhostValuesList.xml")  "CreateGhostValuesList" "CreateGhostValuesList"
        
        $url = $xmldoc.Deployment.SiteCollectionURL.TrimEnd('/')
        Write-Host -f White "Url received:- $url"
        write-log $date "message" "Url received:- $url" "CreateGhostValuesList" "CreateGhostValuesList"

        $configListName = $xmldoc.Deployment.ConfigList
		
		$web = Get-SPWeb -Identity $url

        if($web.Lists[$configListName]) {
            Write-Host -f Yellow "List $configListName already exists in the site"
            write-log $date "message" "List $configListName already exists in the site" "CreateGhostValuesList" "CreateGhostValuesList"
            $list = $web.Lists[$configListName]

        } else {
            $message = "Creating list with name: $configListName"
            write-log $date "message" $message "CreateGhostValuesList" "CreateGhostValuesList"
            $template = [Microsoft.SharePoint.SPListTemplateType]::GenericList 
            $web.Lists.Add($configListName, "", $template)                            
            $web.Update()
            $list = $web.Lists[$configListName]

            $list.Fields.AddFieldAsXml($xmldoc.Deployment.Field.OuterXml, $true, [Microsoft.SharePoint.SPAddFieldOptions]::AddFieldToDefaultView)
            $list.Update()

            $messages = $configListName + " created successfully"
            write-host "$configListName created successfully" -ForegroundColor Green
            write-log $date "message" $messages "CreateGhostValuesList" "CreateGhostValuesList"
        }        
        
		foreach($entry in $xmldoc.Deployment.Entries.Entry)
	    {
            $spQuery = New-Object Microsoft.SharePoint.SPQuery;
            $title = $entry.Title
            $spQuery.Query = "<Where>                              
                                <Eq><FieldRef Name='Title' /><Value Type='Text'>$title</Value></Eq>
                             </Where>"

            $items=$list.GetItems($spQuery)
            $listItemsTotal = $items.Count; 
                     
            if($listItemsTotal -gt 0)
            {
                Write-Host -f Yellow "Entry with title:- $title already exists in the list, updating the same"
                write-log $date "message" "Entry with title:- $title already exists in the list, updating the same" "CreateGhostValuesList" "CreateGhostValuesList"
                $item = $items[0]
                $item["Value"] = $entry.Value
                $item.Update()
                write-host "Entry with title:- $title updated successfully" -ForegroundColor Green
                write-log $date "message" "Entry with title:- $title updated successfully" "CreateGhostValuesList" "CreateGhostValuesList"
            }
            else
            {
                Write-Host -f Yellow "Entry with title:- $title not found in the list, creating"
                write-log $date "message" "Entry with title:- $title not found in the list, creating" "CreateGhostValuesList" "CreateGhostValuesList"
                $item = $list.AddItem()
                $item["Title"] = $entry.Title
                $item["Value"] = $entry.Value
                $item.Update()
                write-host "Entry with title:- $title created successfully" -ForegroundColor Green
                write-log $date "message" "Entry with title:- $title created successfully" "CreateGhostValuesList" "CreateGhostValuesList"
            }
        }
		
		$web.Dispose()
        write-log $date "message" "Update config list Completed" "CreateGhostValuesList" "CreateGhostValuesList"
	}
	catch
	{
		Write-Host $_.Exception.Message
    	write-log $date "error" $_.Exception.Message "CreateGhostValuesList" "CreateGhostValuesList"
    }		
}

CreateGhostValuesList