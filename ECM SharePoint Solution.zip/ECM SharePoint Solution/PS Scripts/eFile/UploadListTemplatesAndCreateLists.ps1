﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
 # Adding the PowerShell Snapin
 Add-PSSnapin "Microsoft.SharePoint.PowerShell"

Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    $logloc="$dp0".Substring(0,$index)    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "UploadListTemplatesAndCreateLists"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "UploadListTemplatesAndCreateLists"
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)


function UploadTemplatesAndCreateLists
{
    [xml]$xmldoc = Get-Content "$dp0\ListTemplates.xml"
    write-log $date "message"  ("Loaded xml from location:"+ "$dp0\ListTemplates.xml")  "GlobalCall" "UploadListTemplatesAndCreateLists"

    foreach ($template in $xmldoc.Templates.Template)
    {
        try
        {
            $templateName = $template.FileName
            $title = $template.Title

            $stpPath = "$dp0\STPs\$templateName"
        
            $siteUrl = $template.Url
            $listName = $template.ListName
            $description = $template.Description
  
            # Get the root web
            $web = Get-SPWeb -Identity $siteUrl
  
            # Get the list template gallery
            $spLTG = $web.getfolder("List Template Gallery")
  
            # Get the list template gallery Collection
            $spcollection = $spLTG.files

            #$exists = $spcollection | where {$_.}
  
            # Get the custom list template file
            $Templatefile = get-item $stpPath
  
            # Add the custom list template file to gallery
            $spcollection.Add("_catalogs/lt/$templateName", $Templatefile.OpenRead(), $true)
  
            Write-Host "$templateName Uploaded to List Template Gallery Successfully"
            write-log $date "message"  ("$templateName Uploaded to List Template Gallery Successfully")  "UploadTemplatesAndCreateLists" "UploadListTemplatesAndCreateLists"
  
            # Get the custom list templates 
            $CustomlistTemplates = $web.Site.GetCustomListTemplates($web)  
            
            $template =  $CustomlistTemplates[$title]

            if ($template -ne $null)
            {
                if ($web.Lists[$listName] -eq $null)
                {
                    Write-Host “Creating the List based on the Template”
                    #Create the custom list using template
                    $web.Lists.Add($listName, $description, $template)
                    $web.Update()

                    Write-Host “Created the List:- $listName successfully”
                    write-log $date "message"  ("Created the List:- $listName successfully")  "UploadTemplatesAndCreateLists" "UploadListTemplatesAndCreateLists"
                }
                else
                {
                    Write-Host “List:- $listName already exists”
                }
            }
        }
        catch
        {
            write-log $date "error" $_.Exception.Message "UploadTemplatesAndCreateLists" "UploadTemplatesAndCreateLists"
        }
    }
}

Write-Host  "Uploading List Templates and creating lists - Started "
write-log $date "message"  "Uploading List Templates and creating lists - Started "  "GlobalCall" "UploadListTemplatesAndCreateLists"

UploadTemplatesAndCreateLists

Write-Host  "Uploading List Templates and creating lists - completed "
write-log $date "message"  "Uploading List Templates and creating lists - completed "  "GlobalCall" "UploadListTemplatesAndCreateLists"