﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#<summary>
#Write log to logfile
#</summary>
#<param name="date">Current date</parm>
#<param name="EventType">Type of Event (message)</parm>
#<param name="EventMesage">Description of the message</parm>
#<param name="functionName">Function Name</parm>
#<param name="Filename">File Name</parm>
#<returns></returns>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    $logloc="$dp0".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."
	
    $LogFilePath = "$dp0\ScriptExecLogs.csv"
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#add sharepoint cmdlets
Write-Host  "eFile Sites List  configuaration setup - Started "
write-log $date "message"  "eFile Sites List  configuaration setup - Started "  "GlobalCall" "UpdateeFileSitesList"


  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "UpdateeFileSitesList"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "UpdateeFileSitesList"
 
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

#<summary>
#Update eFile Sites configuaration list with the new LOB, Country,Product site url and library details
#</summary>
function UpdateeFileSitesList
{
	$dpo=Get-Location
    try
    {
        [xml]$xmldoc = Get-Content "$dp0\eFileSites.xml"
        write-log $date "message"  ("Loaded xml from location:"+ "$dp0\eFileSites.xml")  "UpdateeFileSitesList" "UpdateeFileSitesList"
        foreach($siteCollUrl in $xmldoc.Deployment)
        {
            $url=$siteCollUrl.SiteCollectionURL.TrimEnd('/')
			$configListName = $siteCollUrl.ConfigList
        }
		
		$web = Get-SPWeb -Identity $url		
		$list = $web.Lists[$configListName]

        $items = $list.items
        foreach ($item in $items)
        {
            Write-host "  Say Goodbye to $($item.id)" -foregroundcolor red
            $list.getitembyid($Item.id).Delete()
        }

        foreach ($webpath in $xmldoc.Deployment.Webs.Web)
        {
            $path = $url + "/" + $webpath.Url
            foreach ($node in $webpath.Lists.List)
            {
                [Int] $policyYear = [Int]$node.Name.Split('_')[1]
                [Int] $policyMonth = [Int]$node.Name.Split('_')[2]
                $item = $list.AddItem()
                $item["Country"] = $webpath.Country
                $item["LOB"] = $webpath.LOB
                $item["PolicyInceptionYear"] = $policyYear
                $item["PolicyInceptionMonth"] = $policyMonth
                $item["SiteCollectionURL"] = $path
                $item["DocumentLibraryName"] = $node.Name
                $item["IsActive"] = $true
                $item.Update()
            }
        }
		
		$web.Dispose()
		Write-Host "Update config list Completed" 
	}
	catch
	{
		Write-Host $_.Exception.Message
    	write-log $date "error" $_.Exception.Message "UpdateeFileSitesList" "UpdateeFileSitesList"
    }		
}

UpdateeFileSitesList