﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>

param
    (
        [parameter(mandatory=$true)][string]$Url
    )
	$snapin = Get-PSSnapin | Where-Object {$_.Name -eq 'Microsoft.SharePoint.Powershell'} 
if ($snapin -eq $null) 
{    
       Write-Host "Loading SharePoint Powershell Snapin..."    
       Add-PSSnapin "Microsoft.SharePoint.Powershell" 
}  
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
#[Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint")
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    #$dpo = $(get-location)
    echo $dp0
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    echo $index
    $logloc="$dp0".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

Write-Host  "Install WSP - Started "
write-log $date "message"  "UInstall WSP - Started "  "GlobalCall" "InstallWSPs"


Start-SPAssignment –Global

#Arguments
$xmlFile = "$dp0\DeploymentInputs.xml"

Write-Host "Loading XML"
    
$xml = [xml](Get-Content $xmlFile)

function AddInstallSolutions(){
try{
foreach ($wsp in $xml.Deployment.Solutions.Solution){
try{
    $wspName = $wsp.name
    $wspPath = "$dp0\WSPs\$wspName"

    $farm = Get-SPFarm
    
    #Get all the solutions deployed in the farm 
    $sol = $farm.Solutions[$wspName]
    if($sol)
    {
	    Write-Host -f Yellow "Going to uninstall $wspName"

	    if ($sol.Deployed -eq $TRUE ) 
	    {
		    Uninstall-SPSolution -Identity $wspName -Confirm:0 -Webapplication $Url
           
            Write-Host "waiting for retraction..." -NoNewline
		    while( $sol.JobExists ) 
		    {
                Write-Host "." -NoNewline				
                sleep 2
		    }
	    }
        Write-Host "uninstalled." 
	    Write-Host -f Yellow "Removing $wspName ..."
        
        #To delete the solution package from the solution store of the farm
	    Remove-SPSolution -Identity $wspName -Force -Confirm:0

	    Write-Host -f Green "$wspName is deleted from this Farm" `n
        #Wait for 60 sec after removing the solutions
        Start-Sleep -s 5
    }
    else
    {
	    Write-Host -f Yellow "Solution $wspName not found"
    }


    Write-Host "Deploying WSPs - Add solution"
    Add-SPSolution $wspPath
    Write-Host "Add solution Completed" -f Green

    Write-Host "installing solution"
    Install-SPSolution –Identity $wspName -WebApplication $Url -FullTrustBinDeployment
    $farm = Get-SPFarm
    $sol = $farm.Solutions[$wspName]

    if($sol)
    {
	    Write-Host -f Yellow "Going to install $wspName"        
        Write-Host "waiting for installation..."-NoNewline
	    while( $sol.Deployed -eq $FALSE )
	    {			
            Write-Host "." -NoNewline				
            sleep 2			
	    }
        Write-Host "."        
	    Write-Host -f Green "Solution $wspName is installed" `n
       
        #wait for 60 sec after the solution is deployed
        Start-Sleep -s 5
    }
    else
    {
	    Write-Host -f Red "Installing $wspName has failed. Solution is not found."
    }
}
catch
 {
 write-log $date "Error" $_.Exception.Message "AddInstallSolutions-Foreach" "Install WSPs"
 }
}
# Activate Features
#EnableFeature
# Set Master Page
#SetMasterPage
}
catch
 {
 write-log $date "Error" $_.Exception.Message "AddInstallSolutions" "Install WSPs"
 }
 }

function EnableFeature(){
    foreach ($feature in $xml.Deployment.Features.Feature){
        try{
            $featureID = $feature.Id
            $siteColUrl = $Url
            if ($feature.Url -ne $null)
            {
                $siteColUrl = $siteColUrl.TrimEnd("/") + $feature.Url
            }
             Write-Host "Enable feature"
             Enable-SPFeature -Identity $featureID -Url $siteColUrl
         }
        catch
         {
            write-log $date "Error" $_.Exception.Message "EnableFeature-Foreach" "Install WSPs"
         }
     }
 }

function SetMasterPage{
    try{
        Write-Host "Setting Master Page"
        $masterSiteUrl = $Url.TrimEnd("/")
        $w = Get-SPWeb $masterSiteUrl
        $w | select Url,ClientTag,MasterUrl,CustomMasterUrl,UseV15Rendering
        $w.MasterUrl = $w.ServerRelativeUrl.TrimEnd("/") + "/_catalogs/masterpage/seattle.master"
                    
        $w.CustomMasterUrl = $w.ServerRelativeUrl.TrimEnd("/") + "/_catalogs/masterpage/lmgs_base.master"
        $w.Update()
    }
    catch
    {
        write-log $date "Error" $_.Exception.Message "SetMasterPage-" "Install WSPs"
    }
}

function SetSearchCenterMasterPage{
    try{
        Write-Host "Setting Master Page"
        $masterSiteUrl = $Url.TrimEnd("/") + $xml.Deployment.SearchUrl
        $w = Get-SPWeb $masterSiteUrl
        $w | select Url,ClientTag,MasterUrl,CustomMasterUrl,UseV15Rendering
        $w.MasterUrl = $w.ServerRelativeUrl.TrimEnd("/") + "/_catalogs/masterpage/lmgs_search.master"
                    
        $w.CustomMasterUrl = $w.ServerRelativeUrl.TrimEnd("/") + "/_catalogs/masterpage/lmgs_base_search.master"
        $w.Update()
    }
    catch
    {
        write-log $date "Error" $_.Exception.Message "SetMasterPage-" "Install WSPs"
    }
}
function DeActivateFeaturesFromFile
{
	foreach ($feature in $xml.Deployment.Features.Feature)
	{
        $FeatureUrl = $Url
		$DeactFeatureName = $feature.getattribute("Name")
		#$DeactFeatureScope = $feature.getattribute("Scope")
		$DeactFeatureId = $feature.getattribute("Id")
		#$DeactFeatureUrl = $feature.getattribute("Url")
        if ($feature.Url -ne $null)
        {
            $FeatureUrl = $FeatureUrl.TrimEnd("/") + $feature.Url
        }
        $FeatureActive = Get-SPFeature -Web $FeatureUrl | where {$_.Id -eq $DeactFeatureId}
		if ($FeatureActive -eq $null)
		{
			Write-Host "Feature $DeactFeatureName already deactivated at : $FeatureUrl" -ForegroundColor White
		}
	    else
        {
			Write-Host -f Yellow "Deactivating " $DeactFeatureName "Feature at:" $FeatureUrl	
			Disable-SPFeature -identity $DeactFeatureId -URL $FeatureUrl -confirm:$false  	   
			Write-Host -f Green $DeactFeatureName" Feature Deactivated Successfully"
        }
	}
}

function PublishTemplates
{
    $array = @("content web parts","Search","Filters")
    Write-Output "Publishing templates in " $Url "..."
    $site = Get-SPSite $Url
    $web = $site.OpenWeb()
    foreach ($templateFolder in $array) 
    {
        write-host "Current Folder:"$templateFolder
        $folder = $web.GetFolder("_catalogs/masterpage/display templates/" + $templateFolder)
        foreach($file in $folder.Files)
        {
            if ($file.Level -ne "Published")
            {
                [string]$extn = $file.Item["File Type"]
                $extn = $extn.ToLower()
                if ($file.Level -eq "Draft" -and $extn -eq 'html')
                {
                    write-host $file.Name
                    $file.Publish("Published file via PowerShell script.")
                    $file.Update()
                }
                               
            }
        }
    }

    $web.Close()
    $web.Dispose()
}

DeActivateFeaturesFromFile

AddInstallSolutions

EnableFeature
SetMasterPage
SetSearchCenterMasterPage

PublishTemplates

Write-Host  "Install WSP - Completed "
write-log $date "message"  "UInstall WSP - Completed "  "GlobalCall" "InstallWSPs"
