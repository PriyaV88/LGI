﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    $logloc="$dpo".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."

     $LogFilePath = "$logloc\ScriptExecLogs.csv"
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   

    Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#—————-PowerShell Addin ———————————————
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}
write-log $date "message"  "PowerShell Snapin added successfully"   "CreatePermissionFunc" "CreatePermissions"

 #----------------Get the xml file---------------------------------------------------------------
 write-log $date "message"  "Getting Input xml path"   "CreatePermissionFunc" "CreatePermissions"
$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
$dpo = $dp0
$file = resolve-path("$dp0\Permissions.XML")

if (!$file)
{
    write-log $date "message"  "Could not find the configuration file specified."   "CreatePermissionFunc" "CreatePermissions"
    Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
    Break
}

[string]$ConfigFile = $("$dp0\Permissions.XML")
Write-Host $ConfigFile
[xml]$groupsXML = Get-Content ($ConfigFile)
write-log $date "message"  ("Input xml path got :" + "$dp0\Permissions.xml")    "CreatePermissionFunc" "CreatePermissions"


function CreatePermissionFunc()
{


foreach ($Sites in $groupsXML.Sites.Site)
{
    $web = Get-SPWeb $Sites.url
     write-log $date "message"  ("Sharepoint site URL received:" + $Sites.url)  "CreatePermissionFunc" "CreatePermissions"

        foreach ($permissions in $Sites.Permissions.Permission)
        {
            foreach ($permission in $permissions)
            {
              #--------------Creating a new permission level-------------------

                if($permission.Action -eq "create")
                {

                if($Web.RoleDefinitions[$permission.name] -eq $null)
                {
                    try{
                    write-log $date "message"  ($permission.name+ " does not already exist, going to create...")  "CreatePermissionFunc" "CreatePermissions"
                    Write-Host $permission.name " does not already exist, going to create..."
                    $RoleDefinition = New-Object Microsoft.SharePoint.SPRoleDefinition
                    $RoleDefinition.Name = $permission.Name
                    $RoleDefinition.Description = $permission.Description
                    $RoleDefinition.BasePermissions = $permission.BasePermission
                    $Web.RoleDefinitions.Add($RoleDefinition)
                    Write-log $date "message" ("Created new permission" + $permission.name) "CreatePermissionFunc" "CreatePermissions"
                    }
                    catch
                    {
                       
                        Write-log $date "error" $_.Exception.Message  "CreatePermissionFunc" "CreatePermissions"
                    }
                }
                else
                {
                    Write-Host "The name "$permission.Name" already exists"
                    Write-log $date "message" ($permission.Name+"already exist") "CreatePermissionFunc" "CreatePermissions"
                }
                }
                elseif ($permission.Action -eq "update" -and $Web.RoleDefinitions[$permission.name] -ne $null)
                {
                    $alPermLevel = $Web.RoleDefinitions[$permission.name]
                    $alPermLevel.BasePermissions = $permission.BasePermission
                    $alPermLevel.Update()
                }
                #--------------------Deleting Permission------
                else
                {
                try
                {
                  write-log $date "message"  ( "Deleting Permission" + $permission.Name)  "CreatePermissionFunc" "CreatePermissions"
                  Write-Host "Deleting Permission..."
                  $Web.RoleDefinitions.Delete($permission.Name)
                  write-log $date "message" "permission Deleted" "CreatePermissionFunc" "CreatePermissions"
                  Write-Host "permission Deleted..."
                  }
                  catch
                  {
                   Write-log $date "error" $_.Exception.Message  "CreatePermissionFunc" "CreatePermissions"

                  }
                }
            }
        }
   $web.Update()
   $web.Dispose()
 }
 }

  #----------------Calling the function---------------------------------------------
 CreatePermissionFunc

 write-log $date "message"  "Create Permissions - Completed "  "CreatePermissionFunc" "CreatePermissions"
Write-Host  "Create Permissions - Completed "