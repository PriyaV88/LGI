﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    $logloc="$dpo".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

Write-Host  "Create Pages - Started "
write-log $date "message"  "Create Pages - Started "  "GlobalCall" "CreatePages"

Write-Host "Creating Pages"
Add-PSSnapin microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

## Set variables
## This variable will be the site where I want to start
$ver = $host | select version
if ($ver.Version.Major -gt 1) {$host.Runspace.ThreadOptions = "ReuseThread"} 
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
#Arguments

function CreatePages
{      
    [string]$ConfigFile = "$dp0\CreatePage.xml"
    [System.Xml.XmlDocument] $xmldoc = new-object System.Xml.XmlDocument
    $xmldoc.load($ConfigFile)
    $xpath = "/Webs/Web"   
    $allWebPaths = $xmldoc.selectnodes($xpath)

    if($allWebPaths -ne $null)
    {   

	    foreach($webPath in $allWebPaths)
        {  
            $webUrl = $webPath.getattribute("Url").TrimEnd("/")
            $web = Get-SPWeb $webUrl
            Write-Host $web
            $PubWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($web)
            $site = New-Object Microsoft.SharePoint.SPSite($webUrl)
            $psite = New-Object Microsoft.SharePoint.Publishing.PublishingSite($site)      
        
            if ($webPath.Layouts -ne $null)
		    {
			    foreach ($layout in $webPath.Layouts.ChildNodes)
                {
                    $layoutName = $layout.getattribute("Name")
                
                    $pageLayout = $null
                    if ($layout.Pages -ne $null)
                    {
                        foreach ($page in $layout.Pages.ChildNodes)
                        {
                                $pageUrl = $page.getattribute("Url")
                                $pageTitle = $page.getattribute("Title")
                                $clear = $page.getattribute("ClearAllWebParts")
                                $pages = $PubWeb.GetPublishingPages($PubWeb)
                       
                                $url=$webUrl+"/Pages/"+ $PageUrl
                                $pl = $pubWeb.GetAvailablePageLayouts() | Where { $_.Name -eq $layoutName }

                                # delete pages and recreate if exists
                                $pages = $pubWeb.GetPublishingPages($pubWeb)
                                $pages | ForEach-Object {
                                    if($_.Name -eq $PageUrl)
                                    {
                                        $_.ListItem.Delete();
                                    }
                                }
                                if($pl -ne $null)
                                {
                                    $newpage= $PubWeb.AddPublishingPage($PageUrl, $pl)
                                    $newpage.Title = $pageTitle
                                    $newpage.Update();
                                }
                                else
                                {
                                    write-host "Page layout: $layoutName is not available" 
                                }

                                # Check in the page if not checked out already
                                if ($newpage.ListItem.File.CheckOutType -ne "None")
                                {
                                    $newpage.CheckIn("Page Check in from script, Page Name:$newpage.Title")    
                                }						    

                                # Publish the page if not published already
                                if($newpage.ListItem.File.Level -ne "Published")
                                {
						             $file = $newpage.ListItem.File
						             $file.Publish("Published successfully")
                                }
                           

                                write-host $url(" is  Created.!")
                         }
                    }
                }
        
                $welcomeUrl = $webPath.getattribute("WelcomeUrl")
                $folder = $site.RootWeb.RootFolder
                $folder.WelcomePage = $welcomeUrl
                $folder.update()
            }
        }
    }
}

function CreateSearchPages
{
    [string]$ConfigFile = "$dp0\CreatePage.xml"
    [System.Xml.XmlDocument] $xmldoc = new-object System.Xml.XmlDocument
    $xmldoc.load($ConfigFile)
    $xpath = "/Webs/SearchWeb"   
    $allWebPaths = $xmldoc.selectnodes($xpath)

    if($allWebPaths -ne $null)
    {
	    foreach($webPath in $allWebPaths)
        {  
            $webUrl = $webPath.getattribute("Url").TrimEnd("/")
            $web = Get-SPWeb $webUrl
            Write-Host $web
            $PubWeb = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($web)
            $site = New-Object Microsoft.SharePoint.SPSite($webUrl)
            $psite = New-Object Microsoft.SharePoint.Publishing.PublishingSite($site)      
        
            if ($webPath.Layouts -ne $null)
		    {
                $pgLtCount = $webPath.Layouts.ChildNodes.Count
                $pgLtCount = $pgLtCount + $pubWeb.GetAvailablePageLayouts().Count
                $avaipageLayouts = new-object Microsoft.SharePoint.Publishing.PageLayout[] $pgLtCount
                $index = 0;
                foreach ($apl in $pubWeb.GetAvailablePageLayouts())
                {
                    $avaipageLayouts[$index] = $apl
                    $index = $index + 1
                }
                $pageLayouts = $psite.GetPageLayouts($true);
                foreach ($layout in $webPath.Layouts.ChildNodes)
                {
                    $layoutName = $layout.getattribute("Name")
                    $pl = $null
                    $pageLayouts | ForEach-Object {
                        if ($_.Name -eq $layoutName)
                        {
                            Write-Host "found $pageLayoutName page layout"
                            $pl = $_;
                        }
                    }

                    if ($pl -ne $null)
                    {
                        $avaipageLayouts[$index] = $pl
                        $index = $index + 1
                    }
                }

                $PubWeb.SetAvailablePageLayouts($avaipageLayouts, $True)
                $PubWeb.Update()
                sleep 30
                $NewWebObject = Get-SPWeb $webUrl
                $publishingWebObject = [Microsoft.SharePoint.Publishing.PublishingWeb]::GetPublishingWeb($NewWebObject)
			    foreach ($layout in $webPath.Layouts.ChildNodes)
                {
                    $layoutName = $layout.getattribute("Name")
                    $pageLayout = $null
                    if ($layout.Pages -ne $null)
                    {
                        foreach ($page in $layout.Pages.ChildNodes)
                        {
                                $pageUrl = $page.getattribute("Url")
                                $pageTitle = $page.getattribute("Title")
                                $clear = $page.getattribute("ClearAllWebParts")
                                $pages = $PubWeb.GetPublishingPages($PubWeb)
                       
                                $url=$webUrl+"/Pages/"+ $PageUrl
                                $pl = $publishingWebObject.GetAvailablePageLayouts() | Where { $_.Name -eq $layoutName }

                                # delete pages and recreate if exists
                                $pages = $pubWeb.GetPublishingPages($pubWeb)
                                $pages | ForEach-Object {
                                    if($_.Name -eq $PageUrl)
                                    {
                                        $_.ListItem.Delete();
                                    }
                                }
                                if($pl -ne $null)
                                {
                                    $newpage= $PubWeb.AddPublishingPage($PageUrl, $pl)
                                    $newpage.Title = $pageTitle
                                    $newpage.Update();
                                }
                                else
                                {
                                    write-host "Page layout: $layoutName is not available" 
                                }

                                # Check in the page if not checked out already
                                if ($newpage.ListItem.File.CheckOutType -ne "None")
                                {
                                    $newpage.CheckIn("Page Check in from script, Page Name:$newpage.Title")    
                                }						    

                                # Publish the page if not published already
                                if($newpage.ListItem.File.Level -ne "Published")
                                {
						             $file = $newpage.ListItem.File
						             $file.Publish("Published successfully")
                                }
                           

                                write-host $url(" is  Created.!")
                         }
                    }
                }
            }
        }
    }
}

CreatePages
CreateSearchPages

Write-Host  "Create Pages - Completed "
write-log $date "message"  "Create Pages - Completed "  "GlobalCall" "CreatePages"
