<#Copyright � 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>

#�����-Write log Function ���������������
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
	$dpo = $dp0

    #$dpo = $(get-location)
    echo $dpo
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    echo $index
    $logloc="$dpo".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)


#�����-PowerShell Addin ���������������
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "SetupManagedProperties"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "SetupManagedProperties"



#add sharepoint cmdlets
Write-Host  "Setup Crawl and Managed properties- Started "
write-log $date "message"  "Setup Crawl and Managed properties- Started"  "GlobalCall" "SetupManagedProperties"

$logMsg=("Parameters passed: SearchServiceApplicationName -"+$SearchServiceApplicationName)
write-log $date "message"  $logMsg  "GlobalCall" "ContentSourceSetup"


 #----------------Get the xml file---------------------------------------------------------------
 write-log $date "message"  "Getting Input xml path"   "GlobalCall" "ContentSourceSetup"
$InputFileName= "$dp0\SetupManagedProperties.xml"
 write-log $date "message"  ("Input xml path got :" + $InputFileName)   "GlobalCall" "SetupManagedProperties"
  $xml = [xml](Get-Content $InputFileName)
$SearchServiceApplicationName = $xml.SearchProperties.ssaName

#script reads from xml file to add crawled properties and managed properties
$ErrorActionPreference = "STOP"


#get the XML file
[System.Xml.XmlDocument] $XmlDoc = new-object System.Xml.XmlDocument
$file = resolve-path($InputFileName)
if (!$file)
{
    write-log $date "message"  "Could not find the configuration file specified."   "GlobalCall" "SetupManagedProperties"
    Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
    Break
}

write-log $date "message"  ("Parsing file: " + $file)   "GlobalCall" "SetupManagedProperties"
$XmlDoc = [xml](Get-Content $file)

#get the node containing the name of the search service application where you want to add properties

try
{
if (!$SearchServiceApplicationName) {Throw "Search Service Application Name not specified"}
$searchapp = Get-SPEnterpriseSearchServiceApplication $SearchServiceApplicationName
if (!$searchapp) {Throw "Cant connect to the Search Service Application"}

write-log $date "message"  "Starting... Loop through crawled properties to check or add"   "GlobalCall" "SetupManagedProperties"
Write-Host "Starting... Loop through crawled properties to check or add"
#loop through crawled properties to check or add -- don't add if it already exists
ForEach ($CrawledPropNode in $XmlDoc.SearchProperties.CrawledProperties.CrawledProperty){

try
{
    $SPCrawlProp = $CrawledPropNode.Name
    if (!$SPCrawlProp) {Throw "Crawled Property Name Missing"}
	$SPCrawlPropType = $CrawledPropNode.Type
	if (!$SPCrawlPropType) {Throw "Crawled Property Type Missing"}
    $SPCrawlPropSet = $CrawledPropNode.Propset
	if (!$SPCrawlPropSet) {Throw "Crawled Property Propset Missing"}
	$SPCrawlCategory = $CrawledPropNode.Category
	if (!$SPCrawlCategory) {$SPCrawlCategory="SharePoint"}

    #Create Crawled Property if it doesn't exist   
	If (!(Get-SPEnterpriseSearchMetadataCrawledProperty -SearchApplication $searchapp -Name $SPCrawlProp -Category $SPCrawlCategory -EA 0)) {
		
write-log $date "message"  ("Adding Crawl Property"+ $SPCrawlProp+" of type "+$SPCrawlPropType)   "GlobalCall" "SetupManagedProperties"
Write-Host "Adding Crawl Property" $SPCrawlProp " of type " $SPCrawlPropType
		New-SPEnterpriseSearchMetadataCrawledProperty -SearchApplication $searchapp -Category $SPCrawlCategory -Name $SPCrawlProp -IsNameEnum $false -PropSet $SPCrawlPropSet -VariantType 0 -IsMappedToContents $false | Out-Null
    } Else {
		$message = "Crawl Property " + $SPCrawlCategory + ":" + $SPCrawlProp + " already exists"
		write-log $date "message"  $message   "GlobalCall" "SetupManagedProperties"
Write-Host "Crawl Property " $SPCrawlCategory ":" $SPCrawlProp " already exists"
	}
}
 catch
{
   write-log $date "error" $_.Exception.Message ("On CreateCrawledProperties"+$CrawledPropNode.Name) "SetupManagedProperties"
}
}

write-log $date "message"  "Completed... Loop through crawled properties to check or add"   "GlobalCall" "SetupManagedProperties"
Write-Host "Completed... Loop through crawled properties to check or add"

write-log $date "message"  "Starting... Loop through Managed properties to check and add"   "GlobalCall" "SetupManagedProperties"
Write-Host "Starting... Loop through Managed properties to check and add" 
#now that the crawled properties exist, loop through managed properties and add
ForEach ($ManagedProperty in $XmlDoc.SearchProperties.ManagedProperties.ManagedProperty){
try
{
    $SharePointProp = $ManagedProperty.Name
    $SharePointPropType = $ManagedProperty.Type
	
	$SharePointPropSearchable = $ManagedProperty.Searchable
	$SharePointPropQueryable = $ManagedProperty.Queryable
	$SharePointPropRetrievabale = $ManagedProperty.Retrievabale
	$SharePointPropMultiple = $ManagedProperty.Multiple
	$SharePointPropRefinable = $ManagedProperty.Refinable
	$SharePointPropSortable = $ManagedProperty.Sortable
	$SharePointPropRespectPriority = $ManagedProperty.RespectPriority

	#remove it if it already exists
write-log $date "message"  ("Remove"+ $SharePointProp+" 'Managed Properties' if it already exists")   "GlobalCall" "SetupManagedProperties"
    if ($mp = Get-SPEnterpriseSearchMetadataManagedProperty -SearchApplication $searchapp -Identity $SharePointProp -EA 0){
        $mp.DeleteAllMappings()
        $mp.Delete()
        $searchapp.Update()
    }
	
    switch ($SharePointPropType){  
        "Text" {$type = 1}
        "Integer" {$type = 2}
        "Decimal" {$type = 3}
        "DateTime" {$type = 4}
        "YesNo" {$type = 5}
        "Binary" {$type = 6}
    }
	write-log $date "message"  ("Adding Managed Property"+ $SharePointProp+" of type "+$SharePointPropType)   "GlobalCall" "SetupManagedProperties"
    Write-Host "Adding Managed Property" $SharePointProp " of type " $SharePointPropType
    $mp = New-SPEnterpriseSearchMetadataManagedProperty -SearchApplication $searchapp -Name $SharePointProp -Type $type 
	If ($SharePointPropSearchable.ToUpper() -eq "YES") {
		$mp.Searchable = $true
	} Else {
		$mp.Searchable = $false
	}
	
	if(!$SharePointPropRespectPriority){
		$SharePointPropRespectPriority = "NO"
	}
	If ($SharePointPropRespectPriority.ToUpper() -eq "YES") {
		$mp.RespectPriority = $true
	} Else {
		$mp.RespectPriority = $false
	}
	

	If ($SharePointPropQueryable.ToUpper() -eq "YES") {
		$mp.Queryable = $true
	} Else {
		$mp.Queryable = $false
	}

	If ($SharePointPropRetrievabale.ToUpper() -eq "YES") {
		$mp.Retrievable = $true
	} Else {
		$mp.Retrievable = $false
	}
	
	If ($SharePointPropMultiple.ToUpper() -eq "YES") {
		$mp.HasMultipleValues = $true
	} Else {
		$mp.HasMultipleValues = $false
	}

	If ($SharePointPropRefinable.ToUpper() -eq "YES") {
		$mp.Refinable = $true
		$mp.RefinerConfiguration.Type = "Deep"
	} ElseIf ($SharePointPropRefinable.ToUpper() -eq "LATENT") {
		$mp.Refinable = $true
		$mp.RefinerConfiguration.Type = "Latent"
	} Else {
		$mp.Refinable = $false
	}
	
	If ($SharePointPropSortable.ToUpper() -eq "YES") {
		$mp.Sortable = $true
		$mp.SortableType = "Enabled"
	} ElseIf ($SharePointPropRefinable.ToUpper() -eq "LATENT") {
		$mp.Sortable = $true
		$mp.SortableType = "Latent"
	} Else {
		$mp.Sortable = $false
	}
	$mp.Update()

 write-log $date "message"  ("Add multiple crawled property mappings to '"+ $SharePointProp+"' of type "+$SharePointPropType +" successfully")   "GlobalCall" "SetupManagedProperties"
    #add multiple crawled property mappings
    ForEach ($CrawledProperty in $ManagedProperty.CrawledProperty){
		$SPMapCat = $CrawledProperty.Category
		$SPMapName = $CrawledProperty.InnerText
		$PropSet = ($XmlDoc.SearchProperties.CrawledProperties.CrawledProperty | ? {$_.Name -eq $SPMapName}).PropSet
		
		$cat = Get-SPEnterpriseSearchMetadataCategory -SearchApplication $searchapp -Identity $SPMapCat
		$prop = Get-SPEnterpriseSearchMetadataCrawledProperty -SearchApplication $searchapp -Category $cat -Name $SPMapName | ? { $_.Propset.ToString().Equals($PropSet) }
		New-SPEnterpriseSearchMetadataMapping -SearchApplication $searchapp -CrawledProperty $prop -ManagedProperty $mp | Out-Null
    }

    write-log $date "message"  ("Added Managed Property"+ $SharePointProp+" of type "+$SharePointPropType +" successfully")   "GlobalCall" "SetupManagedProperties"
   Write-Host "Added Managed Property" $SharePointProp " of type " $SharePointPropType " successfully"
}
 catch
{
   write-log $date "error" $_.Exception.Message ("On CreateManagedProperties"+$ManagedProperty.Name) "SetupManagedProperties"
}
}
}
 catch
{
   write-log $date "error" $_.Exception.Message "GlobalCall" "SetupManagedProperties"
}

Write-Host  "Setup Crawl and Managed properties- Completed "
write-log $date "message"  "Setup Crawl and Managed properties- Completed"  "GlobalCall" "SetupManagedProperties"

