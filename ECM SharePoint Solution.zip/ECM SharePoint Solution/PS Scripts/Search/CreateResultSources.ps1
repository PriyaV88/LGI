<#Copyright � 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    $logloc="$dpo".Substring(0,$index)
    
    $EventMesages = $EventMesage -replace ",", "."

    $LogFilePath = "$dp0\ScriptExecLogs.csv"   

    Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#�����-PowerShell Addin ���������������
if ((Get-PSSnapin "Microsoft.SharePoint.PowerShell" -ErrorAction SilentlyContinue) -eq $null) {
    Add-PSSnapin "Microsoft.SharePoint.PowerShell"
}
write-log $date "message"  "PowerShell Snapin added successfully"   "CreateResultSources" "CreateResultSources"

 #----------------Get the xml file---------------------------------------------------------------
 write-log $date "message"  "Getting Input xml path"   "CreateResultSources" "CreateResultSources"
$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
$dpo = $dp0
$file = resolve-path("$dp0\CreateResultSources.XML")

if (!$file)
{
    write-log $date "message"  "Could not find the configuration file specified."   "CreateResultSources" "CreateResultSources"
    Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
    Break
}

[string]$ConfigFile = $("$dp0\CreateResultSources.XML")
Write-Host $ConfigFile
[xml]$eFileViewXML = Get-Content ($ConfigFile)
write-log $date "message"  ("Input xml path got :" + "$dp0\CreateResultSources.xml")    "CreateResultSources" "CreateResultSources"

function CreateResultSources
{
    $searchApplicationName = $eFileViewXML.SearchProperties.ssaName
	$ssa = Get-SPEnterpriseSearchServiceApplication $searchApplicationName
	$fedman = New-Object Microsoft.Office.Server.Search.Administration.Query.FederationManager($ssa)
	  
	$searchOwner = Get-SPEnterpriseSearchOwner -Level Ssa  
	
	foreach ($resultNode in $eFileViewXML.SearchProperties.Sources.Source)
	{
		$resultSourceName = $resultNode.Name
		$qT = $resultNode.Query
		$resultSource = $fedman.GetSourceByName($resultSourceName, $searchOwner)
		if (!$resultSource)
		{
			Write-Host "Result source does not exist. Creating."
			$resultSource = $fedman.CreateSource($searchOwner)
		}
		else { Write-Host "Using existing result source." }
        $queryProperties = New-Object Microsoft.Office.Server.Search.Query.Rules.QueryTransformProperties
		$resultSource.Name = $resultSourceName
		$resultSource.ProviderId = $fedman.ListProviders()['Local SharePoint Provider'].Id
		$resultSource.CreateQueryTransform($queryProperties,$qT)
		$resultSource.Commit()
	}
}

CreateResultSources