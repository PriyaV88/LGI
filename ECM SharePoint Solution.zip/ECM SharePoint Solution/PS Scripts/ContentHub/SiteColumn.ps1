﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
 #—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    echo $dp0
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    echo $index
    $logloc="$dp0".Substring(0,$index)
    echo $logloc
    $EventMesages = $EventMesage -replace ",", "."
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}
  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "SiteColumn"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "SiteColumn"

#add sharepoint cmdlets
Write-Host  "SiteColumn Creation - Started"
write-log $date "message"  "SiteColumn Creation - Started"  "GlobalCall" "SiteColumn"
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

  #—————-CreateSiteColumns Function ———————————————
function CreateSiteColumns($SiteCollectionUrl)
{
try
{
 $xmlFile = "$dp0\SiteColumnList.xml"
 $xml = [xml](Get-Content $xmlFile)
 $CTHUrl = $xml.SiteColumns.Columns.url
 if (!$xmlFile)
{
    write-log $date "message"  ("Could not find the configuration file specified -" +$xmlFile)  "CreateSiteColumns" "SiteColumn"
    Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
    Break
}
  $s = [xml](Get-Content $xmlFile)
   write-log $date "message"  ("Input xml path got :" + $xmlFile)   "GlobalCall" "CTHSiteSetup"
$siteColl = Get-SPSite -Identity $CTHUrl
        if (!$siteColl) 
        {
            write-log $date "site doesnot exist $CTHUrl"  "Create Site Columns"   "CreateSiteColumns" "SiteColumn"
            #Throw ($CTHUrl+" - Site does not exists.")
        }
$rootWeb = $siteColl.RootWeb
$s.SiteColumns.Columns.Field | ForEach-Object{
$FieldName = $_.Name
try
{
    if($rootWeb.Fields[$FieldName] -ne $null)
    #if($rootWeb.Fields.GetField($FieldName) -ne $null)
            {
        #$column = $rootWeb.Fields.GetField($FieldName)
		$column = $rootWeb.Fields[$FieldName]
        $column.AllowDeletion = “true”
        $column.Update()
        $rootWeb.Fields.Delete($column)
        $rootWeb.Update()
 write-log $date "message"  ("Deleted existing site column :" + $FieldName)   "CreateSiteColumns" "SiteColumn"
        Write-Host "Deleted existing site column :" $FieldName -ForegroundColor Yellow
}
    if ($rootWeb.Fields[$FieldName] -eq $null)
            {
            write-log $date "message"  ("Adding site column :" + $FieldName)   "CreateSiteColumns" "SiteColumn"
        Write-Host "Adding site column :" $FieldName -ForegroundColor DarkCyan
            $fieldName =$_.Name
          $fieldXMLString = $_.OuterXml.ToString()
                $rootWeb.Fields.AddFieldAsXml($fieldXMLString)
                 if($_.Type -eq 'TaxonomyFieldType')
                {
                 $sspid = $_.sspId
                    $termSetiD = $_.termSetId
                $taxField = [Microsoft.SharePoint.Taxonomy.TaxonomyField]$rootWeb.Fields.GetField($fieldName);
                $taxField.Update();
                $taxField.SspId =  [GUID]($sspid);
                $taxField.TermSetId =  [GUID]($termSetiD);
                $taxField.Update();
                }
                write-log $date "message"  ("Successfully added site column :" + $FieldName)   "CreateSiteColumns" "SiteColumn"
				Write-Host "Successfully added site column :" $FieldName -ForegroundColor Green
               }
 }
 catch
 {
 write-log $date "Error" $_.Exception.Message ("CreateSiteColumn :"+$FieldName) "SiteColumn"
 }
 }
  }
 catch
 {
 write-log $date "Error" $_.Exception.Message "CreateSiteColumns" "SiteColumn"
 }
 }
CreateSiteColumns $CTHurl

Write-Host  "SiteColumn Creation - Completed"
write-log $date "message"  "SiteColumn Creation - Completed"  "GlobalCall" "SiteColumn"
