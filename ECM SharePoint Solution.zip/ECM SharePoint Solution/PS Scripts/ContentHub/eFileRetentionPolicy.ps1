﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    echo $dp0
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    echo $index
    $logloc="$dp0".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

#—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "SetupManagedProperties"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "SetupManagedProperties"

#add sharepoint cmdlets
Write-Host  "RM Policy Creation - Started"
write-log $date "message"  "RM Policy Creation - Started"  "GlobalCall" "eFileRetenationPolicy"
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

Function MainCall()
{
    $DATE = get-date 
    echo $FilePath
    $logFileCreated = $True
    $ErrorActionPreference = "Stop"
    try
    {
        [string]$ConfigFile = $("$dp0\eFileRMPolicyInputFile.xml")
        [Xml]$xml=Get-Content ($ConfigFile)
        foreach ($Sites in $xml.RMPolicies.policies)
        {
            $web = Get-SPWeb $Sites.url
            foreach( $Policy in $Sites.policy)
            {
                $ContentTypeName = $Policy.ct
                $action=$Policy.action
                $Shedule=""
                if ($action -ne "Delete") 
                {
                    $Shedule=$Policy.InnerXML
                }

                echo $ContentTypeName
                $contentType = $web.ContentTypes[$ContentTypeName]
                $contentType.ReadOnly = $false
                $contentType.Update()

                #DeletePolicy -contentType $contentType

                if ($action -ne "Delete")  
                { 
                    echo "creating policy"
                    CreatePolicy -contentType $contentType $Shedule
                    write-log $date "message"  "RM Policy Created on $ContentTypeName"  "MainCall" "eFileRetentionPolicy"
                    write-host "RM Policy Created on $ContentTypeName"
                }
                else 
                {
                    echo "deleting policy"
                    DeletePolicy -contentType $contentType
                    write-log $date "message"  "RM Policy Deleted on $ContentTypeName"  "MainCall" "eFileRetentionPolicy"
                    write-host "RM Policy Deleted on $ContentTypeName"
                }
            }
        }
    }
    catch
    {
        write-host "Error: Please check the log file"  -ForegroundColor Red   
    }
    echo "Finished!!!"
}

Function CreatePolicy($contentType,$Shedule)
{
    try
    {
        #[Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::CreatePolicy($contentType, $null);
        $newPolicy = [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::GetPolicy($contentType); 
        if ($newPolicy -ne $null)
        {
            $newPolicy.Items.Delete("Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration")
            $newPolicy.Update();
            $newPolicy.Items.Add("Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration", $Shedule);
        }
        else
        {
            [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::CreatePolicy($contentType, $null);
            $newPolicy = [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::GetPolicy($contentType); 
            $newPolicy.Items.Add("Microsoft.Office.RecordsManagement.PolicyFeatures.Expiration", $Shedule);
        }

        $newPolicy.Update(); 
    }
    catch
    {
        #echo "Error Message"
        #$ErrorActionPreference = "SilentlyContinue"
        #echo "Done"
        write-host "Error: Please check the log file"  -ForegroundColor Red  
    }
}

Function DeletePolicy($contentType)
{
    try
    {
        if($contentType)
        {
            [Microsoft.Office.RecordsManagement.InformationPolicy.Policy]::DeletePolicy($contentType);
            echo "Deleted!!!"
        }
    }
    catch
    {
        write-host "Error: Please check the log file"  -ForegroundColor Red  
    }
}

MainCall

Write-Host  "RM Policy Creation - Completed"
write-log $date "message"  "RM Policy Creation - Completed"  "GlobalCall" "eFileRetenationPolicy"