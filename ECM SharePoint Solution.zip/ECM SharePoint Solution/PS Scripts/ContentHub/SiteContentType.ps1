﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dp0 = $(get-location)
    echo $dp0
    $date = get-date
    $index= "$dp0".LastIndexOf("\")
    echo $index
    $logloc="$dp0".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}
 #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "SiteColumn"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "SiteColumn"


#add sharepoint cmdlets
Write-Host  "ContentType Creation - Started"
write-log $date "message"  " ContentType Creation - Started"  "GlobalCall" "SiteContentType"
$dp0 =  [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)

$xmlFileContent = "$dp0\SiteContentInput.xml"
$s = [xml](Get-Content $xmlFileContent)
$CTHurl = $s.ContentTypes.url

 #—————-CreateContentType Function ———————————————
function createContentType()
{
    try
    {
        $site = Get-SPSite -Identity $CTHurl
        if (!$site) {Throw ($CTHurl+" - Site does not exists.")} 
        $xmlFileContent = "$dp0\SiteContentInput.xml"
        if (!$xmlFileContent)
        {
            write-log $date "message"  ("Could not find the configuration file specified -" +$xmlFile)  "createContentType" "SiteContentType"
            Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
            Break
        }
        $content = [xml](Get-Content $xmlFileContent)
        $web = $site.RootWeb
        $content.ContentTypes.ContentType | ForEach-Object{
        try
        {

            $contentTypeName = $_.Name
            $oldCT = $web.ContentTypes[$contentTypeName]
            if($oldCT)
            {
                write-log $date "message" ( $contentTypeName +" - CT exists") "createContentType" "SiteContentType"
                Write-Host "Content type" $contentTypeName "exists" -ForegroundColor Cyan
                if ($oldCT) 
                {
                    $ctusage = [Microsoft.SharePoint.SPContentTypeUsage]::GetUsages($oldCT)
                    foreach ($ctuse in $ctusage) {
                        $list = $web.GetList($ctuse.Url)
                        $contentTypeCollection = $list.ContentTypes;
                        $contentTypeCollection.Delete($contentTypeCollection[$ContentType].Id); 
                    }

                    #Unpublish
                    $contentTypePublisher.UnPublish($oldCT)
                    write-log $date "message" ( "Unpublished existing CT :"+$contentTypeName) "createContentType" "SiteContentType"
                    Write-Host "Unpublished existing Content Type:" $contentTypeName -ForegroundColor DarkGreen

                    if ($oldCT.ReadOnly -eq $true)
                    {
                        $oldCT.ReadOnly = $false
                        $oldCT.Update()
                    }

                    $oldCT.Delete()
                    $web.update()
                    write-log $date "message" ( "Deleted existing CT :"+$contentTypeName) "createContentType" "SiteContentType"

                    Write-Host "Deleted existing Content Type:" $contentTypeName -ForegroundColor Green
                }
            }

        write-log $date "message" ( "Creating CT :"+$contentTypeName) "createContentType" "SiteContentType"
        Write-Host "Creating Content Type :" $contentTypeName
        $ctypeParent = $web.AvailableContentTypes[$_.ParentType]
        $spContentType = New-Object Microsoft.SharePoint.SPContentType($ctypeParent, $web.ContentTypes, $contentTypeName)
        
        #Create Content Type on the site and update Content Type object
        $spContentType.Group = $_.Group
        Write-Host "Adding content type to site"
        $web.ContentTypes.Add($spContentType)
        $web.update()
        $ct=$web.ContentTypes[$spContentType.Name]; 
        if (!$ct) {Throw ($spContentType.Name+" - CT does not exists to add fields.")}
        write-log $date "message" ( "Adding fields to CT :"+$contentTypeName) "createContentType" "SiteContentType"
        Write-Host "Adding fields to CT :" $contentTypeName
        $_.Fields.Field | ForEach-Object{       
        try
        {
           # $fieldAdd=$web.Fields[$_.Name]
           # Changed code to get field by Internal name
            $fieldAdd=$web.Fields.GetFieldByInternalName($_.Name)
            Write-Host $fieldAdd
            $fieldLink = new-Object Microsoft.SharePoint.SPFieldLink($fieldAdd)
            $ct.FieldLinks.Add($fieldLink);
            $ct.Update()
           
            write-log $date "message" ( "Added field to CT :"+$_.Name) "createContentType" "SiteContentType"
            Write-Host "Added field to Content Type :" $_.Name
        }
        catch
        {
             write-log $date "error" $_.Exception.Message ("on"+$_.Name+": field creation") "createContentType" "SiteContentType"
        }
               
                         
      }
       if($contentTypeName.StartsWith("eFileDS"))
         
            {
                $xmlFile1  =  "$dp0\SharedColumns.xml"
                $col = [xml](Get-Content $xmlFile1)
                $sharedcol=$col.SiteColumns.Columns.Field.Name
                 $FieldName = $_.Name         
                    $myCT=$web.ContentTypes[$contentTypeName]
                    $sharedFileXMLPrefix=”<sf:SharedFields xmlns:sf='http://schemas.microsoft.com/office/documentsets/sharedfields' LastModified='1/1/2014 3:31:50 PM'>"
                    $sharedFileXML=""
                    $sharedFileXMLSuffix="</sf:SharedFields>”

                  
                       $sharedcol | ForEach {
                       Write-Host $_
                     #  $id=$myCT.Fields[$_].Id
                     # Changed code to get field by Internal name
                      $id=$myCT.Fields.GetFieldByInternalName($_).Id


                        $sharedFileXML=$sharedFileXML+"<sharedField id='"+$id+"' />"
                            Write-Host $sharedFileXML
                          
                        }
                    #$id = [Microsoft.SharePoint.Taxonomy.TaxonomyField]$rootWeb.Fields.GetField($FieldName);
                    #$FieldName.Split(" ") | ForEach {
                      
               # }

                $FinalValue=$sharedFileXMLPrefix+$sharedFileXML+ $sharedFileXMLSuffix
                Write-Host $FinalValue
                $oXMLDocument=New-Object System.XML.XMLDocument
                $ns = New-Object Xml.XmlNamespaceManager $oXMLDocument.NameTable
                $ns.AddNamespace( "NamespaceURI", "http://schemas.microsoft.com/office/documentsets/sharedfields" )
                $oXMLDocument.LoadXML($FinalValue);
                Write-Host $oXMLDocument.ToString();
                $myCT.XmlDocuments.Delete("http://schemas.microsoft.com/office/documentsets/sharedfields");
                $myCT.XmlDocuments.Add($oXMLDocument);



                $AllowedCTName=$col.SiteColumns.Columns.AllowedCT
                    Write-Host $AllowedCTName
                    $AllowedCT=$web.ContentTypes[$AllowedCTName]
                    $AllowedCTXMLPrefix=”<act:AllowedContentTypes xmlns:act='http://schemas.microsoft.com/office/documentsets/allowedcontenttypes' LastModified='1/1/2014 08:00:00 AM'>"
                    $AllowedCTXML=""
                    $AllowedCTXMLSuffix="</act:AllowedContentTypes>”
                
                       $AllowedCTid=$AllowedCT.Id
                        $AllowedCTXML=$AllowedCTXML+"<AllowedContentType id='"+$AllowedCTid+"' />"
                            Write-Host $AllowedCTXML
                          

                    #$id = [Microsoft.SharePoint.Taxonomy.TaxonomyField]$rootWeb.Fields.GetField($FieldName);
                    #$FieldName.Split(" ") | ForEach {
                      
               # }

                $AllowedCTFinalValue=$AllowedCTXMLPrefix+$AllowedCTXML+ $AllowedCTXMLSuffix
                Write-Host $AllowedCTFinalValue
                $AllowedCTXML=New-Object System.XML.XMLDocument
                $ns1 = New-Object Xml.XmlNamespaceManager $AllowedCTXML.NameTable
                $ns1.AddNamespace( "NamespaceURI", "http://schemas.microsoft.com/office/documentsets/allowedcontenttypes" )
                $AllowedCTXML.LoadXML($AllowedCTFinalValue);
                Write-Host $AllowedCTFinalValue.ToString();
                $myCT.XmlDocuments.Delete("http://schemas.microsoft.com/office/documentsets/allowedcontenttypes");
                $myCT.XmlDocuments.Add($AllowedCTFinalValue);




                $myCT.Update();
           }
    }
    catch
    {
    write-log $date "error" $_.Exception.Message "createcontentTYpefunc" "Creating-ContentTYpe"
    
    }
    

    $web.Dispose()
    $site.Dispose()

  }
}
             catch
             {
             write-log $date "error" $_.Exception.Message "createContentType" "SiteContentType"
             }
}



createContentType $CTHurl

Write-Host  "ContentType Creation - Completed"
write-log $date "message"  " ContentType Creation - Completed"  "GlobalCall" "SiteContentType"