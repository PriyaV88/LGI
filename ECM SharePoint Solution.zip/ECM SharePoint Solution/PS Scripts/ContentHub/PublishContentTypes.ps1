﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
#—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    $logloc="$dpo".Substring(0,$index)    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

Write-Host  "Publish Content Type in CT Hub - Started "
write-log $date "message"  "Publish Content Type in CT Hub - Started "  "GlobalCall" "PublishContentTypes"

$logMsg=("Parameters passed: MMSName -"+$MMSName+"CTHUrl-"+$CTHUrl+" Group-"+$Group)
write-log $date "message"  $logMsg  "GlobalCall" "ContentSourceSetup"

  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "PublishContentTypes"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "PublishContentTypes"
$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
$dpo = $dp0
$xmlFile = "$dp0\ContentTypeMapping.xml"
$xml = [xml](Get-Content $xmlFile)
$CTHurl = $xml.ecm.Url.urlname
$Group = $xml.ecm.Url.Group
$MMSName =$xml.ecm.Url.MMSName

function Publish-ContentTypeHub {
       
    $site = Get-SPSite $CTHUrl
    try
    {
        if(!($site -eq $null))
        {
            write-log $date "message" ("Setting CT Hub url:"+$CTHUrl+" to MMS:"+$MMSName)  "Publish-ContentTypeHub" "PublishContentTypes"
            Write-Host "Setting CT Hub url:" $CTHUrl" to MMS:" $MMSName -ForegroundColor Yellow

            Set-SPMetadataServiceApplication -Identity $MMSName -HubURI $CTHUrl
    
            write-log $date "message" ("Setting "+$MMSName+ " properties to true")  "Publish-ContentTypeHub" "PublishContentTypes"
            Write-Host "Setting " $MMSName " properties to true" -ForegroundColor Yellow
                # Get Metadata service application proxy 
            $metadataserviceapplicationproxy = get-spmetadataserviceapplicationproxy  $MMSName
            if(!$metadataserviceapplicationproxy){Throw ($MMSName+ " - MMS does not exists.")}

            # This service application is the default storage location for Keywords.
            $metadataserviceapplicationproxy.Properties["IsDefaultKeywordTaxonomy"] = $true

            # This service application is the default storage location for column specific term sets.
            $metadataserviceapplicationproxy.Properties["IsDefaultSiteCollectionTaxonomy"] = $true

            # Consumes content types from the Content Type Gallery
            $metadataserviceapplicationproxy.Properties["IsNPContentTypeSyndicationEnabled"] = $true

            # Push-down Content Type Publishing updates from the Content Type Gallery
            # to sub-sites and lists using the content type.
            $metadataserviceapplicationproxy.Properties["IsContentTypePushdownEnabled"] = $true

            $metadataserviceapplicationproxy.Update() 


            write-log $date "message" "Loop through CT to publish"  "Publish-ContentTypeHub" "PublishContentTypes"
            write-Host "Efile Manager Content Types publishing started" -ForegroundColor Yellow

            $contentTypePublisher = New-Object Microsoft.SharePoint.Taxonomy.ContentTypeSync.ContentTypePublisher ($site)

            if ($xml.ecm.Url.ContentTypes -ne $null -and $xml.ecm.Url.ContentTypes.ChildNodes.Count -gt 0)
            {
                foreach ($ctXml in $xml.ecm.Url.ContentTypes.ContentType)
                {
                    $contentType = $site.RootWeb.ContentTypes[$ctXml.Name]
                    if ($contentType -ne $null)
                    {
                        $contentTypePublisher.Publish($contentType)
                        $message = $contentType.Name + "has been republished"
                        write-log $date "message" $message "Publish-ContentTypeHub" "PublishContentTypeHub"
                        Write-Host $contentType.Name "has been republished" -ForegroundColor Green
                    }
                    else
                    {
                       Write-Host "A content type with name:-" $ctXml.Name "was not found. Skipping..." -ForegroundColor Cyan
                    }
                }
            }
            else
            {
                $site.RootWeb.ContentTypes | ? {$_.Group -match $Group} | % {
                    $contentTypePublisher.Publish($_)
                    $message=$_.Name + "has been republished"
                    write-log $date "message" $message "Publish-ContentTypeHub" "PublishContentTypeHub"
                    Write-Host $_.Name "has been republished" -ForegroundColor Green
                }
            }
            write-Host "Efile Manager Content Types publishing completed" -ForegroundColor Magenta
        }
        else
        {
            Throw ($CTHUrl+ " - site does notexists.")
        }
     }
    catch
    {
        write-log $date "Error" $_.Exception.Message "Publish-ContentTypeHub" "PublishContentTypeHub"
    }   
}
    

Publish-ContentTypeHub $MMSName $CTHurl $Group

#add sharepoint cmdlets
Write-Host  "Publish Content Type in CT Hub - Completed "
write-log $date "message"  "Publish Content Type in CT Hub - Completed "  "GlobalCall" "PublishContentTypes"


