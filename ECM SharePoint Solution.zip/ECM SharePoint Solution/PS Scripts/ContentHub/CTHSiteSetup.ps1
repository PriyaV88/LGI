﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
  #—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    echo $dpo
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    echo $index
    $logloc="$dpo".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}


#add sharepoint cmdlets
Write-Host  "CT Hub SiteSetup- Started"
write-log $date "message"  "CT Hub SiteSetup- Started"  "GlobalCall" "CTHSiteSetup"

  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "CTHSiteSetup"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"   "GlobalCall" "CTHSiteSetup"




Start-SPAssignment –Global

#----------------Get the xml file---------------------------------------------------------------
 write-log $date "message"  "Getting Input xml path"   "GlobalCall" "CTHSiteSetup"
$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
$dpo = $dp0
$xmlFile = "$dp0\CTHSiteSetup.xml"
if (!$xmlFile)
{
    write-log $date "message"  ("Could not find the configuration file specified -" +$xmlFile)  "GlobalCall" "CTHSiteSetup"
    Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
    Break
}


#constants
$docLibListTemplate = [Microsoft.SharePoint.SPListTemplateType]::DocumentLibrary
$contentHubUrl=""

#Main stsadm -o provisionservice -action start -servicetype spwebservice
Write-Host "Loading XML"
    
$xml = [xml](Get-Content $xmlFile)
 write-log $date "message"  ("Input xml path got :" + $xmlFile)   "GlobalCall" "CTHSiteSetup"
    
$urlWebApplication =  $xml.Webapplication.Url 
 
 #functions
 function EnsureManagedPaths($urlWebApplication, $xml) {
try
{
    $managedPaths = Get-SPManagedPath -WebApplication $urlWebApplication
     if (!$managedPaths) {
      Write-Host ("Cannot find web application '" + $urlWebApplication + "'") -ForegroundColor Red
     Throw ($urlWebApplication+" - Cannot find web application.")}

	
	$pathInclusionType = @{}
	$pathExists = @{}
	foreach ($xmlPath in $xml.Webapplication.ManagedPaths.Path) {
        if ($xmlPath.Name -ne '/')
        {
		    $pathInclusionType.Add($xmlPath.Name, $xmlPath.Type)
		    $pathExists.Add($xmlPath.Name, $false)
        }
	}
	
	foreach ($managedPath in $managedPaths) {
		if ($pathExists.ContainsKey($managedPath.Name)) {
            $pathExists[$managedPath.Name] = $true
		}
	}
	
    $i = 0
	foreach ($managedPath in $pathExists.Keys) {
		if (!$pathExists[$managedPath]) {
			$newPathCmd = "New-SPManagedPath $managedPath -WebApplication $($urlWebApplication)"
			if ($pathInclusionType[$managedPath] -eq "ExplicitInclusion") {
				$newPathCmd += " -Explicit"
			}
			Invoke-Expression $newPathCmd
			$i++
		}
	}
 write-log $date "message"  ($i.ToString() + " managed paths created")  "EnsureManagedPaths" "ProductSiteSetup"
    }
catch
{
   write-log $date "error" $_.Exception.Message "EnsureManagedPaths" "ProductSiteSetup"
}
}

function CreateSiteCollection(){

foreach ($managedPath in $xml.Webapplication.ManagedPaths.Path) {
		foreach ($siteDef in $managedPath.SiteCollection) {
try
{
			$url = $urlWebApplication
			if (![string]::IsNullOrEmpty($managedPath.Name)) {
				$url += $managedPath.Name 
                $sitePath = $managedPath.Name 
			}
            else
            {
	            $url += "sites"
                $sitePath = "sites"
            }
			
            if ($managedPath.Type -ne "ExplicitInclusion") {
				$url += "/" + $sitedef.Name
                $sitePath+= "/" + $sitedef.Name
			}
			
            $url = $url.TrimEnd("/")
			Write-Host "Checking if SPSite exists at $url"
			
 write-log $date "message"  ("check if SPSite exists, url-" + $url)   "CreateSiteCollection" "CTHSiteSetup"
			# check if SPSite exists already
			$site = Get-SPSite $url -erroraction silentlycontinue
			if ($? -and $site -ne $null) {
 Throw ($(($siteDef).Name)+ "already exists. Skipping...")
			}
			else
			{
			 write-log $date "message"  ("Creating new SPSite, url-" + $url)   "CreateSiteCollection" "CTHSiteSetup"
		    Write-Host "Creating new SPSite, url-" $url
				
				$commandsb = New-Object System.Text.StringBuilder(256)
				[void]$commandsb.Append("`$site = New-SPSite")
				$params = @{" -Url " = '"' + $url + '"';
							" -Name " = '"' + $siteDef.Title + '"';
							" -Description " = '"' + $siteDef.Description + '"';						
							" -Template " ='"'+ $siteDef.WebTemplate+'"';
							" -OwnerAlias " = '"'+$siteDef.PrimaryOwner.ID+'"';}
				foreach ($paramKey in $params.Keys) {
					if ([string]::IsNullOrEmpty($params[$paramKey])) {
						continue
					}
					[void]$commandsb.Append($paramKey)
					[void]$commandsb.Append($params[$paramKey])
				}
				Invoke-Expression $commandsb.ToString()
				
				if ($site -eq $null) {
write-log $date "message"  ("Site creation failed.-" + $url)   "CreateSiteCollection" "CTHSiteSetup"
					Write-Host "Site creation failed." -ForegroundColor Red
					continue
				}
				else
				{
write-log $date "message"  ("Site created successfully.Setting Master page. url-" + $url)   "CreateSiteCollection" "CTHSiteSetup"
Write-Host "Site created successfully.Setting Master page. url-" $url 
					if ($siteDef.WebTemplate -eq "CMSPUBLISHING#0") {
						$w = Get-SPWeb $url
						$w | select Url,ClientTag,MasterUrl,CustomMasterUrl,UseV15Rendering
						$w.MasterUrl = $w.ServerRelativeUrl.TrimEnd("/") + "/_catalogs/masterpage/seattle.master"
						
						$w.CustomMasterUrl = $w.ServerRelativeUrl.TrimEnd("/") + "/_catalogs/masterpage/seattle.master"
						$w.Update()
					}
				}
				
			write-log $date "message"  "Enabling site collection features"   "CreateSiteCollection" "CTHSiteSetup"
            Write-Host "Enabling site collection features"
			foreach ($feature in $siteDef.Features.Feature) {
                if (![string]::IsNullOrEmpty($feature.Name)) {
                
				               
				                Enable-SPFeature -Identity $feature.Name -url $site.Url

                              
                }
			}
write-log $date "message"  "Enabling site collection features completed successfully"   "CreateSiteCollection" "CTHSiteSetup"
Write-Host "Enabling site collection features completed successfully"
          }
              }
     catch
{
   write-log $date "error" $_.Exception.Message "CreateSiteCollection" "CTHSiteSetup"
}
		}
    }

}


EnsureManagedPaths $urlWebApplication $xml
CreateSiteCollection


Stop-SPAssignment -Global

Write-Host  "CT Hub SiteSetup- Completed"
write-log $date "message"  "CT Hub SiteSetup- Completed"  "GlobalCall" "CTHSiteSetup"