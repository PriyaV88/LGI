﻿<#Copyright © 2015 Liberty Mutual Insurance Company. All rights reserved
Proprietary-Trade Secret Liberty Mutual Insurance Company#>
  #—————-Write log Function ———————————————
 Function write-log($date,$EventType,$EventMesage,$functionName,$Filename)
{   
    $dpo = $(get-location)
    echo $dpo
    $date = get-date
    $index= "$dpo".LastIndexOf("\")
    echo $index
    $logloc="$dpo".Substring(0,$index)
    echo $logloc
    
    
    
    $EventMesages = $EventMesage -replace ",", "."
	
     $LogFilePath = "$dp0\ScriptExecLogs.csv"
   # Write-Host $LogFilePath
    $EventMesages = $EventMesage -replace ",", "."
    
    if($EventType -eq $null){
        $EventType="Event type not Specified"
    }
    if($EventMesage -eq $null){
        $EventMessage = "NA"
    }
    if($Filename -eq $null){
        $Filename = "No File Provided"
    }
    if($functionName -eq $null){
        $functionName = "Function name not provided"
    }
    
    
    
    Add-content -Path  $LogFilePath -value  "$date,$EventType,$EventMesages,$functionName,$Filename"
}

Write-Host  "Content Type Hub Timer job - Started " -ForegroundColor Yellow
write-log $date "message"  "Run Timer job - Started "  "GlobalCall" "TimerJobs"


  #—————-PowerShell Addin ———————————————
write-log $date "message"  "Adding PowerShell Snapin"   "GlobalCall" "TimerJobs"
if ( (Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null )
{    
      Add-PsSnapin Microsoft.SharePoint.PowerShell
}
write-log $date "message"  "PowerShell Snapin added successfully"  "GlobalCall" "TimerJobs"

$dp0 = [System.IO.Path]::GetDirectoryName($MyInvocation.MyCommand.Definition)
$dpo = $dp0
$xmlFile  =  "$dp0\TimerJobs.xml"
if (!$xmlFile)
{
    write-log $date "message"  ("Could not find the configuration file specified -" +$xmlFile)  "GlobalCall" "TimerJobs"
    Write-Host "Could not find the configuration file specified. Using Default." -ForegroundColor red
    Break
}
$xml = [xml](Get-Content $xmlFile)

$WebAppUrl=$xml.ecm.WebAppUrl.Urlname
$Jobname1=$xml.ecm.WebAppUrl.JobName1.name
$Jobname2=$xml.ecm.WebAppUrl.JobName2.name

 
function StartJobOnWebApp($WebAppUrl,$Jobname)
{
    try
    {
        $WebApp = Get-SPWebApplication $WebAppUrl;
        if(!$WebApp){Throw( $WebAppUrl+" does not exists")}
        ##Getting right job for right web application
        ##$job = Get-SPTimerJob | ?{$_.Name -match $JobName} | ?{$_.Parent -eq $WebApp}
        write-log $date "message"  ("Starting job" +$JobName)  "StartJobOnWebApp" "TimerJobs"
        Write-Host "Starting job" $JobName "on" $WebAppUrl -ForegroundColor Yellow
        if($JobName -eq 'Content Type Hub')
        {
            $job = Get-SPTimerJob | ?{$_.Name -match "MetadataHubTimerJob"} 
        }
        else{
            $job = $WebApp.JobDefinitions | Where-Object { $_.Title -eq $JobName }
        }

        Write-Host $Job.Title
        if($job -ne $null)
        {
            $startet = $job.LastRunTime
            write-log $date "message"  ( "Running" +$job.DisplayName+"Timer Job.")  "StartJobOnWebApp" "TimerJobs"
            Write-Host  -NoNewLine "Running"$job.DisplayName"Timer Job." -ForegroundColor Yellow
            Start-SPTimerJob $job

            ##Waiting til job is finished
            while (($startet) -eq $job.LastRunTime)
            {
                Write-Host -NoNewLine -ForegroundColor Yellow "."
                Start-Sleep -Seconds 2
            }

            ##Checking for error messages, assuming there will be errormessage if job fails
            if ($job.ErrorMessage)
            {
                write-log $date "message"  ( "Possible error in"+ $job.DisplayName+ "timer job:")  "StartJobOnWebApp" "TimerJobs"
                Write-Host "Possible error in" $job.DisplayName "timer job:" -ForegroundColor Red
                Write-Host "LastRunTime:" $lastRun.Status;
                Write-Host "Errormessage:" $lastRun.EndTime;
            }
            else {
                write-log $date "message"  ( $job.DisplayName+"Timer Job has completed.")  "StartJobOnWebApp" "TimerJobs"
                Write-Host  $job.DisplayName "Timer Job has completed on" $WebAppUrl -ForegroundColor Green
            }
        }
        else {
            write-log $date "message"  ( "ERROR: Timer job"+ $job.DisplayName+ "on web application"+ $WebApp+ "not found.")  "StartJobOnWebApp" "TimerJobs"
            Write-Host "ERROR: Timer job" $job.DisplayName "on web application" $WebApp "not found." -ForegroundColor Red
        }
    }
    catch
    {
       write-log $date "error" $_.Exception.Message "StartJobOnWebApp" "TimerJobs"
    }  
}

StartJobOnWebApp -WebAppUrl $WebAppUrl -JobName $Jobname1
StartJobOnWebApp -WebAppUrl $WebAppUrl -JobName $Jobname2 

Write-Host  "Content Type Hub Timer job - Completed " -ForegroundColor Magenta
write-log $date "message"  "Run Timer job - Completed "  "GlobalCall" "TimerJobs"