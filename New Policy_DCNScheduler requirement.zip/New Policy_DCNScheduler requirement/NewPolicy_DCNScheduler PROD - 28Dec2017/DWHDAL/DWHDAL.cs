﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.IO;



namespace DWHDAL
{
    public class DWHDAL
    {
        //AppConfigHandler configurationHandler { get; set; }
        //string viewconn = ConfigurationManager.ConnectionStrings["ViewConnectionString"].ConnectionString;
        //string spefileconn = ConfigurationManager.ConnectionStrings["SPefileConenctionString"].ConnectionString;
        public string ViewConnectionString { get; set; }
        public string SPefileConenctionString { get; set; }

        public DWHDAL()
        {
            //ViewConnectionString = "Data Source=10.134.11.109,1643; Initial Catalog=LVGI_Staging; User id=EFILE; Password=Efile$123!";
            //SPefileConenctionString = "Data Source=IN-CLD-UDMS2\\SQL2012; Initial Catalog=LVGI_ECM_DB;Integrated Security=True";
            GetConnectionString();
        }

        public void GetConnectionString()
        {
            try
            {
                ViewConnectionString = ConfigurationManager.ConnectionStrings["ViewConnectionString"].ConnectionString;
                SPefileConenctionString = ConfigurationManager.ConnectionStrings["SPefileConenctionString"].ConnectionString;


            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        public EFileMapper GetEfileMetaData(string efileno)
        {

            EFileMapper eFiles = new EFileMapper();

            using (SqlConnection connection = new SqlConnection(ViewConnectionString))
            {
                DataTable table = new DataTable("EfileMetadata");

                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["ViewName"] + " with (NOLOCK) where PolicyNumber = '" + efileno + "' or CaseId = '" + efileno + "'";
                //string command = "SELECT * FROM VW_E_File where PolicyNumber = '201250020115101282300000'";

                var cmd = new SqlCommand(command, connection);
                cmd.CommandTimeout = 200;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                connection.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);
               
                //read data from DataTable 
                //using lamdaexpression
               
                eFiles = (from DataRow row in table.Rows

                          select new EFileMapper
                          {
                            // EndtNo = row["EndorsementNumber"].ToString(),
                              LOB = row["LOB"].ToString(),
                              Product = row["Product"].ToString(),
                              PolicyNo = row["PolicyNumber"].ToString(),
                              Country = row["Country"].ToString(),
                              InsuredName = row["InsuredName"].ToString(),
                              PolicyYear = row["PolicyYear"].ToString(),
                              PolicyInceptionDate = row["PolicyInceptionDate"].ToString(),
                              PolicyExpiryDate = row["PolicyExpiryDate"].ToString(),
                              UWStage = row["UWStage"].ToString(),
                              Company = row["Company"].ToString(),
                              BranchName = row["BranchName"].ToString(),
                              BranchCode = row["BranchCode"].ToString(),
                              QuoteNumber = row["QuoteNumber"].ToString(),
                              BatchNumber = row["BatchNumber"].ToString(),
                              Zone = row["Zone"].ToString(),
                              SourceSystemName = row["SourceSystemName"].ToString(),
                              CaseId = row["CaseId"].ToString(),
                              PreviousPolicyNumber = row["PreviousPolicyNumber"].ToString(),
                              Underwriter = row["Underwriter"].ToString(),
                              UnderwritingAssistant = row["UnderwritingAssistant"].ToString(),
                              MasterStatus = row["MasterStatus"].ToString(),
                              Function = row["Function"].ToString(),
                              RiskLocation = row["RiskLocation"].ToString(),
                              IsConfidential = row["IsConfidential"].ToString(),
                              eFileCategory = row["eFileCategory"].ToString(),
                              InsuredCode = row["InsuredCode"].ToString(),
                              IntermediaryName = row["IntermediaryName"].ToString(),
                              IntermediaryCode = row["IntermediaryCode"].ToString(),
                              SMName = row["SMName"].ToString(),
                              SMCode = row["SMCode"].ToString(),
                              EndtNo = row["EndorsementNumber"].ToString(),

                          }).FirstOrDefault();


            }
            return eFiles;
        }

        public EFileMapper GetPolicySharepointFileURL(string policyNumber,EFileMapper metaDataEfile)
        {
            EFileMapper eFilePath = new EFileMapper();
            using (SqlConnection conn = new SqlConnection(SPefileConenctionString))
            {
                DataTable table = new DataTable("SpEfileLocation");

                //string command = "SELECT * FROM uw_document_set where PolicyNumber = '" + PolicyNumber + "'";
                string command = "SELECT * FROM " + ConfigurationManager.AppSettings["TableName"] + " where policy_no  = '" + policyNumber + "' or case_id = '" + policyNumber + "'";
                //string command = "SELECT * FROM uw_document_set where policy_no =  'POL656565656'";

                var cmd = new SqlCommand(command, conn);
               // cmd.CommandTimeout = 200;
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                conn.Open();
                //Console.WriteLine("connection opened successfuly");
                adapt.Fill(table);
                eFilePath = (from DataRow row in table.Rows

                             select new EFileMapper
                             {
                                 policy_no = row["policy_no"].ToString(),
                                 site_collection_url = row["site_collection_url"].ToString(),
                                 doc_lib_name = row["doc_lib_name"].ToString(),
                                 efile_name = row["efile_name"].ToString(),
                                 efile_Url = row["site_collection_url"].ToString() + row["doc_lib_name"].ToString() + "/" + row["efile_name"].ToString(),
                             }).FirstOrDefault();

            }

            if (eFilePath != null)
            {

                metaDataEfile.policy_no = eFilePath.policy_no;
                metaDataEfile.site_collection_url = eFilePath.site_collection_url;
                metaDataEfile.doc_lib_name = eFilePath.doc_lib_name;
                metaDataEfile.efile_name = eFilePath.efile_name;
                metaDataEfile.efile_Url = eFilePath.efile_Url;


            }
            else
            { 
            
            }


            return metaDataEfile;
        }


    }

}