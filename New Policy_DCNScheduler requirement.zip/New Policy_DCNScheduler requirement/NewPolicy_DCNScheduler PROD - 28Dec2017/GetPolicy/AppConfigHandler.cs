﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Web;
using System.Data;
using System.Configuration;
using System.Xml;
using System.Reflection;

namespace SchedulerForPolicyorDcnData
{
    public class AppConfigHandler
    {  
            // read values from app.config file
      public string viewconn { get; set; }
      public string spefileconn { get; set; }
      public string startdate { get; set; }
      public string enddate { get; set; }
      public string sharedrivepath { get; set; }
      public string ftpuserid { get; set; }
      public string ftppwd { get; set; }
      public string viewname { get; set; }
      public string tablename { get; set; }
      public string logtable { get; set; }
      public string serviceuser { get; set; }
      public string servicepwd { get; set; }
      public string serviceurl { get; set; }
      public string allowfolderfromDB { get; set; }
      public string foldermonthname { get; set; }
      public string allowdatefromDB { get; set; }
      public string folderdatename { get; set; }
      public string completedfolderpath { get; set; }

 
        public AppConfigHandler()
      {
        try 
	        {
                 viewconn = ConfigurationManager.ConnectionStrings["ViewConnectionString"].ConnectionString;
                 spefileconn = ConfigurationManager.ConnectionStrings["SPefileConenctionString"].ConnectionString;
                 startdate = ConfigurationManager.AppSettings["StartDate"];
                 enddate = ConfigurationManager.AppSettings["EndDate"];
                 sharedrivepath = ConfigurationManager.AppSettings["SharedDrivePath"];
                 ftpuserid = ConfigurationManager.AppSettings["FTPuserid"];
                 ftppwd = ConfigurationManager.AppSettings["FTPpwd"];
                 viewname = ConfigurationManager.AppSettings["ViewName"];
                 tablename = ConfigurationManager.AppSettings["TableName"];
                 serviceuser = ConfigurationManager.AppSettings["ServiceUser"];
                 servicepwd = ConfigurationManager.AppSettings["ServicePwd"];
                 serviceurl = ConfigurationManager.AppSettings["ServiceUrl"];
                 logtable = ConfigurationManager.AppSettings["LogTableName"];
                 allowfolderfromDB = ConfigurationManager.AppSettings["AllowFolderfromDB"];
                 foldermonthname = ConfigurationManager.AppSettings["FolderMonthName"];
                 allowdatefromDB = ConfigurationManager.AppSettings["AllowDatefromDB"];
                 folderdatename = ConfigurationManager.AppSettings["FolderDateName"];
                 completedfolderpath = ConfigurationManager.AppSettings["CompletedFolderPath"];
	        }
	   catch (Exception ex)
	        {
		
		        throw ex;
	        }
     

      }


      public void UpdateValuesAppConfig(string Key, string value)
      {
          try
          {
              Configuration config = ConfigurationManager.OpenExeConfiguration(Assembly.GetEntryAssembly().Location); 

            //  System.Configuration.Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

              config.AppSettings.Settings[Key].Value =value;
              config.AppSettings.SectionInformation.ForceSave = true;
              config.Save(ConfigurationSaveMode.Modified);
              ConfigurationManager.RefreshSection(config.AppSettings.SectionInformation.Name);
              }
          catch (Exception ex)
          {

              throw ex;
          }


      }

    }

    
}
