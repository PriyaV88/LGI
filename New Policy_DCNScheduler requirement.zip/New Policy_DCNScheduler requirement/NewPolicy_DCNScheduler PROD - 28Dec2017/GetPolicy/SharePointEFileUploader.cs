﻿using DWHDAL;
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace SchedulerForPolicyorDcnData
{
    public static class SharePointEFileUploader
    {
        /// <summary>
        /// Upload file into Document Set
        /// </summary>
        /// <param name="list">List Title</param>
        /// <param name="docSetName">DocumentSet Name</param>
        /// <param name="fileName">File name to upload</param>

        public static void UploadFileIntoDocumentSet(AppConfigHandler configurationHandler, EFileMapper metaDataEfile, string sharedocfilepath, string policyfileName)
        {
            try
            {
                // LogHelper.LogFileWrite("Log : Info : Inside method UploadFileIntoDocumentSet");
                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                PolicyDocument objClaimDoc = new PolicyDocument();
                //LogHelper.LogFileWrite("Log : Info : fetching Site_colection_url....");
                using (var ctx = new ClientContext(metaDataEfile.site_collection_url))
                {
                    //  LogHelper.LogFileWrite("Log : Info : fetching doc_lib_name....");
                    var list = ctx.Web.Lists.GetByTitle(metaDataEfile.doc_lib_name);

                    ctx.Load(list.RootFolder);
                    ctx.ExecuteQuery();
                    //get stream using FTP Connector
                    using (var fs = new FileStream(sharedocfilepath, FileMode.Open, FileAccess.Read))
                    {
                        ctx.ExecuteQuery();

                        var fileUrl = string.Empty;
                        policyfileName = policyfileName.Replace("&", "and");
                            fileUrl = String.Format("{0}/{1}/{2}", list.RootFolder.ServerRelativeUrl, metaDataEfile.efile_name, policyfileName);

                        ctx.ExecuteQuery();
                        Microsoft.SharePoint.Client.File.SaveBinaryDirect(ctx, fileUrl, fs, true);
                        Microsoft.SharePoint.Client.File file = ctx.Web.GetFileByServerRelativeUrl(fileUrl);
                        file.ListItemAllFields["EFeFileDocumentGroup"] = "Policy Documentation";
                        file.ListItemAllFields["EFDocumentStatus"] = "Final";
                        file.ListItemAllFields["EFDocumentTitle"] = policyfileName.Split('.')[0];
                        file.ListItemAllFields["EFeFileDocumentType"] = "Quotes/Proposals";
                        file.ListItemAllFields["EndorsementNumber"] = "000";
                       // file.ListItemAllFields["ClaimNumber"] = metaDataEfile.ClaimIntNo;
                        file.ListItemAllFields.Update();
                        file.CheckIn("", CheckinType.MajorCheckIn);
                        ctx.Load(file);
                        try
                        {
                            ctx.ExecuteQuery();
                            PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Uploading done successfully...");
                        }
                        catch (Exception ex)
                        {
                            PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Error while uploading files:" + ex.Message);
                            throw ex;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Log : Info : Uploading failed for PolicyNumber#.. " + metaDataEfile.PolicyNo + "  with shareddocfilepath# - " + sharedocfilepath);
                throw ex;
            }
        }

        // check Document set exixts on sharepoint or not 

        public static void CreateNewEFile(AppConfigHandler configurationHandler, EFileMapper currentEfile,string pln)
        {

            HttpWebRequest req = null;
            HttpWebResponse res = null;

            try
            {
                //string url = t
                string url = configurationHandler.serviceurl;
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "url=" + url);
                req = (HttpWebRequest)WebRequest.Create(url);
                req.Method = "POST";
                req.ContentType = "application/xml; charset=utf-8";
                req.Timeout = 300000;
                req.PreAuthenticate = true;
                req.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd, "lvgi");
                
                DateTime PolicyInceptionDate;
                DateTime PolicyExpiryDate;
                
                PolicyInceptionDate = Convert.ToDateTime(currentEfile.PolicyInceptionDate);
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "PolicyInceptionDate= " + PolicyInceptionDate);
                PolicyExpiryDate = Convert.ToDateTime(currentEfile.PolicyExpiryDate);
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "PolicyExpiryDate= " + PolicyExpiryDate);
                string[] formats = { "MM/dd/yyyy" };
                if ((currentEfile.LOB == "Marine") || (currentEfile.LOB == "Marine Cargo"))
                {
                    currentEfile.LOB = "Marine_Cargo";
                }
                //if (currentEfile.LOB == "Miscellaneous")
                //{
                //    currentEfile.LOB = "Misc";
                //}
                if ((currentEfile.LOB == "Miscellaneous - Package") || (currentEfile.LOB == "Miscellaneous"))
                {
                    currentEfile.LOB = "Misc";
                }
                if (currentEfile.LOB == "Engineering")
                {
                    currentEfile.LOB = "ENGG";
                }
                if (currentEfile.LOB == "Personal Accident")
                {
                    currentEfile.LOB = "Personal_Accident";
                }
                if (currentEfile.Company.Trim() == string.Empty)
                {
                    currentEfile.Company = "LVGI";
                }
                if (currentEfile.Function.Trim() == string.Empty)
                {
                    currentEfile.Function = "uploadDocumentECM";
                }
                if (currentEfile.eFileCategory.Trim() == string.Empty)
                {
                    currentEfile.eFileCategory = "Policy";
                }
                if (currentEfile.RiskLocation.Trim() == string.Empty)
                {
                    currentEfile.RiskLocation = "India";
                }
                if (currentEfile.MasterStatus.Trim() == string.Empty)
                {
                    currentEfile.MasterStatus = "Intimated";
                }
                if (currentEfile.IntermediaryName.Length >= 35)
                {
                    currentEfile.IntermediaryName = currentEfile.IntermediaryName.Remove(34);
                }

                if (currentEfile.RiskLocation.Length >= 26)
                {
                    currentEfile.RiskLocation = currentEfile.RiskLocation.Remove(25);
                }
                if (currentEfile.PolicyYear == string.Empty || currentEfile.PolicyYear == "NULL")
                {
                    currentEfile.PolicyYear = Convert.ToDateTime(currentEfile.PolicyInceptionDate.ToString()).Year.ToString();
                }
               

                string sXml = @"<RequestData >
                  <EntityInformation Type='Underwriting'>
                  <MetadataProperties>
		          <MetadataProperty Name='LOB' Value='" + currentEfile.LOB + "' />" +
                  "<MetadataProperty Name='Product' Value='" + currentEfile.Product.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='PolicyNumber' Value='" + currentEfile.PolicyNo + "' />" +
                  "<MetadataProperty Name='Country' Value='" + currentEfile.Country + "' />" +
                  "<MetadataProperty Name='InsuredName' Value='" + currentEfile.InsuredName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='PolicyYear' Value='" + currentEfile.PolicyYear + "' />" +
                  "<MetadataProperty Name='UWStage' Value='" + currentEfile.UWStage + "' />" +
                 // "<MetadataProperty Name='PolicyInceptionDate' Value='01/29/2013' /> " +
                 //" <MetadataProperty Name='PolicyExpiryDate' Value= '08/31/2016' />" +
                  "<MetadataProperty Name='PolicyInceptionDate' Value='" + PolicyInceptionDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) + "' /> " +// MM/dd/yyyy 11/29/2015
                  "<MetadataProperty Name='PolicyExpiryDate' Value='" + PolicyExpiryDate.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture) + "' />" +
                  "<MetadataProperty Name='Company' Value='" + currentEfile.Company + "' />" +
                  "<MetadataProperty Name='BranchName' Value='" + currentEfile.BranchName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='BranchCode' Value='" + currentEfile.BranchCode + "' />" +
                  "<MetadataProperty Name='QuoteNumber' Value='" + currentEfile.QuoteNumber.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null) + "' />" +
                  "<MetadataProperty Name='BatchNumber' Value='" + currentEfile.BatchNumber.Replace("&", "and") + "' />" +
                  "<MetadataProperty Name='Zone' Value='" + currentEfile.Zone + "' />" +
                  "<MetadataProperty Name='SourceSystemName' Value='" + currentEfile.SourceSystemName + "' />" +
                  "<MetadataProperty Name='CaseId' Value='" + currentEfile.CaseId + "' />" +
                  "<MetadataProperty Name='PreviousPolicyNumber' Value='" + currentEfile.PreviousPolicyNumber + "' />" +
                  "<MetadataProperty Name='Underwriter' Value='" + currentEfile.Underwriter + "' />" +
                  "<MetadataProperty Name='UnderwritingAssistant' Value='" + currentEfile.UnderwritingAssistant + "' />" +
                  "<MetadataProperty Name='MasterStatus' Value='" + currentEfile.MasterStatus + "' />" +
                  "<MetadataProperty Name='Function' Value='" + currentEfile.Function.Replace("&", "and") + "' />" +
                  "<MetadataProperty Name='RiskLocation' Value='" + currentEfile.RiskLocation.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='IsConfidential' Value='" + currentEfile.IsConfidential + "' />" +
                  "<MetadataProperty Name='eFileCategory' Value='" + currentEfile.eFileCategory + "' />" +
                  "<MetadataProperty Name='InsuredCode' Value='" + currentEfile.InsuredCode + "' />" +
                  "<MetadataProperty Name='IntermediaryName' Value='" + currentEfile.IntermediaryName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("'", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='IntermediaryCode' Value='" + currentEfile.IntermediaryCode + "' />" +
                  "<MetadataProperty Name='SMName' Value='" + currentEfile.SMName.Replace(".", null).Replace("&", "and").Replace("~", null).Replace("@", null).Replace("#", null).Replace("`", null).Replace(":", null).Replace("(", null).Replace(")", null).TrimEnd() + "' />" +
                  "<MetadataProperty Name='SMCode' Value='" + currentEfile.SMCode + "' />" +
                  "</MetadataProperties >" +
                  "</EntityInformation>" +
                  "</RequestData>";
               
                req.ContentLength = sXml.Length;
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Efile request data: " + sXml);
                var sw = new StreamWriter(req.GetRequestStream());
                sw.Write(sXml);
                sw.Close();

                //ServiceReference1.DocumentManagementServiceClient obj = new ServiceReference1.DocumentManagementServiceClient();
                //obj.CreateOrUpdateEfile();


                res = (HttpWebResponse)req.GetResponse();
                Stream responseStream = res.GetResponseStream();
                var streamReader = new StreamReader(responseStream);

                //Read the response into an xml document
                var soapResonseXmlDocument = new XmlDocument();
                soapResonseXmlDocument.LoadXml(streamReader.ReadToEnd());

                //return only the xml representing the response details (inner request)
                string successString = soapResonseXmlDocument.InnerXml;
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Info : Successstring" + successString);
            }
            catch (Exception ex)
            {
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Error while creating efile:" + ex.Message);
                throw ex;  
            }

            string error = "Error in creating new efile";
            PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, currentEfile.PolicyFTPPath, configurationHandler, error);
        }

    }
}
