﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchedulerForPolicyorDcnData
{
    public class PolicyDocument
    {
        private string policyfilename;
        private string policyfilepath;

        public string PolicyFileName
        {
            get
            {
                return policyfilename;
            }
            set
            {
                policyfilename = value;
            }
        }

        public string PolicyFilePath
        {
            get
            {
                return policyfilepath;
            }
            set
            {
                policyfilepath = value;
            }
        }
    }
}
