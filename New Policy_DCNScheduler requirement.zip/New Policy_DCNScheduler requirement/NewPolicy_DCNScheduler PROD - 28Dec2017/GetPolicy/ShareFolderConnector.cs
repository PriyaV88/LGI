﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Collections;
using System.Net;
using System.Configuration;
using System.Globalization;
using DWHDAL;


namespace SchedulerForPolicyorDcnData
{

    public class ShareFolderConnector
    {
        DWHDAL.DWHDAL newDAL = new DWHDAL.DWHDAL();
        public AppConfigHandler configurationHandler = new AppConfigHandler();
        public List<PolicyDocument> todaysPolicyNumbers = new List<PolicyDocument>();



        public ShareFolderConnector(AppConfigHandler configHandler)
        {
            AppConfigHandler configurationHandler = configHandler;

            //SharedDrivePath = "ftp://10.134.10.52/PDF_File_Generated/GENERATED/";

        }

        /// <summary>
        /// NetworkCredential just to set the User and password of ftp path.
        /// </summary>
        public NetworkCredential CreateNetworkCredentials()
        {
            return new NetworkCredential(configurationHandler.ftpuserid, configurationHandler.ftppwd);
        }


        public string[] GetPolicyNumbersforMultipleDocs(AppConfigHandler configurationHandler, string multipath)
        {
            //LogHelper.LogFileWrite("Log : Info : Inside method GetClaimNumbers... ");
            List<string> PolicyToBeProcessed = new List<string>();
            try
            {

                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                string[] allFolders = System.IO.Directory.GetDirectories(configurationHandler.sharedrivepath + @"\\" + multipath);

                foreach (var newItem in allFolders)
                    {
                        string newfilepath = newItem + "\\";
                        string PolicyFolderName = Path.GetDirectoryName(newfilepath).Split('\\').LastOrDefault();
                        PolicyToBeProcessed.Add(PolicyFolderName);
                    }
                
               return PolicyToBeProcessed.ToArray();
                
            }
            catch (Exception ex)
            {
                // throw;
               // currentMonthFolder = currentmonthfolder;
              //  PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetPolicyNumbers:" + ex.Message);
                return null;
                
            }
            

        }
        
        public List<string> GetallfilesofCurrentFolder(string PolicyNumber,string CaseId)
        {
            try
            {
                List<string> alldocfiles = new List<string>();
                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;

                string newFolderpath = configurationHandler.sharedrivepath + @"\\Policy_multipleDocs";
                string[] getNewFolderDir = System.IO.Directory.GetDirectories(newFolderpath);
                var directoryExist = Directory.Exists(newFolderpath + "\\" + PolicyNumber);
                if (directoryExist)
                {
                    string[] allPolicyFolders = System.IO.Directory.GetDirectories(newFolderpath + "\\" + PolicyNumber);
                    string[] allfiles = System.IO.Directory.GetFiles(newFolderpath + "\\" + PolicyNumber);

                    foreach (var fileName in allfiles)
                    {
                        // checks if the file is hidden or not
                        //if hidden then excludes those files.
                        FileAttributes attributes = File.GetAttributes(fileName);
                        if ((attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //If the filename has an extension, then it actually is 
                            //a file and should be added to 'fnl'.            

                            if (fileName.IndexOf(".") > 0)
                            {
                                PolicyDocument objPolicyDoc = new PolicyDocument();
                                objPolicyDoc.PolicyFilePath = fileName + "\\";

                                //list.Add("file_name");
                                alldocfiles.Add(objPolicyDoc.PolicyFilePath);

                            }
                        }
                    }
                }
                else
                {
                    string[] allfiles = System.IO.Directory.GetFiles(newFolderpath + "\\" + CaseId);

                    foreach (var fileName in allfiles)
                    {
                        // checks if the file is hidden or not
                        //if hidden then excludes those files.
                        FileAttributes attributes = File.GetAttributes(fileName);
                        if ((attributes & FileAttributes.Hidden) != FileAttributes.Hidden)
                        {
                            //If the filename has an extension, then it actually is 
                            //a file and should be added to 'fnl'.            

                            if (fileName.IndexOf(".") > 0)
                            {
                                PolicyDocument objPolicyDoc = new PolicyDocument();
                                objPolicyDoc.PolicyFilePath = fileName + "\\";

                                //list.Add("file_name");
                                alldocfiles.Add(objPolicyDoc.PolicyFilePath);

                            }
                        }
                    }
                }

                   
                
                                return alldocfiles;
                            }


                   
            catch (Exception ex)
            {
                // throw;
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetallfilesofCurrentFolder:" + ex.Message);
                return null;
                //throw new Exception(" no files for " + configurationHandler.sharedrivepath + "\n");
            }
            return null;
        }

        public string[] GetPolicyNumbersforSingleDoc(AppConfigHandler configurationHandler, string singlepath)
        {
            //LogHelper.LogFileWrite("Log : Info : Inside method GetClaimNumbers... ");
            List<string> PolicyFilesToBeProcessed = new List<string>();
            try
            {

                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                string[] allFiles = System.IO.Directory.GetFiles(configurationHandler.sharedrivepath + @"\\" + singlepath);

                foreach (var newItem in allFiles)
                {
                    string newfilepath = newItem + "\\";
                    string lastFolderName = Path.GetDirectoryName(newfilepath).Split('\\').LastOrDefault();
                    string PolicyFileName = lastFolderName.Split(new char[] { '.' })[0];
                    PolicyFilesToBeProcessed.Add(PolicyFileName);
                }

                return PolicyFilesToBeProcessed.ToArray();

            }
            catch (Exception ex)
            {
                // throw;
                // currentMonthFolder = currentmonthfolder;
                //  PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Error in method GetPolicyNumbers:" + ex.Message);
                return null;

            }


        }

    }

}
