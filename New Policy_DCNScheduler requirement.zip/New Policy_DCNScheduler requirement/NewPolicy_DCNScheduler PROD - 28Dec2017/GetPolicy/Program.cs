﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using DWHDAL;
using System.Globalization;



namespace SchedulerForPolicyorDcnData
{
    public class Program
    {
        public static void Main(string[] args)
        {
            AppConfigHandler configurationHandler = new AppConfigHandler();

            
                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                DWHDAL.DWHDAL newDAL = new DWHDAL.DWHDAL();
                List<PolicyDocument> PolicyNumbers = new List<PolicyDocument>();
                //string[] multiDocPaths = { "DCN_multipleDocs", "Policy_multipleDocs" };
                //string[] singleDocPaths = { "DCN_singleDoc", "Policy_singleDoc" };
                
                // Day Scheduler
                //string[] multiDocPaths = { "DCN_multipleDocs" };
                //string[] singleDocPaths = { "DCN_singleDoc" };

                // Night Scheduler
                string[] multiDocPaths = { "Policy_multipleDocs" };
                string[] singleDocPaths = { "Policy_singleDoc" };
                foreach (var multiDocPath in multiDocPaths)
                {
                    string[] PolicyProcessed = newConnector.GetPolicyNumbersforMultipleDocs(newConnector.configurationHandler, multiDocPath);
                    PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + DateTime.Now);
                    PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + DateTime.Now);
                    PolicyOrDcnSchedulerEfileCountLogError.LogFileWrite(Environment.NewLine + DateTime.Now);
                    PolicyOrDcnSchedulerEfileCountLogError.LogFileWrite("Total files count = " + PolicyProcessed.Length.ToString() + "for path =" + multiDocPath);
                    #region for multipleDocs
                    int PCounter = 0;
                    int RCounter = 0;
                    //1. Metadata
                    if (PolicyProcessed != null && PolicyProcessed.Length > 0)
                    {
                        foreach (var item in PolicyProcessed)
                        {


                            try
                            {
                                PCounter++;
                                //Console.WriteLine(PCounter);
                                string currentEfileUrl = string.Empty;
                                EFileMapper eFilePath = new EFileMapper();
                                EFileMapper eFiles = new EFileMapper();
                                //1. Metadata

                                string efileno = item.ToString();

                                eFilePath = newDAL.GetEfileMetaData(efileno);
                                string pln;
                                if (efileno == eFilePath.PolicyNo)
                                {
                                    pln = eFilePath.PolicyNo;

                                }
                                else
                                { pln = eFilePath.CaseId; }

                                if (eFilePath == null)
                                {
                                    PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.PolicyFilePath);
                                    string error = "Policy Metadata not found";
                                    PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Policy Metadata not found" + efileno);
                                    PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);
                                }

                                else
                                {
                                    //2.SharePoint EFIle Path
                                    eFiles = newDAL.GetPolicySharepointFileURL(pln, eFilePath);

                                    if (eFiles != null)
                                    {
                                        //eFiles.ShareDrivePath = item.PolicyFilePath;
                                        if (string.IsNullOrEmpty(eFiles.site_collection_url))
                                        {
                                            try
                                            {
                                                SharePointEFileUploader.CreateNewEFile(newConnector.configurationHandler, eFiles, pln);
                                            }
                                            catch
                                            {
                                                PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                                string error = "Error in creating new efile";
                                                PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);
                                                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Error in creating new efile of PolicyNumber#" + pln);
                                            }
                                        }

                                        //4.newly created EFIle Path from step 3
                                        eFiles = newDAL.GetPolicySharepointFileURL(pln, eFiles);

                                        //5.if exist or new Upload Docs in doc set url from step 2
                                        try
                                        {
                                            //upload the file to efile 

                                            UploadMultipleDocsProcess(configurationHandler, eFiles, pln, multiDocPath);
                                            RCounter++;
                                            PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading Done.. PolicyDocument to sharepoint  #" + eFiles.ShareDrivePath + " with Policyno# - " + eFiles.PolicyNo);
                                        }
                                        catch (Exception ex)
                                        {
                                            //throw ex;
                                            PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                            string error = "Error in uploading document";
                                            PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);

                                        }

                                        PolicyOrDcnSchedulerEfileCountLogError.LogPolicyToDB(eFiles, configurationHandler, pln); //PDF pushed --> path including filename
                                        PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Info : Logging Done.. EFile Details to DWH  #" + PCounter + " Policy Document #" + eFiles.PolicyFileName);//how many folders processe


                                    }

                                    else
                                    {
                                        PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                        PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Info : Policy metadata not found From DWH #" + pln + PCounter);
                                        string error = "Metadata not found from DWH";
                                        PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);
                                    }


                                }


                            }
                            catch (Exception ex)
                            {
                                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Error : Processing Policy Documents  " + item + Environment.NewLine
                                             + ex.StackTrace);//how many folders processe
                              
                            }
                        }
                        PolicyOrDcnSchedulerEfileCountLogError.LogFileWrite("No. of files uploaded for path# " + multiDocPath + "=" + RCounter);
                    }
                    #endregion

                }

                foreach (var singleDocPath in singleDocPaths)
                {
                    string[] PolicyFilesProcessed = newConnector.GetPolicyNumbersforSingleDoc(newConnector.configurationHandler, singleDocPath);

                    PolicyOrDcnSchedulerEfileCountLogError.LogFileWrite("Total files count = " + PolicyFilesProcessed.Length.ToString() + "for path =" + singleDocPath);

                    #region for singleDoc
                    int ICounter = 0;
                    int SCounter = 0;
                    //1. Metadata
                    if (PolicyFilesProcessed != null && PolicyFilesProcessed.Length > 0)
                    {
                        foreach (var item in PolicyFilesProcessed)
                        {


                            try
                            {
                                ICounter++;
                                //Console.WriteLine(PCounter);
                                string currentEfileUrl = string.Empty;
                                EFileMapper eFilePath = new EFileMapper();
                                EFileMapper eFiles = new EFileMapper();
                                //1. Metadata

                                string efileno = item.ToString();


                                eFilePath = newDAL.GetEfileMetaData(efileno);
                                string pln;
                                if (efileno == eFilePath.PolicyNo)
                                {
                                    pln = eFilePath.PolicyNo;

                                }
                                else
                                { pln = eFilePath.CaseId; }

                                if (eFilePath == null)
                                {
                                    PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.PolicyFilePath);
                                    string error = "Policy Metadata not found";
                                    PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Policy Metadata not found" + efileno);
                                    PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(efileno, eFiles.ShareDrivePath, configurationHandler, error);
                                }

                                else
                                {
                                    //2.SharePoint EFIle Path
                                    eFiles = newDAL.GetPolicySharepointFileURL(pln, eFilePath);

                                    if (eFiles != null)
                                    {
                                        //eFiles.ShareDrivePath = item.PolicyFilePath;
                                        if (string.IsNullOrEmpty(eFiles.site_collection_url))
                                        {
                                            try
                                            {
                                                SharePointEFileUploader.CreateNewEFile(newConnector.configurationHandler, eFiles, pln);
                                            }
                                            catch
                                            {
                                                PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                                string error = "Error in creating new efile";
                                                PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);
                                                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Error in creating new efile of PolicyNumber#" + pln);
                                            }
                                        }

                                        //4.newly created EFIle Path from step 3
                                        eFiles = newDAL.GetPolicySharepointFileURL(pln, eFiles);

                                        //5.if exist or new Upload Docs in doc set url from step 2
                                        try
                                        {
                                            //upload the file to efile 

                                            UploadProcess(configurationHandler, eFiles, singleDocPath, pln);
                                            SCounter++;
                                            PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading Done.. PolicyDocument to sharepoint  #" + eFiles.ShareDrivePath + " with Policyno# - " + pln);
                                        }
                                        catch (Exception ex)
                                        {
                                            //throw ex;
                                            PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                            string error = "Error in uploading document";
                                            PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);

                                        }

                                        PolicyOrDcnSchedulerEfileCountLogError.LogPolicyToDB(eFiles, configurationHandler, pln); //PDF pushed --> path including filename
                                        PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Info : Logging Done.. EFile Details to DWH  #" + ICounter + " Policy Document #" + eFiles.PolicyFileName);//how many folders processe
                                    }

                                    else
                                    {
                                        PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                                        PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Info : Policy metadata not found From DWH #" + ICounter);
                                        string error = "Metadata not found from DWH";
                                        PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);
                                    }


                                }


                            }
                            catch (Exception ex)
                            {
                                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Error : Processing Policy Documents  " + item + Environment.NewLine
                                             + ex.StackTrace);//how many folders processe
                            }
                        }
                        PolicyOrDcnSchedulerEfileCountLogError.LogFileWrite("No. of files uploaded for path#" + singleDocPath + " = " + SCounter);
                    }
                    #endregion
                }

            //}
            //catch (Exception ex)
            //{
            //    PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Error : Processing Whole Policy Document " + Environment.NewLine
            //        + ex.StackTrace);
            //   // throw ex;
            //}
        }


        private static void UploadMultipleDocsProcess(AppConfigHandler configurationHandler, EFileMapper eFiles, string pln, string multipath)
        {
            UploadMultipleDocuments(configurationHandler, eFiles, pln, multipath);

        }
        private static void UploadMultipleDocuments(AppConfigHandler configurationHandler, EFileMapper eFiles, string pln, string multipath)
        {
            try
            {

                List<string> allDocfiles = new List<string>();
                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                string[] allFiles = System.IO.Directory.GetFiles(configurationHandler.sharedrivepath + @"\\" + multipath + "\\" + pln + "\\");
                //  allDocfiles = newConnector.GetallfilesofCurrentFolder(eFiles.PolicyNo,eFiles.CaseId);
                bool uploadSuccess = false;
                //string[] allPolicyFiles;
                List<string> allPolicyFiles = new List<string>();
                foreach (var docitem in allFiles)
                {
                    string sharedocfilepath = docitem + "\\";
                    string policyfileName = System.IO.Path.GetDirectoryName(sharedocfilepath).Split('\\').LastOrDefault();
                    sharedocfilepath = sharedocfilepath.TrimEnd('\\');

                //    allPolicyFiles.Add(policyfileName);
                    
                    try
                    {
                        SharePointEFileUploader.UploadFileIntoDocumentSet(configurationHandler, eFiles, sharedocfilepath, policyfileName);
                        uploadSuccess = true;
                        allPolicyFiles.Add(policyfileName);
                        // LogHelper.LogFileWrite("Log : Info : Uploading done for claimfilename#" + claimfileName + "with shareddocfilepath #" + sharedocfilepath);
                    }
                    catch (Exception ex)
                    {
                        //throw ex;
                        PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                        string error = "Error in uploading document";
                        PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(eFiles.PolicyNo, eFiles.ShareDrivePath, configurationHandler, error);
                    }
                   

                    eFiles.ShareDrivePath = sharedocfilepath;
                    PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading done for Policy# - " + pln + " with shareddocfilepath# - " + sharedocfilepath);
                  //  PolicyOrDcnSchedulerEfileCountLogError.LogPolicyToDB(eFiles, configurationHandler, pln);

                    //PDF pushed --> path including filename

                }
                if (uploadSuccess)
                {
                    string sourceLocation = configurationHandler.sharedrivepath + @"\\" + multipath;
                    string DestLocation = configurationHandler.sharedrivepath + @"\\Completed\\" + multipath + "_Completed";
                    //  string Dest = configurationHandler.completedfolderpath + @"\\Completed\\" + multipath + "_Completed";
                    foreach (var policyfileName in allPolicyFiles)
                    {
                        MoveMultipleFilesToCompletedDirectory(sourceLocation, DestLocation, pln, policyfileName);
                    }
                    
                    if (Directory.Exists(configurationHandler.sharedrivepath + @"\\" + multipath))
                    {
                        System.IO.DirectoryInfo extractdirectory = new DirectoryInfo(configurationHandler.sharedrivepath + @"\\" + multipath + "\\" + pln + "\\");

                        foreach (FileInfo file in extractdirectory.GetFiles())
                        {

                            if (allPolicyFiles.Contains(file.Name))
                            {
                                file.Delete(); 
                            }
                        }

                        // check if all files deleted

                        //foreach (DirectoryInfo dir in extractdirectory.GetDirectories())
                        //{
                        //        dir.Delete(true);
                        //}

                        if (System.IO.Directory.GetFiles(configurationHandler.sharedrivepath + @"\\" + multipath + "\\" + pln + "\\").Length == 0)
                        Directory.Delete(configurationHandler.sharedrivepath + @"\\" + multipath + "\\" + pln + "\\");
                    }
                }
               
            }

            catch (Exception ex)
            {
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Error : Uploading document " + Environment.NewLine
                          + ex.StackTrace);
            }
        }

        private static void UploadProcess(AppConfigHandler configurationHandler, EFileMapper eFiles, string singlepath, string pln)
        {
            UploadDocuments(configurationHandler, eFiles, singlepath, pln);

        }
        private static void UploadDocuments(AppConfigHandler configurationHandler, EFileMapper eFiles, string singlepath, string pln)
        {
            try
            {

                List<string> allDocfiles = new List<string>();
                ShareFolderConnector newConnector = new ShareFolderConnector(configurationHandler);
                WebRequest request = FileWebRequest.Create(configurationHandler.sharedrivepath);
                request.Credentials = new NetworkCredential(configurationHandler.serviceuser, configurationHandler.servicepwd);
                request.Proxy = null;
                request.PreAuthenticate = true;
                string[] allFiles = System.IO.Directory.GetFiles(configurationHandler.sharedrivepath + @"\\" + singlepath);

                foreach (var docitem in allFiles)
                {
                    string sharedocfilepath = docitem + "\\";
                    string policyfileName = System.IO.Path.GetDirectoryName(sharedocfilepath).Split('\\').LastOrDefault();
                    sharedocfilepath = sharedocfilepath.TrimEnd('\\');
                    string fileName = policyfileName.Split(new char[] { '.' })[0];
                    if (fileName == eFiles.PolicyNo || fileName == eFiles.CaseId)
                    {
                        bool uploadSuccess = false;
                        try
                        {
                            SharePointEFileUploader.UploadFileIntoDocumentSet(configurationHandler, eFiles, sharedocfilepath, policyfileName);
                            uploadSuccess = true;
                            // LogHelper.LogFileWrite("Log : Info : Uploading done for claimfilename#" + claimfileName + "with shareddocfilepath #" + sharedocfilepath);
                        }
                        catch (Exception ex)
                        {
                            //throw ex;
                            PolicyorDCNSchedulerDocsNotUploadedLog.LogFileWrite(Environment.NewLine + "Filepath:- " + eFiles.ShareDrivePath);
                            string error = "Error in uploading document";
                            PolicyOrDcnSchedulerEfileCountLogError.LogFailureErrorToDB(pln, eFiles.ShareDrivePath, configurationHandler, error);
                        }
                        if (uploadSuccess)
                        {
                            string sourceLocation = configurationHandler.sharedrivepath + @"\\" + singlepath;
                            string DestLocation = configurationHandler.sharedrivepath + @"\\Completed\\" + singlepath + "_Completed";
                            // string Dest = configurationHandler.completedfolderpath + @"\\Completed\\" + multipath + "_Completed";
                            MoveSingleFilesToCompletedDirectory(sourceLocation, DestLocation, policyfileName, sharedocfilepath);
                            if (Directory.Exists(configurationHandler.sharedrivepath + @"\\" + singlepath))
                            {
                                string DirfileName = policyfileName.Split(new char[] { '.' })[0];
                                System.IO.DirectoryInfo extractdirectory = new DirectoryInfo(configurationHandler.sharedrivepath + @"\\" + singlepath + "\\");

                                foreach (FileInfo file in extractdirectory.GetFiles())
                                {
                                    if (policyfileName == file.Name)
                                    {
                                        file.Delete();
                                    }
                                }

                            }
                        }

                        eFiles.ShareDrivePath = sharedocfilepath;
                        PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite(Environment.NewLine + "Log : Info : Uploading done for Policy# - " + pln + " with shareddocfilepath# - " + sharedocfilepath);
                       // PolicyOrDcnSchedulerEfileCountLogError.LogPolicyToDB(eFiles, configurationHandler, pln);
                        break;
                    }
                    //PDF pushed --> path including filename

                }

            }

            catch (Exception ex)
            {
                PolicyorDCNSchedulerMovePolicyDataLogError.LogFileWrite("Log : Error : Uploading document " + Environment.NewLine
                           + ex.StackTrace);
            }
        }
        public static void MoveSingleFilesToCompletedDirectory(string sourcePath, string targetPath, string policyfilename, string sharedocfilepath)
        {
            if (!System.IO.Directory.Exists(targetPath))
            {
                System.IO.Directory.CreateDirectory(targetPath);
            }
            string fileName = string.Empty;
            string destFile = string.Empty;
            destFile = System.IO.Path.Combine(targetPath + "//", policyfilename);
            System.IO.File.Copy(sharedocfilepath, destFile, true);
        }

        public static void MoveMultipleFilesToCompletedDirectory(string sourcePath, string targetPath, string pln, string policyfileName)
        {
            //To copy a folder's contents to a new location:
            //Create a new target folder, if necessary.
            if (!System.IO.Directory.Exists(targetPath + "//" + pln))
            {
                System.IO.Directory.CreateDirectory(targetPath + "//" + pln);
            }

            string fileName = string.Empty;
            string destFile = string.Empty;
            if (System.IO.Directory.Exists(sourcePath))
            {
                string[] files = System.IO.Directory.GetFiles(sourcePath + "\\" + pln + "\\");

                // Copy the files and overwrite destination files if they already exist.

                foreach (string s in files)
                {
                    //Use static Path methods to extract only the file name from the path.
                    fileName = System.IO.Path.GetFileName(s);
                    if (policyfileName == fileName)
                    {
                        destFile = System.IO.Path.Combine(targetPath + "//" + pln + "//", fileName);
                        System.IO.File.Copy(s, destFile, true); 
                    }
                }
            }
            else
            {
                Console.WriteLine("Source path does not exist!");
            }

        }

    }
}








