﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
//using Microsoft.Office.Interop.Excel;
//using System.Runtime.InteropServices;
using System.Web.Hosting;
using System.Web;

namespace GenericMailer
{
    class Program
    {
        static string XMLPath = string.Empty;
        static void Main(string[] args)
        {
          BLL_SendEmail objEMAIL = new BLL_SendEmail();
          string strErr = objEMAIL.RenewalEmailSend();
           
        }
    }
}
