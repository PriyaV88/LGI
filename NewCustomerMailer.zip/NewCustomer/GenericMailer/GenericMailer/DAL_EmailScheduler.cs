﻿using System;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace GenericMailer
{
    public class DAL_EmailScheduler
    {
        Common objCommon = new Common();
       
        public DataSet ConvertCSVtoDataTable()
        {
            DataTable dt = new DataTable();
            DataSet ds =new System.Data.DataSet();
            using (StreamReader sr = new StreamReader(System.Configuration.ConfigurationManager.AppSettings["FilePath"].ToString()))
            {
                string[] headers = sr.ReadLine().Split(',');
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }
                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    DataRow dr = dt.NewRow();
                    for (int i = 0; i < headers.Length; i++)
                    {
                        dr[i] = rows[i];
                    }
                    dt.Rows.Add(dr);
                }
            }
            //return dt;
            ds.Tables.Add(dt);
            return ds;
        }
    }
}
