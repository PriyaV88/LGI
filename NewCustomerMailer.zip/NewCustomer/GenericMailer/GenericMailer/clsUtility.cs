﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Xml;
using System.Xml.Linq;
using System.IO;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Net.Mime;
using HtmlAgilityPack;
namespace GenericMailer
{
    class clsUtility
    {
        static string XMLPath = string.Empty;
        string Template;
        string strMailHost;
        string liberty1;
        int strPort;
        string EmailFrom;
        string Subject;
        string DisplayName;
        string mailbody;
        string imagepath;
        public int sendMail(string strToEmail)
        {
            Common objCommon = new Common();
            System.IO.StreamReader sr;
            try
            {
                XMLPath = System.Configuration.ConfigurationManager.AppSettings["Xmlpath"].ToString();
                strMailHost = objCommon.GetMessage("//EmailConfig/MailHost", XMLPath);
                Template = objCommon.GetMessage("//EmailConfig/EmailTemplate", XMLPath);
                liberty1 = objCommon.GetMessage("//EmailConfig/EmailTemplate_liberty1", XMLPath);
                
                strPort = Convert.ToInt32(objCommon.GetMessage("//EmailConfig/Port", XMLPath));

                EmailFrom = objCommon.GetMessage("//EmailConfig/EmailFrom", XMLPath);
                Subject = string.Empty;
                Subject = objCommon.GetMessage("//EmailConfig/Subject", XMLPath);
                
                DisplayName = string.Empty;
                sr = new System.IO.StreamReader(Template);
                mailbody = sr.ReadToEnd();
                sr.Close();

                DisplayName = objCommon.GetMessage("//EmailConfig/DisplayName", XMLPath);

                System.Net.Mail.MailMessage emailmsg = new System.Net.Mail.MailMessage();
                emailmsg.From = new System.Net.Mail.MailAddress(EmailFrom, DisplayName);
                emailmsg.To.Add(strToEmail);//Uncomment for Production
                
                AlternateView plainView = AlternateView.CreateAlternateViewFromString(mailbody, null, "text/plain");
                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailbody, null, MediaTypeNames.Text.Html);
                
                LinkedResource Link_liberty1 = new LinkedResource(liberty1, MediaTypeNames.Image.Jpeg);//Jpeg
                Link_liberty1.ContentId = "images/banner1.jpg";
                htmlView.LinkedResources.Add(Link_liberty1);


                emailmsg.AlternateViews.Add(plainView);
                emailmsg.AlternateViews.Add(htmlView);
              
                emailmsg.Subject = Subject;
                emailmsg.IsBodyHtml = true;
                emailmsg.Priority = System.Net.Mail.MailPriority.Normal;
                emailmsg.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8");
                emailmsg.Body = mailbody;
                System.Net.Mail.SmtpClient cln = new System.Net.Mail.SmtpClient(strMailHost, strPort);
                cln.Credentials = new System.Net.NetworkCredential("onlinesales", "pass#1234");
                cln.Send(emailmsg);
                //objCommon.WriteLog("MailSend");
                return 0;
            }
            catch (Exception ex)
            {
                objCommon.WriteLog(strToEmail+" Generic Mailer Exception - MailSend : " + ex.Message.ToString());
                /*objEntity.Emails = strToEmail;
                objEntity.Status = "Failed";
                objEmailDAlScheduler.SaveSMSstatusDetails(objEntity);*/
                return 1;
            }
            finally
            {
                objCommon = null;
            }
        }

        public int sendMail_Manual(string strToEmail)
        {
            Common objCommon = new Common();
            System.IO.StreamReader sr;
            try
            {
                XMLPath = System.Configuration.ConfigurationManager.AppSettings["Xmlpath"].ToString();
                strMailHost = objCommon.GetMessage("//EmailConfig/MailHost", XMLPath);
                Template = objCommon.GetMessage("//EmailConfig/EmailTemplate", XMLPath);
                liberty1 = objCommon.GetMessage("//EmailConfig/EmailTemplate_liberty1", XMLPath);
                strPort = Convert.ToInt32(objCommon.GetMessage("//EmailConfig/Port", XMLPath));

                EmailFrom = objCommon.GetMessage("//EmailConfig/EmailFrom", XMLPath);
                Subject = string.Empty;
                Subject = objCommon.GetMessage("//EmailConfig/Subject", XMLPath);

                DisplayName = string.Empty;
                sr = new System.IO.StreamReader(Template);
                mailbody = sr.ReadToEnd();
                sr.Close();

                DisplayName = objCommon.GetMessage("//EmailConfig/DisplayName", XMLPath);

                System.Net.Mail.MailMessage emailmsg = new System.Net.Mail.MailMessage();
                emailmsg.From = new System.Net.Mail.MailAddress(EmailFrom, DisplayName);
                emailmsg.To.Add(strToEmail);//Uncomment for Production

                AlternateView plainView = AlternateView.CreateAlternateViewFromString(mailbody, null, "text/plain");
                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailbody, null, MediaTypeNames.Text.Html);
                LinkedResource Link_liberty1 = new LinkedResource(liberty1, MediaTypeNames.Image.Jpeg);
                Link_liberty1.ContentId = "liberty1";
                htmlView.LinkedResources.Add(Link_liberty1);

                emailmsg.AlternateViews.Add(plainView);
                emailmsg.AlternateViews.Add(htmlView);

                emailmsg.Subject = Subject;
                emailmsg.IsBodyHtml = true;
                emailmsg.Priority = System.Net.Mail.MailPriority.Normal;
                emailmsg.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8");
                emailmsg.Body = mailbody;
                System.Net.Mail.SmtpClient cln = new System.Net.Mail.SmtpClient(strMailHost, strPort);
                //cln.Credentials = new System.Net.NetworkCredential("onlinesales", "pass#1234");
                cln.Send(emailmsg);
                objCommon.WriteLog(emailmsg.To.ToString());
                objCommon.WriteLog(strToEmail+" MailSend");
                return 0;
            }
            catch (Exception ex)
            {
                objCommon.WriteLog(strToEmail + " Manual Generic Mailer Exception - MailSend : " + ex.Message.ToString());
                return 1;
            }
            finally
            {
                objCommon = null;
            }   
        }


        public void sendCompletionMail()
        {
            Common objCommon = new Common();
          
            try
            {
                XMLPath = System.Configuration.ConfigurationManager.AppSettings["Xmlpath"].ToString();
                strMailHost = objCommon.GetMessage("//EmailConfig/MailHost", XMLPath);
                strPort = Convert.ToInt32(objCommon.GetMessage("//EmailConfig/Port", XMLPath));
                EmailFrom = objCommon.GetMessage("//EmailConfig/EmailFrom", XMLPath);
                Subject = string.Empty;
                Subject = objCommon.GetMessage("//EmailConfig/Subject", XMLPath);
                DisplayName = string.Empty;
                mailbody = "Mailer Execution Successfully Completed";

                DisplayName = objCommon.GetMessage("//EmailConfig/DisplayName", XMLPath);

                System.Net.Mail.MailMessage emailmsg = new System.Net.Mail.MailMessage();
                emailmsg.From = new System.Net.Mail.MailAddress(EmailFrom, DisplayName);
                //emailmsg.To.Add(strToEmail);//Uncomment for Production

                /*comment for Production Start*/
                string EmailTo = objCommon.GetMessage("//EmailConfig/EmailTo", XMLPath);
                System.Net.Mail.MailAddress emailTo;
                string[] ToId = EmailTo.Split(',');

                if (EmailTo.Trim() != "")
                {
                    foreach (string ToEmail in ToId)
                    {
                        emailTo = new System.Net.Mail.MailAddress(ToEmail);
                        emailmsg.To.Add(emailTo);
                    }
                }
                /*comment for Production End*/

                emailmsg.Subject = Subject;
                emailmsg.IsBodyHtml = true;
                emailmsg.Priority = System.Net.Mail.MailPriority.Normal;
                emailmsg.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8");
                emailmsg.Body = mailbody;
                System.Net.Mail.SmtpClient cln = new System.Net.Mail.SmtpClient(strMailHost, strPort);
                cln.Credentials = new System.Net.NetworkCredential("onlinesales", "pass#1234");
                cln.Send(emailmsg);
                objCommon.WriteLog(" Completion Mailer Send");
            }
            catch (Exception ex)
            {
                objCommon.WriteLog(" Completion Mailer Exception - MailSend : " + ex.Message.ToString());
                /*objEntity.Emails = strToEmail;
                objEntity.Status = "Failed";
                objEmailDAlScheduler.SaveSMSstatusDetails(objEntity);*/
            }
            finally
            {
                objCommon = null;
            }
       
        }

        public int sendMail_Dynamic(string strToEmail)
        {
            Common objCommon = new Common();
            System.IO.StreamReader sr;
            try
            {
                XMLPath = System.Configuration.ConfigurationManager.AppSettings["Xmlpath"].ToString();
                strMailHost = objCommon.GetMessage("//EmailConfig/MailHost", XMLPath);
                Template = objCommon.GetMessage("//EmailConfig/EmailTemplate", XMLPath);
                strPort = Convert.ToInt32(objCommon.GetMessage("//EmailConfig/Port", XMLPath));
                imagepath = objCommon.GetMessage("//EmailConfig/ImagePath", XMLPath);

                EmailFrom = objCommon.GetMessage("//EmailConfig/EmailFrom", XMLPath);
                Subject = string.Empty;
                Subject = objCommon.GetMessage("//EmailConfig/Subject", XMLPath);

                DisplayName = string.Empty;
                sr = new System.IO.StreamReader(Template);
                mailbody = sr.ReadToEnd();
                sr.Close();

                DisplayName = objCommon.GetMessage("//EmailConfig/DisplayName", XMLPath);

                System.Net.Mail.MailMessage emailmsg = new System.Net.Mail.MailMessage();
                emailmsg.From = new System.Net.Mail.MailAddress(EmailFrom, DisplayName);
                emailmsg.To.Add(strToEmail);//Uncomment for Production

               
                string outputHtmlContent = string.Empty;
                string outputnode = string.Empty;
                var myResources = new List<LinkedResource>();

                if ((!string.IsNullOrEmpty(mailbody)))
                {
                    HtmlDocument doc = new HtmlDocument();
                    //doc.LoadHtml(data1);
                    //var doc = doc1;//new System.Windows.Forms.HtmlDocument;
                    doc.LoadHtml(mailbody);
                    HtmlNodeCollection nodes = doc.DocumentNode.SelectNodes("//img");
                    if (nodes != null)
                    {
                        foreach (HtmlNode node in nodes)
                        {
                            if (node.Attributes.Contains("src"))
                            {
                                string data = node.Attributes["src"].Value;
                                string data1 = data.Replace("cid:", "");
                                string imgPath = @imagepath + @data1;//System.Windows.Forms.Application.StartupPath +"//"+ @data; //System.Web.HttpContext.Current.Server.MapPath(data);
                                var imgLogo = new LinkedResource(imgPath);
                                imgLogo.ContentId = @data1;//Guid.NewGuid().ToString();
                                imgLogo.ContentType = new ContentType("image/jpeg");
                                myResources.Add(imgLogo);
                                //node.Attributes["src"].Value = string.Format("cid:{0}", imgLogo.ContentId);
                                //mailbody = mailbody.Replace(data, "cid:" + imgLogo.ContentId);
                                //outputnode = doc.DocumentNode.OuterHtml;
                                //outputHtmlContent = doc.DocumentNode.InnerHtml;//doc.DocumentNode.OuterHtml;
                            }
                        }
                    }
                }
                else
                {
                    outputHtmlContent = mailbody;
                }


                AlternateView plainView = AlternateView.CreateAlternateViewFromString(mailbody, null, "text/plain");
                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(mailbody, null, MediaTypeNames.Text.Html);//mailbody
                /*LinkedResource Link_liberty1 = new LinkedResource(liberty1, MediaTypeNames.Image.Jpeg);//Jpeg
                Link_liberty1.ContentId = "liberty1";
                htmlView.LinkedResources.Add(Link_liberty1);
                */

                foreach (LinkedResource linkedResource in myResources)
                {
                    htmlView.LinkedResources.Add(linkedResource);
                }

                emailmsg.AlternateViews.Add(plainView);
                emailmsg.AlternateViews.Add(htmlView);

                emailmsg.Subject = Subject;
                emailmsg.IsBodyHtml = true;
                emailmsg.Priority = System.Net.Mail.MailPriority.Normal;
                emailmsg.BodyEncoding = System.Text.Encoding.GetEncoding("utf-8");
                emailmsg.Body = mailbody;
                System.Net.Mail.SmtpClient cln = new System.Net.Mail.SmtpClient(strMailHost, strPort);
                cln.Credentials = new System.Net.NetworkCredential("onlinesales", "pass#1234");
                cln.Send(emailmsg);
                //objCommon.WriteLog("MailSend");
                return 0;
            }
            catch (Exception ex)
            {
                objCommon.WriteLog(strToEmail + " Generic Mailer Exception - MailSend : " + ex.Message.ToString());
                /*objEntity.Emails = strToEmail;
                objEntity.Status = "Failed";
                objEmailDAlScheduler.SaveSMSstatusDetails(objEntity);*/
                return 1;
            }
            finally
            {
                objCommon = null;
            }
        }

    }
}
