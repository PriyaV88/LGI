﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Threading;
namespace GenericMailer
{
    class BLL_SendEmail
    {
        DAL_EmailScheduler objEmailDAlScheduler = new DAL_EmailScheduler();
        EL_Scheduler objEntity;
        clsUtility objClsUtil = new clsUtility();
        Common objCommon = new Common();
        int i = 0;
        public string RenewalEmailSend()
        {
            DataSet ds;
            try
            {
                string str = "";
                ds = new DataSet();
                ds = objEmailDAlScheduler.ConvertCSVtoDataTable();

                if (ds.Tables.Count > 0)
                {
                    
                    if (ds.Tables[i].Rows.Count > 0)
                    {
                        objCommon.WriteLog("Total Data Count: " + ds.Tables[i].Rows.Count);
                        objCommon.WriteLog("------------------Email ID-------------");
                        for (int j = 0; j < ds.Tables[i].Rows.Count; j++)
                        {
                            objEntity = new EL_Scheduler();
                            try
                            {

                                objEntity.Emails = ds.Tables[i].Rows[j]["Email"].ToString().Trim();
                                
                                /*if(j%1000==0)
                                {
                                    Thread.Sleep(900000);
                                }*/

                                //int status=objClsUtil.sendMail(objEntity.Emails);
                                int status = objClsUtil.sendMail_Dynamic(objEntity.Emails);
                                if (status == 0)
                                {
                                    objEntity.Status = "Sent";
                                    //objEmailDAlScheduler.SaveSMSstatusDetails(objEntity);
                                }
                                else
                                {
                                    objEntity.Status = "Failed";
                                   // objEmailDAlScheduler.SaveSMSstatusDetails(objEntity);
                                }
                                objCommon.WriteLog(objEntity.Emails + "  " + objEntity.Status);
                            }
                            catch (Exception ex)
                            {
                                objCommon.WriteLog("Data Processed Exception: " + ex.Message);
                            }
                            finally
                            {
                                objEntity = null;
                            }
                        }
                        objCommon.WriteLog("Successfully Completed");
                        objClsUtil.sendCompletionMail();
                    }
                    else
                    {
                        objCommon.WriteLog("No Records Found");
                    }
                }
                else
                {
                    objCommon.WriteLog("No Tables Found");
                }

                return str;
            }
            catch (ThreadAbortException ex)
            {
                objCommon.WriteLog("ThreadAbortException: " + ex.Message);
                return "Error";
            }
            catch (Exception ex)
            {
                objCommon.WriteLog("SendMailException: " + ex.Message);
                return "Error";
            }
            finally
            {
                objCommon = null;
                objEmailDAlScheduler = null;
                ds = null;
            }
        }


    }
}
