﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericMailer
{
    public class EL_Scheduler
    {
        private string strEmail = "";
        private string str_val1 = "";
        private string str_val2 = "";
        private string str_val3 = "";
        private string str_val4 = "";
        private string str_val5 = "";
        private string str_val6 = "";
        private string status="";

        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
            }
        }

        public string Val1
        {
            get
            {
                return str_val1;
            }
            set
            {
                str_val1 = value;
            }
        }

       
        public string Val2
        {
            get
            {
                return str_val2;
            }
            set
            {
                str_val2 = value;
            }
        }

        public string Val3
        {
            get
            {
                return str_val3;
            }
            set
            {
                str_val4 = value;
            }
        }

        public string Val4
        {
            get
            {
                return str_val4;
            }
            set
            {
                str_val4 = value;
            }
        }

        public string Val5
        {
            get
            {
                return str_val5;
            }
            set
            {
                str_val5 = value;
            }
        }

        public string Val6
        {
            get
            {
                return str_val6;
            }
            set
            {
                str_val6 = value;
            }
        }


        public string Emails
        {
            get
            {
                return strEmail;
            }
            set
            {
                strEmail = value;
            }
        }

    }
}
